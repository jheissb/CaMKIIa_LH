function fsignal=notchfilterfd153(signal,frecs,nfbins);
%notchfilterfd(signal,frecs) performs notch filter in the frequency domain
%by doing linear interpolation of the values of the fft around 60 Hz and the armonics. 
%signal is the power spectrum, frecs is the vector of frecuencies for every point of the signal.  
%nfbins is the radius of the interpolation area.
linef=154;
fsignal=signal;
if max(frecs)>linef
    points2f=linef:linef:max(frecs);%frequencies to be filtered
    for i=1:length(points2f)
        p=min(find(frecs>points2f(i)));%position in the data of the noise
        startv=signal(p-nfbins);
        endv=signal(p+nfbins);
        fsignal(p-nfbins:p+nfbins)=startv:(endv-startv)/(2*nfbins):endv;
    end
else
    disp('line noise after max frec')
end
