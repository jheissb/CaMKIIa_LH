function n=getsimev(matrix,thresholds,windowl,sr);
%n=getsimev(matrix,thresholds,window) calculates the number of simultaneous
%events/s divided by the total number of events (within a window window of l sec.) in a matrix with traces sampled at
%sr Hz. Events are detected when the amplitud goes above threshold.
%Finding the first event in the matrix:
winl=windowl*sr;%length in points
dur=length(matrix)/sr;
auxpe=zeros(size(matrix));
auxne=zeros(size(matrix));
n=0;
for i=1:size(matrix,1)
    lim=thresholds(i);
    vec=matrix(i,:);
    vec2=vec(2:end);
    posevents=find(vec(1:end-1)<lim & vec2>lim);
    event=find(vec>lim);
    nevents=length(posevents);
    if nevents>0
    %fixing ending or starting at the event
        endevents=find(vec(1:end-1)>lim & vec2<lim);
        if length(endevents)>nevents
         nevents=nevents+1;
         posevents=[1 posevents];
        end
        if nevents>length(endevents)
         endevents=[endevents length(vec)];
        end
        %Filling hte matrices with the onset and offset of the events
    auxpe(i,event)=1;   
    auxne(i,endevents)=1;   
    end
end
% figure
% plot(sum(auxpe),'r-')
% hold on
% plot(sum(auxne),'b-')
% timep=0;
% while timep<size(matrix,2)
%     timep=timep+1;
%     %looking for the begining of the earliest event
%     [v,p]=max(auxpe(:,timep));
%     if v>0
%         n=n+sum(sum(auxpe(:,timep:min(size(matrix,2),timep+winl))))-1;%IF there is only one cell firing, gives 0;
%         timep=timep+winl-2;
%     end
% end
% n=n/dur;%simultaneous events per sec.
s=sum(auxpe);
        n=s(find(s>0))/nevents;% degree of synchrony in time