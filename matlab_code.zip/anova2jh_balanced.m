%runs a 2-way anova unbalanced
%G1=TIme
%G2=AAV

cd 'F:\data2017\HCRT_DREADD\DOX10'
dox=load('difcumtime.mat');
cd 'F:\data2017\HCRT_DREADD\noDOX10'
nodox=load('difcumtime.mat');
%getting the number of elements in each combination
Ndox_alm=length(dox.alm_cno);
Ndox_veh=length(dox.veh_cno);
Nnodox_alm=length(nodox.alm_cno);
Nnodox_veh=length(nodox.veh_cno);
data(1,:,1)=dox.alm_cno;
data(2,:,1)=dox.veh_cno;
data(1,:,2)=nodox.alm_cno;
data(2,:,2)=nodox.veh_cno;

[pvals_singlerep,pval_conds]=repmeasanova(data)

data(1,:,1)=dox.alm_cno;
data(1,:,2)=dox.veh_cno;
data(2,:,1)=nodox.alm_cno;
data(2,:,2)=nodox.veh_cno;

[pvals_singlerep,pval_conds]=repmeasanova(data)


g1=[repmat('SIDOX',Ndox_alm,1);repmat('SIDOX',Ndox_veh,1);repmat('NODOX',Nnodox_alm,1);repmat('NODOX',Nnodox_veh,1)];
g2=[repmat('ALM',Ndox_alm,1);repmat('VEH',Ndox_veh,1);repmat('ALM',Nnodox_alm,1);repmat('VEH',Nnodox_veh,1)];
[pv,tbl,stats,terms]= anovan(y,{g1,g2},'varnames',{'Chow','Drug'},'model','interaction')
tmc=multcompare(stats,'Display','on','ctype','bonferroni')
vtp=[mean(dox.alm_cno) mean(dox.veh_cno) mean(nodox.alm_cno) mean(nodox.veh_cno)];
err=[sem(dox.alm_cno) sem(dox.veh_cno) sem(nodox.alm_cno) sem(nodox.veh_cno)];
figure
box off
errorbar(vtp,err,'k.','linewidth',1);
hold on
bar(vtp)
set(gca,'xlim',[0.5 4.5])
set(gca,'xtick',[1 2 3 4])
minmax=get(gca,'ylim');
% if pv_cum(ztok)<0.05
%     plot(1.5,minmax(2),'k*')
% end
set(gca,'xticklabel',{'ALM-DOX+','VEH-DOX+','ALM-DOX-','VEH-DOX-'})
set(gca,'ylim',[0 minmax(2)]);
set(gca,'fontsize',14)
box off
ylabel('D Total W time (min)','fontsize',18)
