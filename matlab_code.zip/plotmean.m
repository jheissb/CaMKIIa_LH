function plotmean(mat,sr,col,x0);
%Plot the mean and SEM as shaddow for a data X x N matrix of X points in
%time and N individuals. col is [red green blue] (0-1)
%sr is the sampling rate. x0 is the time for the first point
if nargin==2
    col=[0 0 1];
    x0=0;
end
if nargin==3
    x0=0;
end
if size(mat,1)>size(mat,2)
    mat=mat';
end
xvect=x0+(0:size(mat,2)-1)/sr;
%figure
prom=mean(mat);
plot(xvect,prom,'-','color',col,'linewidth',1.5)
hold on
semmat=sem(mat);
einf=prom-semmat;
emax=prom+semmat;
X=[xvect,fliplr(xvect)];                %create continuous x value array for plotting
Y=[einf,fliplr(emax)];              %create y values for out and then back
%hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
hl=fill(X,Y,min(0.7+col,[1 1 1]),'EdgeColor','none');   
uistack(hl,'bottom')
axis tight
box off
set(gca,'fontsize',14)
xlabel('Time (s)','fontsize',21)
