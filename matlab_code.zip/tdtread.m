function varargout = tdtread(varargin)
% TDTREAD MATLAB code for tdtread.fig
%      TDTREAD, by itself, creates a new TDTREAD or raises the existing
%      singleton*.
%
%      H = TDTREAD returns the handle to a new TDTREAD or the handle to
%      the existing singleton*.
%
%      TDTREAD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TDTREAD.M with the given input arguments.
%
%      TDTREAD('Property','Value',...) creates a new TDTREAD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tdtread_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tdtread_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tdtread

% Last Modified by GUIDE v2.5 13-Jul-2012 14:09:56

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tdtread_OpeningFcn, ...
                   'gui_OutputFcn',  @tdtread_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tdtread is made visible.
function tdtread_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tdtread (see VARARGIN)

% Choose default command line output for tdtread
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tdtread wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tdtread_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

 handles.TTX = actxcontrol('TTank.X');
% set(h,'Visible','off');
 handles.TTX.ConnectServer('Local', 'Me')
 i=1;
 n=handles.TTX.GetEnumTank(i-1);
while ~strcmp(n,'')
     namelist{i}=n;
     i=i+1;
     n=handles.TTX.GetEnumTank(i-1);     
end
set(handles.tanklist,'string',char(namelist));

% TTX.selectfolder(tank, 'R')
% TTX.SelectBlock(['~' block])
% 
% TTX.SetGlobalV('WavesMemLimit',1e9);
% TTX.SetGlobalV('Channel',channel);
% waves = TTX.ReadWavesV(store);
handles.TTX.CloseTank
handles.TTX.ReleaseServer


varargout{1} = handles.output;
guidata(hObject, handles);

% --- Executes on button press in selectfolder.
function selectfolder_Callback(hObject, eventdata, handles)
% hObject    handle to selectfolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
STARTPATH='D:\jhexp\2012'
TITLE='Where is the data?';
f=uigetdir(STARTPATH,TITLE);
cd(f);
% i=1+strfind(f,'\');
% handles.blockname=f(i(end):end);
guidata(hObject, handles);


% --- Executes on selection change in tanklist.
function tanklist_Callback(hObject, eventdata, handles)
% hObject    handle to tanklist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns tanklist contents as cell array
%        contents{get(hObject,'Value')} returns selected item from tanklist
 handles.TTX = actxcontrol('TTank.X');
% set(h,'Visible','off');
 handles.TTX.ConnectServer('Local', 'Me');
 st=get(hObject,'string');
 handles.tank=st(get(hObject,'value'),:);
 handles.TTX.OpenTank(handles.tank, 'R')
 
 
 i=1;
 n=handles.TTX.QueryBlockName(i-1);
while ~strcmp(n,'')
     namelist{i}=n;
     i=i+1;
     n=handles.TTX.QueryBlockName(i-1);    
end
if i>1
    set(handles.selectblock,'string',char(namelist));
end
% TTX.selectfolder(tank, 'R')
% TTX.SelectBlock(['~' block])
% 
% TTX.SetGlobalV('WavesMemLimit',1e9);
% TTX.SetGlobalV('Channel',channel);
% waves = TTX.ReadWavesV(store);
handles.TTX.CloseTank
handles.TTX.ReleaseServer


guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function tanklist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tanklist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in selectblock.
function selectblock_Callback(hObject, eventdata, handles)
% hObject    handle to selectblock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.TTX.SelectBlock(hObject.string(hObject.value),:);
 i=1;
 n=handles.TTX.QueryBlockName(i-1);
while ~strcmp(n,'')
     namelist{i}=n;
     i=i+1;
     n=handles.TTX.QueryBlockName(i-1);    
end
set(handles.selectblock,'string',char(namelist));

guidata(hObject, handles);

% Hints: contents = cellstr(get(hObject,'String')) returns selectblock contents as cell array
%        contents{get(hObject,'Value')} returns selected item from selectblock


% --- Executes during object creation, after setting all properties.
function selectblock_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selectblock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in selchan.
function selchan_Callback(hObject, eventdata, handles)
% hObject    handle to selchan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns selchan contents as cell array
%        contents{get(hObject,'Value')} returns selected item from selchan
%handles.store=store = 'Wave';
channel = 1;

h = figure;

TTX = actxcontrol('TTank.X');
set(h,'Visible','off');

TTX.ConnectServer('Local', 'Me')
TTX.OpenTank(tank, 'R')
TTX.SelectBlock(['~' block])

TTX.SetGlobalV('WavesMemLimit',1e9);
TTX.SetGlobalV('Channel',channel);
waves = TTX.ReadWavesV(store);


% --- Executes during object creation, after setting all properties.
function selchan_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selchan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
