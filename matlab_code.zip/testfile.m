%reading text file
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the stim data');
handles.fn=filename;
%handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
k=0;
disp('Reading text file with results...')
%C2 = textscan(fid, '%f %f %f %f %f %f %s %f %f %s %s %f %f %s %s %s %s %s %s %s %f %f %f %f %f %s');
