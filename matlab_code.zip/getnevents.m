function [nevents,peakevent,meanevent,areaevents,maxarea,maxdurevent,meandurevent]=getnevents(vec,lim,samplingr);
%[nevents,peakevent,meanevent,areaevent,maxdurevent,meandurevent]=getnevents(vec,nstd);
%guess what it does. Inputs are a trace and number of std's to
%consider for an event.
%samplingr=5;%assuming 5 samp/sec
vec=vec(:)';
durvec=length(vec)/samplingr;%duration in secs.
vec2=vec(2:end);
posevents=find(vec(1:end-1)<lim & vec2>lim);
nevents=length(posevents);
if nevents>0
    %fixing ending or starting at the event
    endevents=find(vec(1:end-1)>lim & vec2<lim);
    if length(endevents)>nevents
        nevents=nevents+1;
        posevents=[1 posevents];
    end
    if nevents>length(endevents)
        endevents=[endevents length(vec)];
    end
    if endevents(1)<posevents(1)
        nevents=nevents+1;
        posevents=[1 posevents];
    end
    if endevents(end)<posevents(end)
        endevents=[endevents length(vec)];
    end

        
    vec=vec-lim;
    peakevent=max(vec);
    for k=1:nevents
        area(k)=sum(vec(posevents(k):endevents(k)));
        peak(k)=max(vec(posevents(k):endevents(k)));
    end
    durevents=endevents-posevents;
    meanevent=mean(peak);
    areaevents=sum(area)/durvec;
    maxarea=max(area);
    maxdurevent=max(durevents);
    meandurevent=mean(durevents);
    nevents=nevents/durvec;
else
    nevents=0;peakevent=0;meanevent=0;areaevents=0;maxarea=0;maxdurevent=0;meandurevent=0;
end



