%Reshape text file for rep meas anova in sigmaplot
clear
%cd('C:\Users\abash_000\Dropbox\work\hcrt\DreaDD data\stats_hcrt_Dreadd')
%cd('C:\tmp\stats')
dir_struct = dir ('*.txt'); 
timp2skip=2;%skip time points before dosing
for i=1:length(dir_struct)
    fname=dir_struct(i).name
    m=load(fname);
    condxsubj=size(m,1);
    ntimes=size(m,2);
    if condxsubj>27
        nconds=4;
        nameconds=['alm-cno';'alm-sal';'veh-cno';'veh-sal'];
    else
        nconds=2;
        nameconds=['cno';'sal'];
    end
    namet=strcat(repmat('band',ntimes,1),num2str((1:ntimes)'));
    nsub=condxsubj/nconds;
    namesub=strcat(repmat('mse',nsub,1),num2str((1:nsub)'));
    vecd=reshape(m,condxsubj*ntimes,1);
    veccond=repmat(nameconds,nsub*ntimes,1);
    veczt=[];%repmat('',nconds*nsub*ntimes,1);%init
    vecnsub=[];
    for t=1:ntimes
        veczt=[veczt;repmat(namet(t,:),nconds*nsub,1)];
    end
    for t=1:nsub
        vecnsub=[vecnsub;repmat(namesub(t,:),nconds,1)];
    end
    vecnsubf=repmat(vecnsub,ntimes,1);
    T=table(cellstr(vecnsubf((timp2skip*nconds*nsub)+1:end,:)),cellstr(veccond((timp2skip*nconds*nsub)+1:end,:)),cellstr(veczt((timp2skip*nconds*nsub)+1:end,:)),vecd((timp2skip*nconds*nsub)+1:end),'VariableNames',{'subject','condition','time','data'});
    newfname=[fname(1:end-3) 'xls'];
    writetable(T,newfname);
end