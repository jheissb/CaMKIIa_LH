function varargout = iscore(varargin)
%Graphic interface to score and analyze EEG data in EDF format
%By Jaime Heiss, March 2013
% ISCORE MATLAB code for iscore.fig
%      ISCORE, by itself, creates a new ISCORE or raises the existing
%      singleton
%
%      H = ISCORE returns the handle to a new ISCORE or the handle to
%      the existing singleton*.
%
%      ISCORE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ISCORE.M with the given input arguments.
%
%      ISCORE('Property','Value',...) creates a new ISCORE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before iscore_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to iscore_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help iscore

% Last Modified by GUIDE v2.5 25-Oct-2014 19:00:29

% rescore initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @iscore_OpeningFcn, ...
    'gui_OutputFcn',  @iscore_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before iscore is made visible.
function iscore_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to iscore (see VARARGIN)

% Choose default command line output for iscore
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes iscore wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = iscore_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in load_edf.
function load_edf_Callback(hObject, eventdata, handles)
% hObject    handle to load_edf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla
axes(handles.axes2)
cla
% box off
% axis off
axes(handles.axes3)
cla
box off
axis off
set(handles.raw_signals,'value',1)
cla
cn=getComputerName();
cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     cd ('D:\jhexp\2013\vivo')
% end
% if strcmp('laptopjh',cn)
%     cd ('C:\Users\john\Documents\My Dropbox\Jaime')
% end

if isfield(handles,'EDF')
    handles.EDF=sdfclose(handles.EDF);
end

% handles.EDF=sdfopen(get(handles.filename,'string'));

if isfield(handles,'nump')
    handles=rmfield(handles,'nump')
end

%cd ('C:\Users\E26903\Documents\My Dropbox\laptopsleep\anushka')
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file to analyze');
handles.fn=filename;
handles.pathEDF=pathname;
cd (pathname)
set(handles.text8,'BackgroundColor',[1 0 0])
set(handles.text8,'string','Reading File')
handles.EDF=sdfopen(filename);
%handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
set(handles.filename,'string',filename)
handles.dur=handles.EDF.NRec*handles.EDF.Dur;%duration in secs of the whole thing
a=handles.EDF.Label(1,:);
if strcmp(a,'                ')
    handles.EDF.Label(1,1:4)='Stim'
end
set(handles.raw_signals,'string',handles.EDF.Label);
handles.selchan=get(handles.raw_signals,'value');
handles.hto=handles.EDF.T0(4);%initial hour
handles.mto=handles.EDF.T0(5);%initial minute
handles.sto=handles.EDF.T0(6);%initial second
set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));
nh=floor(handles.dur/3600);
if nh>48
    nh=48;%Limit on the total duration that can be read to avoid memory issues.
end
handles.nh=nh;
nm=floor((handles.dur-(nh*3600))/60);
ns=handles.dur-(nh*3600)-(nm*60);
sf=mod(handles.sto+ns,60);
mf=mod((handles.mto+floor((handles.sto+ns)/60)+nm),60);
hf=mod(handles.hto+nh+floor((handles.mto+floor((handles.sto+ns)/60)+nm)/60),24);
nd=floor((handles.hto+nh+floor((handles.mto+floor((handles.sto+ns)/60)+nm)/60))/24);
ht0_str=num2str(handles.hto);
if length(ht0_str)==1
    ht0_str=strcat('0',ht0_str);
end
mt0_str=num2str(handles.mto);
if length(mt0_str)==1
    mt0_str=strcat('0',mt0_str);
end

st0_str=num2str(handles.sto);
if length(st0_str)==1
    st0_str=strcat('0',st0_str);
end

handles.emgscale=[0 10^-9];%Fixed scale for FFT

set(handles.endtime,'string',strcat('Tf:',num2str(hf),':',num2str(mf),':',num2str(round(ns))));
set(handles.toedit,'string',strcat(ht0_str,':',mt0_str,':',st0_str));
set(handles.stdate,'string',strcat('D0:',num2str(handles.EDF.T0(3)),'/',num2str(handles.EDF.T0(2)),'/',num2str(handles.EDF.T0(1))));
set(handles.enddate,'string',strcat('Df:',num2str(handles.EDF.T0(3)+nd),'/',num2str(handles.EDF.T0(2)),'/',num2str(handles.EDF.T0(1))));
handles.d0=0.5;
handles.df=4;
handles.tet0=4;
handles.tetf=8;
ltrace=round(3600);%1 h
set(handles.endp,'string',num2str(floor(handles.dur)))
set(handles.startp,'string','0')

[handles.s,edfs]=sdfread(handles.EDF,ltrace,ltrace);
handles.cht=0;
handles.chemg=0;
if get(handles.dsi,'value')
    if size(handles.EDF.Label,1)==3
        for i=1:3
            if length(strfind(handles.EDF.Label(i,:),'EEG'))>0
                if handles.cht==0
                    handles.cht=i;
                else
                    handles.chemg=i;%If there is a second channel also named EEG it will be asigned as EMG
                end
                    
                
            end
            if length(strfind(handles.EDF.Label(i,:),'EMG'))>0
                handles.chemg=i;
            end
        end
        handles.chfft=handles.cht;%channel used for FFTn
    elseif size(handles.EDF.Label,1)==4
        handles.cht=2;%channel with highest theta
        handles.chfft=2;%channel used for FFT
        handles.chemg=3;%channel with EMG
        
    else
        handles.cht=1;%channel with highest theta
        handles.chfft=1;%channel used for FFT
        handles.chemg=2;%channel with EMG
    end
    
else
    if size(handles.s,2)>2
        if size(handles.s,2)>3
            handles.cht=3;%channel with highest theta
            handles.chfft=1;%channel used for FFT
            handles.chemg=4;%channel with EMG
        else
            handles.cht=2;%channel with highest theta
            handles.chfft=1;%channel used for FFT
            handles.chemg=3;%channel with EMG
        end
    else
        handles.cht=1;%channel with highest theta
        handles.chfft=1;%channel used for FFT
        handles.chemg=2;%channel with EMG
    end
end
if get(handles.mt,'value')
    num=str2double(get(handles.limemg2,'string'));
    if ~isfield(handles,'chemg')
        handles.limemg=[0 num*std(handles.s(:,2))];
    else
        handles.limemg=[0 num*std(handles.s(:,handles.chemg))];
    end
else
    handles.limemg=0;
end

%Making the vector with the epoch times and score for the whole register
handles.el=str2double(get(handles.edit7,'string'));%Duration of the epoch
handles.nepochs=floor(handles.dur/handles.el);
handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
handles.score=ones(size(handles.epocht));
handles.score(:)=NaN;
%Now getting the EMG and RMS per epoch and user defined threshold for wake
handles.emgpe=[];%zeros(1,handles.nepochs);
handles.rms=[];%zeros(1,handles.nepochs);
handles.powbands=[];
handles.distance=8;%distance between traces
disp('reading channel')

%Making a large matrix with all the EEG and EMG data (ch num, epoch num, data). Each row has one
%epoch of data points

[aux,edfs]=sdfread(handles.EDF,handles.el,0);
auxfft=getthepower(aux(:,handles.cht),handles.el,100,0);
npepoch=round(handles.el*handles.EDF.SampleRate(handles.cht));
handles.edfdata=zeros(length(handles.EDF.SampleRate),npepoch,handles.nepochs);
handles.fftmat=zeros(handles.nepochs,length(auxfft));
stdeeg=[];
%read the whole thing, filter and make epochs and FFTs
[handles.EDF]=sdfclose(handles.EDF);
handles.EDF=sdfopen(get(handles.filename,'string'));
progressbar('Reading EDF file')


for i=0:handles.nepochs-1
    [aux,edfs]=sdfread(handles.EDF,handles.el,i*handles.el);
    handles.edfdata(:,:,i+1)=aux';
    
    if mod(i,1000)==0
        progressbar((i+1)/(handles.nepochs-1)) % Update figure
    end
end
eegdata=fixdim(handles.edfdata(handles.cht,:,:));
handles.filteeg=bandpassfilter(reshape(eegdata,1,size(eegdata,1)*size(eegdata,2)),handles.EDF.SampleRate(1),[0.5 ceil(handles.EDF.SampleRate(1)/2.5)]);
eegdata=reshape(handles.filteeg,size(eegdata,1),size(eegdata,2));
% for i=1:handles.nepochs
%     handles.fftmat(min(i+1,handles.nepochs),:)=getthepower(eegdata(:,i),handles.el,100,0);
% end
% handles.fftmat(1,:)=handles.fftmat(2,:);
for i=1:handles.nepochs
    handles.fftmat(i,:)=getthepower((10^6)*eegdata(:,i),handles.el,100,0);%In microvolts
end


progressbar(1);
ltrace=str2num(get(handles.lengthtrace,'string'));
dat2plot=handles.edfdata(:,:,1:round(ltrace/handles.el));
handles.s=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*round(ltrace/handles.el)))';
%doing the sqaure of the EMG for better separation
aux=fixdim(handles.edfdata(handles.chemg,:,:));
aux2=aux(:);
indn=find(aux2<0);
indp=find(aux2>0);
indn2=find(aux<0);
indp2=find(aux>0);
if std(aux2(indn))>std(aux2(indp))%This is correlated to the heart artifact going downwards
    aux(indn2)=0;
else
    aux(indp2)=0;
end
aux=aux.^2;
handles.emgpe=rms(aux);

handles.rms=rms(eegdata);
stdeeg=std(eegdata(:));
[handles.EDF]=sdfclose(handles.EDF);%check if its ok to call it ike that
handles.edfdata(handles.cht,:,:)=eegdata;
%getting delta, theta and high gamma as the maximum power in the band (check if this is not too noisy):
N=length(aux(:,handles.cht));
handles.freq = [0:floor(N/2)-1]/(handles.el);
lowlim=[0.1 5 80];
highlim=[4.5 9 100];
for i = 1:length(lowlim)%1=delta, 2=theta, 3=high gamma
    [v,pmin]=min(abs(handles.freq-lowlim(i)));
    [v,pmax]=min(abs(handles.freq-highlim(i)));
    handles.powbands(i,:)=max(handles.fftmat(:,pmin:pmax)');
end



% if nh>0
%     disp(handles.EDF.T0(5))
%     for i=0:(nh)-1%reading in 1h chunks except the last one
%         [handles.EDF]=sdfclose(handles.EDF);
%         handles.EDF=sdfopen(get(handles.filename,'string'));
%         [handles.s,edfs]=sdfread(handles.EDF,ltrace,i*ltrace);
%         largo=floor(handles.el*edfs.SampleRate(handles.selchan))*floor(length(handles.s(:,handles.selchan))/(handles.el*edfs.SampleRate(handles.selchan)));
%         if get(handles.mt,'value')
%             auxmt=rms(reshape(handles.s(1:largo,handles.chemg),floor(handles.el*edfs.SampleRate(handles.selchan)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.selchan)))));
%         else
%             auxmt=0;
%         end
%         eegtrs=reshape(handles.s(1:largo,handles.cht),floor(handles.el*edfs.SampleRate(handles.cht)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.cht))));
%         ltr=length(eegtrs)/edfs.SampleRate(handles.selchan);
%         auxeeg=rms(eegtrs);
%         handles.emgpe=[handles.emgpe auxmt];
%         handles.rms=[handles.rms auxeeg];
%         stdeeg=[stdeeg std(handles.s(1:largo,handles.cht))];
%         if get(handles.smart_score,'value')
%             %getting the average power for each band for each epoch
%             for kqk=1:size(eegtrs,2)
%                 pbands(kqk,:)=getpbands(eegtrs(:,kqk),ltr);%To do: add the duration of the trace. {'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%             end
%             handles.powbands=[handles.powbands pbands'];
%         end
%
%     end
%     startr=ceil(6*nh*ltrace);
%     if handles.dur-startr>0
%         [handles.s,edfs]=sdfread(handles.EDF,handles.dur-startr,startr);
%         largo=floor(handles.el*edfs.SampleRate(handles.cht))*floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.cht)));
%         if get(handles.mt,'value')
%             auxmt=rms(reshape(handles.s(1:largo,handles.chemg),floor(handles.el*edfs.SampleRate(handles.chemg)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.chemg)))));
%         else
%             auxmt=0;
%         end
%         eegtrs=reshape(handles.s(1:largo,handles.cht),floor(handles.el*edfs.SampleRate(handles.cht)),floor(length(temptimev)/(handles.el*edfs.SampleRate(handles.cht))));
%         ltr=length(eegtrs)/edfs.SampleRate(handles.cht);
%         auxeeg=rms(eegtrs);
%         handles.emgpe=[handles.emgpe auxmt];
%         handles.rms=[handles.rms auxeeg];
%         if get(handles.smart_score,'value')
%             pbands=[];
%            %getting the average power for each band for each epoch
%             for kqk=1:size(eegtrs,2)
%                 pbands(kqk,:)=getpbands(eegtrs(:,kqk),ltr);%{'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%             end
%             handles.powbands=[handles.powbands pbands'];
%         end
%
%     end
%
% else
%     [handles.s,edfs]=sdfread(handles.EDF,inf);
%     largo=floor(handles.el*edfs.SampleRate(handles.chemg))*floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.chemg)));
%     if get(handles.mt,'value')
%         auxmt=rms(reshape(handles.s(1:largo,handles.chemg),floor(handles.el*edfs.SampleRate(handles.chemg)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.chemg)))));
%     else
%         auxmt=0;
%     end
%     eegtrs=reshape(handles.s(1:largo,handles.cht),floor(handles.el*edfs.SampleRate(handles.cht)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.cht))));
%     ltr=length(eegtrs)/edfs.SampleRate(handles.cht);
%     auxeeg=rms(eegtrs);
%     handles.emgpe=auxmt;
%     handles.rms=auxeeg;
%     if get(handles.smart_score,'value')
%             pbands=[];
%            %getting the average power for each band for each epoch
%             for kqk=1:size(eegtrs,2)
%                 pbands(kqk,:)=getpbands(eegtrs(:,kqk),ltr);%{'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%             end
%             handles.powbands=pbands';
%         end
%
%
% end
disp(handles.EDF.T0(5))
f=figure%limits for EMG
wthres=0;
if get(handles.mt,'value')
    %test handles.powbands(3,:).*handles.emgpe
    %try normalizing powbands
    xvec=(0:length(handles.emgpe)-1)*(handles.el/3600);
    set(f, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(removepeaks(handles.emgpe)),'k.')
    %     hold on
    %     plot(xvec,removepeaks(handles.emgpe),'c--')
    ylabel('EMG','fontsize',16)
    title('Set threshold for wake','fontsize',18)
    [xpos,wthres]=ginput(1);
    title('Set threshold for sleep','fontsize',18)
    [xpos,semgthres]=ginput(1);
    indsleep=find(handles.emgpe<wthres);
    cla
    [frec,inter]=hist(removepeaks(handles.emgpe),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    minmax=get(gca,'ylim')
    hold on
    plot([wthres wthres],minmax,'g--')
    plot([semgthres semgthres],minmax,'g--')
    title('EMG','fontsize',16)
    
    f1=figure
    xvec=(0:length(handles.rms)-1)*(handles.el/3600);
    set(f1, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.rms),'.')
    ylabel('RMS EEG','fontsize',16)
    title('Set threshold for movement artifact','fontsize',18)
    [xpos,mthres]=ginput(1);
    
    f1=figure
    set(f1, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.rms),'.')
    ylabel('RMS EEG','fontsize',16)
    title('Set threshold for NREM','fontsize',18)
    [xpos,nrem]=ginput(1);
    title('Set threshold for REM or WA','fontsize',18)
    [xpos,notnrem]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(handles.rms),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    hold on
    minmax=get(gca,'ylim')
    plot([nrem nrem],minmax,'g--')
    plot([notnrem notnrem],minmax,'g--')
    ylabel('RMS EEG','fontsize',16)
    
    %Now the power
    f2=figure
    set(f2, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec(indsleep),removepeaks(handles.powbands(1,indsleep)),'.')
    ylabel('Delta power','fontsize',16)
    title('Set threshold for NREM','fontsize',18)
    [xpos,nremd]=ginput(1);
    title('Set threshold for REM or WA','fontsize',18)
    [xpos,notnremd]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(handles.powbands(1,:)),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    %hist(removepeaks(handles.powbands(1,:)),1000)
    hold on
    minmax=get(gca,'ylim')
    plot([nremd nremd],minmax,'g--')
    plot([notnremd notnremd],minmax,'g--')
    ylabel('Delta power','fontsize',16)
    
    f2=figure
    rempower=((handles.powbands(2,1:length(handles.emgpe))/median(handles.powbands(2,1:length(handles.emgpe))).^2)./((handles.powbands(1,1:length(handles.emgpe))/median(handles.powbands(1,1:length(handles.emgpe)))).^2));
    rempower=rempower./((handles.emgpe/median(handles.emgpe)).^2);
    set(f2, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,rempower)
    ylabel('Theta/Delta','fontsize',16)%consider multiplying it by normalized EMG
    title('Set threshold for REM','fontsize',18)
    [xpos,rem]=ginput(1);
    title('Set threshold for NREM or WA','fontsize',18)
    [xpos,notrem]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(rempower),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    hold on
    minmax=get(gca,'ylim')
    plot([rem rem],minmax,'g--')
    plot([notrem notrem],minmax,'g--')
    ylabel('Theta/Delta','fontsize',16)%consider multiplying it by normalized EMG
    
    f3=figure
    set(f3, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.powbands(3,:)),'.')
    ylabel('High Gamma','fontsize',16)
    title('Set threshold for Wake','fontsize',18)
    [xpos,wakeg]=ginput(1);
    title('Set threshold for sleep','fontsize',18)
    [xpos,notwakeg]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(handles.powbands(3,:)),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    hold on
    minmax=get(gca,'ylim')
    plot([wakeg wakeg],minmax,'g--')
    plot([notwakeg notwakeg],minmax,'g--')
    ylabel('High Gamma','fontsize',16)
    
    %Auto scoring:
    %W is everything that has high EMG and low EEG
    %WA is everythng that has high EMG and also high EEG
    %NREM is everything that has high EEG, and low EMG
    %NA has too high EEG
    %REM has low EEG, low EMG and low delta/theta
    
    %close (f)
    %0:W, 0.1:WA, , 0.05:Systematic WA, 1:NR, 1.1:NRA, 2:R, 2.1:RA, -0.1:C1, -0.2:C2, -0.3:U
    %W
    indw=find((handles.emgpe>semgthres) & (handles.emgpe>wthres | ((handles.powbands(3,:)>wakeg) & handles.rms<notnrem)));
    %WA:
    indwa=indw(find((handles.rms(indw)>nrem) | (handles.powbands(1,indw)>nremd)));
    
    %NREM
    indnr=find(handles.emgpe<semgthres & (handles.powbands(3,:)<notwakeg) &((handles.rms>nrem) | (handles.powbands(1,:)>nremd)));
    
    %NREMA
    indna=indnr(find(handles.rms(indnr)>mthres));
    
    %REM
    indrem=find(handles.emgpe<semgthres & rempower>rem & handles.rms<notnrem & handles.powbands(1,:)<notnremd & handles.powbands(3,:)<notwakeg);
    
    handles.score(indrem)=2;
    handles.score(indw)=0;
    handles.score(indwa)=0.1;
    handles.score(indnr)=1;
    handles.score(indna)=1.1;
end
%to fix: very low EMG cannot be wake
notsc=length(find(isnan(handles.score)));
helpdlg(strcat('% auto-scored:',num2str(100*(length(handles.score)-notsc)/length(handles.score))))

handles.eegrange=7*mean(stdeeg);%nrem;%range for plotting EEG (minmax=[-eegrange +eegrange])

% load (strcat(handles.fn(1:end-3),'mat'));
% figure
% plot(sc,'r.--','linewidth',2)
% hold on
% plot(handles.score,'k-','linewidth',1)
handles.ascore=handles.score;
handles.validatedsc=zeros(size(handles.score));

%  manu=round(sc(1:10800));
%  indrem=find(round(manu)==2);
%  autos=round(handles.score(1:10800));
% figure
%  plot(1:length(manu),rempower(1:length(manu)),'.')
% hold on
% plot(indrem,rempower(indrem),'ro')
% indrema=find(autos==2);
%  plot(indrema,rempower(indrema),'k*')
axes(handles.axes3)
cla
guidata(hObject, handles);
plot(ep2zt(handles.epocht,handles),handles.score,'k-')
axis tight
box off
set(gca,'xcolor','g')
%axis off

% if get(handles.smart_score,'value')
%     xv=14.3756+(1:length(handles.powbands'))*(handles.el/3600);
%     %xv=xv*0.0028;%xvector in hours
%     mtp=normat_one(handles.powbands')+(diag(1:6)'*ones(size(handles.powbands'))')';%shift each row by one more than previous for visualization
%     figure
%     plot(xv,mtp);
%     %legend('D', 'T', 'A', 'B', 'lG', 'hG')
%     legend('30-40 Hz', '40-50 Hz', '50-60 Hz', '60-70 Hz', '70-80 Hz', '80-90 Hz')
%     xlabel('h')
% end
%reading the trace
handles.ltrace=str2double(get(handles.lengthtrace,'string'));
handles.neptpl=floor(handles.ltrace/handles.el);
if handles.neptpl<1
    set(handles.lengthtrace,'string',num2str(handles.el))
    handles.ltrace=handles.el;
    handles.neptpl=1;
end
% [handles.EDF]=sdfclose(handles.EDF);
% handles.EDF=sdfopen(filename);
% [handles.s,edfs]=sdfread(handles.EDF,ltrace,0);
handles.sr=edfs.SampleRate;
set(handles.text6,'string',strcat('SR: ',num2str(handles.sr(handles.selchan))));
handles.x=handles.ltrace*(0:length(handles.s(:,handles.selchan))-1)/(length(handles.s(:,handles.selchan))-1);
handles.xi=1/handles.sr(handles.selchan);
handles.t0=0;%Initial time to plot in s
handles.ce=1;%current epoch
handles.tf=handles.t0+handles.ltrace;%final time to plot in s
handles.maxf=12;%maxfrec for plotting when scoringplot_traces(handles);
handles.step=handles.el*handles.sr(handles.selchan);%number of points of each epoch
plot_traces(handles)
set(handles.text8,'BackgroundColor',[0 1 0])
set(handles.text8,'string','Ready')
handles.NOWscoring=0;%Flag for scoring mode

guidata(hObject, handles);

function plot_traces(handles)
set(handles.edit6,'string',num2str(handles.ce))
%disp(handles.ce*handles.el)
%disp(handles.epocht(handles.ce))
axes(handles.axes1)
cla
xlabel('s','fontsize',14)
%set(handles.slider1,'max',tl);
%getting the max in the slider
nchtp=length(handles.selchan);%number of channels to plot
for i=1:nchtp
    selchan=handles.selchan(i);
    handles.x=handles.ltrace*(0:length(handles.s(:,selchan))-1)/(length(handles.s(:,selchan))-1);
    handles.x=handles.x+handles.t0;
    if selchan==1 & handles.cht==2
        handles.s(:,selchan)=handles.s(:,selchan)*0.4*1E-4;
    end
    if selchan==2 & size(handles.s,2)>2 & ~get(handles.dsi,'value')
        plot(handles.x,(handles.distance*(i-1)*std(handles.s(:,handles.selchan(1))))+(handles.s(:,1)-handles.s(:,3)),'k-')
    else
        plot(handles.x,(handles.distance*(i-1)*2*std(handles.s(:,handles.selchan(1))))+handles.s(:,selchan),'k-')
    end
    %plot(handles.x,handles.s(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.raw_signals,'value')))
    axis tight
    if selchan==handles.cht
        set(gca,'ylim',[-handles.eegrange handles.eegrange])
    end
end
xi=handles.x(1);
xf=handles.x(end);
minmax=get(gca,'ylim');
p=find(handles.epocht>=xi);%(xi/handles.sr(selchan)));
firstep=p(1);
p=find(handles.epocht<=xf);%;(xf/handles.sr(selchan)));
lastep=p(end);
hold on
plot([handles.epocht(firstep:lastep)' handles.epocht(firstep:lastep)'],minmax,'g--')
%writing the scoring
posytxt=minmax(1)+0.95*(minmax(2)-minmax(1));
posxtxt=0.05*handles.el;
for i=firstep:lastep
    %  text(handles.epocht(i)+posxtxt,posytxt,strcat('EMG:',num2str(handles.emgpe(i)),scr2txt(handles.score(i))),'fontsize',14,'color','r');
    if handles.validatedsc(i)==1
        text(handles.epocht(i)+posxtxt,posytxt,scr2txt(handles.score(i)),'fontsize',14,'color','r');
    else
        text(handles.epocht(i)+posxtxt,posytxt,scr2txt(handles.score(i)),'fontsize',14,'color','g');
    end
end
%Finally marking h=the active epoch
xv=[handles.epocht(handles.ce) handles.epocht(handles.ce+1)];
einf=[minmax(1) minmax(1)];
emax=[minmax(2) minmax(2)];
X=[xv,fliplr(xv)];                %create continuous x value array for plotting
Y=[einf,fliplr(emax)];              %create y values for out and then back
%hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
hl=fill(X,Y,[0.92 0.92 0.95],'EdgeColor','none');
uistack(hl,'bottom')


%Now plot MT
if get(handles.mt,'value')
    axes(handles.axes5)
    cla
    emgtp=handles.s(:,handles.chemg);
    indp=find(emgtp>0);
    indn=find(emgtp<0);
    if get(handles.rev_hf,'value')
            emgtp(indn)=0;
        else
            emgtp(indp)=0;
    end
    plot(handles.x,(emgtp.^2),'b-')
    axis tight
    if get(handles.fixEMG,'value')
        set(gca,'ylim',handles.limemg)
    end
    %set(gca,'ylim',[mean(handles.s(:,handles.chemg))-handles.limemg mean(handles.s(:,handles.chemg))+handles.limemg])
    %     set(gca,'ylim',[0 mean(handles.s(:,handles.chemg).^2)+handles.limemg])
    axis off
    if str2double(get(handles.lengthtrace,'string'))<=120
        plot_FFT(handles);
    else
        axes(handles.axes2)
        cla
        axis off
        axes(handles.axes4)
        cla
        axis off
    end
end

%Now plotting the the current position
%figure
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
% newt0=mod(h0-zt0,24);
newt0=h0-zt0;
% if h0<zt0
%     newt0=-newt0;
% end
% figure
% plot([newt0+(handles.epocht(handles.ce)/3600) newt0+(handles.epocht(handles.ce)/3600)],[0 2],'r.-')
% set(gca,'Xtick',0:floor(handles.dur/3600))
% box off
% hold on
% plot(newt0+(handles.epocht/3600),handles.score,'k-')
% xlabl=str2num(get(gca,'Xticklabel'));
% axis tight
%
% % set(gca,'Xticklabel',num2str(mod(xlabl,24)))
% %now plotting the stimulus (sync signal)
% if isfield(handles,'stimoff')
%     plot([(newt0+handles.stimoff)' (newt0+handles.stimoff)'],[0 2]','c--')
% end
% if isfield(handles,'stimon')
%     plot([(newt0+handles.stimon)' (newt0+handles.stimon)'],[0 2]','m--')
% end

axes(handles.axes3)
cla
plot([newt0+(handles.epocht(handles.ce)/3600) newt0+(handles.epocht(handles.ce)/3600)],[0 2],'r.-')
set(gca,'Xtick',0:floor(handles.dur/3600))
box off
hold on
plot(newt0+(handles.epocht/3600),handles.score,'k-')
xlabl=str2num(get(gca,'Xticklabel'));
axis tight

% set(gca,'Xticklabel',num2str(mod(xlabl,24)))
%now plotting the stimulus (sync signal)
if isfield(handles,'stimoff')
    plot([(newt0+handles.stimoff)' (newt0+handles.stimoff)'],[0 2]','c--')
end
if isfield(handles,'stimon')
    plot([(newt0+handles.stimon)' (newt0+handles.stimon)'],[0 2]','m--')
end
set(gca,'TickLength',[0 0])


function plot_FFT(handles)
%plotting the FFT and the bar plots with delta and teta
axes(handles.axes2)
cla
axis on
pvec=[];
N = floor(handles.el*handles.sr(handles.chfft)); %% number of points
T = handles.el; %% define time of interval
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
[v,posmaxf]=min(abs(freq-handles.maxf));
df=freq(2)-freq(1);
%make a single vector with the concatenated fft from 0 to maxf
aux=handles.fftmat(max(1+floor(handles.t0/handles.el)):ceil(handles.tf/handles.el),1:round(posmaxf-1))';
% xaux1=ones(size(aux));
% d=diag(freq(1:posmaxf));
% newm=d*xaux1;
pvec=aux(:);
xpvec=0:df:df*(length(pvec)-1);
% for i=0:floor(handles.ltrace/handles.el)-1
%     aux=getthepower(handles.s(floor(1+(i*(handles.el*handles.sr(handles.cht)))):floor((1+i)*(handles.el*handles.sr(handles.cht))),handles.cht),handles.el,handles.maxf-df,0)';
%     pvec=[pvec aux];
%     if i==0
%         xpvec=freq(1:length(aux));
%     else
%         xpvec=[xpvec 2*xpvec(end)-xpvec(end-1)+freq(1:length(aux))];
%     end
% end
plot(xpvec,pvec)
axis tight;
set(gca,'ylim',handles.emgscale)
minmax=handles.emgscale;
hold on
plot([(0:handles.maxf:length(pvec))' (0:handles.maxf:length(pvec))'],minmax,'g--','linewidth',2)
set(gca,'XTick',0:2:length(pvec));
set(gca,'XTickLabel',num2str((0:2:handles.maxf-0.1)'))
grid on

%Now the bar plots with the ratios of frequncies: delta=delta power/total
%power of the epoch. Teta=teta power/delta power (both for the epoch)
% axes(handles.axes4)
% [v,xi]=min(abs(handles.x-handles.ti));
% [v,xf]=min(abs(handles.x-handles.tf));
% cla
% for kk=0:handles.neptpl-1
%     trace=handles.s((xi*kk)+1:(xi*kk)+handles.step,handles.chfft);
%     tracet=handles.s((xi*kk)+1:(xi*kk)+handles.step,handles.cht);
%     delta(kk+1)=getpband(trace,handles.el,handles.d0,handles.df)/getpband(trace,handles.el,handles.d0,handles.tetf);
%     teta(kk+1)=getpband(tracet,handles.el,handles.tet0,handles.tetf)/getpband(trace,handles.el,handles.d0,handles.df);
% end
% %bar([(delta-min(delta))',(teta-min(teta))'])
%
% %x=1:length(delta);
% bar([delta',teta'])
%
% set(gca,'xticklabel','')
%axis tight
%axis off
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, ~, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rescore.
function rescore_Callback(hObject, eventdata, handles)
% hObject    handle to rescore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    %Ask the user to reset the thresholds for auto scoring. This time it
    %plots the parameters of manually scored epochs with different colors for different epochs.
    indwa=find(handles.validatedsc==1 & handles.score==0);
    indnrem=find(handles.validatedsc==1 & handles.score==1);
    indrem=find(handles.validatedsc==1 & handles.score==2);
            
            
    f=figure;        
    xvec=(0:length(handles.emgpe)-1)*(handles.el/3600);
    set(f, 'Position', get(0,'Screensize')); % Maximize figure.
    vtp=removepeaks(removepeaks(handles.emgpe));
    plot(xvec,vtp,'k.')
    hold on
    plot(xvec(indwa),vtp(indwa),'g.')
    plot(xvec(indnrem),vtp(indnrem),'b.')
    plot(xvec(indrem),vtp(indrem),'r.')
    
    %     hold on
    %     plot(xvec,removepeaks(handles.emgpe),'c--')
    ylabel('EMG','fontsize',16)
    title('Set threshold for wake','fontsize',18)
    [xpos,wthres]=ginput(1);
    title('Set threshold for sleep','fontsize',18)
    [xpos,semgthres]=ginput(1);
    indsleep=find(handles.emgpe<wthres);
    cla
    [frec,inter]=hist(removepeaks(handles.emgpe),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    minmax=get(gca,'ylim')
    hold on
    plot([wthres wthres],minmax,'g--')
    plot([semgthres semgthres],minmax,'g--')
    title('EMG','fontsize',16)
    
    f1=figure
    xvec=(0:length(handles.rms)-1)*(handles.el/3600);
    set(f1, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.rms),'k.')
    vtp=removepeaks(handles.rms);
    hold on
    plot(xvec(indwa),vtp(indwa),'g.')
    plot(xvec(indnrem),vtp(indnrem),'b.')
    plot(xvec(indrem),vtp(indrem),'r.')
    ylabel('RMS EEG','fontsize',16)
    title('Set threshold for movement artifact','fontsize',18)
    [xpos,mthres]=ginput(1);
    
    f1=figure
    set(f1, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.rms),'k.')
    hold on
    plot(xvec(indwa),vtp(indwa),'g.')
    plot(xvec(indnrem),vtp(indnrem),'b.')
    plot(xvec(indrem),vtp(indrem),'r.')
    ylabel('RMS EEG','fontsize',16)
    title('Set threshold for NREM','fontsize',18)
    [xpos,nrem]=ginput(1);
    title('Set threshold for REM or WA','fontsize',18)
    [xpos,notnrem]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(handles.rms),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    hold on
    minmax=get(gca,'ylim')
    plot([nrem nrem],minmax,'g--')
    plot([notnrem notnrem],minmax,'g--')
    ylabel('RMS EEG','fontsize',16)
    
    %Now the power
    f2=figure
    set(f2, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.powbands(1,:)),'k.')
    vtp=removepeaks(handles.powbands(1,:));
    hold on
    plot(xvec(indwa),vtp(indwa),'g.')
    plot(xvec(indnrem),vtp(indnrem),'b.')
    plot(xvec(indrem),vtp(indrem),'r.')
    
    ylabel('Delta power','fontsize',16)
    title('Set threshold for NREM','fontsize',18)
    [xpos,nremd]=ginput(1);
    title('Set threshold for REM or WA','fontsize',18)
    [xpos,notnremd]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(handles.powbands(1,:)),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    %hist(removepeaks(handles.powbands(1,:)),1000)
    hold on
    minmax=get(gca,'ylim')
    plot([nremd nremd],minmax,'g--')
    plot([notnremd notnremd],minmax,'g--')
    ylabel('Delta power','fontsize',16)
    
    f2=figure
    rempower=((handles.powbands(2,1:length(handles.emgpe))/median(handles.powbands(2,1:length(handles.emgpe))).^2)./((handles.powbands(1,1:length(handles.emgpe))/median(handles.powbands(1,1:length(handles.emgpe)))).^2));
    rempower=rempower./((handles.emgpe/median(handles.emgpe)).^2);
    set(f2, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,rempower,'k-')
     hold on
    plot(xvec(indwa),rempower(indwa),'g.')
    plot(xvec(indnrem),rempower(indnrem),'b.')
    plot(xvec(indrem),rempower(indrem),'r.')
    ylabel('Theta/Delta','fontsize',16)%consider multiplying it by normalized EMG
    title('Set threshold for REM','fontsize',18)
    [xpos,rem]=ginput(1);
    title('Set threshold for NREM or WA','fontsize',18)
    [xpos,notrem]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(rempower),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    hold on
    minmax=get(gca,'ylim')
    plot([rem rem],minmax,'g--')
    plot([notrem notrem],minmax,'g--')
    ylabel('REM power','fontsize',16)%consider multiplying it by normalized EMG
    
    f3=figure
    set(f3, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,removepeaks(handles.powbands(3,:)),'k.')
    hold on
    vtp=removepeaks(handles.powbands(3,:));
    plot(xvec(indwa),vtp(indwa),'g.')
    plot(xvec(indnrem),vtp(indnrem),'b.')
    plot(xvec(indrem),vtp(indrem),'r.')
    
    ylabel('High Gamma','fontsize',16)
    title('Set threshold for Wake','fontsize',18)
    [xpos,wakeg]=ginput(1);
    title('Set threshold for sleep','fontsize',18)
    [xpos,notwakeg]=ginput(1);
    cla
    [frec,inter]=hist(removepeaks(handles.powbands(3,:)),1000);
    plot(inter(3:end-2),frec(3:end-2),'.-')
    hold on
    minmax=get(gca,'ylim')
    plot([wakeg wakeg],minmax,'g--')
    plot([notwakeg notwakeg],minmax,'g--')
    ylabel('High Gamma','fontsize',16)
    figure
    title('high gamma vs EMG amp')
    plot(removepeaks(handles.powbands(3,:)),removepeaks(handles.emgpe),'k.')
    hold on
    plot(removepeaks(handles.powbands(3,indwa)),removepeaks(handles.emgpe(indwa)),'g.')
    plot(removepeaks(handles.powbands(3,indnrem)),removepeaks(handles.emgpe(indnrem)),'b.')
    plot(removepeaks(handles.powbands(3,indrem)),removepeaks(handles.emgpe(indrem)),'r.')
    
    figure
    title('rem pow vs EMG amp')
    plot(rempower,removepeaks(handles.emgpe),'k.')
    hold on
    plot(rempower(indwa),removepeaks(handles.emgpe(indwa)),'g.')
    plot(rempower(indnrem),removepeaks(handles.emgpe(indnrem)),'b.')
    plot(rempower(indrem),removepeaks(handles.emgpe(indrem)),'r.')
    
    %Auto scoring:
    %W is everything that has high EMG and low EEG
    %WA is everythng that has high EMG and also high EEG
    %NREM is everything that has high EEG, and low EMG
    %NA has too high EEG
    %REM has low EEG, low EMG and low delta/theta
    
    %close (f)
    %0:W, 0.1:WA, , 0.05:Systematic WA, 1:NR, 1.1:NRA, 2:R, 2.1:RA, -0.1:C1, -0.2:C2, -0.3:U
    %W
    indw=find((handles.emgpe>semgthres) & (handles.emgpe>wthres | ((handles.powbands(3,:)>wakeg) & handles.rms<notnrem)));
    %WA:
    indwa=indw(find((handles.rms(indw)>nrem) | (handles.powbands(1,indw)>nremd)));
    
    %NREM
    indnr=find(handles.emgpe<semgthres & (handles.powbands(3,:)<notwakeg) &((handles.rms>nrem) | (handles.powbands(1,:)>nremd)));
    
    %NREMA
    indna=indnr(find(handles.rms(indnr)>mthres));
    
    %REM
    indrem=find(handles.emgpe<semgthres & rempower>rem & handles.rms<notnrem & handles.powbands(1,:)<notnremd & handles.powbands(3,:)<notwakeg);
    newscore=nan(size(handles.score));
    newscore(indrem)=2;
    newscore(indw)=0;
    newscore(indwa)=0.1;
    newscore(indnr)=1;
    newscore(indna)=1.1;
    indsc=find(handles.validatedsc~=1);
    handles.score(indsc)=newscore(indsc);
    notsc=length(find(isnan(handles.score)));
    helpdlg(strcat('% scored:',num2str(100*(length(handles.score)-notsc)/length(handles.score))))


guidata(hObject, handles);



% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.rescore,'BackgroundColor',[0 1 0])
set(handles.stop,'BackgroundColor',[0.5 0 0])
handles.NOWscoring=0;
guidata(hObject, handles);

% --- Executes on selection change in raw_signals.
function raw_signals_Callback(hObject, eventdata, handles)
% hObject    handle to raw_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns raw_signals contents as cell array
%        contents{get(hObject,'Value')} returns selected item from raw_signals
handles.selchan=get(hObject,'Value');
guidata(hObject, handles);
plot_traces(handles);

% --- Executes during object creation, after setting all properties.
function raw_signals_CreateFcn(hObject, eventdata, handles)
% hObject    handle to raw_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmen

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in functions.
function functions_Callback(hObject, eventdata, handles)
% hObject    handle to functions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% Hints: contents = cellstr(get(hObject,'String')) returns functions contents as cell array
%        contents{get(hObject,'Value')} returns selected item from functions
contents = cellstr(get(hObject,'String'))
switch get(hObject,'Value')
    case 2
        %qEEG around stim
        %Assuming stim is on channel 1 and is marked by a negative
        %deflection. Inter stim interval >30 s
        %1- Detect stim times for first one every >30 s
        %2- Get average stim wave
        %3- Get RMS value of EEG nd EMG 30 s before and after first stim
        %for al epochs and for sleep/wake epochs pre-stim
        %4- make matrix for all epochs and sleep/wakre epochs
        %5- Run time/frequency anlysis using fieldtrip
        
        %1: Reading whole file looking for stim. Stim chan must be the
        %selected one
        nh=floor(handles.dur/3600);
        ltrace=round(600);%10 min chunks
        sr=handles.EDF.SampleRate(1);
        stimt=[];
        stimty=[];
        disp('Reading timings of stim...')
        if nh>0
            for i=0:(6*nh)-1%reading in 10 min. chunks except the last one
                [handles.EDF]=sdfclose(handles.EDF);
                handles.EDF=sdfopen(get(handles.filename,'string'));
                [handles.s,edfs]=sdfread(handles.EDF,ltrace,i*ltrace);
                stimtr=round(handles.s(:,handles.selchan));
                stimtrf=[0 stimtr(1:end-1)']';
                ind=find(stimtr>-4 & stimtrf<-4);
                tind=((ind/sr)+(i*ltrace))';
                indy=find(stimtr<4 & stimtrf>4);
                tindy=((indy/sr)+(i*ltrace))';
                stimt=[stimt tind];
                stimty=[stimty tindy];
            end
            startr=ceil(6*nh*ltrace);
            if handles.dur-startr>0
                [handles.s,edfs]=sdfread(handles.EDF,handles.dur-startr,startr);
                stimtr=handles.s(:,handles.selchan);
                stimtrf=[0 stimtr(1:end-1)']';
                ind=find(stimtr>-4 & stimtrf<-4);
                tind=((ind/sr)+(i*ltrace))';
                indy=find(stimtr<4 & stimtrf>4);
                tindy=((indy/sr)+(i*ltrace))';
                stimt=[stimt tind];
                stimty=[stimty tindy];
            else
                [handles.s,edfs]=sdfread(handles.EDF,inf);
                stimtr=handles.s(:,handles.selchan);
                stimtrf=[0 stimtr(1:end-1)']';
                ind=find(stimtr>-4 & stimtrf<-4);
                tind=((ind/sr)+(i*ltrace))';
                indy=find(stimtr<4 & stimtrf>4);
                tindy=((indy/sr)+(i*ltrace))';
                stimt=[stimt tind];
                stimty=[stimty tindy];
            end
        else
            [handles.EDF]=sdfclose(handles.EDF);
            handles.EDF=sdfopen(get(handles.filename,'string'));
            [handles.s,edfs]=sdfread(handles.EDF);
            stimtr=handles.s(:,handles.selchan);
            stimtrf=[0 stimtr(1:end-1)']';
            ind=find(stimtr>-4 & stimtrf<-4);
            tind=((ind/sr)+(i*ltrace))';
            indy=find(stimtr<4 & stimtrf>4);
            tindy=((indy/sr)+(i*ltrace))';
            stimt=[stimt tind];
            stimty=[stimty tindy];
        end
        firststim=stimt([find(diff(stimt)>30) length(stimt)]);%First stim is >30 s apart from the next one. Actually is the last stim in a train, thus the need to add the last by hand
        indystim=1+find(diff(stimty)<1);
        ystim=stimty(indystim);
        disp('Done.')
        %Now making matrix with EEG and EMG traces around stim
        Taround=45;%Time around stim to analyze
        EEGmatNR=[];
        EMGmatNR=[];
        EEGmatW=[];
        EMGmatW=[];
        EEGmatNR1st=[];
        EEGmatNR2nd=[];
        kW=0;
        kNR=0;
        kNR1st=0;
        kNR2nd=0;
        
        EEGmatNRy=[];
        EMGmatNRy=[];
        EEGmatWy=[];
        EMGmatWy=[];
        EEGmatNR1sty=[];
        EEGmatNR2ndy=[];
        kWy=0;
        kNRy=0;
        kNR1sty=0;
        kNR2ndy=0;
        for nstim=1:length(firststim)
            [handles.EDF]=sdfclose(handles.EDF);
            handles.EDF=sdfopen(get(handles.filename,'string'));
            [handles.s,edfs]=sdfread(handles.EDF,2*Taround,firststim(nstim)-Taround);
            if state(firststim(nstim),handles)==0 %& state(firststim(nstim)+handles.el,handles)==0 & state(firststim(nstim)+2*handles.el,handles)==0
                kW=kW+1;
                EEGmatW(:,kW)=handles.s(:,handles.cht);
                EMGmatW(:,kW)=handles.s(:,handles.chemg);
                stimmat(:,nstim)=handles.s(:,handles.selchan);
                
            end
            if state(firststim(nstim),handles)==1 %& state(firststim(nstim)+handles.el,handles)==1 & state(firststim(nstim)+2*handles.el,handles)==1
                kNR=kNR+1;
                EEGmatNR(:,kNR)=handles.s(:,handles.cht);
                EMGmatNR(:,kNR)=handles.s(:,handles.chemg);
                stimmat(:,nstim)=handles.s(:,handles.selchan);
                %latency to wake:
                sepocht=[handles.epocht(2:end) handles.epocht(end)+handles.el ];
                ce=find(firststim(nstim)>=handles.epocht & firststim(nstim)<sepocht);%current epoch
                indwa(kNR)=min(find(round(handles.score(ce:length(handles.score)))==0))-1;
                %duartion of the WA
                durwa(kNR)=0;
                while handles.score(ce+indwa(kNR)+durwa(kNR))==0
                    durwa(kNR)=durwa(kNR)+1;
                end
                if nstim<length(firststim)/2
                    kNR1st=kNR1st+1;
                    EEGmatNR1st(:,kNR1st)=handles.s(:,handles.cht);
                else
                    kNR2nd=kNR2nd+1;
                    EEGmatNR2nd(:,kNR2nd)=handles.s(:,handles.cht);
                end
            end
        end
        
        %now for yellow-only stim:
        for nstim=1:length(ystim)
            [handles.EDF]=sdfclose(handles.EDF);
            handles.EDF=sdfopen(get(handles.filename,'string'));
            [handles.s,edfs]=sdfread(handles.EDF,2*Taround,ystim(nstim)-Taround);
            if state(ystim(nstim),handles)==0 %& state(firststim(nstim)+handles.el,handles)==0 & state(firststim(nstim)+2*handles.el,handles)==0
                kWy=kWy+1;
                EEGmatWy(:,kWy)=handles.s(:,handles.cht);
                EMGmatWy(:,kWy)=handles.s(:,handles.chemg);
                stimmaty(:,nstim)=handles.s(:,handles.selchan);
                
            end
            if state(ystim(nstim),handles)==1 %& state(firststim(nstim)+handles.el,handles)==1 & state(firststim(nstim)+2*handles.el,handles)==1
                kNRy=kNRy+1;
                EEGmatNRy(:,kNRy)=handles.s(:,handles.cht);
                EMGmatNRy(:,kNRy)=handles.s(:,handles.chemg);
                stimmaty(:,nstim)=handles.s(:,handles.selchan);
                %latency to wake:
                sepocht=[handles.epocht(2:end) handles.epocht(end)+handles.el ];
                ce=find(ystim(nstim)>=handles.epocht & ystim(nstim)<sepocht);%current epoch
                indway(kNRy)=min(find(round(handles.score(ce:length(handles.score)))==0))-1;
                if nstim<length(ystim)/2
                    kNR1sty=kNR1sty+1;
                    EEGmatNR1sty(:,kNR1sty)=handles.s(:,handles.cht);
                else
                    kNR2ndy=kNR2ndy+1;
                    EEGmatNR2ndy(:,kNR2ndy)=handles.s(:,handles.cht);
                end
            end
        end
        figure;
        subplot(1,2,1);
        bar(indwa)
        subplot(1,2,2);
        bar(indway)
        
        aux=EEGmatW(:);
        save('EEGmatW.mat','aux')
        aux=EMGmatW(:);
        save('EMGmatW.mat','aux')
        aux=EEGmatNR(:);
        save('EEGmatNR.mat','aux')
        aux=EMGmatNR(:);
        save('EMGmatNR.mat','aux')
        if length(EEGmatNR1st)==0
            EEGmatNR1st=zeros(size(EEGmatNR,1),1);
        end
        aux=EEGmatNR1st(:);
        save('EEGmatNR1st.mat','aux')
        if length(EEGmatNR2nd)==0
            EEGmatNR2nd=zeros(size(EEGmatNR,1),1);
        end
        aux=EEGmatNR2nd(:);
        save('EEGmatNR2nd.mat','aux')
        alltrials=[EEGmatW(:); EEGmatNR(:)];
        save('alltrials.mat','alltrials')
        aux=EEGmatWy(:);
        save('EEGmatWy.mat','aux')
        aux=EMGmatWy(:);
        save('EMGmatWy.mat','aux')
        aux=EEGmatNRy(:);
        save('EEGmatNRy.mat','aux')
        aux=EEGmatNRy(:);
        save('EEGmatNRy.mat','aux')
        if length(EEGmatNR1sty)==0
            EEGmatNR1sty=zeros(size(EEGmatNR,1),1);
        end
        aux=EEGmatNR1sty(:);
        save('EEGmatNR1sty.mat','aux')
        if length(EEGmatNR2ndy)==0
            EEGmatNR2ndy=zeros(size(EEGmatNR,1),1);
        end
        aux=EEGmatNR2ndy(:);
        save('EEGmatNR2ndy.mat','aux')
        alltrialsy=[EEGmatWy(:); EEGmatNRy(:)];
        save('alltrialsy.mat','alltrialsy')
        %         figure;
        %         subplot(3,2,1)
        %plot(sem2d(EEGmat,sr))
        %plot(rms2d(EEGmat,sr)')
        %hold on
        %         bins=1;%duration of the bin in s
        %         plot(rms2d(EEGmatW,bins*sr)')
        %         hold on
        %         plot(mean(rms2d(EEGmatW,bins*sr)',2),'k.','linewidth',2)
        %         title('RMS EEG W')
        %         subplot(3,2,2)
        %         plot(rms2d(EEGmatNR,bins*sr)')
        %         hold on
        %         plot(mean(rms2d(EEGmatNR,bins*sr)',2),'k.','linewidth',2)
        %         title('RMS EEG NR')
        %         subplot(3,2,3)
        %         plot(rms2d(EMGmatW,bins*sr)')
        %         hold on
        %         plot(mean(rms2d(EMGmatW,bins*sr)',2),'k.','linewidth',2)
        %         title('RMS EMG W')
        %         subplot(3,2,4)
        %         plot(rms2d(EMGmatNR,bins*sr)')
        %         hold on
        %         plot(mean(rms2d(EMGmatNR,bins*sr)',2),'k.','linewidth',2)
        %         title('RMS EMG NR')
        %         subplot(3,2,5)
        %         x=0:size(stimmat,1)-1;
        %         x=x/sr;
        %
        %         plot(x,mean(round(stimmat),2),'k-','linewidth',1);
        %doing ERP and Heatmap:
        %clipboard('copy','2000 4500')
        if exist('ERPNR2ndyxx.edf')
            fn1='ERPWA.edf';
            fn2='ERPNR.edf';
            fn4='ERPNR2nd.edf';
            fn1y='ERPWAy.edf';
            fn2y='ERPNRy.edf';
            fn3y='ERPNR1sty.edf';
            fn4y='ERPNR2ndy.edf';
            fn5='alltrials.edf';
            fn5y='alltrialsy.edf';
        else
            eegout=pop_importdata('setname','ERPWA','data','EEGmatW.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatW),'srate',sr);
            %pop_erpimage(eegout,1);
            %         f=gca;
            %         set(f, 'Position', get(0,'Screensize')); % Maximize figure.
            clipboard('copy','ERPWA.edf')
            fn1='ERPWA.edf';
            pop_writeeeg(eegout);
            eegout=pop_importdata('setname','ERPNR','data','EEGmatNR.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatNR),'srate',sr);
            %         pop_erpimage(eegout,1);
            %         f=gca;
            %         set(f, 'Position', get(0,'Screensize')); % Maximize figure.
            clipboard('copy','ERPNR.edf')
            fn2='ERPNR.edf';
            pop_writeeeg(eegout);
            
            
            eegout=pop_importdata('setname','ERPNR1st','data','EEGmatNR1st.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatNR1st),'srate',sr);
            clipboard('copy','ERPNR1st.edf')
            fn3='ERPNR1st.edf';
            pop_writeeeg(eegout);
            
            eegout=pop_importdata('setname','ERPNR2nd','data','EEGmatNR2nd.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatNR2nd),'srate',sr);
            clipboard('copy','ERPNR2nd.edf')
            fn4='ERPNR2nd.edf';
            pop_writeeeg(eegout);
            
            eegout=pop_importdata('setname','alltrials','data','alltrials.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(alltrials),'srate',sr);
            clipboard('copy','alltrials.edf')
            fn5='alltrials.edf';
            pop_writeeeg(eegout);
            
            
            %now for yellow only:
            eegout=pop_importdata('setname','ERPWAy','data','EEGmatWy.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatWy),'srate',sr);
            %pop_erpimage(eegout,1);
            %         f=gca;
            %         set(f, 'Position', get(0,'Screensize')); % Maximize figure.
            clipboard('copy','ERPWAy.edf')
            fn1y='ERPWAy.edf';
            pop_writeeeg(eegout);
            eegout=pop_importdata('setname','ERPNRy','data','EEGmatNRy.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatNRy),'srate',sr);
            %         pop_erpimage(eegout,1);
            %         f=gca;
            %         set(f, 'Position', get(0,'Screensize')); % Maximize figure.
            clipboard('copy','ERPNRy.edf')
            fn2y='ERPNRy.edf';
            pop_writeeeg(eegout);
            
            eegout=pop_importdata('setname','ERPNR1sty','data','EEGmatNR1sty.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatNR1sty),'srate',sr);
            clipboard('copy','ERPNR1sty.edf')
            fn3y='ERPNR1sty.edf';
            pop_writeeeg(eegout);
            
            
            eegout=pop_importdata('setname','ERPNR2ndy','data','EEGmatNR2ndy.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(EEGmatNR2ndy),'srate',sr);
            clipboard('copy','ERPNR2ndy.edf')
            fn4y='ERPNR2ndy.edf';
            pop_writeeeg(eegout);
            
            eegout=pop_importdata('setname','alltrialsy','data','alltrialsy.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',length(alltrialsy),'srate',sr);
            clipboard('copy','alltrialsy.edf')
            fn5='alltrialsy.edf';
            pop_writeeeg(eegout);
            
        end
        
        %         winfft=2;
        %         stepfft=0.1;
        winfft=2;
        stepfft=0.1;
        maxftp=80;
        figure
        subplot(5,1,1)
        cfg = [];                                           % empty configuration
        cfg.dataset                 = fn1;       % name of CTF dataset
        cfg.trialdef.triallength=length(EEGmatW)/sr;
        cfg.trialdef.ntrials=round(size(EEGmatW,2)/2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname;
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 1 to 50 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 1 sec
        cfg.toi          = 0:stepfft:length(EEGmatW)/sr;                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatW = ft_freqanalysis(cfg, dataFIC);
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatW);
        title('Stim during W')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        %title('mtmconvol= multiplication in the frequency domain')
        %             set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1','1.5'})
        %             set(gca,'fontsize',14)
        %             title(strcat('Avg FFT ',fn(1:end-4),'_ch:',selchan))
        %             saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'fig');
        %             saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'jpg');
        %Now for NR
        subplot(5,1,2)
        cfg = [];                                           % empty configuration
        cfg.dataset  = fn2;       % name of CTF dataset
        cfg.trialdef.triallength=floor(length(EEGmatNR)/sr);
        cfg.trialdef.ntrials=size(EEGmatNR,2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 1 sec
        cfg.toi          = 0:stepfft:round(length(EEGmatNR)/sr);                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatNR = ft_freqanalysis(cfg, dataFIC);
        
        
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatNR);
        title('Stim during NREM')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        %Now for NR1st
        
        subplot(5,1,3)
        cfg = [];                                           % empty configuration
        cfg.dataset  = fn3;       % name of CTF dataset
        cfg.trialdef.triallength=floor(length(EEGmatNR1st)/sr);
        cfg.trialdef.ntrials=size(EEGmatNR1st,2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 2 sec
        cfg.toi          = 0:stepfft:round(length(EEGmatNR)/sr);                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatNR1st = ft_freqanalysis(cfg, dataFIC);
        
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatNR1st);
        title('Stim during NREM 1st half')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        %Now for NR2nd
        subplot(5,1,4)
        cfg = [];                                           % empty configuration
        cfg.dataset  = fn4;       % name of CTF dataset
        cfg.trialdef.triallength=floor(length(EEGmatNR2nd)/sr);
        cfg.trialdef.ntrials=size(EEGmatNR2nd,2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 1 sec
        cfg.toi          = 0:stepfft:round(length(EEGmatNR)/sr);                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatNR2nd = ft_freqanalysis(cfg, dataFIC);
        
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatNR2nd);
        title('Stim during NREM 2nd half')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        subplot(5,1,5)
        x=0:size(stimmat,1)-1;
        x=x/sr;
        stimtr=mean(round(stimmat),2);
        bluest=zeros(size(stimtr));
        yellowst=bluest;
        bluest(find(stimtr<-1))=5;
        yellowst(find(stimtr>1))=5;
        plot(x,yellowst,'r-','linewidth',1);
        hold on
        plot(x,bluest,'b-','linewidth',1);
        
        %%%%%%%%%%%%%%%%% NOW YELLOW %%%%%%%%%%%%%%%
        figure
        subplot(5,1,1)
        cfg = [];                                           % empty configuration
        cfg.dataset= fn1y;       % name of CTF dataset
        cfg.trialdef.triallength=length(EEGmatWy)/sr;
        cfg.trialdef.ntrials=round(size(EEGmatWy,2)/2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 1 sec
        cfg.toi          = 0:stepfft:length(EEGmatWy)/sr;                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatWy = ft_freqanalysis(cfg, dataFIC);
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatWy);
        title('Y.Stim during W')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        %title('mtmconvol= multiplication in the frequency domain')
        %             set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1','1.5'})
        %             set(gca,'fontsize',14)
        %             title(strcat('Avg FFT ',fn(1:end-4),'_ch:',selchan))
        %             saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'fig');
        %             saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'jpg');
        %Now for NR
        subplot(5,1,2)
        cfg = [];                                           % empty configuration
        cfg.dataset  = fn2y;       % name of CTF dataset
        cfg.trialdef.triallength=floor(length(EEGmatNRy)/sr);
        cfg.trialdef.ntrials=size(EEGmatNRy,2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 1 sec
        cfg.toi          = 0:stepfft:round(length(EEGmatNRy)/sr);                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatNRy = ft_freqanalysis(cfg, dataFIC);
        
        
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatNRy);
        title('Y.Stim during NREM')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        
        
        %Now for NR1st
        if length(EEGmatNR1sty)>0
            subplot(5,1,3)
            cfg = [];                                           % empty configuration
            cfg.dataset  = fn3y;       % name of CTF dataset
            cfg.trialdef.triallength=floor(length(EEGmatNR1sty)/sr);
            cfg.trialdef.ntrials=size(EEGmatNR1sty,2);
            cfg = ft_definetrial(cfg);
            cfg.continuous='yes';
            chname='Chan 1';%handles.hedf.Label;
            % while (chname(end)==' ')
            %     chname=chname(1:end-1);
            % end
            % preprocess the data
            cfg.channel   =chname
            cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
            dataFIC = ft_preprocessing(cfg);
            for kk=1:length(dataFIC.trial)
                dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
            end
            cfg              = [];
            cfg.output       = 'pow';
            cfg.channel      = chname;
            cfg.method       = 'mtmconvol';
            cfg.taper        = 'hanning';
            cfg.keeptrials = 'yes';
            cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
            cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 2 sec
            cfg.toi          = 0:stepfft:round(length(EEGmatNRy)/sr);                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
            TFRhannEEGmatNR1sty = ft_freqanalysis(cfg, dataFIC);
            
            %plotting heatmap
            xtimes=cfg.toi-3;
            cfg = [];
            cfg.baseline     = [0 Taround-5];
            cfg.baselinetype ='relative';
            %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
            cfg.channel      = chname;
            cfg.zlim = [0 3.5];
            cfg.colorbar='no'
            ft_singleplotTFR(cfg,TFRhannEEGmatNR1sty);
            title('Y.Stim during NREM 1st half')
            ylabel('Hz')
            xlabel('s')
            set(gca,'fontsize',14)
        end
        
        %Now for NR2nd
        subplot(5,1,4)
        cfg = [];                                           % empty configuration
        cfg.dataset  = fn4y;       % name of CTF dataset
        cfg.trialdef.triallength=floor(length(EEGmatNR2ndy)/sr);
        cfg.trialdef.ntrials=size(EEGmatNR2ndy,2);
        cfg = ft_definetrial(cfg);
        cfg.continuous='yes';
        chname='Chan 1';%handles.hedf.Label;
        % while (chname(end)==' ')
        %     chname=chname(1:end-1);
        % end
        % preprocess the data
        cfg.channel   =chname
        cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
        dataFIC = ft_preprocessing(cfg);
        for kk=1:length(dataFIC.trial)
            dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
        end
        cfg              = [];
        cfg.output       = 'pow';
        cfg.channel      = chname;
        cfg.method       = 'mtmconvol';
        cfg.taper        = 'hanning';
        cfg.keeptrials = 'yes';
        cfg.foi          = 0:2:maxftp;                         % analysis 2 to 30 Hz in steps of 2 Hz
        cfg.t_ftimwin    = ones(length(cfg.foi),1).*winfft;   % length of time window = 1 sec
        cfg.toi          = 0:stepfft:round(length(EEGmatNRy)/sr);                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
        TFRhannEEGmatNR2ndy = ft_freqanalysis(cfg, dataFIC);
        
        %plotting heatmap
        xtimes=cfg.toi-3;
        cfg = [];
        cfg.baseline     = [0 Taround-5];
        cfg.baselinetype ='relative';
        %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
        cfg.channel      = chname;
        cfg.zlim = [0 3.5];
        cfg.colorbar='no'
        ft_singleplotTFR(cfg,TFRhannEEGmatNR2ndy);
        title('Y. Stim during NREM 2nd half')
        ylabel('Hz')
        xlabel('s')
        set(gca,'fontsize',14)
        subplot(5,1,5)
        x=0:size(stimmat,1)-1;
        x=x/sr;
        stimtr=mean(round(stimmat),2);
        bluest=zeros(size(stimtr));
        yellowst=bluest;
        bluest(find(stimtr<-1))=5;
        yellowst(find(stimtr>1))=5;
        plot(x,yellowst,'r-','linewidth',1);
        hold on
        plot(x,bluest,'r-','linewidth',1);
        
        %%%%%%%%%%%%%%%DONE%%%%%%%%%%%%%%%%%%%%%%
        
        
        
        %         %now the heatmap of all the trace
        startp=firststim(1)-Taround;
        endp=firststim(end)+Taround;
        %         [v,ep0]=min(abs(handles.epocht-startp));
        %         [v,epf]=min(abs(handles.epocht-endp));
        %         %initializing matrices with the power spectrum
        %         maxfrec=100;
        %         nEDF=sdfopen(handles.fn);
        %         winlen=2;%FFT every 2 s, no overlapping
        %         [eegtrace,edfs]=sdfread(nEDF,winlen,1);
        %         %[nEDF]=sdfclose(nEDF);
        %         aux=getthepower(eegtrace(:,handles.selchan),winlen,maxfrec,0);
        %         N = length(eegtrace); %% number of points
        %         T = winlen; %% define time of interval
        %         t = [0:N-1]/N; %% define time
        %         t = t*T; %% define time in seconds
        %         freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
        %         freq=freq(1:length(aux));
        %         k=0;
        %         %nEDF=sdfopen(handles.fn);
        %         matheatmap=zeros(ceil((endp-startp)/winlen),length(aux));
        %         [nEDF]=sdfclose(nEDF);
        %         nEDF=sdfopen(handles.fn);
        %         for currpos=startp:winlen:endp
        %             [eegtrace,edfs]=sdfread(nEDF,winlen,currpos);
        %             aux2=getthepower(1000*eegtrace(:,handles.cht),winlen,maxfrec,0);
        %             k=k+1;
        %             matheatmap(k,:)=aux2;
        %         end
        figure
        [v,epoch0]=min(abs(handles.epocht-startp));
        [v,epochf]=min(abs(handles.epocht-endp));
        %plotting hypnogram
        zti=5;
        zt0=get(handles.edit4,'string');
        %subplot(8,1,1)
        %plot(handles.EDF.T0(4)+(handles.EDF.T0(5)/60)+(handles.EDF.T0(6)/3600)-str2double(zt0(1:2))-(str2double(zt0(4:5))/60)-(str2double(zt0(7:7))/3600)+(startp/3600)+(handles.epocht(epoch0:epochf)/3600),round(handles.score(epoch0:epochf)),'k-','linewidth',1.5);
        %plot(5+(handles.epocht(epoch0:epochf)/3600),round(handles.score(epoch0:epochf)),'k-','linewidth',1.5);
        figure
        x=(0:length(handles.score)-1)*handles.el;
        plot(5+x/3600,handles.score,'k-','linewidth',1.5);
        axis tight;
        minmax=get(gca,'ylim');
        xl=get(gca,'xlim')
        hold on
        %plot([xl(1)+(firststim-firststim(1))/3600; xl(1)+(firststim-firststim(1))/3600]',[minmax]','g--','linewidth',0.7)
        
        set(gca,'YTick',[0 1 2])
        set(gca,'YTicklabel',{'W','NREM','REM'})
        box off
        set(gca,'fontsize',14)
        xlabel('ZT (Hours)','fontsize',16)
        %         figure
        %         %changing the range of heatmap to [0 64]
        %         minhm=min(min(matheatmap));
        %         maxhm=max(max(matheatmap));
        %         matheatmap=matheatmap-minhm;
        %         matheatmap=matheatmap/(maxhm-minhm);
        %         matheatmap=matheatmap*64;
        %         %shifting heatmap so the plot saturates at 99% of max val
        %         v=sort(matheatmap(:));
        %         chosen_val=v(round(0.99*length(v)));
        %         fact=64/chosen_val;
        %         matheatmap=fact*matheatmap;
        %         image(matheatmap');
        %         axis xy
        %         colormap('jet')
        %         minmax=get(gca,'xlim')
        %         %set(gca,'xlim',0.1*round(minmax.*10));
        %         %minmax=get(gca,'xlim');
        %         %oldxax=get(gca,'XTick');
        %
        %         set(gca,'XTick',[min(minmax):30:max(minmax)]);
        %         xlabl=str2num(get(gca,'Xticklabel'));
        %         %set(gca,'Xticklabel',num2str(0.1*round(10*seg2zt(winlen*xlabl+startp,handles))));
        %         set(gca,'Xticklabel',num2str(0.1*round(10*(winlen*xlabl))));
        %         ylabl=str2num(get(gca,'Yticklabel'))
        %         set(gca,'Yticklabel',num2str(ylabl/10))
        %         xlabel('ZT (hours)','fontsize',21)
        %         ylabel('Hz','fontsize',21)
        %         %adding a stim bar
        %         %             hold on
        %         %             plot([70 160]',[([(firststim-firststim(1))/winlen]-firststim(1))' ([(firststim-firststim(1))/winlen])'],'w-','linewidth',1)
        %         %title('Heatmap')
        %         set(gca,'fontsize',14)
        %         c=colorbar;
        %         ylablcb=str2num(get(c,'Yticklabel'));
        %         set(c,'Yticklabel',num2str(0.1*round(10*((ylablcb./64)*(maxhm-minhm)+minhm))));
        %         set(gca,'fontsize',14)
        %To add:
        %ploting histogram of the duration of the WA after stim during NREM
        figure;
        hist(durwa,10)
        xlabel('No of epochs')
        ylabel('Frequency')
        
        %saving data:
        scored=handles.score;
        eptime=handles.epocht;
        el=handles.el;
        fnd=strcat(handles.EDF.FileName(1:end-4),'data.mat')
        if length(EEGmatNR1sty)>0
            save(fnd,'Taround','winfft','stepfft','maxftp','TFRhannEEGmatNR2ndy','TFRhannEEGmatNR1sty','TFRhannEEGmatNR2nd','TFRhannEEGmatNR1st','TFRhannEEGmatNRy','TFRhannEEGmatNR','TFRhannEEGmatWy','TFRhannEEGmatW',...
                'EEGmatW','EMGmatW','EEGmatNR','EEGmatNR','EEGmatNR1st','EEGmatNR2nd','EEGmatWy','EEGmatNRy','EEGmatNR1sty','EEGmatNR2ndy','scored','stimmat','stimmaty','firststim','ystim','eptime','indwa','indway','el','durwa');
        else
            save(fnd,'Taround','winfft','stepfft','maxftp','TFRhannEEGmatNR2ndy','TFRhannEEGmatNR2nd','TFRhannEEGmatNR1st','TFRhannEEGmatNRy','TFRhannEEGmatNR','TFRhannEEGmatWy','TFRhannEEGmatW',...
                'EEGmatW','EMGmatW','EEGmatNR','EEGmatNR','EEGmatNR1st','EEGmatNR2nd','EEGmatWy','EEGmatNRy','EEGmatNR2ndy','scored','stimmat','stimmaty','firststim','ystim','eptime','indwa','indway','el','durwa');
        end
    case 3
        %plots the example displayed in the screen
        figure
        subplot (9,1,[1:4])
        %getting the max in the slider
        nchtp=length(handles.selchan);%number of channels to plot
        for i=1:nchtp
            selchan=handles.selchan(i);
            handles.x=handles.ltrace*(0:length(handles.s(:,selchan))-1)/(length(handles.s(:,selchan))-1);
            handles.x=handles.x+handles.t0;
            if selchan==1 & handles.cht==2
                handles.s(:,selchan)=handles.s(:,selchan)*0.4*1E-4;
            end
            if selchan==2 & size(handles.s,2)>2 & ~get(handles.dsi,'value')
                plot(handles.x,(handles.distance*(i-1)*std(handles.s(:,handles.selchan(1))))+(handles.s(:,1)-handles.s(:,3)),'k-')
            else
                plot(handles.x,(handles.distance*(i-1)*2*std(handles.s(:,handles.selchan(1))))+handles.s(:,selchan),'k-')
            end
            %plot(handles.x,handles.s(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.raw_signals,'value')))
            axis tight
            if selchan==handles.cht
                set(gca,'ylim',[-handles.eegrange handles.eegrange])
            end
        end
        xi=handles.x(1);
        xf=handles.x(end);
        minmax=get(gca,'ylim');
        p=find(handles.epocht>=xi);%(xi/handles.sr(selchan)));
        firstep=p(1);
        p=find(handles.epocht<=xf);%;(xf/handles.sr(selchan)));
        lastep=p(end);
        hold on
        plot([handles.epocht(firstep:lastep)' handles.epocht(firstep:lastep)'],minmax,'g--')
        %writing the scoring
        posytxt=minmax(1)+0.95*(minmax(2)-minmax(1));
        posxtxt=0.05*handles.el;
        for i=firstep:lastep
            %  text(handles.epocht(i)+posxtxt,posytxt,strcat('EMG:',num2str(handles.emgpe(i)),scr2txt(handles.score(i))),'fontsize',14,'color','r');
            if handles.validatedsc(i)==1
                text(handles.epocht(i)+posxtxt,posytxt,scr2txt(handles.score(i)),'fontsize',14,'color','r');
            else
                text(handles.epocht(i)+posxtxt,posytxt,scr2txt(handles.score(i)),'fontsize',14,'color','g');
            end
            
        end
        scalebar(2,2E-4)
        %Now plot MT
        
        subplot(9,1,[5:8])
        cla
        plot(handles.x,(handles.s(:,handles.chemg))-mean(handles.s(:,handles.chemg)),'k-')
        axis tight
        if get(handles.fixEMG,'value')
            set(gca,'ylim',handles.limemg)
        end
        axis tight
        scalebar(2,1E-4)
        %now the stim
        subplot(9,1,9)
        stim=round(handles.s(:,1));
        b=zeros(size(stim));
        y=zeros(size(stim));
        b(find(stim<0))=1;
        y(find(stim>0))=1;
        plot(handles.x,y,'y-')
        hold on
        plot(handles.x,b,'b-')
        axis tight
        scalebar(2,1)
end

% --- Executes during object creation, after setting all properties.
function functions_CreateFcn(hObject, eventdata, handles)
% hObject    handle to functions (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lengthtrace_Callback(hObject, eventdata, handles)
% hObject    handle to lengthtrace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lengthtrace as text
%        str2double(get(hObject,'String')) returns contents of lengthtrace as a double
if isfield (handles,'el')
    if str2double(get(handles.lengthtrace,'string'))<handles.el
        set(handles.lengthtrace,'string',num2str(handles.el))
    end
    handles.ltrace=min(240,str2double(get(handles.lengthtrace,'string')));
    handles.tf=handles.t0+handles.ltrace;
    [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
    robot = java.awt.Robot;
    pos = get(handles.axes1, 'Position');
    set(0, 'PointerLocation', [pos(1:2)+100]);
    robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
    robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);
    
    guidata(hObject, handles);
    plot_traces(handles)
end
% --- Executes during object creation, after setting all properties.
function lengthtrace_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lengthtrace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in stats.
function stats_Callback(hObject, eventdata, handles)
% hObject    handle to stats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%getting the Nepochs by state
np=str2num(get(handles.nperiods,'string'));
if np>1
    for i=1:np
        prompt{2*i-1}=strcat('Start P',num2str(i))
        prompt{2*i}=strcat('End P',num2str(i))
    end
    name='Enter start and end times';
    numlines=1;2*np;
    defaultanswer={'0','3600','18000','21600','39600','43200'};
    answer=str2num(char(inputdlg(prompt,name,numlines,defaultanswer)));
    startsec=answer(1:2:end);
    endsec=answer(2:2:end);
    indwa=[];
    indnr=[];
    indr=[];
    indawa=[];
    indanr=[];
    indar=[];
    for i=1:np %building the indexes of the epochs across all periods
        [v,startep(i)]=min(abs(handles.epocht-startsec(i)));
        [v,endep(i)]=min(abs(handles.epocht-endsec(i)));
        indawa=[indawa startep(i)-1+find(handles.score(startep(i):endep(i))>=0 & handles.score(startep(i):endep(i))<1)];
        indanr=[indanr startep(i)-1+find(handles.score(startep(i):endep(i))>=1 & handles.score(startep(i):endep(i))<2)];
        indar=[indar startep(i)-1+find(handles.score(startep(i):endep(i))>=2)];
        indwa=[indwa startep(i)-1+find(handles.score(startep(i):endep(i))==0)];
        indnr=[indnr startep(i)-1+find(handles.score(startep(i):endep(i))==1)];
        indr=[indr startep(i)-1+find(handles.score(startep(i):endep(i))==2)];
    end
else
startsec=str2double(get(handles.startp,'string'));
endsec=str2double(get(handles.endp,'string'));
[v,startep]=min(abs(handles.epocht-startsec));
[v,endep]=min(abs(handles.epocht-endsec));

%indexes with artifacts
indawa=startep-1+find(handles.score(startep:endep)>=0 & handles.score(startep:endep)<1);
indanr=startep-1+find(handles.score(startep:endep)>=1 & handles.score(startep:endep)<2);
indar=startep-1+find(handles.score(startep:endep)>=2);

%indexes without artifacts
indwa=startep-1+find(handles.score(startep:endep)==0);
indnr=startep-1+find(handles.score(startep:endep)==1);
indr=startep-1+find(handles.score(startep:endep)==2);

end
%Calculating stats: Percentage in each state, distribution of bout lenghts,
%power spect by state and Heatmap.3876-7416
if length(indawa)<2
    boutwa=0;
else
    boutwa=getbout(indawa)*handles.el;
end
if length(indanr)<2 %This is not the right way to fix this
    boutnr=0;
else
    boutnr=getbout(indanr)*handles.el;
end
if length(indar)<2
    boutr=0;
else
    boutr=getbout(indar)*handles.el;
end

figure
subplot (4,3,[4 7 10])
neps=length(indwa)+ length(indnr)+ length(indr);
bar(100*[length(indwa)/neps length(indnr)/neps length(indr)/neps]);
set(gca,'fontsize',14)
set(gca,'xticklabel',{'WA','NR','REM'})
title('% Time','fontsize',21)
box off

subplot (4,3,[4 7 10]+1)
bar([mean(boutwa) mean(boutnr) mean(boutr)]);
set(gca,'xticklabel',{'WA','NR','REM'})
set(gca,'fontsize',14)
title('Mean Bout Duration (s)','fontsize',21)
box off

%Calculating the average FFT by state from channels 1, 3 and 1-3:
%edit 3 and edit 2 have the start and end of the period under stimulation

%initializing matrices with the power spectrum
maxfrec=20;
nEDF=sdfopen(handles.fn);
[eegtrace,edfs]=sdfread(nEDF,handles.el,1);
%[nEDF]=sdfclose(nEDF);
aux=getthepower(eegtrace(:,handles.selchan),handles.el,maxfrec,0);
N = length(eegtrace); %% number of points
T = handles.el; %% define time of interval, 3.4 seconds
t = [0:N-1]/N; %% define time
t = t*T; %% define time in seconds
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
freq=freq(1:length(aux));

kWA=0;kNR=0;kREM=0;k=0;
%nEDF=sdfopen(handles.fn);
if get(handles.do_all,'value')
    newep0=1;
    newepf=handles.nepochs-2;
else
    newep0=startep;
    newepf=endep;
end

matpowerWA=zeros(length(indwa),length(aux));
matpowerNR=zeros(length(indnr),length(aux));
matpowerREM=zeros(length(indr),length(aux));

if np==1 
    matheatmap=zeros(newepf-newep0+1,length(aux));
end
vecep=[];
for i=1:np
    vecep=[vecep startep(i):endep(i)];
end
for currep=vecep
    [nEDF]=sdfclose(nEDF);
    nEDF=sdfopen(handles.fn);
    [eegtrace,edfs]=sdfread(nEDF,handles.el,handles.epocht(currep));
    %     if handles.selchan==2
    %         aux2=getthepower(1000*(eegtrace(:,1)-eegtrace(:,3)),handles.el,maxfrec,0);
    %     else
    aux2=getthepower((10^6)*eegtrace(:,handles.selchan),handles.el,maxfrec,0);%In microvolts
    %     end
    
    if handles.score(currep)==0
        kWA=kWA+1;
        matpowerWA(kWA,:)=aux2;
    end
    if handles.score(currep)==1
        kNR=kNR+1;
        matpowerNR(kNR,:)=aux2;
    end
    if handles.score(currep)==2
        kREM=kREM+1;
        matpowerREM(kREM,:)=aux2;
    end
    k=k+1;
    matheatmap(k,:)=aux2;
end
subplot (4,3,[4 7 10]+2)
plot(freq,mean(matpowerWA),'k-','linewidth',2);
box off
hold on
plot(freq,mean(matpowerNR),'b-','linewidth',2);
xlabel('Hz','fontsize',21)

plot(freq,mean(matpowerREM),'r-','linewidth',2);
set(gca,'fontsize',14)
xlabel('Frequency (Hz)','fontsize',21)
box off
ylabel('Power (\muV^2)','fontsize',21)
legend('W','NR','REM')

subplot (4,3,1:3)
zt0=get(handles.edit4,'string');
plot(handles.EDF.T0(4)+(handles.EDF.T0(5)/60)+(handles.EDF.T0(6)/3600)-str2double(zt0(1:2))-(str2double(zt0(4:5))/60)-(str2double(zt0(7:7))/3600)+(handles.epocht(newep0(1))/3600)+(handles.epocht(vecep)/3600),round(handles.score(vecep)),'k-','linewidth',1.5);
set(gca,'YTick',[0 1 2])
set(gca,'YTicklabel',{'W','NREM','REM'})
box off
set(gca,'fontsize',14)
xlabel('ZT (Hours)','fontsize',16)
figure
%changing the range of heatmap to [0 64]
% minhm=min(min(matheatmap));
% maxhm=max(max(matheatmap));
% matheatmap=matheatmap-minhm;
% matheatmap=matheatmap/(maxhm-minhm);
% matheatmap=matheatmap*64;
% %shifting heatmap so the plot saturates at 99% of max val
% v=sort(matheatmap(:));
% chosen_val=v(round(0.99*length(v)));
% fact=64/chosen_val;
% matheatmap=fact*matheatmap;
% image(matheatmap');
% axis xy
% colormap('jet')
% minmax=get(gca,'xlim')
% set(gca,'xlim',0.1*round(minmax.*10));
% minmax=get(gca,'xlim');
% set(gca,'XTick',[min(minmax):(minmax(2)-minmax(1))/10:max(minmax)]);
% xlabl=str2num(get(gca,'Xticklabel'));
% %each x point is one epoch
% 
% set(gca,'Xticklabel',num2str(0.1*round(10*ep2zt(10*xlabl+handles.epocht(newep0),handles))));
% ylabl=str2num(get(gca,'Yticklabel'))
% set(gca,'Yticklabel',num2str(ylabl/10))
% xlabel('ZT (hours)','fontsize',21)
% ylabel('Hz','fontsize',21)
% 
% %adding a stim bar
% if get(handles.do_all,'value')
%     hold on
%     plot(6*[startp/60 endp/60],[5 5],'w-','linewidth',3)
% end
% %title('Heatmap')
% set(gca,'fontsize',14)
% c=colorbar;
% ylablcb=str2num(get(c,'Yticklabel'));
% set(c,'Yticklabel',num2str(0.1*round(10*((ylablcb./64)*(maxhm-minhm)+minhm))));
% set(gca,'fontsize',14)
%saving data
fndata=strcat(handles.fn(1:end-4),'_',num2str(startsec(1)),'_',num2str(endsec(end)),'_',num2str(np),'_periods','_data.mat');
sc=handles.score;
pwa=100*length(indwa)/neps;
pnr=100*length(indnr)/neps;
pr=100*length(indr)/neps;

mboutwa=mean(boutwa);mboutnr=mean(boutnr);mboutr=mean(boutr);
save(fndata,'zt0','sc','pwa','pnr','pr','startsec','endsec','matpowerWA','matpowerNR','matpowerREM','freq','mboutwa','mboutnr','mboutr')
helpdlg('Data file saved')
[nEDF]=sdfclose(nEDF);
%Now the power spectra


%ylabel('mV^2')

function newt=ep2zt(time_points,handles)
%Convert a set of time points in sec. to their respective ZT times in hours
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
aux2=h0+(time_points/3600);
newt=mod(aux2-zt0,24);

function newt=seg2zt(time_points,handles)
%Convert a set of time points in sec. to their respective ZT times in hours
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
aux2=h0+(time_points/3600);
newt=mod(aux2-zt0,24);


% --- Executes on button press in calcsignals.
function calcsignals_Callback(hObject, eventdata, handles)
% hObject    handle to calcsignals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.nsr=25;%subsampling slected channel and getting his RMS value in 2 s bins.
ct=1/handles.nsr;%time point at the begining of the read operation
disp('Subsampling trace at 25  Hz')
%initialize matrices
aux=zeros(1,nsec*handles.nsr);
%newsig=[];
newsig=zeros(EDF.NS,handles.dur*handles.nsr);
%builds new signal
k=0;
tic
while ct<handles.dur
    if k==0
        [aux,edfs]=sdfread(EDF,round(nsec),0);
    else
        [aux,edfs]=sdfread(EDF,round(nsec),ct);
    end
    newsig=[newsig;aux];
    ct=ct+nsec;
    if ct>=handles.dur
        ct=handles.dur;
    end
    k=k+1;
    %     if (k/10)-round(k/10)==0
    %         disp((handles.dur/60)-(ct/60))
    %     end
end
toc

handles.ls=length(handles.s);
handles.selchan=1;%get(handles.chanlist,'value');
handles.sr=edfs.SampleRate;

%Now subsampling at 30 Hz:
news=subsam(handles.s(:,handles.selchan),handles.sr(handles.selchan),30);
% handles.s=news;
% handles.sr=30;

set(handles.text6,'string',num2str(handles.sr(handles.selchan)));
handles.hto=EDF.T0(4);%initial hour
handles.mto=EDF.T0(5);%initial minute
handles.sto=EDF.T0(6);%initial second
set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));

%handles.ltrace=length(handles.s(:,handles.selchan))/handles.sr(handles.selchan);%total length in s
handles.x=handles.ltrace*(0:length(handles.s(:,handles.selchan))-1)/(length(handles.s(:,handles.selchan))-1);
handles.xi=1/handles.sr(handles.selchan);
xlabel('s','fontsize',14)
%set(handles.slider1,'max',tl);
%getting the max in the slider
axes(handles.axes1)

ti=0;
tf=ti+str2double(get(handles.lengthtrace,'string'));
[v,xi]=min(abs(handles.x-ti));
[v,xf]=min(abs(handles.x-tf));
plot(handles.x(xi:xf),handles.s(xi:xf,handles.selchan),'k-')

%plot(handles.x,handles.s(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.raw_signals,'value')))
axis tight


set(handles.filename,'string',filename);


guidata(hObject, handles);


% --- Executes on button press in dsi.
function dsi_Callback(hObject, eventdata, handles)
% hObject    handle to dsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dsi


% --- Executes on button press in rev_hf.
function rev_hf_Callback(hObject, eventdata, handles)
% hObject    handle to rev_hf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rev_hf
plot_traces(handles);

% --- Executes on button press in smart_score.
function smart_score_Callback(hObject, eventdata, handles)
% hObject    handle to smart_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smart_score


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6


% --- Executes on button press in do_all.
function do_all_Callback(hObject, eventdata, handles)
% hObject    handle to do_all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of do_all


% --- Executes on button press in mt.
function mt_Callback(hObject, eventdata, handles)
% hObject    handle to mt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mt


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9


% --- Executes on scroll wheel click while the figure is in focus.
function figure1_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)
l=str2double(get(handles.lengthtrace,'string'));
if eventdata.VerticalScrollCount==1
    if l>5
        set(handles.lengthtrace,'string',num2str(round(l-5)))
    end
else
    if l<handles.dur
        set(handles.lengthtrace,'string',num2str(min(handles.dur,round(l+5))))
    end
end
guidata(hObject, handles);


function endp_Callback(hObject, eventdata, handles)
% hObject    handle to endp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endp as text
%        str2double(get(hObject,'String')) returns contents of endp as a double


% --- Executes during object creation, after setting all properties.
function endp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startp_Callback(hObject, eventdata, handles)
% hObject    handle to startp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startp as text
%        str2double(get(hObject,'String')) returns contents of startp as a double


% --- Executes during object creation, after setting all properties.
function startp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%
% % --- Executes on key press with focus on figure1 or any of its controls.
% function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% % hObject    handle to figure1 (see GCBO)
% % eventdata  structure with the following fields (see FIGURE)
% %	Key: name of the key that was pressed, in lower case
% %	Character: character interpretation of the key(s) that was pressed
% %	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% % handles    structure with handles and user data (see GUIDATA)
% set(handles.text8,'BackgroundColor',[1 0 0])
% set(handles.text8,'string','Reading File')
% handles.EDF=sdfopen(get(handles.filename,'string'));
% %handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
%
% switch eventdata.Key
%
%     case 'rightarrow'
%         handles.ce=min(handles.ce+1,handles.nepochs);
%         %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
%         handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
%         handles.tf=handles.t0+handles.ltrace;
%         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
%         guidata(hObject, handles);
%         plot_traces(handles);
%     case 'leftarrow'
%         handles.ce=(max(1,handles.ce-1));
%         handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
%         disp('t0=')
%         disp(handles.t0)
%         disp('CEpoch=')
%         disp(handles.ce)
%         handles.tf=handles.t0+handles.ltrace;
%         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
%         guidata(hObject, handles);
%         plot_traces(handles);
% end
% %disp(handles.ce)
%pause(0.01);
% set(handles.text8,'BackgroundColor',[0 1 0])
% set(handles.text8,'string','Ready')
%





function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text

%        str2double(get(hObject,'String')) returns contents of edit6 as a double
handles.ce=str2double(get(hObject,'String'));
robot = java.awt.Robot;
pos = get(handles.axes1, 'Position');
set(0, 'PointerLocation', [pos(1:2)+100]);
robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key release with focus on figure1 or any of its controls.
function figure1_WindowKeyReleaseFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was released, in lower case
%	Character: character interpretation of the key(s) that was released
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) released
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'s')
    %iscore('figure1_WindowKeyReleaseFcn',hObject,eventdata,guidata(hObject))
    set(handles.text8,'BackgroundColor',[1 0 0])
    set(handles.text8,'string','Reading File')
    %if isfield(handles,'EDF')
    % handles.EDF=sdfclose(handles.EDF);
    % handles.EDF=sdfopen(get(handles.filename,'string'));
    %handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
    %This will display a cross at the cursor and disable the keypress to avoid crashing
    ltrace=str2num(get(handles.lengthtrace,'string'));
    
    datacursormode on
    switch eventdata.Key
        
        case 'rightarrow'
            
            handles.ce=(min(handles.nepochs,handles.ce+1));
            handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            
            
            
            
            
            %         handles.ce=min(handles.ce+1,handles.nepochs);
            %         %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
            %         handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            %         handles.tf=handles.t0+handles.ltrace;
            %         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            %         guidata(hObject, handles);
            %         plot_traces(handles);
        case 'leftarrow'
            
            handles.ce=(max(1,handles.ce-1));
            handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            
            
        case 'uparrow'
            
            handles.ce=min(handles.ce+floor(handles.ltrace/handles.el),handles.nepochs);
            %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+(floor(handles.ltrace/handles.el)*handles.el));
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            
            
        case 'downarrow'
            
            handles.ce=(max(1,handles.ce-floor(handles.ltrace/handles.el)));
            handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            
            %now for the scoring:
            %0:W, 0.1:WA, , 0.05:Systematic WA, 1:NR, 1.1:NRA, 2:R, 2.1:RA, -0.1:C1, -0.2:C2, -0.3:U
            
        case 'numpad7'
            handles.score(handles.ce)=1.1;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
            
        case 'numpad8'
            handles.score(handles.ce)=2.1;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
            
        case 'numpad9'
            handles.score(handles.ce)=0.1;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
           if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
        case 'numpad4'
            handles.score(handles.ce)=-0.1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
            
        case 'numpad5'
            handles.score(handles.ce)=2;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
            
        case 'numpad6'
            handles.score(handles.ce)=-0.3;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
        case 'numpad1'
            handles.score(handles.ce)=1;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
        case 'numpad2'
            handles.score(handles.ce)=-0.2;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
        case 'numpad3'
            handles.score(handles.ce)=2;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
        case 'numpad0'
            handles.score(handles.ce)=0;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            
            
        case 'decimal'
            handles.score(handles.ce)=0.05;
            handles.validatedsc(handles.ce)=1;
            handles.ce=min(handles.ce+1,handles.nepochs);
            handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            if get(handles.smart_score,'value')
                handles.ce=min(find(isnan(handles.score)));
                handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            end
            
        case 'v'
            handles.validatedsc(handles.ce)=1;
            handles.ce=(min(handles.nepochs,handles.ce+1));
            handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
            
        case 'n'
            handles.ce=min(find(isnan(handles.score)));
            handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
            handles.tf=handles.t0+handles.ltrace;
            dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
            aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
            handles.s=aux(1:round(handles.ltrace*handles.sr),:);
            %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
         case 'a'
             if get(handles.smart_score,'value')
                 set(handles.smart_score,'value',0)
             else
                 set(handles.smart_score,'value',1)
             end
            
    end
    guidata(hObject, handles);
    plot_traces(handles);
            
    %disp(handles.ce)
    set(handles.edit6,'string',num2str(handles.ce))
    % axes(handles.axes3)
    % cla
    % plot([(handles.epocht(handles.ce)/3600) (handles.epocht(handles.ce))/3600],[0 2],'r.-')
    % box off
    % hold on
    % plot(handles.epocht/3600,handles.score,'k-')
    % axis tight
    % set(gca,'xcolor','g')
    %
    %pause(0.01);
    axes(handles.axes1)
    %plot_traces(handles)
    set(handles.text8,'BackgroundColor',[0 1 0])
    set(handles.text8,'string','Ready')
    datacursormode off
end
%guidata(hObject, handles);



% --- Executes on button press in savescore.
function savescore_Callback(hObject, eventdata, handles)
% hObject    handle to savescore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'.mat');
k=0;
backupfn=fn;
while exist(backupfn)
    k=k+1;
    backupfn=get(handles.filename,'string');
    backupfn=strcat(fn(1:end-4),'_',num2str(k),'.mat');
end
if k>0
    copyfile(fn,backupfn)
end

if isnan(handles.score(end))
    handles.score(end)=handles.score(end-1);
end
startp=str2double(get(handles.startp,'string'));
endp=str2double(get(handles.endp,'string'));
sc=handles.score;
vali=handles.validatedsc;
scalefft=get(handles.limemg2,'string');
zt0=get(handles.edit4,'string');
rangefft=handles.emgscale;
epocl=handles.el;
save(fn,'sc','vali','startp','endp','zt0','scalefft','rangefft','epocl');
helpdlg('Score saved')

% --- Executes on button press in loadscore.
function loadscore_Callback(hObject, eventdata, handles)
% hObject    handle to loadscore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'_BL.mat');
if isnan(handles.score(end))
    handles.score(end)=handles.score(end-1);
end
startp=str2double(get(handles.startp,'string'));
endp=str2double(get(handles.endp,'string'));
sc=handles.score;
vali=handles.validatedsc;
scalefft=get(handles.limemg2,'string');
zt0=get(handles.edit4,'string');
rangefft=handles.emgscale;
epocl=handles.el;
save(fn,'sc','vali','startp','endp','zt0','scalefft','rangefft','epocl');

fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'.mat');
dat=load(fn);
if isfield(dat,'scalefft')
    set(handles.limemg2,'string',dat.scalefft);
    set(handles.edit4,'string',dat.zt0);
    handles.emgscale=dat.rangefft;
end
if isfield(dat,'epocl')
    handles.el=dat.epocl;
    if handles.el~=str2num(get(handles.edit7,'string'));
        set(handles.edit,'string',num2str(dat.epocl));
        handles.nepochs=floor(handles.dur/handles.el);
        handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
        
    end
end

handles.score(1:length(dat.sc))=dat.sc;
handles.validatedsc(1:length(dat.vali))=dat.vali;
if isfield(dat,'endp')
    set(handles.endp,'string',num2str(dat.endp));
    set(handles.startp,'string',num2str(dat.startp));
end
handles.ce=1;
helpdlg('Score loaded')
if exist('imagingtime.mat') & get(handles.checkbox10,'value') %loading sync signal with onset and ofset of imaging
    imgt=load('imagingtime.mat')
    handles.stimoff=imgt.stopimg;
    handles.stimon=imgt.startimg;
    handles.origimgon=handles.stimon;
    handles.origimgoff=handles.stimoff;
end
guidata(hObject, handles);
plot_traces(handles);


% --- Executes on button press in goto.
function goto_Callback(hObject, eventdata, handles)
% hObject    handle to goto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%TO dO: hide all other plots
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
%newt0=mod(h0-zt0,24);
newt0=(h0-zt0);

axes(handles.axes3)
[xpos,nrem]=ginput(1);
xpos=xpos-newt0;
[v,p]=min(abs(handles.epocht-xpos*3600));
handles.ce=p;
handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
handles.tf=handles.t0+handles.ltrace;
dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(handles.ltrace/handles.el)))';
handles.s=aux(1:round(handles.ltrace*handles.sr),:);
%[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
guidata(hObject, handles);
plot_traces(handles);


% --- Executes on button press in readsync.
function readsync_Callback(hObject, eventdata, handles)
% hObject    handle to readsync (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%Read a sync signal and shows the timepoints in the hypnogram.
mindist=10;% distance between frames
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file with the SYNC data');
cd (pathname)
EDF=sdfopen(filename);
dur=EDF.NRec*EDF.Dur;%duration in secs of the whole thing
ltrace=3600;
handles.stimon=[];
handles.stimoff=[];
handles.subs=[];
disp('Reading Sync data...')
%[s,edfs]=sdfread(EDF,ltrace,ltrace);
syncsignal=[];
newsrsync=EDF.SampleRate;
% if EDF.SampleRate>2500 %if sampling rate is too high, subsamplin to 1 KHz
%     newsrsync=1000;
%calculating stim on and stim off in 1h chuncks
figure
if dur>ltrace
    tempstimon=[];
    tempstimoff=[];
    for nchunk=0:(ceil(dur/ltrace))-1%reading in 60 min. chunks except the last one
        disp(strcat('H=',num2str(nchunk)))
        EDF=sdfclose(EDF);
        EDF=sdfopen(filename);
        [s,edfs]=sdfread(EDF,ltrace,nchunk*ltrace);%,ltrace,nchunk*ltrace);
        auxs=s(2:end);
        indon=[];
        indoff=[];
        auxindon=[];
        auxindoff=[];
        auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
        auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
        sr=1./diff(auxindon/newsrsync);
        plot(sr,'k.-')
        %Getting only the first and last edge within a series of edges
        k=1;
        if ~isempty(auxindon)
            for i=1:length(auxindon)
                if i==1
                    indon(k)=auxindon(i);
                else
                    %if (auxindon(i)-indon(k))>(mindist*newsrsync)
                    if (auxindon(i)-auxindon(i-1))>(mindist*newsrsync)
                        k=k+1;
                        indon(k)=auxindon(i);
                    end
                end
            end
        end
        if ~isempty(auxindoff)
            k=1;
            for i=length(auxindoff):-1:1
                if i==length(auxindoff)
                    indoff(k)=auxindoff(i);
                else
                    if auxindoff(i+1)-auxindoff(i)>mindist*newsrsync
                        k=k+1;
                        indoff(k)=auxindoff(i);
                    end
                end
            end
            indoff=fliplr(indoff);
        end
        %Converting into time (in hours)
        if ~isempty(indon)
            for k=1:length(indon)
                %nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
                nextv=(indon(k)/(3600*newsrsync));
                tempstimon=[tempstimon nextv+nchunk];
            end
        end
        if ~isempty(indoff)
            for k=1:length(indoff)
                %nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
                nextv=(indoff(k)/(3600*newsrsync));
                tempstimoff=[tempstimoff nextv+nchunk];
            end
        end
    end
    
    %     if nchunk == 1
    %         syncsignal=[syncsignal subsam(s,EDF.SampleRate,newsrsync)'];
    %REading the remainder
    %     nchunk=nchunk+1;
    %     EDF=sdfclose(EDF);
    %     EDF=sdfopen(filename);
    %     [s,edfs]=sdfread(EDF,ltrace,nchunk*ltrace);
    %     syncsignal=[syncsignal subsam(s,EDF.SampleRate,newsrsync)'];
    %     s=syncsignal;
    %     auxs=s(2:end);
    %     indon=[];
    %     indoff=[];
    %     auxindon=[];
    %     auxindoff=[];
    %     auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
    %     auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
    %     sr=1./diff(auxindon/newsrsync);
    %     figure;plot(sr,'k.-')
    %     %Getting only the first and last edge within a series of edges
    %     k=1;
    %     if ~isempty(auxindon)
    %         for i=1:length(auxindon)
    %             if i==1
    %                 indon(k)=auxindon(i);
    %             else
    %                 %if (auxindon(i)-indon(k))>(mindist*newsrsync)
    %                 if (auxindon(i)-auxindon(i-1))>(mindist*newsrsync)
    %                     k=k+1;
    %                     indon(k)=auxindon(i);
    %                 end
    %             end
    %         end
    %     end
    %     if ~isempty(auxindoff)
    %         k=1;
    %         for i=length(auxindoff):-1:1
    %             if i==length(auxindoff)
    %                 indoff(k)=auxindoff(i);
    %             else
    %                 if auxindoff(i+1)-auxindoff(i)>mindist*newsrsync
    %                     k=k+1;
    %                     indoff(k)=auxindoff(i);
    %                 end
    %             end
    %         end
    %         indoff=fliplr(indoff);
    %     end
    %     %Converting into time (in hours)
    %     if ~isempty(indon)
    %         for k=1:length(indon)
    %             %nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
    %             nextv=(indon(k)/(3600*newsrsync));
    %             tempstimon=[tempstimon nextv+nchunk];
    %         end
    %     end
    %     if ~isempty(indoff)
    %         for k=1:length(indoff)
    %             %nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
    %             nextv=(indoff(k)/(3600*newsrsync));
    %             tempstimoff=[tempstimoff nextv+nchunk];
    %         end
    %     end
else
    EDF=sdfclose(EDF);
    EDF=sdfopen(filename);
    [s,edfs]=sdfread(EDF,inf);%,ltrace,nchunk*ltrace);
    auxs=s(2:end);
    indon=[];
    indoff=[];
    auxindon=[];
    auxindoff=[];
    auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
    auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
    sr=1./diff(auxindon/newsrsync);
    figure;plot(sr,'k.-')
    %Getting only the first and last edge within a series of edges
    k=1;
    if ~isempty(auxindon)
        for i=1:length(auxindon)
            if i==1
                indon(k)=auxindon(i);
            else
                %if (auxindon(i)-indon(k))>(mindist*newsrsync)
                if (auxindon(i)-auxindon(i-1))>(mindist*newsrsync)
                    k=k+1;
                    indon(k)=auxindon(i);
                end
            end
        end
    end
    if ~isempty(auxindoff)
        k=1;
        for i=length(auxindoff):-1:1
            if i==length(auxindoff)
                indoff(k)=auxindoff(i);
            else
                if auxindoff(i+1)-auxindoff(i)>mindist*newsrsync
                    k=k+1;
                    indoff(k)=auxindoff(i);
                end
            end
        end
        indoff=fliplr(indoff);
    end
    %Converting into time (in hours)
    if ~isempty(indon)
        for k=1:length(indon)
            %nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
            nextv=(indon(k)/(3600*newsrsync));
            tempstimon=[tempstimon nextv];
        end
    end
    if ~isempty(indoff)
        for k=1:length(indoff)
            %nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
            nextv=(indoff(k)/(3600*newsrsync));
            tempstimoff=[tempstimoff nextv];
        end
    end
end


handles.stimon=tempstimon;
handles.stimoff=tempstimoff;

%     end
%handles.subs=[handles.subs subsam(s,EDF.SampleRate,handles.sr(handles.selchan)/20)'];

%getting the position of the onset and offset of the sync signal
%(or stimuluas)
%     handles.indon=find(s(1:end-1)<0.5 & auxs>0.5);
%     handles.indoff=find(s(1:end-1)>0.5 & auxs<0.5);

%end
%now the remaining time
% EDF=sdfclose(EDF);
% EDF=sdfopen(filename);
% [s,edfs]=sdfread(EDF,dur-((nchunk+1)*ltrace),(nchunk+1)*ltrace);
% %handles.subs=[handles.subs subsam(s,EDF.SampleRate,handles.sr(handles.selchan)/20)'];
% auxs=s(2:end);
% %getting the position of the onset and offset of the sync signal
% %(or stimulus)
% auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
% auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
%     k=1;
%     for i=1:length(auxindon)
%         if i==1
%             indon(k)=auxindon(i);
%         else
%             if auxindon(i)-indon(k)>mindist*EDF.SampleRate
%                 k=k+1;
%                 indon(k)=auxindon(i);
%             end
%         end
%     end
%     k=1;
%     for i=length(auxindoff):-1:1
%         if i==length(auxindoff)
%             indoff(k)=auxindoff(i);
%         else
%             if indoff(k)-auxindoff(i)>mindist*EDF.SampleRate
%                 k=k+1;
%                 indoff(k)=auxindoff(i);
%             end
%         end
%     end
%     indoff=fliplr(indoff)
% %Converting into time (in hours)
%     if length(indon)>0
%         for k=1:length(indon)
%             nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
%             handles.stimon=[handles.stimon nextv];
%         end
%     end
%     if length(indoff)>0
%         for k=1:length(indoff)
%             nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
%             handles.stimoff=[handles.stimoff nextv];
%         end
%     end
guidata(hObject, handles);
disp('Ready!')
% ximaging=(0:length(handles.subs)-1)*(dur/length(handles.subs));
% imaging=handles.subs;
% ximaging=(0:length(s)-1)*(dur/length(s));
% imaging=s;
%
score=handles.score;
xscore=(0:length(score)-1)*handles.el;

ston=handles.stimon*3600;
stoff=handles.stimoff*3600;
% figure
% plot(ximaging,imaging,'r-')
% axis tight
% hold on
% plot(xscore,2*round(score),'k-','linewidth',2)
% set(gca,'yticklabel',{'WA','','','','NR','','','','REM'})
% xlabel('s','fontsize',18)
% set(gca,'fontsize',14)
startimg=handles.stimon;
stopimg=handles.stimoff;
save('imagingtime.mat','score','xscore','startimg','stopimg')%fle for sharing the data
handles.origimgon=handles.stimon;
handles.origimgoff=handles.stimoff;
guidata(hObject, handles);
plot_traces(handles)

% --- Executes on button press in gcamp.
function gcamp_Callback(hObject, eventdata, handles)
% hObject    handle to gcamp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load traces from calcium imaging and display the analysis
%we will calculate the area above the 3 std line, the number of times it
%goes above the line, the average length of each event, the max peak value and the number of
%correlated pairs
[filename, pathname] = uigetfile('*.txt','Pick the trace file with the calcium imaging');
cd (pathname)
matinfile=load(filename);
handles.traces=matinfile(:,2:end);
handles.stimon=handles.origimgon;
handles.stimoff=handles.origimgoff;
guidata(hObject, handles);
load timestamp.txt
htstamp=floor(timestamp(:,1)./10000);
remstamp=rem(timestamp(:,1),10000);
minstamp=floor(remstamp./100);
segstamp=rem(remstamp,100);
newstamp=(htstamp*3600+(minstamp*60)+segstamp);
nston=length(handles.stimon);
nstoff=length(handles.stimon);
if strcmp ('tracesg6f8recovery.txt',filename)
    handles.stimon=handles.stimon(nston-133:nston);
    handles.stimoff=handles.stimoff(nstoff-133:nston);
    %handles.traces=handles.traces((228*2)+1:end,:);%taking out the first two movies.
    minmaxeeg=[-0.6 0.6];
    minmaxemg=[-0.2 0.2];
    newstamp=(htstamp*3600+(minstamp*60)+segstamp-(8*3600)-(4*60)-11.76)';
    %newstamp=newstamp-0;
    startrs=1;
    endsd=1;
    %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
end

if strcmp ('tracesG6F10ZT0.txt',filename)
    handles.traces=handles.traces((228*2)+1:end,:);%taking out the first two movies.
    minmaxeeg=[-0.6 0.6];
    minmaxemg=[-0.2 0.2];
    handles.stimon=handles.stimon(2:end);
    handles.stimoff=handles.stimoff(2:end);
    newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600)-(58*60)-12)';
    %newstamp=newstamp-0;
    startrs=2;
    endsd=1;
    %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
end
if strcmp ('tracesg6f8sd.txt',filename)
    aux=[handles.traces(1:3342,:)' handles.traces(3647:6686,:)' handles.traces(6990:10028,:)' handles.traces(10333:end,:)']';
    handles.traces=aux;
    newstamp=(htstamp*3600+(minstamp*60)+segstamp-(8*3600)-(4*60)-11.655)';%could be also 11.865
    newstamp=[newstamp(1:11) newstamp(13:22) newstamp(24:33) newstamp(35:95)];
    minmaxeeg=[-0.6 0.6];
    minmaxemg=[-0.2 0.2];
    handles.stimon=[handles.stimon(40:83) handles.stimon(128) handles.stimon(143:170) handles.stimon(215:233)];
    handles.stimoff=[handles.stimoff(40:83) handles.stimoff(128) handles.stimoff(143:170) handles.stimoff(215:233)];
    %newstamp=newstamp-0;s
    endsd=92;
    %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
end


if strcmp ('traces_5_27_13.txt',filename)
    handles.traces=handles.traces(1+476+141:end,:);%taking out the first two movies.
    minmaxeeg=[-0.6 0.6];
    minmaxemg=[-0.2 0.2];
    handles.stimon=handles.stimon(4:end);
    handles.stimoff=handles.stimoff(4:end);
    newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600+(11*60)+30))';
    newstamp=newstamp-17;
    startrs=31;
    endsd=31;
    %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
end

if strcmp ('traces_5_28_13.txt',filename)
    handles.traces=[handles.traces(1:3601,:)' handles.traces(3843:11042,:)' handles.traces(11170:end,:)']';%taking out the shorter movies to avoid sync issues. remove also 3.412 and 5.834
    handles.stimon=[handles.stimon(1:8) handles.stimon(10:25) handles.stimon(27:end)];
    handles.stimoff=[handles.stimoff(1:8) handles.stimoff(10:25) handles.stimoff(27:end)];
    handles.stimon=[handles.stimon(1:24) handles.stimon(34:end)];
    handles.stimoff=[handles.stimoff(1:24) handles.stimoff(34:end)];
    newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600+(8*60)+30))';
    newstamp=newstamp-17.712;
    newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
    startrs=1%length(handles.stimon)-24;
    endsd=length(handles.stimon)-24;
    minmaxeeg=1E-4*[-6 6];
    minmaxemg=[-2*1E-4 2*1E-3];
    
end


if strcmp ('traces_5_21_13.txt',filename)
    newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600+10))';
    handles.stimon=handles.stimon(5:end);
    handles.stimoff=handles.stimoff(5:end);
    %     handles.stimon=[handles.stimon(1:19) handles.stimon(21:33) handles.stimon(35:end)];
    %     handles.stimoff=[handles.stimoff(1:19) handles.stimoff(21:33) handles.stimoff(35:end)];
    minmaxeeg=1E-4*[-6 6];
    minmaxemg=[-2*1E-4 2*1E-3];
    
    newstamp=newstamp-(newstamp(2)-handles.stimon(2)*3600)+10;
    %     handles.stimon=[handles.stimon(1:34) handles.stimon(36:end)];
    %     handles.stimoff=[handles.stimoff(1:34) handles.stimoff(36:end)];    .
    startrs=1;%length(handles.stimon)-23;
    endsd=length(handles.stimon)-23;
end
figure
plot([(newstamp/3600)' (newstamp/3600)'],[0 2]','c--')
hold on
plot([(handles.stimon)' (handles.stimon)'],[0 2]','m--')
plot([(handles.stimoff)' (handles.stimoff)'],[0 2]','k--')
srcalcium=median(timestamp(:,2))/(median(handles.stimoff-handles.stimon)*3600);
totpoints=size(handles.traces,1);
totimagtime=sum(handles.stimoff-handles.stimon)*3600;%in s
ltrace=floor((handles.stimoff-handles.stimon)*3600*srcalcium);%vector with the length of each video in points of calcium imaging data (i.e. frames).
if sum(ltrace)<totpoints
    ltrace(end)=ltrace(end)+totpoints-sum(ltrace);%correction for rounding error
end
handles.ncells=size(handles.traces,2);
%     if i<9
%         [r,p]=corrcoef(newmat');
%         nsigcorr(i)=length(find(p<1E-8))/2;%number of cells significantly correlated
%     end
%     ltrace(i)=length(newmat);
%     handles.traces=[handles.traces newmat];
%     %concatenating each trace
% end

%binmat=zeros(size(handles.traces(:,2:end)));
%Getting the threshold values using all traces for each cell
%figure
%for k=1:handles.ncells
%     threscell(k)=mean(handles.traces(:,k))+3*std((handles.traces(:,k)));SInce
%     all traces have std = 1, the threshold can be the same for everybody.
%     Let's fix it as 90% of the peak for the trace with lowest maximum
threscell=ones(1,handles.ncells)*min(3,0.9*min(max(handles.traces)));
%     plot(handles.traces(:,k+1))
%     hold on
%     plot(threscell(k)*ones(size(handles.traces(:,k+1))),'k--')
%     pause
%     cla
%end

% for i=1:length(handles.stimon)
%    if i==1
%        newmat=handles.traces(1:ltrace(1),:);
%    else
%        indx=sum(ltrace(1:i-1));%starting pos of the matrix
%        newmat=handles.traces(indx:indx+ltrace(i)-1,:);
%         for j=1:handles.ncells
%             [nevents(i,j),peakevent(i,j),meanevent(i,j),areaevents(i,j),maxarea(i,j),maxdurevent(i,j),meandurevent(i,j)]=getnevents(newmat(:,j)',threscell(j),srcalcium);
%         end
%    end
% end

%Making continuous heatmap
cheeg=1;
chemg=2;
cd (handles.pathEDF)
allmovspow=[];
allraster=[];
xhypno=[];
allepochs=[];
%[handles.EDF]=sdfclose(handles.EDF);
k=0
for chunk=startrs:length(handles.stimon)%Chunk of EEG to do the heatmap
    durimag=3600*(handles.stimoff(chunk)-handles.stimon(chunk));%seconds of EEG + imaging
    %figure
    nEDF=sdfopen(handles.fn);
    [eegtrace,edfs]=sdfread(nEDF,durimag,3600*handles.stimon(chunk));
    [nEDF]=sdfclose(nEDF);
    sr=max(nEDF.SampleRate);
    for nepoch=1:floor(durimag/handles.el)
        p(:,nepoch)=getthepower(eegtrace(1+(floor(sr*handles.epocht(nepoch)):ceil(sr*handles.epocht(nepoch+1))),cheeg),handles.el,16,0);
    end
    allmovspow=[allmovspow p];
    k=k+1;
    xeeg=(0:length(eegtrace)-1)/sr;
    subplot(15,1,[1 2])
    plot(xeeg,eegtrace(:,cheeg),'k-');
    axis tight
    set(gca,'ylim',minmaxeeg)
    title(num2str(handles.stimon(chunk)),'fontsize',21)
    subplot(15,1,[3 4])
    plot(xeeg,eegtrace(:,chemg),'k-');
    axis tight
    set(gca,'ylim',minmaxemg)
    %     subplot(9,1,[5 6])
    %     p=p-min(min(p));%Normalizing the power within [0 1]
    %     p=p/max(max(p));
    %     image(p*75)
    %     axis xy
    %     colormap('jet')
    %     xlabl=str2num(get(gca,'Xticklabel'));
    %     set(gca,'Xticklabel',num2str(xlabl*4))
    %     set(gca,'YTick',([0 4 8 12 16]+0.1231)./0.2462)
    %     ylabl=str2num(get(gca,'Yticklabel'))
    %     set(gca,'Yticklabel',num2str(round(0.2462*ylabl-0.1231)));%takeng from eq. of the line that passes thru 0.5,0 and 65.5,16
    %     xlabel('S')
    %     ylabel('Hz')
    %     %now the raster
    currep=round(3600*handles.stimon(chunk)/handles.el);
    if k==1
        xhypno=handles.epocht(currep:currep+round(durimag/handles.el))-handles.epocht(currep);
        imgstart(k)=0;
        
    else
        newelem=xhypno(end)+handles.el+handles.epocht(currep:currep+round(durimag/handles.el))-handles.epocht(currep);
        xhypno=[xhypno newelem];
        imgstart(k)=newelem(1);
        
    end
    allepochs=[allepochs currep:currep+round(durimag/handles.el)];
    %     subplot(9,1,[7 8])
    subplot(15,1,[5 6])
    
    %     plot(x,raster,'k.')
    %     subplot(9,1,9)
    tp=round(handles.score(currep:currep+round(durimag/handles.el)));
    xtp=(0:length(tp)-1)*180/(length(tp)-1);
    plot(xtp,round(handles.score(currep:currep+round(durimag/handles.el))),'k-','linewidth',1);
    set(gca,'ylim',[0 2.1])
    set(gca,'YTick',[0 1 2])
    set(gca,'Yticklabel',{'W','NREM','REM'})
    axis tight
    %Now the traces:
    %subplot(15,1,[7 15])
    if chunk>1
        newmat=handles.traces(sum(ltrace(1:chunk-1)):sum(ltrace(1:chunk)),1:20);
    else
        newmat=handles.traces(1:sum(ltrace(1)),1:20);
    end
    %[vwv,posim]=sort(std(newmat),'descend');
    %newmat2=newmat(:,posim(1:20));
    for i=1:20
        newmat(:,i)=newmat(:,i)+(i-1)*8;
    end
    xnewmat=(0:length(newmat)-1)/srcalcium;
    %plot(xnewmat,newmat)
    %for kk=1:20
    %    text(xnewmat(1),(kk-1)*8,num2str(kk))
    %end
    %set(gca,'ylim',[-1 160])
    %axis tight
    
    aa=0;
end
%plotting the heatmap, raster and hipnogram for the whole thing
%allraster=binmatfpl(handles.traces(sum(ltrace(1:endsd-1)):end,:),median(threscell));
%allraster=binmatfpl(handles.traces(sum(ltrace(1:startrs)):end,:),median(threscell));
allraster=binmatfpl(handles.traces,0.9);

disp('Making traces for NREM, REM and WA point by point')
matWA=[];
matWAsd=[];
matWArs=[];
matREM=[];
matNREM=[];
matWAsd=[];%Matrixes of n points in the state x ncells in chronological order
syncp=zeros(1,totpoints);%This vector has the corresponding time in sec for every point in the imaging
pos=1;

for i1=1:length(ltrace)
    %durtr=ltrace(i1)/srcalcium;%Duration in seconds of the current video
    durtr=(handles.stimoff(i1)-handles.stimon(i1))*3600;
    syncp(pos:pos+ltrace(i1)-1)=handles.stimon(i1)*3600+((0:ltrace(i1)-1)/(ltrace(i1)-1))*durtr;%Vector with the time in seconds where there was imaging
    pos=pos+ltrace(i1);
end

%matWASD
for i=1:sum(ltrace(1:endsd))
    if state(syncp(i),handles)==0
        matWAsd=[matWAsd; handles.traces(i,:)];
    end
end
%matWArs
%for i=sum(ltrace(1:endsd)):totpoints
for i=1:totpoints
    if state(syncp(i),handles)==0
        matWArs=[matWArs; handles.traces(i,:)];
    end
end

for i=1:totpoints%sum(ltrace(1:32))+1:totpoints
    if state(syncp(i),handles)==0
        matWA=[matWA; handles.traces(i,:)];
    end
    if state(syncp(i),handles)==1
        matNREM=[matNREM; handles.traces(i,:)];
    end
    if state(syncp(i),handles)==2
        matREM=[matREM; handles.traces(i,:)];
    end
end
%making rasters for REM and NREM
allrasterREM=binmatfpl(matREM,0.9);
allrasterNREM=binmatfpl(matNREM,0.9);
allrasterWAsd=binmatfpl(matWAsd,0.9);
allrasterWArs=binmatfpl(matWArs,0.9);
figure;
subplot(5,1,1:4)
plot(allrasterNREM,'k.')
title('NREM')
subplot(5,1,5)
%Now converting to binary matrices
minREM=zeros(size(allrasterREM));
minREM(find(allrasterREM>0))=1;
minNREM=zeros(size(allrasterNREM));
minNREM(find(allrasterNREM>0))=1;
minWAsd=zeros(size(allrasterWAsd));
minWAsd(find(allrasterWAsd>0))=1;
minWArs=zeros(size(allrasterWArs));
minWArs(find(allrasterWArs>0))=1;

%Now making a vector of events/s
vsum=sum(minNREM,2)/size(minNREM,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newNREM=mean(newsum*srcalcium,1);
hpNREM=mean(newNREM(1:3));
lpNREM=mean(newNREM(end-2:end));
plot(newNREM,'k')
vsum=sum(minREM,2)/size(minREM,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newREM=mean(newsum*srcalcium,1);
if length(newREM)>1
    hpREM=mean(newREM(1:3));
    lpREM=mean(newREM(end-2:end));
else
    hpREM=0;
    lpREM=0;
end

vsum=sum(minWAsd,2)/size(minWAsd,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
if endsd>1
    newWAsd=mean(newsum*srcalcium,1);
    lpWAsd=mean(newWAsd(1:3));
    hpWAsd=mean(newWAsd(end-2:end))
else
    newWAsd=0;
    lpWAsd=0;
    hpWAsd=0;
end
vsum=sum(minWArs,2)/size(minWArs,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newWArs=mean(newsum*srcalcium,1);
hpWArs=mean(newWArs(1:3));
lpWArs=mean(newWArs(end-2:end))

figure
%bar([[hpREM lpREM]' [hpNREM lpNREM]' [hpWArs lpWArs]' [hpWAsd lpWAsd]' ])
bar([[hpREM hpNREM hpWArs hpWAsd]' [lpREM lpNREM lpWArs lpWAsd]'])
set(gca,'XTick',[1 2 3 4])
set(gca,'XTicklabel',{'REM','NREM','WA-Rec','WA-SD'})
legend('HP','LP')
colormap bone
set(gca,'fontsize',14)
box off
xlabel('State','fontsize',21)
ylabel('Mean Events/s','fontsize',21)
ind1=find(matREM>0.9)
for ncell=1:handles.ncells
    if length(matREM)>1
        remevents(ncell)=length(find(matREM(:,ncell)>0.9));
        remrat(ncell)=(remevents(ncell)/(size(matREM,1))*srcalcium);
    else
        remevents(ncell)=0;
        remrat(ncell)=0;
    end
    nremevents(ncell)=length(find(matNREM(:,ncell)>0.9));
    wavents(ncell)=length(find(matWA(:,ncell)>0.9));
    
    nremrat(ncell)=(nremevents(ncell)/(size(matNREM,1))*srcalcium);
    warat(ncell)=(wavents(ncell)/(size(matWA,1))*srcalcium);
end

%ploting raster WA SD
figure
subplot(5,1,1:4)
xras=(0:length(allrasterWAsd)-1)/(srcalcium*60);
plot(xras,allrasterWAsd,'k.','markersize',4)
axis tight
set(gca,'fontsize',14)
box off
ylabel('Cell #','fontsize',21)
set(gca,'XTicklabel','')
subplot(5,1,5)
plot(newWAsd,'k','linewidth',1.5)
xlabel('Time(min)','fontsize',21)
axis tight
minmax=get(gca,'ylim')
set(gca,'ylim',[0 max(minmax)])
set(gca,'fontsize',14)
box off

%ploting it as a scatter plot
figure
plot(newWAsd,'ko')
xlabel('Time(min)','fontsize',21)
axis tight
ylabel('Mean Events/s','fontsize',21)
set(gca,'fontsize',14)
box off
figure
title(num2str(handles.stimon(endsd)))
nplots=length(find(max([warat' nremrat' remrat']')>0));
q1=1;
k=1;
% while q1<nplots
%     if max([warat(k) nremrat(k) remrat(k)])>0
%         subplot(9,ceil(nplots/9),q1)
%         bar([warat(k) nremrat(k) remrat(k)])
%         set(gca,'XTick',[1 2 3])
%         set(gca,'Xticklabel',{'W','N','R'})
%         q1=q1+1;
%     end
%     k=k+1;
% end

% figure
% bar([remrat' nremrat' warat'])
remcells=find(remrat>(max(nremrat,warat))*2);
figure
tobar=[mean(warat) mean(nremrat) mean(remrat)];
toerr=[sem(warat) sem(nremrat) sem(remrat)];
errorbar(tobar,toerr,'k.')
hold on
bar(tobar)
set(gca,'XTick',[1 2 3])
set(gca,'Xticklabel',{'WA','NREM','REM'})
set(gca,'fontsize',14)
ylabel('Events/sec','fontsize',21)
figure
subplot(4,1,1)
xhyp=xhypno/60;
plot(xhyp,round(handles.score(allepochs)),'k-','linewidth',1)
set(gca,'ylim',[0 2.1])
set(gca,'YTick',[0 1 2])
set(gca,'Yticklabel',{'W','NREM','REM'})
set(gca,'fontsize',14)
eps=round(3600*handles.stimon(31:end)/handles.el);
set(gca,'xticklabel','')
%xlabel('Time (min)','fontsize',24)
keysc=round(handles.score(allepochs));
% epochs=[];
% for i=1:length(handles.stimon)
%     [v,st]=min(abs(3600*handles.stimon(i)-handles.epocht));
%     [v,en]=min(abs(3600*handles.stimoff(i)-handles.epocht));
%     epochs=[epochs st:en];
% end
%     plot((handles.epocht(epochs)-handles.epocht(epochs(1)))/60,round(handles.score(epochs)),'k-','linewidth',2)
%     set(gca,'ylim',[0 2.1])
%     set(gca,'YTick',[0 1 2])
%     set(gca,'Yticklabel',{'WA','NREM','REM'})
%     set(gca,'fontsize',14)
%     xlabel('m','fontsize',24)
hold on
plot([imgstart'/60 imgstart'/60],[0 2.1],'g:','linewidth',1)
axis tight
plot(xhyp,round(handles.score(allepochs)),'k-','linewidth',1)
data.hypno=round(handles.score(allepochs));
data.hypnox=xhyp;
data.hypnoingstart=imgstart'/60;
box off
% subplot(6,1,1:2)
% allmovspow=allmovspow-min(min(p));%Normalizing the power within [0 1]
% aux=sort(allmovspow(:));
% maxi=aux(round(0.995*length(aux)));%normalizing by the 85% largest value
% allmovspow=allmovspow/maxi;
% image(allmovspow*60)
% axis xy
% colormap('jet')
% xlabl=str2num(get(gca,'Xticklabel'));
% set(gca,'Xticklabel',num2str(xlabl*4))
% set(gca,'YTick',([0 4 8 12 16]+0.1231)./0.2462)
% ylabl=str2num(get(gca,'Yticklabel'))
% set(gca,'Yticklabel',num2str(round(0.2462*ylabl-0.1231)));%taken from eq. of the line that passes thru 0.5,0 and 65.5,16
% box off
% set(gca,'Xticklabel','')
% %xlabel('S')
% ylabel('Hz','fontsize',21)
% set(gca,'Xticklabel','')

subplot(4,1,[2:3])
x=(0:length(allraster)-1)/(60*srcalcium);
plot(x,allraster,'k.','markersize',4)
axis tight
set(gca,'Xticklabel','')
set(gca,'fontsize',14)
ylabel('Cell #','fontsize',18)
box off
axis tight
set(gca,'Xticklabel','')
hold on
%plot(x,allraster(:,remcells),'r.','markersize',5)
data.rasterd=allraster;
data.rasterx=x;

% %finding rem only cells
% remcells=[];
% for ncell=1:handles.ncells
%     posev=find(allraster(:,ncell)>0)/srcalcium;%in secs
%     posev=round(posev/4);%in epochs
%     ratio(ncell)=length(find(keysc(posev)==2))/length(posev);%fraction of events during REM
% end
% figure
% bar (ratio)



subplot(4,1,4)
newmp=zeros(size(allraster));
ind1=find(~isnan(allraster));
newmp(ind1)=1;
vsum=sum(newmp,2)*srcalcium/handles.ncells;
xv=(0:length(vsum)-1)/(60*srcalcium);


newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
%plot(mean(newsum,1),'k-')
plot(xv,vsum,'k-')
xlabel('Time (min)','fontsize',24)
set(gca,'fontsize',14)
ylabel('Events/s','fontsize',21)
box off
axis tight

%newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
%plot(mean(newsum,1),'k.-','linewidth',2)
% plot(xv,vsum,'k')
% xlabel('Time (min)','fontsize',24)
% set(gca,'fontsize',14)
% ylabel('Events/min','fontsize',21)
% box off
% axis tight

mwasd=binmatfpl(matWAsd,3.5);
x=(0:length(mwasd)-1)/srcalcium;

figure;
subplot(5,1,1:4)
plot(x,mwasd,'k.')
set(gca,'fontsize',14)
%xlabel('s','fontsize',18)
ylabel('Cell #','fontsize',21)
%xlabel('s','fontsize',18)
box off
axis tight
set(gca,'Xticklabel','')
%Plotting raster for WA SD
newmp=zeros(size(mwasd));
ind1=find(mwasd>0);
newmp(ind1)=1;
subplot(5,1,5)
vsum=sum(newmp,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
plot(mean(newsum,1),'k-')
xlabel('Time (min)','fontsize',24)
set(gca,'fontsize',14)
ylabel('Events/min','fontsize',21)
box off
axis tight

% %NOw WA during RS
% mwasd=binmatfpl(matWA,3);
% x=(0:length(mwasd)-1)/srcalcium;
% figure;
% subplot(5,1,1:4)
% plot(x,mwasd,'k.')
% set(gca,'fontsize',14)
% %xlabel('s','fontsize',18)
% ylabel('Cell #','fontsize',18)
% %xlabel('s','fontsize',18)
% box off
% axis tight
%
% newmp=zeros(size(mwasd));
% ind1=find(mwasd>0);
% newmp(ind1)=1;
% subplot(5,1,5)
% vsum=sum(newmp,2);
% newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
% plot(mean(newsum,1),'k-')
% xlabel('m','fontsize',21)
% set(gca,'fontsize',14)
% ylabel('Mean No Spikes WA RS','fontsize',21)
% box off
% axis tight
%
% figure
% hist(vsum,max(vsum))
% ylabel('Frequency','fontsize',21)
% xlabel('# Simultaneous events (WA RS)','fontsize',21)



%Plotting NREM
% mwasd=binmatfpl(matNREM,3);
% x=(0:length(mwasd)-1)/srcalcium;
% figure;
% subplot(5,1,1:4)
% plot(x,mwasd,'k.')
% set(gca,'fontsize',14)
% %xlabel('s','fontsize',18)
% ylabel('Cell #','fontsize',18)
% %xlabel('s','fontsize',18)
% box off
% axis tight
%
% newmp=zeros(size(mwasd));
% ind1=find(mwasd>0);
% newmp(ind1)=1;
% subplot(5,1,5)
% vsum=sum(newmp,2);
% newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
% plot(mean(newsum,1),'k-')
% xlabel('m','fontsize',21)
% set(gca,'fontsize',14)
% ylabel('Mean No Spikes NREM','fontsize',21)
% box off
% axis tight
%
% figure
% hist(vsum,max(vsum));
% ylabel('Frequency','fontsize',21)
% xlabel('# Simultaneous events (NREM)','fontsize',21)
%


%Finally REM
% mwasd=binmatfpl(matREM,3);
% x=(0:length(mwasd)-1)/srcalcium;
% figure;
% subplot(5,1,1:4)
% plot(x,mwasd,'k.')
% set(gca,'fontsize',14)
% %xlabel('s','fontsize',18)
% ylabel('Cell #','fontsize',18)
% %xlabel('s','fontsize',18)
% box off
% axis tight
%
% newmp=zeros(size(mwasd));
% ind1=find(mwasd>0);
% newmp(ind1)=1;
% subplot(5,1,5)
% vsum=sum(newmp,2);
% newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
% plot(mean(newsum,1),'k-')
% xlabel('m','fontsize',21)
% set(gca,'fontsize',14)
% ylabel('Mean No Spikes REM','fontsize',21)
% box off
% axis tight
%
% figure
% hist(vsum,max(vsum));
% ylabel('Frequency','fontsize',21)
% xlabel('# Simultaneous events (REM)','fontsize',21)





% [r,p]=corrcoef(matWA);
% sigcorrWA=length(find(p<1E-8))/2;
% [r,p]=corrcoef(matNREM);
% sigcorrNREM=length(find(p<1E-8))/2;
% [r,p]=corrcoef(matREM);
% sigcorrREM=length(find(p<1E-8))/2;
%
%  for j=1:handles.ncells
%             [neventsWA(j),peakeventWA(j),meaneventWA(j),areaeventsWA(j),maxareaWA(j),maxdureventWA(j),meandureventWA(j)]=getnevents(matWA(j,:),threscell(j),srcalcium);
%             [neventsNREM(j),peakeventNREM(j),meaneventNREM(j),areaeventsNREM(j),maxareaNREM(j),maxdureventNREM(j),meandureventNREM(j)]=getnevents(matNREM(j,:),threscell(j),srcalcium);
%             [neventsREM(j),peakeventREM(j),meaneventREM(j),areaeventsREM(j),maxareaREM(j),maxdureventREM(j),meandureventREM(j)]=getnevents(matREM(j,:),threscell(j),srcalcium);
%  end
% nsimWA=getsimev(matWA',threscell,1,srcalcium);%calculating the number of simultaneous events in a matrix with traces (1 s window)
% nsimNREM=getsimev(matNREM',threscell,1,srcalcium);
% nsimREM=getsimev(matREM',threscell,1,srcalcium);
% figure
% errorv=[sem(nsimWA) sem(nsimNREM) sem(nsimREM)];
% datav=[mean(nsimWA) mean(nsimNREM) mean(nsimREM)];
% errorbar(datav,errorv,'k.');
% hold on
% bar(datav)
% set(gca,'XTick',[1 ;2; 3])
% set(gca,'XTickLabel',{'WA','NREM','REM'})
% set(gca,'fontsize',14)
% box off
% ylabel('Sim. events/N events','fontsize',21)
%
% figure
% % subplot(2,1,1)
% % bar(nsigcorr)
% % subplot(2,1,1)
% bar([sigcorrWA sigcorrNREM sigcorrREM]);
% figure
% title('Event frequency')
% for ploti=1:handles.ncells
%     subplot(round(sqrt(handles.ncells)),ceil(sqrt(handles.ncells)),ploti)
%     bar([neventsWA(ploti) neventsNREM(ploti) neventsREM(ploti)]);
%    % set(gca,'fontsize',14)
%     set(gca,'XTickLabel',{'WA','NREM','REM'})
% end
% figure
% subplot(1,2,1)
% error=[sem(neventsWA) sem(neventsNREM) sem(neventsREM)];
% neventstp=[mean(neventsWA) mean(neventsNREM) mean(neventsREM)];
% errorbar(neventstp,error,'k.')
% hold on
% bar(neventstp)
%    % set(gca,'fontsize',14)
%    set(gca,'XTick',[1 ;2; 3])
% set(gca,'XTickLabel',{'WA','NREM','REM'})
% set(gca,'fontsize',14)
% box off
% ylabel('Mean Events/sec','fontsize',21)
%  m=[neventsWA' neventsNREM' neventsREM'];
%  [v,p]=max(m');
%  pwa=100*length(find(p==1))/64;
%  pnrem=100*length(find(p==2))/64;
%  prem=100*length(find(p==3))/64 ;
%  subplot(1,2,2)
%  bar([pwa pnrem prem]);
%    % set(gca,'fontsize',14)
%    set(gca,'XTick',[1 ;2; 3])
% set(gca,'XTickLabel',{'WA','NREM','REM'})
% set(gca,'fontsize',14)
% box off
% ylabel('% of population with max event rate','fontsize',21)
% set(gca,'ylim',[0 100])

% figure
% subplot(4,2,1)
% plot([peakeventWA; peakeventNREM; peakeventREM],'.-');
% hold on
% plot(mean([peakeventWA' peakeventNREM' peakeventREM']),'o-','linewidth',2)
% axis tight
% title('Peak Event','fontsize',16)
%
% subplot(4,2,2)
% plot(nevents,'.-');
% hold on
% plot(mean(nevents'),'o-','linewidth',2)
% axis tight
% title('N Events','fontsize',16)
%
%
% subplot(4,2,3)
% plot(meanevent,'.-');
% hold on
% plot(mean(meanevent'),'o-','linewidth',2)
% axis tight
% title('Mean events','fontsize',16)
%
% subplot(4,2,4)
% plot(areaevents,'.-');
% hold on
% plot(mean(areaevents'),'o-','linewidth',2)
% axis tight
% title('Area Events','fontsize',16)
%
% subplot(4,2,5)
% plot(maxarea,'.-');
% hold on
% plot(mean(maxarea'),'o-','linewidth',2)
% axis tight
% title('Max area','fontsize',16)
%
% subplot(4,2,6)
% plot(maxdurevent,'.-');
% hold on
% plot(mean(maxdurevent'),'o-','linewidth',2)
% axis tight
% title('Max Dur Event','fontsize',16)
%
% subplot(4,2,7)
% plot(meandurevent,'.-');
% hold on
% plot(mean(meandurevent'),'o-','linewidth',2)
% axis tight
% title('Mean Dur Event','fontsize',16)

% figure
%subplot(2,1,1)
%for ploti=1:8
%ploti=6;
%subplot(4,2,ploti)
% plot(nevents(:,(1+8*(ploti-1)):(1+8*(ploti-1))+7),'o-');
% hold on
% plot(mean(nevents(:,(1+8*(ploti-1)):(1+8*(ploti-1))+7),2),'kd-','linewidth',2)
% axis tight
% ylabel('N Events (4 cells)','fontsize',21)
% set(gca,'fontsize',14)
% xlabel('Period of SD','fontsize',21)

% box off
% %end
% subplot(2,1,2)
% plot(nevents(1,:),nevents(8,:),'ko')
% hold on
% plot([0 max(nevents(8,:))],[0 max(nevents(8,:))],'g--')
% set(gca,'fontsize',14)
% xlabel('N Events SD 1','fontsize',21)
% ylabel('N Events SD 8','fontsize',21)
% axis tight
% box off
%

%end
% axes(handles.axes2)
%plot(handles.traces')
% hold on
% v=ones(1,size(handles.traces,2));
% for i=1:size(handles.traces,1)
%     %cla
%     plot(handles.traces(i,:)')
%     top=std(handles.traces(i,:))*3*v;
%     plot(top,'k--')
%     %pause
% end
%Dividing the traces in 11 groups: SD 1-8, NREM, WA and REM
% handles.sttimes4tr=syncp([1 find(diff(syncp)>10)]);
% handles.edtimes4tr=syncp([find(diff(syncp)>10)]);
data.warate=warat;
data.nremrate=nremrat;
data.remrate=remrat;
data.hp=[hpREM hpNREM hpWArs hpWAsd]';
data.lp=[lpREM lpNREM lpWArs lpWAsd]';
fname2=strcat(filename(1:end-3),'dat.mat');
save(fname2,'data')
helpdlg('Data saved!')
guidata(hObject, handles);


function st=state(timeinp,handles)
%returns the state for a given time in s
sepocht=[handles.epocht(2:end) handles.epocht(end)+handles.el ];
ind=find(timeinp>=handles.epocht & timeinp<sepocht);
st=round(handles.score(ind));

function st=statefl(timeinp,handles)
%returns the state for a given time in s
ind=round(timeinp/handles.el);
st=handles.score(ind);



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
robot = java.awt.Robot;
pos = get(handles.axes1, 'Position');
set(0, 'PointerLocation', [pos(1:2)+100]);
robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in incemg.
function incemg_Callback(hObject, eventdata, handles)
% hObject    handle to incemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.emgscale=handles.emgscale*2;
guidata(hObject, handles);


% --- Executes on button press in decemg.
function decemg_Callback(hObject, eventdata, handles)
% hObject    handle to decemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.emgscale=handles.emgscale/2;
guidata(hObject, handles);



function limemg2_Callback(hObject, eventdata, handles)
% hObject    handle to limemg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of limemg2 as text
%        str2double(get(hObject,'String')) returns contents of limemg2 as a double
num=str2double(get(hObject,'String'));
handles.limemg=num*std(handles.s(:,handles.chemg));
robot = java.awt.Robot;
pos = get(handles.axes1, 'Position');
set(0, 'PointerLocation', [pos(1:2)+100]);
robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);
guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function limemg2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to limemg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in gcamp2.
function gcamp2_Callback(hObject, eventdata, handles)
% hObject    handle to gcamp2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load events from calcium imaging and display the analysis
%Perform the following analysys for each group, for each cell:
%1- mean event rate/epoch for each sleep state and correlation with the
%power of the different bands
%pairwise correlations??

%Selecting the start and end epochs of every period to be analyzed
v=0;
if isfield(handles,'nump')
    v=handles.nump==str2double(get(handles.nperiods,'string'));
end
if ~isfield(handles,'nump') | ~v
    zt0=time2h(get(handles.edit4,'string'));%The time for lights on
    aux1=get(handles.toedit,'string');
    h0=time2h(aux1(1:8));%the time of the first recorded data point
    newt0=h0-zt0;
    handles.nump=str2double(get(handles.nperiods,'string'));
    axes(handles.axes3)
    for i=1:handles.nump%Getting the start and end epochs for the periods of imaging to be analized
        set(handles.text8,'BackgroundColor',[0.5 0.7 0.7])
        set(handles.text8,'string',strcat('Start of period ',num2str(i)));
        [xpos,nrem]=ginput(1);
        xpos=xpos-newt0;
        [v,p]=min(abs(handles.epocht-xpos*3600));
        handles.startpz(i)=p;
        set(handles.text8,'BackgroundColor',[0.5 0.3 0.3])
        set(handles.text8,'string',strcat('End of period ',num2str(i)));
        [xpos,nrem]=ginput(1);
        xpos=xpos-newt0;
        [v,p]=min(abs(handles.epocht-xpos*3600));
        handles.endpz(i)=p;
    end
    disp(handles.startpz)%starting epoch
    disp(handles.endpz)%ending epoch
end
set(handles.text8,'BackgroundColor',[0 1 0])
set(handles.text8,'string','');
eval('cd textfiles')
filename=dir('*.txt');
guidata(hObject, handles);
%Making a vector with the times in seconds of the starting of each video:
nmovs=length(filename);
disp('Reading time of videos...')
for k=1:nmovs
    auxs=filename(k).name;
    l=length(auxs);
    day=str2num(auxs(l-12:l-11));
    h0=num2str(handles.EDF.T0(4));
    m0=num2str(handles.EDF.T0(5));
    s0=num2str(handles.EDF.T0(6));
    if length(h0)<2
        h0=strcat('0',h0);
    end
    if length(m0)<2
        m0=strcat('0',m0);
    end
    if length(s0)<2
        s0=strcat('0',s0);
    end
    timev(k)=time2secs(strcat(h0,m0,s0),auxs(l-9:l-4));
    if day~=handles.EDF.T0(3)
        timev(k)=timev(k)+86400;
    end
    %Getting the duration of the video from the txt file
    fileid=fopen(auxs);
    ss=fscanf(fileid,'%s');
    tp=strfind(ss,'TIME');
    aproxd=str2num(ss(tp+4+(1:2)))*60+str2num(ss(tp+4+(4:5)));
    tp=strfind(ss,'FPS');
    %fpsvid=str2num(ss(tp+3+(1:12)));
    fpsvid=str2num(ss(tp+3+(1:6)));
    if aproxd>61
        nlim=4;
    else
        if aproxd>=10
            nlim=3;
        else
            nlim=1;
        end
    end
    tp1=strfind(ss,'[');
    tp2=strfind(ss,']');
    if tp2-tp1>1
        f2add=length(eval(ss(tp1:tp2)));
    else
        f2add=0;
    end
    tp=strfind(ss,'FRAMES');
    frmvid(k)=f2add+str2num(ss(tp+6+(1:nlim)));
    durvi(k)=frmvid(k)/fpsvid;
    %      if k<nmovs
    %          durvi(k)=durvi(k)+2;%adding 2s added artificially during concat
    %      end
    %add here rejection of videos that have >1 dropped frame
    fclose(fileid);
end
liminf=(min(handles.startpz)-1)*handles.el;%First second to consider
limsup=(max(handles.endpz)+1)*handles.el;%Last second to consider
ind1=find(handles.origimgon*3600>liminf & handles.origimgon*3600<limsup);
tempstimon=handles.origimgon(ind1)*3600;
tempstimoff=handles.origimgoff(ind1)*3600;

%eliminating short events
vdift=tempstimoff-tempstimon;
indgt=find(vdift>30);
tempstimoff=tempstimoff(indgt);
tempstimon=tempstimon(indgt);

figure;plot(durvi,'.-')
ind2=find(timev>liminf & timev<limsup);
temptimev=timev(ind2);
if length(temptimev)>length(tempstimon)
    helpdlg('too many video files')
end
%Automatic deletion of the tempstims that were not used in the video
%using the closest or the first to adjust the timings
if get(handles.synclast,'value')%actually is sync closest to the last
    [v,p]=min(abs(tempstimon-temptimev(end)));
    timev=timev-(temptimev(end)-tempstimon(p));
    timevoff=temptimev+durvi(ind2);
    [v,p]=min(abs(tempstimoff-timevoff(1)));
    timevoff=timevoff-(timevoff(1)-tempstimoff(p));
else
    temptimev=temptimev-(temptimev(1)-tempstimon(1));
    timevoff=temptimev+durvi(ind2);
    timevoff=timevoff-(timevoff(1)-tempstimoff(1));
end

figure
subplot(2,1,1)
xvec=1:round((tempstimon(end))+200);
tracedet=zeros(size(xvec));
tracevid=tracedet;
handles.stimon=[];
handles.stimoff=[];
%deleting stimtimes
for i=1:length(tempstimon)
    if min(abs(tempstimon(i)-temptimev))<21
        handles.stimon=[handles.stimon tempstimon(i)];
        handles.stimoff=[handles.stimoff tempstimoff(i)];
    end
end
%fixing stimoff times
ind=find(abs(timevoff-handles.stimoff)>3)
handles.stimoff(ind)=timevoff(ind);
%plotting

for i=1:length(handles.stimoff)
    tracedet(round(handles.stimon(i)):round(handles.stimoff(i)))=1;
end
for i=1:length(temptimev)
    tracevid(round(temptimev(i)):round(timevoff(i)))=1;
end
plot(xvec,tracedet,'k-','linewidth',2);
hold on
plot(xvec,tracevid,'r-');
box off
subplot(2,1,2)
for i=1:length(handles.stimon)
    v(i)=sum(tracevid(round(handles.stimon(i)):round(handles.stimoff(i))));
end
subplot(2,1,2)
plot(v,'.')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %Making matrix with time of events%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eval('cd ..')
eval('cd events')
filename=dir('*.mat');
ncells=length(filename);
firstevent=load(filename(1).name);
tvect=firstevent.Object.XVector;
binevents=zeros(ncells,length(tvect));
matevents=binevents;
disp('Reading Events');
for k=1:ncells
    filread=load(filename(k).name);
    p1=strfind(filename(k).name,'_');
    p1=p1(1)+1;
    p2=strfind(filename(k).name,' - ');
    p2=p2(1)-1;
    numfilt=str2double(filename(k).name(p1:p2));
    filread=load(filename(k).name);
    if isfield(filread.Object,'DataStorage')
        events=filread.Object.DataStorage;
    else
        events=filread.Object.Data;
    end
    
    indx=find(events>0.1);
    matevents(numfilt,:)=events;
    binevents(numfilt,indx)=1;
end
figure;plot(matevents)
newmatevnts=[];
totimagtime=sum(handles.stimoff-handles.stimon);%total video time in s
if abs((totimagtime/length(handles.stimon))-(mean(durvi)))>1%difference in average duration of videos vs detected must be less than 1 s
    helpdlg('Error. Event time different than sync time')
    return
end
srcalcium=length(tvect)/totimagtime;
disp(strcat('sr video=',num2str(srcalcium)))
handles.stimon=handles.stimon/3600;
handles.stimoff=handles.stimoff/3600;
handles.events=binevents';
handles.ncells=size(handles.events,2);
totpoints=size(handles.events,1);
ltrace=floor((handles.stimoff-handles.stimon)*3600*srcalcium);%vector with the length of each video in points of calcium imaging data (i.e. frames).
if sum(ltrace)<totpoints
    ltrace(end)=ltrace(end)+totpoints-sum(ltrace);%correction for rounding error
end

%loading cell images
th=5;%Threshold to isolate the cells from the noise
eval('cd ..')
eval('cd filters')
filename=dir('*.mat');
ncells=length(filename);
firstfilt=load(filename(1).name);
if isfield(firstfilt.Object,'DataStorage')
    matfilt=firstfilt.Object.DataStorage;
else
    matfilt=firstfilt.Object.Data;
end
matfilt=thres(matfilt,th);

image(matfilt);
disp('Reading filters');
filtmat=zeros(size(matfilt,1),size(matfilt,2),ncells);
filtmat2=filtmat;
for k=1:ncells
    p=strfind(filename(k).name,'_');%looks for the identifier of the filter number in the filename
    numfilt=str2double(filename(k).name(p(1)+1:p(2)-1));
    filread=load(filename(k).name);
    if isfield(filread.Object,'DataStorage')
        filtmat(:,:,numfilt)=thres(filread.Object.DataStorage,th);
        filtmat2(:,:,numfilt)=thres(filread.Object.DataStorage,2*th);
    else
        filtmat(:,:,numfilt)=thres(filread.Object.Data,th);
        filtmat2(:,:,numfilt)=thres(filread.Object.Data,2.5*th);
    end
    filtmat(:,:,numfilt)=filtmat(:,:,numfilt)./max(max(filtmat(:,:,numfilt)));
    filtmat2(:,:,numfilt)=filtmat2(:,:,numfilt)./max(max(filtmat2(:,:,numfilt)));
    
    %getting the position of the filter as the x and y of the brightest
    %pixel
    [v1,p1]=max(filtmat(:,:,numfilt));
    [v2,p2]=max(v1);
    filterposx(numfilt)=p1(p2);
    filterposy(numfilt)=p2;
end
disp('done!')

%reading traces
eval('cd ..')
eval('cd traces')
filename=dir('*.mat');
ncells=length(filename);
firstr=load(filename(1).name);
if isfield(firstr.Object,'DataStorage')
    mattr=firstr.Object.DataStorage;
else
    mattr=firstr.Object.Data;
end
disp('Reading traces');
trmat=zeros(length(mattr),ncells);
for k=1:ncells
    p=strfind(filename(k).name,'_');%looks for the identifier of the filter number in the filename
    numfilt=str2double(filename(k).name(p(1)+1:p(2)-1));
    filread=load(filename(k).name);
    if isfield(filread.Object,'DataStorage')
        trmat(:,numfilt)=filread.Object.DataStorage-basel(filread.Object.DataStorage);
    else
        trmat(:,numfilt)=filread.Object.Data-basel(filread.Object.Data);
    end
    
    %     indaux=find(trmat(:,numfilt)<0);
    %     trmat(indaux,numfilt)=0;
    %     trmat(:,numfilt)=trmat(:,numfilt)/std(trmat(:,numfilt));
end
disp('done!')
eval('cd ..')
ncells=size(trmat,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now making structure for each video. Each cell will have the traces,
%events,time vector, epochs and score
%first, checking if the number of frames matches:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cp=1;%current period
thr=3.5;%Threshold for event detection = 3.5 stds
disp('Making struct with video data')
nper=length(handles.startpz);
for i=1:nper
    matevwa{i}=[];
    matevnrem{i}=[];
    matevrem{i}=[];
    matevall{i}=[];
    matlmawa{i}=[];
    matevsleep{i}=[];
end
lenwap=zeros(size(handles.startpz));
lennremp=zeros(size(handles.startpz));
lenremp=zeros(size(handles.startpz));%this will be the length of epochs in each state (w/o artifacts) for each period
figure
%handles.EDF=sdfclose(handles.EDF);
if isfield(handles,'fnamLMA')
    cd (handles.pathLMA)
    handles.EDFlma=sdfopen(handles.fnamLMA);
end
if abs(sum(frmvid)-size(trmat,1))<5
    if sum(frmvid)<size(trmat,1)
        trmat=trmat(1:sum(frmvid),:);
    else
        trmat=[trmat zeros(sum(frmvid)-size(trmat,1),size(trmat,2))];
    end
end
%Initializing structure
for i=1:nmovs
    viddata(i).frames=[];
    viddata(i).time=[];
    viddata(i).epochs=[];
    viddata(i).score=[];
    viddata(i).period=[];
    viddata(i).lma=[];
    viddata(i).xaxisLMA=[];
    viddata(i).traces=[];
    viddata(i).events=[];
    viddata(i).meanevrate=[];
    viddata(i).delta=[];
    viddata(i).theta=[];
    viddata(i).Lgama=[];
    viddata(i).Hgama=[];
end
delta0=0.5;%Hz
deltaf=4;
theta0=4;
thetaf=9;
lgama0=30;
lgamaf=80;
hgama0=80;
hgamaf=120;
alldelta=[];
alltheta=[];
allLgama=[];
allHgama=[];
allfrate=[];
allepochsindx=[];
epimg=[];
nepsp1=0;
nepsp=[0 0 0];
wrms=0.5;
for p=1:3
    alldeltap{p}=[];
    allthetap{p}=[];
    allLgamap{p}=[];
    allHgamap{p}=[];
    allfratep{p}=[];
end
if sum(frmvid)==size(trmat,1)
    nEDF=sdfopen(handles.fn);
    figure
    for currmov=1:nmovs
        viddata(currmov).frames=1:frmvid(currmov);
        viddata(currmov).time=3600*(handles.stimon(currmov):(handles.stimoff(currmov)-handles.stimon(currmov))/(frmvid(currmov)-1):handles.stimoff(currmov));%timepoints in sec
        viddata(currmov).epochs=ceil(viddata(currmov).time(1)/handles.el):floor((viddata(currmov).time(end)-handles.el)/handles.el);
        viddata(currmov).score=handles.score(viddata(currmov).epochs);
        viddata(currmov).period=length(find((handles.startpz-viddata(currmov).epochs(1))<0));
        indperiod(currmov)=viddata(currmov).period;
        if indperiod(currmov)==1
            nepsp1=nepsp1+length(viddata(currmov).epochs);
        end
        nepsp(indperiod(currmov))=nepsp(indperiod(currmov))+length(viddata(currmov).epochs);%neps imaged for all periods
        
        epimg=[epimg viddata(currmov).epochs];
        if ~isfield(handles,'fnamLMA')%Adding the LMA data   
            [filename, pathname] = uigetfile({'*.edf'},'Pick the EDF file with the LMA');
            handles.fnamLMA=filename;
            handles.pathLMA=pathname;
            cd (pathname);
            handles.EDFlma=sdfopen(handles.fnamLMA);
        end
        auxdur=viddata(currmov).time(end)-viddata(currmov).time(1);
        viddata(currmov).lma=sdfread(handles.EDFlma,auxdur,viddata(currmov).time(1));%reads the raw LMA data for the current movie
        viddata(currmov).xaxisLMA=(auxdur*(0:length(viddata(currmov).lma)-1)/(length(viddata(currmov).lma)-1))+viddata(currmov).time(1);
        %calculating power bands for the epochs:
        for k=1:length(viddata(currmov).epochs)
            ti=handles.epocht(viddata(currmov).epochs(k));
            eegtrace=handles.filteeg(round(ti*handles.sr(1)):round((ti+handles.el)*handles.sr(1))-1);
            %[eegtrace,edfs]=sdfread(nEDF,handles.el,ti);%replace by the filtered EEG
            viddata(currmov).delta(k)=getpband(eegtrace,handles.el,delta0,deltaf);
            viddata(currmov).theta(k)=getpband(eegtrace,handles.el,theta0,thetaf)./viddata(currmov).delta(k);
            viddata(currmov).Lgama(k)=getpband(eegtrace,handles.el,lgama0,lgamaf);
            viddata(currmov).Hgama(k)=getpband(eegtrace,handles.el,hgama0,hgamaf);
            nv=bandpassfilter(eegtrace,handles.sr(1),[delta0 deltaf]);%bandpass in the respective frequency
            viddata(currmov).delta05(k,:)=winrms(nv,handles.sr(1),wrms);%RMS in 0.5 s windows (8 points/epoch)
            nv=bandpassfilter(eegtrace,handles.sr(1),[theta0 thetaf]);
            viddata(currmov).theta05(k,:)=winrms(nv,handles.sr(1),wrms);%./viddata(currmov).delta05(k,:);
            nv=bandpassfilter(eegtrace,handles.sr(1),[lgama0 lgamaf]);
            viddata(currmov).Lgama05(k,:)=winrms(nv,handles.sr(1),wrms);
            nv=bandpassfilter(eegtrace,handles.sr(1),[hgama0 hgamaf]);
            viddata(currmov).Hgama05(k,:)=winrms(nv,handles.sr(1),wrms);
            for i=1:floor(handles.el/wrms)%Getting the value in 0.5 s chunks without overlapping nor smoothing.
%                 viddata(currmov).delta05(k,i)=getpband(eegtrace(round(1+(i-1)*0.5*handles.sr(1)):round((i*0.5*handles.sr(1)))),handles.el,delta0,deltaf);
%                 viddata(currmov).theta05(k,i)=getpband(eegtrace(round(1+(i-1)*0.5*handles.sr(1)):round((i*0.5*handles.sr(1)))),handles.el,theta0,thetaf)/viddata(currmov).delta05(k,i);
%                 viddata(currmov).Lgama05(k,i)=getpband(eegtrace(round(1+(i-1)*0.5*handles.sr(1)):round((i*0.5*handles.sr(1)))),handles.el,lgama0,lgamaf);
%                 viddata(currmov).Hgama05(k,i)=getpband(eegtrace(round(1+(i-1)*0.5*handles.sr(1)):round((i*0.5*handles.sr(1)))),handles.el,hgama0,hgamaf);
                viddata(currmov).timefrec(k,i)=mean(ti+(round(1+(i-1)*wrms*handles.sr(1)):round(i*wrms*handles.sr(1)))/handles.sr(1));
            end
            if viddata(currmov).score(k)==round(viddata(currmov).score(k))%Same but making nan the epochs with artifacts
                viddata(currmov).deltana(k)=viddata(currmov).delta(k);
                viddata(currmov).thetana(k)=viddata(currmov).theta(k);
                viddata(currmov).Lgamana(k)=viddata(currmov).Lgama(k);
                viddata(currmov).Hgamana(k)=viddata(currmov).Hgama(k);
            else
                viddata(currmov).deltana(k)=nan;
                viddata(currmov).deltana(k)=nan;
                viddata(currmov).thetana(k)=nan;
                viddata(currmov).Lgamana(k)=nan;
                viddata(currmov).Hgamana(k)=nan;
            end
        end
        st=round(handles.score(ind));
        if currmov>1
            viddata(currmov).traces=trmat(sum(frmvid(1:currmov-1))+1:sum(frmvid(1:currmov-1))+frmvid(currmov),:);
            %viddata(currmov).events=binevents(:,sum(frmvid(1:currmov-1))+1:sum(frmvid(1:currmov-1))+frmvid(currmov));
        else
            viddata(currmov).traces=trmat(1:frmvid(currmov),:);
            %viddata(currmov).events=binevents(:,1:frmvid(currmov));e
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%
        %CONDITIONING THE TRACE
        %%%%%%%%%%%%%%%%%%%%%%%
        %bringing all offsets to zero for each movie:
        %first, deleting  negative artifacts identified as negative values smaller than -2 stds(making it -1 std):
        mo=ones(size(viddata(currmov).traces));
        diag2=diag(mean(viddata(currmov).traces));
        auxvid=viddata(currmov).traces-mo*diag2;
        diag3=diag(std(auxvid));
        auxstdmat=mo*diag3;
        auxvid2=auxvid+auxstdmat;%auxvid+2*auxstdmat;
        indnegart=find(auxvid2<0);
        viddata(currmov).traces(indnegart)=-auxstdmat(indnegart);
        %Now substracting individual baseline for all traces
        auxt=viddata(currmov).traces;
        indaux=find(viddata(currmov).traces<0);
        auxt(indaux)=0;%Making the negative values 0 so they won't offset the baseline too much
        D=diag(basel2d(auxt));%Substracting individual baseline for all traces
        viddata(currmov).traces=viddata(currmov).traces-mo*D;
        
        %Now replacing the lowest value by the second lowest in the
        %histogram
        for q1=1:ncells
            tr=viddata(currmov).traces(:,q1);
            [n,x]=hist(tr,100);
            indaux=find(n>0);
            lowerval=x(indaux(2));%Second smallest interval with >0 cases
            tr(find(tr<lowerval))=lowerval;
            viddata(currmov).traces(:,q1)=tr;
        end
        %doing hte baseline thing again with the "clean" traces
        D=diag(basel2d(viddata(currmov).traces));%Substracting individual baseline for all traces
        viddata(currmov).traces=viddata(currmov).traces-mo*D;
        valmula=handles.el;%It was 10 originally
        neps=length(viddata(currmov).epochs);
        fp=viddata(currmov).time(1);
        [vs,ps]=min(abs(viddata(currmov).time-fp-valmula));
        frmov=(ps-1)/valmula;
        [vmin,pmin]=min(abs(handles.el*ceil(viddata(currmov).time(1)/handles.el)-viddata(currmov).time));%identifying the timepoint when the 1st epoch starts
        pminmov=max(1,pmin-1);%double check this
        pmaxmov=pminmov+round(neps*floor(handles.el*frmov))-1;%the number of points must be multiple of neps
        viddata(currmov).events=detect_events(viddata(currmov).traces(pminmov:pmaxmov,:),thr);
        viddata(currmov).trace05=fixdim(winmean(viddata(currmov).traces(pminmov:pmaxmov,:),frmov,wrms));
         %pmax=min(length(viddata(currmov).events),pmin+round(neps*floor(handles.el*frmov))-1);
        %[vmax,pmax]=min(abs(handles.el*(floor(viddata(currmov).time(end)/handles.el))-viddata(currmov).time));%identifying the timepoint when the last epoch ends
        s=size(viddata(currmov).events);
        viddata(currmov).meanevrate=fixdim(sum(reshape(viddata(currmov).events,neps,floor(s(1)/neps),s(2)),2)/handles.el);%mean events/sec for each epoch
        
        viddata(currmov).totev=sum(viddata(currmov).events,2);
        viddata(currmov).fixedtime=viddata(currmov).time(pminmov:pmaxmov);
        %viddata(currmov).meanevrate=fixdim(max(reshape(viddata(currmov).events(pmin:pmax,:),neps,floor(s(1)/neps),s(2)),2));%max # events for each epoch
        %The same for the LMA. 
        
        ti=handles.epocht(viddata(currmov).epochs(k));
        tf=ti+handles.el*length(viddata(currmov).epochs);
        viddata(currmov).events05=fixdim(winmean(viddata(currmov).events,frmov,wrms));
        
        %now reshaping and cutting the edges to get the mean event rate
        %/epoch
        %         if mod(currmov,10)==0
        %             cla
        %             ccell=round(rand(1,1)*ncells);
        %             celltp=max(1,ccell):min(ccell+4,ncells)
        %             plot(viddata(currmov).time,viddata(currmov).traces(:,celltp));
        %             hold on
        %             plot(viddata(currmov).time,-8*viddata(currmov).events(:,celltp),'.')
        %             plot(viddata(currmov).time,ones(length(viddata(currmov).time),length(celltp))*diag(std(viddata(currmov).traces(:,celltp))*thr),'--')
        %             %min threshold:
        %             mstd=median(std(viddata(currmov).traces));
        %
        %             plot(viddata(currmov).time,ones(1,length(viddata(currmov).time)).*(mstd*(2/3))*thr,'r-')
        %             plot(viddata(currmov).time,ones(1,length(viddata(currmov).time)).*(mstd*(5/3))*thr,'r-')
        %             pause
        %         end
        if currmov>1 && viddata(currmov).period>viddata(currmov-1).period %Detects pasasge to the next period
            %figure
            totnmovs(cp)=currmov-1;
            cp=cp+1;
        end
        %Excluding artifacts from the analysis.
        [vmin,pmin]=min(abs(handles.el*ceil(viddata(currmov).time(1)/handles.el)-viddata(currmov).xaxisLMA));%identifying the timepoint when the 1st epoch starts
        pmax=pmin+round(neps*floor(handles.el*handles.EDFlma.SampleRate))-1;
        s=size(viddata(currmov).lma(pmin:pmax,:));
        viddata(currmov).meanLMA=fixdim(sum(reshape(viddata(currmov).lma(pmin:pmax,:),neps,floor(s(1)/neps),s(2)),2)/handles.el);
        
        alldelta=[alldelta viddata(currmov).deltana(find(isfinite(viddata(currmov).deltana)))];
        alltheta=[alltheta viddata(currmov).thetana(find(isfinite(viddata(currmov).deltana)))];
        allLgama=[allLgama viddata(currmov).Lgamana(find(isfinite(viddata(currmov).deltana)))];
        allHgama=[allHgama viddata(currmov).Hgamana(find(isfinite(viddata(currmov).deltana)))];
        if length(allfrate)==0;
            allfrate=[viddata(currmov).meanevrate(find(isfinite(viddata(currmov).deltana)),:)];
        else
            allfrate=[allfrate; viddata(currmov).meanevrate(find(isfinite(viddata(currmov).deltana)),:)];
        end
        if length(alldeltap{cp})==0
            alldeltap{cp}=viddata(currmov).delta(find(isfinite(viddata(currmov).deltana)));
            allthetap{cp}=viddata(currmov).theta(find(isfinite(viddata(currmov).deltana)));
            allLgamap{cp}=viddata(currmov).Lgama(find(isfinite(viddata(currmov).deltana)));
            allHgamap{cp}=viddata(currmov).Hgama(find(isfinite(viddata(currmov).deltana)));
            allfratep{cp}=viddata(currmov).meanevrate(find(isfinite(viddata(currmov).deltana)),:);
        else  
            alldeltap{cp}=horzcat(alldeltap{cp},viddata(currmov).delta(find(isfinite(viddata(currmov).deltana))));
            allthetap{cp}=horzcat(allthetap{cp},viddata(currmov).theta(find(isfinite(viddata(currmov).deltana))));
            allLgamap{cp}=horzcat(allLgamap{cp},viddata(currmov).Lgama(find(isfinite(viddata(currmov).deltana))));
            allHgamap{cp}=horzcat(allHgamap{cp},viddata(currmov).Hgama(find(isfinite(viddata(currmov).deltana))));
            allfratep{cp}=[allfratep{cp}; viddata(currmov).meanevrate(find(isfinite(viddata(currmov).deltana)),:)];
        end
        allepochsindx=[allepochsindx viddata(currmov).epochs(find(isfinite(viddata(currmov).deltana)))];
        %Now making a matrix with event rate per epoch for each state, for
        %each period, for each cell. NO ARTIFACTS
        indwa=find(viddata(currmov).score==0);
        lenwap(cp)=lenwap(cp)+length(indwa);
        indnrem=find(viddata(currmov).score==1);
        lennremp(cp)=lennremp(cp)+length(indnrem);
        indrem=find(viddata(currmov).score==2);
        lenremp(cp)=lenremp(cp)+length(indrem);
        %filling matev (REM,NREMa and WA)
        matevwa{cp}=[matevwa{cp};viddata(currmov).meanevrate(indwa,:)];
        matevrem{cp}=[matevrem{cp};viddata(currmov).meanevrate(indrem,:)];
        matevnrem{cp}=[matevnrem{cp};viddata(currmov).meanevrate(indnrem,:)];
        matevsleep{cp}=[matevsleep{cp};viddata(currmov).meanevrate(sort([indnrem indrem]),:)];
        matevall{cp}=[matevall{cp};viddata(currmov).meanevrate];
        matlmawa{cp}=[matlmawa{cp};viddata(currmov).meanLMA(indwa,:)];
    end
    [nEDF]=sdfclose(nEDF);
else
    disp('sum(frmvid)~=size(trmat,1)')
    return
end
guidata(hObject, handles);
%plotting epoch EvRate vs epoch power band for each cell for each period
%for Theta, delta and 
np=3
figure 

for cp=1:np
    for nc=1:ncells
        [v,p]=corrcoef(alldeltap{cp}',allfratep{cp}(:,nc));
        vcordelta(nc,cp)=v(2,1);
        pcordelta(nc,cp)=p(2,1);
        [v,p]=corrcoef(allHgamap{cp}',allfratep{cp}(:,nc));
        vcordgama(nc,cp)=v(2,1);
        pcorgama(nc,cp)=p(2,1);
        [v,p]=corrcoef(allthetap{cp}',allfratep{cp}(:,nc));
        vcorteta(nc,cp)=v(2,1);
        pcorteta(nc,cp)=p(2,1);
    end
    
%     indsigdeltap=find(pcordelta(:,cp)<0.001 & vcordelta(:,2)>0.2);
%     indsigdeltan=find(pcordelta(:,cp)<0.001 & vcordelta(:,2)<0.2);
    % indnosigdeltap=find(pcordelta(:,2)>=0.05 & ;
    %Now the figure with the cells for the correlation with the frecs
    %making merged figures with the right colors
    figcells=zeros(size(filtmat,1),size(filtmat,2),3);%3-D matrix with all the cells color coded according to firing preference
    %normalizing correlation values:
    vcordgaman(:,cp)=vcordgama(:,cp)-min(vcordgama(:,cp));
    vcordgaman(:,cp)=vcordgaman(:,cp)/max(vcordgaman(:,cp));
    vcortetan(:,cp)=vcorteta(:,cp)-min(vcorteta(:,cp));
    vcortetan(:,cp)=vcortetan(:,cp)/max(vcortetan(:,cp));
    vcordeltan(:,cp)=vcordelta(:,cp)-min(vcordelta(:,cp));
    vcordeltan(:,cp)=vcordeltan(:,cp)/max(vcordeltan(:,cp));
    matcolcell=[vcortetan(:,cp)'; vcordgaman(:,cp)'; vcordeltan(:,cp)']';
    
    %Red:theta, Green:gamma, Blue:delta
    for i=1:ncells
        auxteta=[];
        auxdelta=[];
        auxgama=[];
        auxmat=fixdim(filtmat(:,:,i)); %image with the cell (normalized filter)
        for q1=1:3
            m1=fixdim(figcells(:,:,q1));
            m2=auxmat*matcolcell(i,q1);%red
            sfc=size(m1);
            newmatf=max([m1(:)' ;m2(:)']);
            figcells(:,:,q1)=reshape(newmatf,sfc);
        end
    end
    subplot(np,1,cp)
    %figcells=figcells*1.4;
    ind2=find(figcells>1);
    figcells(ind2)=1;
    image(figcells)%figcells(x,y,ind) is the level of color
    axis off
    
end


%Now the figure with the cells:
%making merged figures with the right colors
figcells=zeros(size(filtmat,1),size(filtmat,2),3);%3-D matrix with all the cells color coded according to firing preference
%Red:REM, Green:WA, Blue:NREM %using last period for mean f rate
for i=1:ncells
    auxrem=[];
    auxnrem=[];
    auxwa=[];
    for np=1:nper
        if size(matevrem{np},1)>0
            auxrem=[auxrem; matevrem{np}(:,i)];
        end
        auxnrem=[auxnrem; matevnrem{np}(:,i)];
        auxwa=[auxwa; matevwa{np}(:,i)];
        if length(matevrem{np}(:,i))>0
            auxremp{np}=[matevrem{np}(:,i)];
        else
            auxremp{np}=0;
        end
        auxnremp{np}=[matevnrem{np}(:,i)];
        auxwap{np}=[matevwa{np}(:,i)];
        fratep{np}=[mean(auxremp{np}) mean(auxwap{np}) mean(auxnremp{np})];%mean f rate by period
        if max(fratep{np})>0
            fratevp{np}(i,:)=fratep{np}./sum(fratep{np});%This will be the normalized color values (sum of the 3 colors =1)
        else
            fratevp{np}(i,:)=fratep{np};
        end
    end
    frate=[mean(auxrem) mean(auxwa) mean(auxnrem)];%Global frates for all periods combined
    if max(frate)>0
        fratev(i,:)=frate./sum(frate);%This will be the normalized color values (sum of the 3 colors =1)
    else
        fratev(i,:)=frate;
    end
    auxmat=fixdim(filtmat(:,:,i)); %image with the cell (normalized filter)
    for q1=1:3
        m1=fixdim(figcells(:,:,q1));
        m2=auxmat*fratev(i,q1);%red
        sfc=size(m1);
        newmatf=max([m1(:)' ;m2(:)']);
        figcells(:,:,q1)=reshape(newmatf,sfc);
    end
end

%Quantifying how many cells change preference
%pref=1 -> REM, 2-> WA, 3->NREM
pref=zeros(nper,ncells);
leastpref=zeros(nper,ncells);
for np=1:nper
    [v,p]=max(fratevp{np}');
    [vmin,pmin]=min(fratevp{np}');
    indsigp=find(v>1.3*median(fratevp{np}'));%event rate of prefered must be > 30% higher than the next e.r. (given by the median)
    indlowsigp=find(v<=1.3*median(fratevp{np}') & v>1.3*vmin);
    pref(np,indsigp)=p(indsigp);
    leastpref(np,indlowsigp)=p(indlowsigp)+0.1*pmin(indlowsigp);
    %nsigp(np)=length(find(pref(np,:)>0));
    nsigp(np)=length(indsigp);
    indxpref(np,:)=v./(median(fratevp{np}')+vmin);
    [y,indordr]=sort(indxpref(np,:),'descend');
    ordpref(np,:)= pref(np,indordr);
    ordleastpref(np,:)=leastpref(np,indordr);
    
    %     for nc=1:ncells
    %         if pref(np,nc)>0
    %             ind=find(auxmat<0.2*max(max(auxmat))& auxmat>0.1*max(max(auxmat)));
    %         end
    %     end
end
figure
bar(100*nsigp./ncells)
title('% of State Dependent Cells')
xlabel('ZT')
[v,allpref]=max(fratev');
indc=zeros(1,ncells);%Index for cells that remain state dependent in all 3(2) periods to the same state
indcstateWA=find(prod(pref(2:3,:))==4);
indcstateNR=find(prod(pref(2:3,:))==9);
indcstateR=find(prod(pref(2:3,:))==1);
indc(indcstateWA)=1;
indc(indcstateNR)=1;
indc(indcstateR)=1;
indanypref=zeros(1,ncells);
indanypref(find(prod(pref(2:3,:))>0))=1;%Index of non specific preference for the last two periods

%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%Outline of the cells

imCentroids = zeros(size(filtmat));
imCentroidscenter=imCentroids;
limx=size(imCentroids,1);
limy=size(imCentroids,2);
for j = 1:ncells
    imageIn=binsign(fixdim(filtmat2(:,:,j)));%binary image
    [imCentroids(:,:,j)]=edge2(imageIn);
    %      [imCentroidsin(:,:,j)]=edge2(~imageIn);
    %      [imCentroids2(:,:,j)]=edge2(~(imageIn - fixdim(imCentroidsin(:,:,j))-fixdim(imCentroids(:,:,j))));
    [imCentroidscenter(max(1,filterposx(j)-1):min(limx,filterposx(j)+1),filterposy(j),j)]=100;
    [imCentroidscenter(filterposx(j),max(1,filterposy(j)-1):min(limy,filterposy(j)+1),j)]=100;
end

%%%%%%%
figure
figcells=figcells*1.4;
ind2=find(figcells>1);
figcells(ind2)=1;
image(figcells)%figcells(x,y,ind) is the level of color
axis off

figure
%Now plotting the figure for each period:
for np=1:nper
    figcells=zeros(size(filtmat,1),size(filtmat,2),3);
    figcells2=figcells;
    
    for i=1:ncells
        auxmat=fixdim(filtmat(:,:,i));%*1.2? %image with the cell (normalized filter)
        for q1=1:3
            m1=fixdim(figcells(:,:,q1));
            mm1=fixdim(figcells2(:,:,q1));
            if pref(np,i)==q1
                %                 m2=auxmat*fratevp{np}(i,q1)+(100*binsign(imCentroids(:,:,i)));
                %             else
                %                 m2=auxmat*fratevp{np}(i,q1);
                
                mm2=100*binsign(imCentroids(:,:,i));
            else
                mm2=zeros(size(binsign(imCentroids(:,:,i))));
                
            end
            m2=auxmat*fratevp{np}(i,q1);
            sfc=size(m1);
            newmatf=max([m1(:)' ;m2(:)']);
            auxnewmatf=max([mm1(:)' ;mm2(:)']);
            figcells(:,:,q1)=reshape(newmatf,sfc);
            figcells2(:,:,q1)=reshape(auxnewmatf,sfc);
            if indc(i)>0%Making white dot in center of state dependent cells that don't change preference
                figcells2(:,:,q1)=figcells2(:,:,q1)+100*(imCentroidscenter(:,:,i).*indc(i));
            end
        end
    end
    figcells=figcells*1.4;
    %add centroids2 for cells that change or vice.
    ind2=find(figcells>1);
    figcells(ind2)=1;
    subplot(2,nper,np)
    image(figcells)%figcells(x,y,ind) is the level of color
    axis off
    tit{1}='ZT 0-1';
    tit{2}='ZT 5-6';
    tit{3}='ZT 11-12';
    title(strcat('Period: ',tit{np}),'fontsize',21)
    ind2=find(figcells2>1);
    figcells2(ind2)=1;
    subplot(2,nper,np+3)
    image(figcells2)%figcells(x,y,ind) is the level of color
    axis off
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%calculating correlations with the data at 2 Hz%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Correlataions for all the cells either for all epochs or for epochs
%without artifacts in each state for each period

%now getting lag and crosscorr between the bands and the events
wincorr=round(3/wrms);%checking for corr in  a -3, +3 s range
for i=1:nper
    adelta{i}=[];%all epochs
    atheta{i}=[];
    algam{i}=[];
    ahgam{i}=[];
    sdeltawa{i}=[];%state specific epochs
    sthetawa{i}=[];
    slgamwa{i}=[];
    shgamwa{i}=[];
    sdeltanr{i}=[];
    sthetanr{i}=[];
    slgamnr{i}=[];
    shgamnr{i}=[];
    sdeltar{i}=[];
    sthetar{i}=[];
    slgamr{i}=[];
    shgamr{i}=[];
    alltraces05{i}=[];
    alleventcell{i}=[];%zeros(1,ncells);
    waeventcell{i}=[];%zeros(1,ncells);
    nreventcell{i}=[];%zeros(1,ncells);
    reventcell{i}=[];%zeros(1,ncells);
end

%Building the vectors for correlations:
%         delta=reshape(viddata(currmov).delta05,round(handles.el/wrms)*length(viddata(currmov).epochs),1);
%         theta=reshape(viddata(currmov).theta05,round(handles.el/wrms)*length(viddata(currmov).epochs),1);
%         lgam=reshape(viddata(currmov).Lgama05,round(handles.el/wrms)*length(viddata(currmov).epochs),1);
%         hgam=reshape(viddata(currmov).Hgama05,round(handles.el/wrms)*length(viddata(currmov).epochs),1);
%         disp('Calculating correlations for all cells...')

currmov=1;

for np=1:nper
    while viddata(currmov).period==np
        
        %making vector of the frequencies
        adelta{np}=[adelta{np}; reshape(viddata(currmov).delta05,round(handles.el/wrms)*length(viddata(currmov).epochs),1)];
        atheta{np}=[atheta{np}; reshape(viddata(currmov).theta05,round(handles.el/wrms)*length(viddata(currmov).epochs),1)];
        algam{np}=[algam{np}; reshape(viddata(currmov).Lgama05,round(handles.el/wrms)*length(viddata(currmov).epochs),1)];
        ahgam{np}=[ahgam{np}; reshape(viddata(currmov).Hgama05,round(handles.el/wrms)*length(viddata(currmov).epochs),1)];
        
        iwa=find(viddata(currmov).score==0);
        sdeltawa{np}=[sdeltawa{np}; reshape(viddata(currmov).delta05(iwa,:),round(handles.el/wrms)*length(iwa),1)];
        sthetawa{np}=[sthetawa{np}; reshape(viddata(currmov).theta05(iwa,:),round(handles.el/wrms)*length(iwa),1)];
        slgamwa{np}=[slgamwa{np}; reshape(viddata(currmov).Lgama05(iwa,:),round(handles.el/wrms)*length(iwa),1)];
        shgamwa{np}=[shgamwa{np}; reshape(viddata(currmov).Hgama05(iwa,:),round(handles.el/wrms)*length(iwa),1)];
        
        inr=find(viddata(currmov).score==1);
        sdeltanr{np}=[sdeltanr{np}; reshape(viddata(currmov).delta05(inr,:),round(handles.el/wrms)*length(inr),1)];
        sthetanr{np}=[sthetanr{np}; reshape(viddata(currmov).theta05(inr,:),round(handles.el/wrms)*length(inr),1)];
        slgamnr{np}=[slgamnr{np}; reshape(viddata(currmov).Lgama05(inr,:),round(handles.el/wrms)*length(inr),1)];
        shgamnr{np}=[shgamnr{np}; reshape(viddata(currmov).Hgama05(inr,:),round(handles.el/wrms)*length(inr),1)];
        
        ir=find(viddata(currmov).score==2);
        sdeltar{np}=[sdeltar{np}; reshape(viddata(currmov).delta05(ir,:),round(handles.el/wrms)*length(ir),1)];
        sthetar{np}=[sthetar{np}; reshape(viddata(currmov).theta05(ir,:),round(handles.el/wrms)*length(ir),1)];
        slgamr{np}=[slgamr{np}; reshape(viddata(currmov).Lgama05(ir,:),round(handles.el/wrms)*length(ir),1)];
        shgamr{np}=[shgamr{np}; reshape(viddata(currmov).Hgama05(ir,:),round(handles.el/wrms)*length(ir),1)];
        
        %now making matrices of the events for all cells
        alleventcell{np}=[alleventcell{np}; viddata(currmov).events05];
        
        %index for specific states
        t05=handles.epocht(viddata(currmov).epochs(1))+(0:size(viddata(currmov).events05,1)-1)*wrms;%vector with the times of each point
        twa=handles.epocht(viddata(currmov).epochs(iwa));%time of the start of the selected epochs
        tnr=handles.epocht(viddata(currmov).epochs(inr));
        tr=handles.epocht(viddata(currmov).epochs(ir));
        iwaev=[];
        inrev=[];
        irev=[];
        for nep=1:length(twa)%building indexes for each epoch with the position of tall the time points inside the selcted epochs
            iwaev=[iwaev find(t05>=twa(nep) & t05<twa(nep)+handles.el)];
        end
        for nep=1:length(tnr)
            inrev=[inrev find(t05>=tnr(nep) & t05<tnr(nep)+handles.el)];
        end
        for nep=1:length(tr)
            irev=[irev find(t05>=tr(nep) & t05<tr(nep)+handles.el)];
        end
        waeventcell{np}=[waeventcell{np}; viddata(currmov).events05(iwaev,:)];
        nreventcell{np}=[nreventcell{np}; viddata(currmov).events05(inrev,:)];
        reventcell{np}=[reventcell{np}; viddata(currmov).events05(irev,:)];
        alltraces05{np}=[alltraces05{np}; viddata(currmov).trace05];
        
        if currmov<nmovs
            currmov=currmov+1;
        else
            np=np+1;%so it will exit the loop
        end
    end    
end
%now getting the corrcoef, p val , max corr and lag for every cell for all
%data and for state specific. using xcov(a,b,'coeff') gives the pearson
%coefficient at every lag


for np=1:nper
    
    %Init:
        
        %optimal lag for correlation between events and bands
        alldeltalag{np}=zeros(1,ncells);
        wadeltalag{np}=zeros(1,ncells);
        nrdeltalag{np}=zeros(1,ncells);
        rdeltalag{np}=zeros(1,ncells);
        allthetalag{np}=zeros(1,ncells);
        wathetalag{np}=zeros(1,ncells);
        nrthetalag{np}=zeros(1,ncells);
        rthetalag{np}=zeros(1,ncells);
        alllgamlag{np}=zeros(1,ncells);
        walgamlag{np}=zeros(1,ncells);
        nrlgamlag{np}=zeros(1,ncells);
        rlgamlag{np}=zeros(1,ncells);
        allhgamlag{np}=zeros(1,ncells);
        wahgamlag{np}=zeros(1,ncells);
        nrhgamlag{np}=zeros(1,ncells);
        rhgamlag{np}=zeros(1,ncells);
        
        %max corrcoef for the lag
        alldeltacc{np}=zeros(1,ncells);
        wadeltacc{np}=zeros(1,ncells);
        nrdeltacc{np}=zeros(1,ncells);
        rdeltacc{np}=zeros(1,ncells);
        allthetacc{np}=zeros(1,ncells);
        wathetacc{np}=zeros(1,ncells);
        nrthetacc{np}=zeros(1,ncells);
        rthetacc{np}=zeros(1,ncells);
        alllgamcc{np}=zeros(1,ncells);
        walgamcc{np}=zeros(1,ncells);
        nrlgamcc{np}=zeros(1,ncells);
        rlgamcc{np}=zeros(1,ncells);
        allhgamcc{np}=zeros(1,ncells);
        wahgamcc{np}=zeros(1,ncells);
        nrhgamcc{np}=zeros(1,ncells);
        rhgamcc{np}=zeros(1,ncells);
        
        %corrcoef at 0 lag
        alldeltac0{np}=zeros(1,ncells);
        wadeltac0{np}=zeros(1,ncells);
        nrdeltac0{np}=zeros(1,ncells);
        rdeltac0{np}=zeros(1,ncells);
        allthetac0{np}=zeros(1,ncells);
        wathetac0{np}=zeros(1,ncells);
        nrthetac0{np}=zeros(1,ncells);
        rthetac0{np}=zeros(1,ncells);
        alllgamc0{np}=zeros(1,ncells);
        walgamc0{np}=zeros(1,ncells);
        nrlgamc0{np}=zeros(1,ncells);
        rlgamc0{np}=zeros(1,ncells);
        allhgamc0{np}=zeros(1,ncells);
        wahgamc0{np}=zeros(1,ncells);
        nrhgamc0{np}=zeros(1,ncells);
        rhgamc0{np}=zeros(1,ncells);
        
        %p-val at 0 lag
        alldeltapv{np}=zeros(1,ncells);
        wadeltapv{np}=zeros(1,ncells);
        nrdeltapv{np}=zeros(1,ncells);
        rdeltapv{np}=zeros(1,ncells);
        allthetapv{np}=zeros(1,ncells);
        wathetapv{np}=zeros(1,ncells);
        nrthetapv{np}=zeros(1,ncells);
        rthetapv{np}=zeros(1,ncells);
        alllgampv{np}=zeros(1,ncells);
        walgampv{np}=zeros(1,ncells);
        nrlgampv{np}=zeros(1,ncells);
        rlgampv{np}=zeros(1,ncells);
        allhgampv{np}=zeros(1,ncells);
        wahgampv{np}=zeros(1,ncells);
        nrhgampv{np}=zeros(1,ncells);
        rhgampv{np}=zeros(1,ncells);
    
    
    
    for nc=1:ncells
        [alldeltalag{np}(nc),alldeltacc{np}(nc),alldeltac0{np}(nc),alldeltapv{np}(nc)]=getcoefs(adelta{np},alleventcell{np}(:,nc),wincorr,wrms);
        [allthetalag{np}(nc),allthetacc{np}(nc),allthetac0{np}(nc),allthetapv{np}(nc)]=getcoefs(atheta{np},alleventcell{np}(:,nc),wincorr,wrms);
        [alllgamlag{np}(nc),alllgamcc{np}(nc),alllgamc0{np}(nc),alllgampv{np}(nc)]=getcoefs(algam{np},alleventcell{np}(:,nc),wincorr,wrms);
        [allhgamlag{np}(nc),allhgamcc{np}(nc),allhgamc0{np}(nc),allhgampv{np}(nc)]=getcoefs(ahgam{np},alleventcell{np}(:,nc),wincorr,wrms);
        
        [wadeltalag{np}(nc),wadeltacc{np}(nc),wadeltac0{np}(nc),wadeltapv{np}(nc)]=getcoefs(sdeltawa{np},waeventcell{np}(:,nc),wincorr,wrms);
        [wathetalag{np}(nc),wathetacc{np}(nc),wathetac0{np}(nc),wathetapv{np}(nc)]=getcoefs(sthetawa{np},waeventcell{np}(:,nc),wincorr,wrms);
        [walgamlag{np}(nc),walgamcc{np}(nc),walgamc0{np}(nc),walgampv{np}(nc)]=getcoefs(slgamwa{np},waeventcell{np}(:,nc),wincorr,wrms);
        [wahgamlag{np}(nc),wahgamcc{np}(nc),wahgamc0{np}(nc),wahgampv{np}(nc)]=getcoefs(shgamwa{np},waeventcell{np}(:,nc),wincorr,wrms);
        
        [nrdeltalag{np}(nc),nrdeltacc{np}(nc),nrdeltac0{np}(nc),nrdeltapv{np}(nc)]=getcoefs(sdeltanr{np},nreventcell{np}(:,nc),wincorr,wrms);
        [nrthetalag{np}(nc),nrthetacc{np}(nc),nrthetac0{np}(nc),nrthetapv{np}(nc)]=getcoefs(sthetanr{np},nreventcell{np}(:,nc),wincorr,wrms);
        [nrlgamlag{np}(nc),nrlgamcc{np}(nc),nrlgamc0{np}(nc),nrlgampv{np}(nc)]=getcoefs(slgamnr{np},nreventcell{np}(:,nc),wincorr,wrms);
        [nrhgamlag{np}(nc),nrhgamcc{np}(nc),nrhgamc0{np}(nc),nrhgampv{np}(nc)]=getcoefs(shgamnr{np},nreventcell{np}(:,nc),wincorr,wrms);
        
        [rdeltalag{np}(nc),rdeltacc{np}(nc),rdeltac0{np}(nc),rdeltapv{np}(nc)]=getcoefs(sdeltar{np},reventcell{np}(:,nc),wincorr,wrms);
        [rthetalag{np}(nc),rthetacc{np}(nc),rthetac0{np}(nc),rthetapv{np}(nc)]=getcoefs(sthetar{np},reventcell{np}(:,nc),wincorr,wrms);
        [rlgamlag{np}(nc),rlgamcc{np}(nc),rlgamc0{np}(nc),rlgampv{np}(nc)]=getcoefs(slgamr{np},reventcell{np}(:,nc),wincorr,wrms);
        [rhgamlag{np}(nc),rhgamcc{np}(nc),rhgamc0{np}(nc),rhgampv{np}(nc)]=getcoefs(shgamr{np},reventcell{np}(:,nc),wincorr,wrms);
        %
    end
    indwacells{np}=find(pref(np,:)==0);
    indnrcells{np}=find(pref(np,:)==1);
    indrcells{np}=find(pref(np,:)==2);
    
figure;
subplot(3,1,1)
plot(mean(alltraces05{np}(:,indwacells{np}),2),'k')
box off
title('Mean traces')
subplot(3,1,2);
plot(max(alleventcell{np}(:,indwacells{np}),2),'k')
box off
title('Max of events')
subplot(3,1,3);
plot(ahgam{np},'k')
box off
title('High Gamma')
end

currmov=1;
dt=viddata(currmov).fixedtime(2)-viddata(currmov).fixedtime(1);

%for cp=1:handles.nump
for cp=handles.nump+1:handles.nump
    figure
    viddata(currmov).period=0
    while viddata(currmov).period==cp
        
        %plotting raster with scoring
        subplot(7,1,1)
        movscore=zeros(size(viddata(currmov).fixedtime));
        for t=1:length(viddata(currmov).fixedtime)
            movscore(t)=state(viddata(currmov).fixedtime(t),handles);
        end
        plot(viddata(currmov).fixedtime,movscore,'k-','linewidth',1.5)
        %plot(handles.el*viddata(currmov).epochs,viddata(currmov).score,'k-','linewidth',1.5)
        hold on
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                %first plottingt the scoring during hte shadow time
                
                xvect=[viddata(currmov-1).fixedtime(end)+dt viddata(currmov).fixedtime(1)-dt];
                tvect=[viddata(currmov-1).fixedtime(end)+dt:dt:viddata(currmov).fixedtime(1)-dt];
                movscore=zeros(size(tvect));
                for t=1:length(tvect)
                    movscore(t)=state(tvect(t),handles);
                end
                plot(tvect,movscore,'k-','linewidth',1.5)
                
                
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        %         if currmov>1%plotting shadow in gap between movies
        %             if viddata(currmov).period==viddata(currmov-1).period
        %                 xvect=[viddata(currmov-1).epochs(end) viddata(currmov).epochs(1)];
        %                 minmax=[0 2.1];%get(gca,'ylim');
        %                 einf=[minmax(1) minmax(1)];
        %                 emax=[minmax(2) minmax(2)];
        %                 X=[xvect,fliplr(xvect)];                %create continuous x value array for plotting
        %                 Y=[einf,fliplr(emax)];              %create y values for out and then back
        %                 %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
        %                 hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
        %                 uistack(hl,'bottom')
        %             end
        %         end
        axis tight
        subplot(7,1,2)
        %plot(viddata(currmov).epochs,mean(viddata(currmov).meanevrate,2),'k-')
        plot(viddata(currmov).fixedtime,viddata(currmov).totev,'k-')
        hold on
        %         if currmov>1 %plotting shadow in gap between movies
        %             if viddata(currmov).period==viddata(currmov-1).period
        %                 xvect=[viddata(currmov-1).epochs(end) viddata(currmov).epochs(1)];
        %                 minmax=get(gca,'ylim');
        %                 einf=[minmax(1) minmax(1)];
        %                 emax=[minmax(2) minmax(2)];
        %                 X=[xvect,fliplr(xvect)];                %create continuous x value array for plotting
        %                 Y=[einf,fliplr(emax)];              %create y values for out and then back
        %                 %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
        %                 hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
        %                 uistack(hl,'bottom')
        %             end
        %         end
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        
        
        
        axis tight
        subplot(7,1,3:6)%plotting raster
        bdtp=binmatfpl(viddata(currmov).events,0.9);
        hold on
        k=size(bdtp,2);
        newind=nan(size(bdtp));
        indr1=find(pref(cp,:)==1);
        lindr1(cp)=length(indr1);
        indr2=find((leastpref(cp,:)>1 & leastpref(cp,:)<2));
        lindr2(cp)=length(indr2);
        indw1=find(pref(cp,:)==2);
        lindw1(cp)=length(indw1);
        indw2=find((leastpref(cp,:)>2 & leastpref(cp,:)<3));
        lindw2(cp)=length(indw2);
        indnr1=find(pref(cp,:)==3);
        lindnr1(cp)=length(indnr1);
        indnr2=find(leastpref(cp,:)>3);
        lindnr2(cp)=length(indnr2);
        indinv=find(leastpref(cp,:)==0 & pref(cp,:)==0);
        lindinv(cp)=length(indinv);
        
        vecind=[indr1 indr2 indw1 indw2 indnr1 indnr2 indinv];
        for nc=vecind
            %for nc=1:size(bdtp,2)
            colr=1.4*fratevp{cp}(nc,:);
            colr(find(colr>1))=1;
            newind(~isnan(bdtp(:,nc)),nc)=k;
            k=k-1;
            %if ~max(isnan(fratev(nc,:)))
            %plot(viddata(currmov).time,bdtp(:,nc),'.','markersize',5,'color',colr);%add color fratev(ncell)
                plot(viddata(currmov).fixedtime,newind(:,nc),'.','markersize',4,'color',colr);%add color fratev(ncell)
            %end
        end
        axis tight
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        title(strcat('Period :',num2str(viddata(currmov).period)))
        if isfield(handles,'fnamLMA')%Adding the LMA data
            subplot(7,1,7)
            hold on
            plot(viddata(currmov).xaxisLMA,viddata(currmov).lma)
        end
        if currmov<nmovs
            currmov=currmov+1;
        else
            cp=cp+1;
        end
    end
    subplot(7,1,1)
    box off
    axis tight
    subplot(7,1,2)
    box off
    axis tight
    subplot(7,1,3:6)
    box off
    axis tight
    subplot(7,1,7)
    box off
    axis tight
end

%plotting figure with filtered EEG and raster of the prefered and invariant
%cells  %plot instead viddata(currmov).delta05(k,i)

currmov=1;
dt=viddata(currmov).fixedtime(2)-viddata(currmov).fixedtime(1);
for cp=1:handles.nump
    figure
    while viddata(currmov).period==cp
        subplot(16,1,[1 2])
        %plotting bands
        %plot(handles.epocht(viddata(currmov).epochs),viddata(currmov).delta,'k-')
        
        lentime=length(viddata(currmov).fixedtime);
        lenfrec=length(viddata(currmov).delta);
        plot(viddata(currmov).fixedtime,zeros(size(viddata(currmov).fixedtime)),'Visible','off')%setting x ticks in the right place
        hold on
        aux1=viddata(currmov).timefrec';
        aux2=viddata(currmov).delta05';
        plot(aux1(:),aux2(:),'k-')
        
        ylabel('Delta')
        hold on
%         if currmov<nmovs
%             ep2p=viddata(currmov).epochs(end)+1:viddata(currmov+1).epochs(1)-1;
%             plot(handles.epocht(ep2p),viddata(currmov).delta(ep2p),'k-')
%         end
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        axis tight
        set(gca,'xlim',[4.183 4.188]*10^4)
        subplot(16,1,[3 4])
        %plotting bands
        
        %plot(viddata(currmov).fixedtime,simpres(viddata(currmov).Hgama,round(lentime/lenfrec)),'k-')
        %plot(handles.epocht(viddata(currmov).epochs),viddata(currmov).Hgama,'k-')
        plot(viddata(currmov).fixedtime,zeros(size(viddata(currmov).fixedtime)),'Visible','off')%setting x ticks in the right place
        
        aux1=viddata(currmov).timefrec';
        aux2=viddata(currmov).Hgama05';
        plot(aux1(:),aux2(:),'k-')
        ylabel('Gamma')
        hold on
        axis tight
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
%         if currmov<nmovs
%             ep2p=viddata(currmov).epochs(end)+1:viddata(currmov+1).epochs(1)-1;
%             plot(handles.epocht(ep2p),viddata(currmov).Hgama(ep2p),'k-')
        end
        axis tight
        set(gca,'xlim',[4.183 4.188]*10^4)        
        subplot(16,1,[5 6])
        %plotting bands
        %plot(viddata(currmov).fixedtime,simpres(viddata(currmov).theta,round(lentime/lenfrec)),'k-')
        %plot(handles.epocht(viddata(currmov).epochs),viddata(currmov).theta,'k-')
        plot(viddata(currmov).fixedtime,zeros(size(viddata(currmov).fixedtime)),'Visible','off')%setting x ticks in the right place
        hold on
        
        aux1=viddata(currmov).timefrec';
        aux2=viddata(currmov).theta05';
        plot(aux1(:),aux2(:),'k-')
        ylabel('Theta')  
        hold on
        axis tight
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
%         if currmov<nmovs
%             ep2p=viddata(currmov).epochs(end)+1:viddata(currmov+1).epochs(1)-1;
%             plot(handles.epocht(ep2p),viddata(currmov).theta(ep2p),'k-')
        end
        axis tight
        xl=get(gca,'xlim');
        %set(gca,'xlim',[4.161 4.2396]*10^4);%for the example
        %plotting hypnogram
%         subplot(16,1,7)
%         lenh=length(viddata(currmov).score);
%         plot(viddata(currmov).fixedtime,simpres(viddata(currmov).score,round(lentime/lenh)),'k-','linewidth',1.5)
%         %plot(handles.epocht(viddata(currmov).epochs),viddata(currmov).score,'k-','linewidth',1.5)  
%         hold on
% %         if currmov<nmovs
% %             ep2p=viddata(currmov).epochs(end)+1:viddata(currmov+1).epochs(1)-1;
% %             plot(handles.epocht(ep2p),round(handles.score(ep2p)),'k-','linewidth',1.5)
% %         end
%         axis tight
set(gca,'xlim',[4.183 4.188]*10^4)        
        subplot(16,1,[15 16])%plotting # simultaneous events
        plot(viddata(currmov).fixedtime,sum(viddata(currmov).events,2))
        hold on
        axis tight
  set(gca,'xlim',[4.183 4.188]*10^4)      
        subplot(16,1,7:8)%plotting LMA
        %plot(viddata(currmov).xaxisLMA,viddata(currmov).lma)
        lenlma=length(viddata(currmov).lma);
        flma=find(viddata(currmov).xaxisLMA>=viddata(currmov).fixedtime(1));
        lstlma=find(viddata(currmov).xaxisLMA<=viddata(currmov).fixedtime(end));
        flma=flma(1);
        lstlma=lstlma(end);
        p=plot(viddata(currmov).fixedtime,zeros(size(viddata(currmov).fixedtime)),'--','linewidth',0.01);
       
        hold on
        plot(viddata(currmov).xaxisLMA(flma:lstlma),viddata(currmov).lma(flma:lstlma),'k-','linewidth',1.5)
        set(p,'Visible','off')%plot(handles.epocht(viddata(currmov).epochs),viddata(currmov).score,'k-','linewidth',1.5)  
%         hold on
%         if currmov<nmovs
%             ep2p=viddata(currmov).epochs(end)+1:viddata(currmov+1).epochs(1)-1;
%             plot(handles.epocht(ep2p),round(handles.score(ep2p)),'k-','linewidth',1.5)
%         end
%         
        axis tight
        subplot(16,1,9:14)%plotting raster
        bdtp=binmatfpl(viddata(currmov).events,0.9);
        hold on
        k=size(bdtp,2);
        newind=nan(size(bdtp));
        indr1=find(pref(cp,:)==1);
        indw1=find(pref(cp,:)==2);
        indnr1=find(pref(cp,:)==3);
        indinv=find(leastpref(cp,:)==0 & pref(cp,:)==0);
        vecind=[indr1 indw1 indnr1 indinv];
        for nc=vecind
        %for nc=1:size(bdtp,2)
            colr=1.4*fratevp{cp}(nc,:);
            colr(find(colr>1))=1;
            newind(~isnan(bdtp(:,nc)),nc)=k;
            k=k-1;            
            %if ~max(isnan(fratev(nc,:)))
                %plot(viddata(currmov).time,bdtp(:,nc),'.','markersize',5,'color',colr);%add color fratev(ncell)
                plot(viddata(currmov).fixedtime,newind(:,nc),'.','markersize',4,'color',colr);%add color fratev(ncell)
            %end            
        end
        axis tight
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        %set(gca,'xlim',[4.183 4.188]*10^4)
        %set(gca,'xlim',[4.161 4.2396]*10^4);%for the example
        if currmov<nmovs
            currmov=currmov+1;
        else
            cp=cp+1;
        end
    end
end


%figure with EEG,EMG, hypnogram and 3 traces of each type color
%coded
currmov=1;
figure
dt=viddata(currmov).fixedtime(2)-viddata(currmov).fixedtime(1);
% for cp=1:handles.nump
%     figure
%     while viddata(currmov).period==cp
for cp=handles.nump+1:handles.nump
    figure
    while viddata(currmov).period==cp
        
        subplot(7,1,1)
        %plotting EEG and EMG
        if currmov<nmovs
            neps=length(viddata(currmov).epochs(1):viddata(min(nmovs,currmov+1)).epochs(1)-1);
            eeg=reshape(handles.edfdata(handles.cht,:,viddata(currmov).epochs(1):viddata(currmov+1).epochs(1)-1),1,size(handles.edfdata,2)*neps);
            emg=reshape(handles.edfdata(handles.chemg,:,viddata(currmov).epochs(1):viddata(currmov+1).epochs(1)-1),1,size(handles.edfdata,2)*neps);
        else
            neps=length(viddata(currmov).epochs);
            eeg=reshape(handles.edfdata(handles.cht,:,viddata(currmov).epochs),1,size(handles.edfdata,2)*neps);
            emg=reshape(handles.edfdata(handles.chemg,:,viddata(currmov).epochs),1,size(handles.edfdata,2)*neps);
        end
        tveceeg=viddata(currmov).fixedtime(1)+((0:length(eeg)-1)/handles.sr(1));
        plot(tveceeg,eeg*10^6,'k-')
        set(gca,'ylim',[-handles.eegrange handles.eegrange]*10^6)
        hold on
        box off
        subplot(7,1,2)
        plot(tveceeg,emg*10^6,'k-')
        set(gca,'ylim',0.3*[-handles.eegrange handles.eegrange]*10^6)
        box off
        hold on
       %Now hypnogram
       subplot(7,1,3)
        movscore=zeros(size(viddata(currmov).fixedtime));
        for t=1:length(viddata(currmov).fixedtime)
            movscore(t)=state(viddata(currmov).fixedtime(t),handles);
        end
        plot(viddata(currmov).fixedtime,movscore,'k-','linewidth',1.5)
        %plot(handles.el*viddata(currmov).epochs,viddata(currmov).score,'k-','linewidth',1.5)
        hold on
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                %first plottingt the scoring during hte shadow time
                xvect=[viddata(currmov-1).fixedtime(end)+dt viddata(currmov).fixedtime(1)-dt];
                tvect=[viddata(currmov-1).fixedtime(end)+dt:dt:viddata(currmov).fixedtime(1)-dt];
                movscore=zeros(size(tvect));
                for t=1:length(tvect)
                    movscore(t)=state(tvect(t),handles);
                end
                plot(tvect,movscore,'k-','linewidth',1.5)
                box off
                axis tight
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        %Now selected traces
        indr1=find(pref(cp,:)==1);
        indw1=find(pref(cp,:)==2);
        indnr1=find(pref(cp,:)==3);
        indinv=find(leastpref(cp,:)==0 & pref(cp,:)==0);
        subplot(7,1,[4:7])
        vecind=[indr1(1:min(length(indr1),3)) indw1(1:min(length(indw1),3)) indnr1(1:min(length(indnr1),3)) indinv(1:min(length(indinv),3))];
        k=length(vecind);
        hold on
        neps=length(viddata(currmov).epochs);
        fp=viddata(currmov).time(1);
        [vs,ps]=min(abs(viddata(currmov).time-fp-handles.el));
        frmov=(ps-1)/valmula;
        [vmin,pmin]=min(abs(handles.el*ceil(viddata(currmov).time(1)/handles.el)-viddata(currmov).time));%identifying the timepoint when the 1st epoch starts
        pminmov=max(1,pmin-1);%double check this
        pmaxmov=pminmov+round(neps*floor(handles.el*frmov))-1;%the number of points must be multiple of neps
        for nc=vecind
         
        %for nc=1:size(bdtp,2)
            colr=1.4*fratevp{cp}(nc,:);
            colr(find(colr>1))=1;
            plot(viddata(currmov).fixedtime,100*k+viddata(currmov).traces(pminmov:pmaxmov,nc),'Color',colr);%add color fratev(ncell)
            k=k-1;            
           
        end
        axis tight
        if currmov>1 %plotting shadow in gap between movies
            if viddata(currmov).period==viddata(currmov-1).period
                xvect=[viddata(currmov-1).fixedtime(end) viddata(currmov).fixedtime(1)];
                minmax=get(gca,'ylim');
                einf=[minmax(1) minmax(1)];
                emax=[minmax(2) minmax(2)];
                X=[xvect,fliplr(xvect)];            %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                %hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
                hl=fill(X,Y,[0.9 0.9 0.9],'EdgeColor','none');
                uistack(hl,'bottom')
            end
        end
        if currmov<nmovs
            currmov=currmov+1;
        else
            cp=cp+1;
        end
    end
end

%range for period 2 g6f21: set(gca,'xlim',[1.954*10^4 1.992*10^4])
%statistics of sleep architecture during stim and in between periods
%first during imaging (including artifacts)
indwai=find(round(handles.score(epimg))==0);
indnri=find(round(handles.score(epimg))==1);
indri=find(round(handles.score(epimg))==2);

%Bout duration and bout num during imaging:
if length(indwai)>0
    boutdurimgwa=handles.el*getbout(epimg(indwai));
else
    boutdurimgwa=0;
end
if length(indnri)>0
    boutdurimgnr=handles.el*getbout(epimg(indnri));
else
    boutdurimgnr=0;
end
if length(indri)>0
    boutdurimgr=handles.el*getbout(epimg(indri));
else
    boutdurimgr=0;
end
%Bout duration and bout num during the whole imaging period. include the gaps between movies for bout duration:
boutdurimgpwa=[];
boutdurimgpnr=[];
boutdurimgpr=[];
for ip=1:np
    ind=find(indperiod==ip);
    firstep(ip)=viddata(ind(1)).epochs(1);
    lastep(ip)=viddata(ind(end)).epochs(end);
    indi(ip).wa=firstep(ip)-1+find(round(handles.score(firstep(ip):lastep(ip)))==0);
    indi(ip).nr=firstep(ip)-1+find(round(handles.score(firstep(ip):lastep(ip)))==1);
    indi(ip).r=firstep(ip)-1+find(round(handles.score(firstep(ip):lastep(ip)))==2);
    if length(indi(ip).wa)>0
        boutdurimgpwa=[boutdurimgpwa handles.el*getbout(indi(ip).wa)];
    end
    if length(indi(ip).nr)>0
        boutdurimgpnr=[boutdurimgpnr handles.el*getbout(indi(ip).nr)];
    end
    if length(indi(ip).r)>0
        boutdurimgpr=[boutdurimgpr handles.el*getbout(indi(ip).r)];
    end
end

%Average FFT for each state (discarding artifacts)
indwaif=find(handles.score(epimg)==0);
indnrif=find(handles.score(epimg)==1);
indrif=find(handles.score(epimg)==2);
fftimgwa=mean(handles.fftmat(epimg(indwaif),:));
fftimgnr=mean(handles.fftmat(epimg(indnrif),:));
fftimgr=mean(handles.fftmat(epimg(indrif),:));

%Same for the inter-imaging periods
epochs2consider=[];
for ip=1:np-1
    epochs2consider=[epochs2consider lastep(ip)+1:firstep(ip+1)-1];
end
indwa=find(round(handles.score(epochs2consider))==0);
indnr=find(round(handles.score(epochs2consider))==1);
indr=find(round(handles.score(epochs2consider))==2);
boutdurwa=handles.el*getbout(epochs2consider(indwa));
boutdurnr=handles.el*getbout(epochs2consider(indnr));
boutdurr=handles.el*getbout(epochs2consider(indr));

%Average FFT for each state (discarding artifacts)
indwaf=find((handles.score(epochs2consider)==0));
indnrf=find((handles.score(epochs2consider)==1));
indrf=find((handles.score(epochs2consider)==2));
fftwa=mean(handles.fftmat(epochs2consider(indwaf),:));
fftnr=mean(handles.fftmat(epochs2consider(indnrf),:));
fftr=mean(handles.fftmat(epochs2consider(indrf),:));

%Now plotting
figure
subplot (4,3,[4 7 10])
nepsi=length(indwai)+ length(indnri)+ length(indri);
neps=length(indwa)+ length(indnr)+ length(indr);
bar(100*[[length(indwa)/neps ;length(indnr)/neps; length(indr)/neps] [length(indwai)/nepsi; length(indnri)/nepsi;length(indri)/nepsi]]);
set(gca,'fontsize',14)
set(gca,'XTick',[1.5 4.5 7.5])
set(gca,'xticklabel',{'WA','NR','REM'})
title('% Time','fontsize',18)
box off
set(gca,'TickLength',[0 0])
subplot (4,3,[4 7 10]+1)
bar([[mean(boutdurwa); mean(boutdurnr);mean(boutdurr)] [mean(boutdurimgpwa); mean(boutdurimgpnr) ;mean(boutdurimgpr)]]);
set(gca,'xticklabel',{'WA','NR','REM'})
set(gca,'fontsize',14)
title('Mean Bout Duration (s)','fontsize',21)
box off
set(gca,'TickLength',[0 0])
legend('Ctrl','Img')
[v,ind20]=min(abs(handles.freq-20));%position of 20 Hz freq
subplot (4,3,[4 7 10]+2)
plot(handles.freq(1:ind20),fftwa(1:ind20),'k-','linewidth',2);
box off
hold on
plot(handles.freq(1:ind20),fftnr(1:ind20),'b-','linewidth',2);
xlabel('Hz','fontsize',21)
plot(handles.freq(1:ind20),fftr(1:ind20),'r-','linewidth',2);
set(gca,'fontsize',14)
xlabel('Frequency (Hz)','fontsize',21)
box off
ylabel('Power (\muV^2)','fontsize',21)

plot(handles.freq(1:ind20),fftimgwa(1:ind20),'k--','linewidth',2);
plot(handles.freq(1:ind20),fftimgnr(1:ind20),'b--','linewidth',2);
plot(handles.freq(1:ind20),fftimgr(1:ind20),'r--','linewidth',2);
legend('W','NR','REM','W img','NR img','REM img')
newep0=epimg(1);
newepf=epimg(end);
subplot (4,3,1:3)
zt0=get(handles.edit4,'string');
plot(handles.EDF.T0(4)+(handles.EDF.T0(5)/60)+(handles.EDF.T0(6)/3600)-str2double(zt0(1:2))-(str2double(zt0(4:5))/60)-(str2double(zt0(7:7))/3600)+(handles.epocht(newep0)/3600)+(handles.epocht(newep0:newepf)/3600),round(handles.score(newep0:newepf)),'k-','linewidth',1.5);
set(gca,'YTick',[0 1 2])
set(gca,'YTicklabel',{'W','NREM','REM'})
box off
set(gca,'fontsize',14)
xlabel('ZT (Hours)','fontsize',16)




figure;
%Number of epochs/hour in between imaging
numh=neps*handles.el/3600;%number of hours
numbwa=length(boutdurwa)/numh;
numbnr=length(boutdurnr)/numh;
numbr=length(boutdurr)/numh;
%Number of epochs/hour during imaging. Using the whole imaging period (including gaps), to
%avoid fragmentation

numhi=(sum(lastep-firstep))*handles.el/3600;%number of hours
numbwai=length(boutdurimgpwa)/numhi;
numbnri=length(boutdurimgpnr)/numhi;
numbri=length(boutdurimgpr)/numhi;

bar([[numbwa ;numbnr; numbr] [numbwai ;numbnri ;numbri]]);
set(gca,'xticklabel',{'WA','NR','REM'})
set(gca,'fontsize',14)
title('# Bouts/h','fontsize',21)
box off
set(gca,'TickLength',[0 0])
legend('Ctrl','Img')
%bar plots of the average firing rate by state. Then scatter plot for the
%average event rate cell by cell of period1 vs period 2

for i=1:length(handles.startpz)
    ewanp(i)=std(mean(matevwa{i}));%Instead of all cells, only considering hte ones that have preference for that state. i.e. only wake active cells for wake, rem active for rem, etc.
    tpwanp(i)=mean(mean(matevwa{i}));
    enremnp(i)=std(mean(matevnrem{i}));
    tpnremnp(i)=mean(mean(matevnrem{i}));
    eremnp(i)=std(mean(matevrem{i}));
    tpremnp(i)=mean(mean(matevrem{i}));
    
    ewa(i)=std(mean(matevwa{i}(:,find(pref(i,:)==2))));%Instead of all cells, only considering the ones that have preference for that state. i.e. only wake active cells for wake, rem active for rem, etc.
    tpwa(i)=mean(mean(matevwa{i}(:,find(pref(i,:)==2))));
    enrem(i)=std(mean(matevnrem{i}(:,find(pref(i,:)==3))));
    tpnrem(i)=mean(mean(matevnrem{i}(:,find(pref(i,:)==3))));
    erem(i)=std(mean(matevrem{i}(:,find(pref(i,:)==1))));
    tprem(i)=mean(mean(matevrem{i}(:,find(pref(i,:)==1))));
end
figure
subplot(3,1,1)
errorbar(tpwa,ewa,'k.')
hold on
bar(tpwa)
title ('WA Epchs only')
%set(gca,'ylim',[0 0.1])
box off
subplot(3,1,2)
errorbar(tpnrem,enrem,'k.')
hold on
bar(tpnrem)
title ('NREM Epchs only')
%set(gca,'ylim',[0 0.1])
box off
subplot(3,1,3)
errorbar(tprem,erem,'k.')
hold on
bar(tprem)
title ('REM Epchs only')
%set(gca,'ylim',[0 0.1])
box off

figure
subplot(3,1,1)
errorbar(tpwanp,ewanp,'k.')
hold on
bar(tpwanp)

%set(gca,'ylim',[0 0.1])
box off
title ('WA pref, all epchs')
subplot(3,1,2)
errorbar(tpnremnp,enremnp,'k.')
hold on
bar(tpnremnp)

%set(gca,'ylim',[0 0.1])
box off
title ('NREM pref, all epchs')
subplot(3,1,3)
errorbar(tpremnp,eremnp,'k.')
hold on
bar(tpremnp)
box off
title ('REM pref, all epchs')
%set(gca,'ylim',[0 0.1])




%scatter plot WA vs Sleep and NREM vs REM for each period

figure
%for i=1:length(handles.startpz)
i=2%only period 3
if i==1
    texto='ZT 0-1'
end
if i==2
    texto='ZT 5-6'
end
if i==3
    texto='ZT 11-12'
end
ind_cellwpref=find(pref(i,:)>0);
ind_cellwopref=find(pref(i,:)==0);
totind=[ind_cellwopref ind_cellwpref];%Index of all cells sorted so the non prefered will be plotted first
%subplot(2,length(handles.startpz),i)
m=max([max(mean(matevnrem{i},1)) max(mean(matevwa{i},1)) max(mean(matevrem{i},1))]);
subplot(1,3,1)
for nci=1:ncells
    nc=totind(nci);
    colr=1.4*fratevp{i}(nc,:);
    colr(find(colr>1))=1;
    if nci<=length(ind_cellwopref)%plotting no prefered first
        plot(mean(matevnrem{i}(:,nc)),mean(matevwa{i}(:,nc)),'d','color',colr,'markerfacecolor',colr,'markersize',5);
    else
        plot(mean(matevnrem{i}(:,nc)),mean(matevwa{i}(:,nc)),'ko','markerfacecolor',colr,'markersize',6);
    end
    hold on
end
axis tight
xlabel('NREM','fontsize',21)
ylabel('Wake','fontsize',21)
hold on
%     minmax1=get(gca,'ylim');
%     minmax2=get(gca,'xlim');
%     m=max([minmax1(2) minmax2(2)]);
plot([0 m],[0 m],'r--')
set(gca,'xlim',[0 m])
set(gca,'ylim',[0 m])
title(strcat('Mean Event Rate',texto),'fontsize',21)
box off

subplot(1,3,2)

for nci=1:ncells
    nc=totind(nci);
    colr=1.4*fratevp{i}(nc,:);
    colr(find(colr>1))=1;
    if nci<=length(ind_cellwopref)%plotting no prefered first
        plot(mean(matevrem{i}(:,nc)),mean(matevwa{i}(:,nc)),'d','color',colr,'markerfacecolor',colr,'markersize',5);
    else
        plot(mean(matevrem{i}(:,nc)),mean(matevwa{i}(:,nc)),'ko','markerfacecolor',colr,'markersize',6);
    end
    hold on
end
axis tight
xlabel('REM','fontsize',21)
ylabel('Wake','fontsize',21)
hold on
%     minmax1=get(gca,'ylim');
%     minmax2=get(gca,'xlim');
%     m=max([minmax1(2) minmax2(2)]);
plot([0 m],[0 m],'r--')
set(gca,'xlim',[0 m])
set(gca,'ylim',[0 m])
title(strcat('Mean Event Rate',texto),'fontsize',21)
box off

subplot(1,3,3)
for nci=1:ncells
    nc=totind(nci);
    colr=1.4*fratevp{i}(nc,:);
    colr(find(colr>1))=1;
    if nci<=length(ind_cellwopref)%plotting no prefered first
        plot(mean(matevrem{i}(:,nc)),mean(matevnrem{i}(:,nc)),'d','color',colr,'markerfacecolor',colr,'markersize',5);
    else
        plot(mean(matevrem{i}(:,nc)),mean(matevnrem{i}(:,nc)),'ko','markerfacecolor',colr,'markersize',6);
    end
    hold on
end
axis tight
xlabel('REM','fontsize',21)
ylabel('NREM','fontsize',21)
hold on
%     minmax1=get(gca,'ylim');
%     minmax2=get(gca,'xlim');
%     m=max([minmax1(2) minmax2(2)]);
plot([0 m],[0 m],'r-')
set(gca,'xlim',[0 m])
set(gca,'ylim',[0 m])
title(strcat('Mean Event Rate',texto),'fontsize',21)
box off
%end

%ploting scatter LMA vs mean event rate/epoch
figure
subplot(3,1,1)
plot(mean(matevwa{1}(:,find(pref(1,:)==2))'),matlmawa{1},'k.');
[r,p]=corrcoef(mean(matevwa{1}(:,find(pref(1,:)==2))'),matlmawa{1});
%axis tight
xlabel(strcat('Event Rate. r=',num2str(r(2,1)),'p=',num2str(p(2,1))),'fontsize',21)
ylabel('LMA','fontsize',21)
title('ZT 0-1','fontsize',21)
subplot(3,1,2)
plot(mean(matevwa{2}(:,find(pref(2,:)==2))'),matlmawa{2},'k.');
[r,p]=corrcoef(mean(matevwa{2}(:,find(pref(2,:)==2))'),matlmawa{2});
%axis tight
xlabel(strcat('Event Rate. r=',num2str(r(2,1)),'p=',num2str(p(2,1))),'fontsize',21)
ylabel('LMA','fontsize',21)
%title('ZT 4-5','fontsize',21)

subplot(3,1,3)
plot(mean(matevwa{3}(:,find(pref(3,:)==2))'),matlmawa{3},'k.');
[r,p]=corrcoef(mean(matevwa{3}(:,find(pref(3,:)==2))'),matlmawa{3});
%axis tight
xlabel(strcat('Event Rate. r=',num2str(r(2,1)),'p=',num2str(p(2,1))),'fontsize',21)
ylabel('LMA','fontsize',21)
%title('ZT 11-12','fontsize',21)

%looking for correlations between firing rates and spectral power
%generating index with the epochs of each state
nepwa=0;
nepnr=0;
nepr=0;
%pref=1 -> REM, 2-> WA, 3->NREM
indpwa=find(allpref==2);
indpnr=find(allpref==3);
indpr=find(allpref==1);
frater=[];fratenr=[];fratewa=[];
for q1=1:length(allepochsindx)
    switch handles.score(allepochsindx(q1))
        case 0%WA
            nepwa=nepwa+1;
            deltawa(nepwa)=alldelta(q1);
            thetawa(nepwa)=alltheta(q1);
            lgamawa(nepwa)=allLgama(q1);
            hgamawa(nepwa)=allHgama(q1);
            fratewa(nepwa)=mean(allfrate(q1,indpwa),2);%This has the mean firing rate of all WA active cells during each WA epoch            
        case 1%NREM
            nepnr=nepnr+1;
            deltanr(nepnr)=alldelta(q1);
            thetanr(nepnr)=alltheta(q1);
            lgamanr(nepnr)=allLgama(q1);
            hgamanr(nepnr)=allHgama(q1);
            fratenr(nepnr)=mean(allfrate(q1,indpnr),2);
        case 2%REM
            nepr=nepr+1;
            deltar(nepr)=alldelta(q1);
            thetar(nepr)=alltheta(q1);
            lgamar(nepr)=allLgama(q1);
            hgamar(nepr)=allHgama(q1);
            frater(nepr)=mean(allfrate(q1,indpr),2);
    end

end
frateallepwa=allfrate(:,indpwa);%This has the firing rate of all the epochs for all the cells that are WA active
frateallepnr=allfrate(:,indpnr);
frateallepr=allfrate(:,indpr);

for icell=1:length(indpwa)
    [r,p]=corrcoef(deltawa,fratewa);
    rdeltawa(icell)=r(2,1);
    pdeltawa(icell)=p(2,1);
    [r,p]=corrcoef(thetawa,fratewa);
    rthetawa(icell)=r(2,1);
    pthetawa(icell)=p(2,1);
    [r,p]=corrcoef(lgamawa,fratewa);
    rLgamawa(icell)=r(2,1);
    pLgamawa(icell)=p(2,1);
    [r,p]=corrcoef(hgamawa,fratewa);
    rHgamawa(icell)=r(2,1);
    pHgamawa(icell)=p(2,1);
end

for icell=1:length(indpnr)
    [r,p]=corrcoef(deltanr,fratenr);
    rdeltanr(icell)=r(2,1);
    pdeltanr(icell)=p(2,1);
    [r,p]=corrcoef(thetanr,fratenr);
    rthetanr(icell)=r(2,1);
    pthetanr(icell)=p(2,1);
    [r,p]=corrcoef(lgamanr,fratenr);
    rLgamanr(icell)=r(2,1);
    pLgamanr(icell)=p(2,1);
    [r,p]=corrcoef(hgamanr,fratenr);
    rHgamanr(icell)=r(2,1);
    pHgamanr(icell)=p(2,1);
end

for icell=1:length(indpr)
    [r,p]=corrcoef(deltar,frater);
    rdeltar(icell)=r(2,1);
    pdeltar(icell)=p(2,1);
    [r,p]=corrcoef(thetar,frater);
    rthetar(icell)=r(2,1);
    pthetar(icell)=p(2,1);
    [r,p]=corrcoef(lgamar,frater);
    rLgamar(icell)=r(2,1);
    pLgamar(icell)=p(2,1);
    [r,p]=corrcoef(hgamar,frater);
    rHgamar(icell)=r(2,1);
    pHgamar(icell)=p(2,1);
end
figure
subplot(3,1,1)
bar([rdeltawa rthetawa rLgamawa rHgamawa])
hold on
ylabel('Corrcoef for WA cells during WA')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[pdeltawa pthetawa pLgamawa pHgamawa]<0.05;
plot(pvals*max([rdeltawa rthetawa rLgamawa rHgamawa]),'k*')
colormap('hot')

subplot(3,1,2)
bar([rdeltanr rthetanr rLgamanr rHgamanr])
hold on
ylabel('Corrcoef for NR cells during NR')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[pdeltanr pthetanr pLgamanr pHgamanr]<0.05;
plot(pvals*max([rdeltanr rthetanr rLgamanr rHgamanr]),'k*')

subplot(3,1,3)
bar([rdeltar rthetar rLgamar rHgamar])
hold on
ylabel('Corrcoef for REM cells during REM')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[pdeltar pthetar pLgamar pHgamar]<0.05;
plot(pvals*max([rdeltar rthetar rLgamar rHgamar]),'k*')
colormap('hot')

figure
%Now with the overall mean firing rate
[r,p]=corrcoef(deltawa,fratewa);
allrdeltawa=r(2,1);
allpdeltawa=p(2,1);
[r,p]=corrcoef(thetawa,fratewa);
allrthetawa=r(2,1);
allpthetawa=p(2,1);
[r,p]=corrcoef(lgamawa,fratewa);
allrLgamawa=r(2,1);
allpLgamawa=p(2,1);
[r,p]=corrcoef(hgamawa,fratewa);
allrHgamawa=r(2,1);
allpHgamawa=p(2,1);
bar([allrdeltawa allrthetawa allrLgamawa allrHgamawa])
ylabel('Corrcoef for WA')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[allpdeltawa allpthetawa allpLgamawa allpHgamawa]<0.05;
plot(pvals*max([allrdeltawa allrthetawa allrLgamawa allrHgamawa]),'k*')

[r,p]=corrcoef(deltanr,fratenr);
allrdeltanr=r(2,1);
allpdeltanr=p(2,1);
[r,p]=corrcoef(thetanr,fratenr);
allrthetanr=r(2,1);
allpthetanr=p(2,1);
[r,p]=corrcoef(lgamanr,fratenr);
allrLgamanr=r(2,1);
allpLgamanr=p(2,1);
[r,p]=corrcoef(hgamanr,fratenr);
allrHgamanr=r(2,1);
allpHgamanr=p(2,1);
subplot(3,1,2)
bar([allrdeltanr allrthetanr allrLgamanr allrHgamanr])
ylabel('Corrcoef for NREM')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[allrdeltanr allrthetanr allrLgamanr allrHgamanr]<0.05;
hold on
plot(pvals*max([allrdeltanr allrthetanr allrLgamanr allrHgamanr]),'k*')


[r,p]=corrcoef(deltar,frater);
allrdeltar=r(2,1);
allpdeltar=p(2,1);
[r,p]=corrcoef(thetar,frater);
allrthetar=r(2,1);
allpthetar=p(2,1);
[r,p]=corrcoef(lgamar,frater);
allrLgamar=r(2,1);
allpLgamar=p(2,1);
[r,p]=corrcoef(hgamar,frater);
allrHgamar=r(2,1);
allpHgamar=p(2,1);
subplot(3,1,3)
bar([allrdeltar allrthetar allrLgamar allrHgamar])
ylabel('Corrcoef for REM')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[allrdeltar allrthetar allrLgamar allrHgamar]<0.05;
hold on
plot(pvals*max([allrdeltar allrthetar allrLgamar allrHgamar]),'k*')
%Now the same for all epochs, not just the ones scored as the cell
%preference
figure
%Now with the overall mean firing rate.
%This is the one tha matters.. Or not?
[r,p]=corrcoef(alldelta,mean(frateallepwa,2));
allrdeltawa=r(2,1);
allpdeltawa=p(2,1);
[r,p]=corrcoef(alltheta,mean(frateallepwa,2));
allrthetawa=r(2,1);
allpthetawa=p(2,1);
[r,p]=corrcoef(allLgama,mean(frateallepwa,2));
allrLgamawa=r(2,1);
allpLgamawa=p(2,1);
[r,p]=corrcoef(allHgama,mean(frateallepwa,2));
allrHgamawa=r(2,1);
allpHgamawa=p(2,1);
subplot(3,1,1)
bar([allrdeltawa allrthetawa allrLgamawa allrHgamawa])
ylabel('Corrcoef for WA')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
title('All epochs, WA active cells')
pvals=[allpdeltawa allpthetawa allpLgamawa allpHgamawa]<0.05;
hold on
plot(pvals*max([allrdeltawa allrthetawa allrLgamawa allrHgamawa]),'k*')
fftcorwa=[allrdeltawa allrthetawa allrLgamawa allrHgamawa];
pvfftcorwa=[allpdeltawa allpthetawa allpLgamawa allpHgamawa];

[r,p]=corrcoef(alldelta,mean(frateallepnr,2));
allrdeltanr=r(2,1);
allpdeltanr=p(2,1);
[r,p]=corrcoef(alltheta,mean(frateallepnr,2));
allrthetanr=r(2,1);
allpthetanr=p(2,1);
[r,p]=corrcoef(allLgama,mean(frateallepnr,2));
allrLgamanr=r(2,1);
allpLgamanr=p(2,1);
[r,p]=corrcoef(allHgama,mean(frateallepnr,2));
allrHgamanr=r(2,1);
allpHgamanr=p(2,1);
subplot(3,1,2)
bar([allrdeltanr allrthetanr allrLgamanr allrHgamanr])
ylabel('Corrcoef for NREM')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[allpdeltanr allpthetanr allpLgamanr allpHgamanr]<0.05;
hold on
plot(pvals*max([allrdeltanr allrthetanr allrLgamanr allrHgamanr]),'k*')

fftcornr=[allrdeltanr allrthetanr allrLgamanr allrHgamanr];
pvfftcornr=[allpdeltanr allpthetanr allpLgamanr allpHgamanr];

%for REM is only the last two periods
[r,p]=corrcoef(alldelta(nepsp1+1:end),mean(frateallepr(nepsp1+1:end,:),2));
allrdeltar=r(2,1);
allpdeltar=p(2,1);
[r,p]=corrcoef(alltheta(nepsp1+1:end),mean(frateallepr(nepsp1+1:end,:),2));
allrthetar=r(2,1);
allpthetar=p(2,1);
[r,p]=corrcoef(allLgama(nepsp1+1:end),mean(frateallepr(nepsp1+1:end,:),2));
allrLgamar=r(2,1);
allpLgamar=p(2,1);
[r,p]=corrcoef(allHgama(nepsp1+1:end),mean(frateallepr(nepsp1+1:end,:),2));
allrHgamar=r(2,1);
allpHgamar=p(2,1);
subplot(3,1,3)
bar([allrdeltar allrthetar allrLgamar allrHgamar])
ylabel('Corrcoef for REM')
set(gca,'xtick',[1 2 3 4])
set(gca,'xticklabel',{'Delta','Theta','L Gama','H Gama'})
pvals=[allpdeltar allpthetar allpLgamar allpHgamar]<0.05;
hold on
plot(pvals*max([allrdeltar allrthetar allrLgamar allrHgamar]),'k*')
fftcorr=[allrdeltar allrthetar allrLgamar allrHgamar];
pvfftcorr=[allpdeltar allpthetar allpLgamar allpHgamar];
figure
subplot(4,3,1)
hist(rdeltawa,20);
xlabel('Delta WA')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,2)
hist(rdeltanr,20);
xlabel('Delta NREM')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,3)
hist(rdeltar,20);
xlabel('Delta REM')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,4)
hist(rthetawa,20);
xlabel('Theta WA')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,5)
hist(rthetanr,20);
xlabel('Theta NREM')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,6)
hist(rthetar,20);
xlabel('Theta REM')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,7)
hist(rLgamawa,20);
xlabel('LGamma WA')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,8)
hist(rLgamar,20);
xlabel('LGamma NREM')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,9)
hist(rLgamanr,20);
xlabel('LGamma REM')
set(gca,'xlim',[-0.6 0.6])

subplot(4,3,10)
hist(rHgamawa,20);
xlabel('HGamma WA')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,11)
hist(rHgamar,20);
xlabel('HGamma NREM')
set(gca,'xlim',[-0.6 0.6])
subplot(4,3,12)
hist(rHgamanr,20);
xlabel('HGamma REM')
set(gca,'xlim',[-0.6 0.6])

%now ploting:

%examples of correlated firing and power spectra
%indsdelta=find(pdelta<0.001)
[vmaxd,pmaxd]=max(rdeltanr);
[vmind,pmind]=min(rdeltanr);
[vmaxt,pmaxt]=max(rthetar);
[vmint,pmint]=min(rthetar);
[vmaxlg,pmaxlg]=max(rLgamawa);
[vminlg,pminlg]=min(rLgamawa);
[vmaxhg,pmaxhg]=max(rHgamawa);
[vminhg,pminhg]=min(rHgamawa);

figure
subplot(2,4,1)
plot(allfrate(:,pmaxd),alldelta,'ro')
xlabel('F.rate/epoch','fontsize',19)
ylabel('Delta power','fontsize',19)
subplot(2,4,2)
plot(allfrate(:,pmind),alldelta,'ko')
xlabel('F.rate/epoch','fontsize',19)
ylabel('Delta power','fontsize',19)
subplot(2,4,3)
plot(allfrate(:,pmaxt),alltheta,'ro')
xlabel('F.rate/epoch','fontsize',19)
ylabel('Theta power','fontsize',19)
subplot(2,4,4)
plot(allfrate(:,pmint),alltheta,'ko')
xlabel('F.rate/epoch','fontsize',19)
ylabel('Theta power','fontsize',19)
subplot(2,4,5)
plot(allfrate(:,pmaxlg),allLgama,'ro')
xlabel('F.rate/epoch','fontsize',19)
ylabel('Low Gamma power','fontsize',19)
subplot(2,4,6)
plot(allfrate(:,pminlg),allLgama,'ko')
xlabel('F.rate/epoch','fontsize',19)
ylabel('Low Gamma power','fontsize',19)

subplot(2,4,7)
plot(allfrate(:,pmaxhg),allHgama,'ro')
xlabel('F.rate/epoch')
ylabel('High Gamma power')
subplot(2,4,8)
plot(allfrate(:,pminhg),allHgama,'ko')

xlabel('F.rate/epoch')
ylabel('High Gamma power')



figure
subplot(3,1,1)
for nc=1:ncells
    plot(mean(matevwa{1}(:,nc)),mean(matevwa{3}(:,nc)),'ko','markerfacecolor',fratev(nc,:),'markersize',4);
    hold on
end
axis tight
xlabel('ZT 0-1','fontsize',21)
ylabel('ZT 11-12','fontsize',21)
hold on
minmax1=get(gca,'ylim');
minmax2=get(gca,'xlim');
m=max([minmax1(2) minmax2(2)]);
plot([0 m],[0 m],'r-')
set(gca,'xlim',[0 m])
set(gca,'ylim',[0 m])
title('Mean Event Rate WA','fontsize',21)
box off

subplot(3,1,2)
for nc=1:ncells
    plot(mean(matevrem{1}(:,nc)),mean(matevrem{3}(:,nc)),'ko','markerfacecolor',fratev(nc,:),'markersize',4);
    hold on
end
axis tight
xlabel('ZT 0-1','fontsize',21)
ylabel('ZT 11-12','fontsize',21)
hold on
minmax1=get(gca,'ylim');
minmax2=get(gca,'xlim');
m=max([minmax1(2) minmax2(2)]);
plot([0 m],[0 m],'r-')
set(gca,'xlim',[0 m])
set(gca,'ylim',[0 m])
title('Mean Event Rate REM','fontsize',21)
box off

subplot(3,1,3)
for nc=1:ncells
    plot(mean(matevnrem{1}(:,nc)),mean(matevnrem{3}(:,nc)),'.','color',fratev(nc,:),'markersize',4);
    hold on
end
axis tight
xlabel('ZT 0-1','fontsize',21)
ylabel('ZT 11-12','fontsize',21)
hold on
minmax1=get(gca,'ylim');
minmax2=get(gca,'xlim');
m=max([minmax1(2) minmax2(2)]);
plot([0 m],[0 m],'r-')
set(gca,'xlim',[0 m])
set(gca,'ylim',[0 m])
title('Mean Event Rate NREM','fontsize',21)
box off
%     subplot(2,2,2)
%     plot(mean(matevwa{4},1),mean(matevwa{5},1),'k.')
%     axis tight
%     xlabel('1st h. Recovery','fontsize',21)
%     ylabel('6th h. Recovery','fontsize',21)
%     hold on
%     minmax1=get(gca,'ylim');
%     minmax2=get(gca,'xlim');
%     m=max([minmax1(2) minmax2(2)]);
%     plot([0 m],[0 m],'r-')
%     set(gca,'xlim',[0 m])
%     set(gca,'ylim',[0 m])
%     title('Mean Event Rate WA','fontsize',21)
%     box off
%
%     subplot(2,2,3)
%     plot(mean(matevnrem{4},1),mean(matevnrem{5},1),'k.')
%     axis tight
%     xlabel('1st h. Recovery','fontsize',21)
%     ylabel('6th h. Recovery','fontsize',21)
%     hold on
%     minmax1=get(gca,'ylim');
%     minmax2=get(gca,'xlim');
%     m=max([minmax1(2) minmax2(2)]);
%     plot([0 m],[0 m],'r-')
%     set(gca,'xlim',[0 m])
%     set(gca,'ylim',[0 m])
%     title('Mean Event Rate NREM','fontsize',21)
%     box off
%
%     subplot(2,2,4)
%     plot(mean(matevrem{4},1),mean(matevrem{5},1),'k.')
%     axis tight
%     xlabel('1st h. Recovery','fontsize',21)
%     ylabel('6th h. Recovery','fontsize',21)
%     hold on
%     minmax1=get(gca,'ylim');
%     minmax2=get(gca,'xlim');
%     m=max([minmax1(2) minmax2(2)]);
%     plot([0 m],[0 m],'r-')
%     set(gca,'xlim',[0 m])
%     set(gca,'ylim',[0 m])
%     title('Mean Event Rate REM','fontsize',21)
%     box off

barpercstate=100*[[length(indwa)/neps ;length(indnr)/neps; length(indr)/neps] [length(indwai)/nepsi; length(indnri)/nepsi;length(indri)/nepsi]];
bar([[mean(boutdurwa); mean(boutdurnr);mean(boutdurr)] [mean(boutdurimgpwa); mean(boutdurimgpnr) ;mean(boutdurimgpr)]]);

xfreq=handles.freq;
plot(handles.freq(1:ind20),fftwa(1:ind20),'k-','linewidth',2);
datafn=strcat(handles.fn(1:end-4),'data.mat');
save(datafn,'viddata','pref','fratev','matevnrem','matevrem','matevwa','matlmawa','matevall','barpercstate',...
    'boutdurwa','boutdurnr','boutdurr','boutdurimgpwa','boutdurimgpnr','boutdurimgpr','xfreq','fftwa','fftnr','fftr','fftimgwa',...
    'fftimgnr','fftimgr','indcstateWA','indcstateNR','indcstateR','indc','indanypref','thr','fftcorr','pvfftcorr',...
    'fftcornr','pvfftcornr','fftcorwa','pvfftcorwa','leastpref','lindr1','lindr2','lindw1','lindw2','lindnr1','lindnr2','lindinv')
%fftcorr=[allrdeltar allrthetar allrLgamar allrHgamar]; (these are only for
%periods 2 and 3 for rem, and all periods for the other states)
helpdlg('data saved')
guidata(hObject, handles);

%xlim:  set(gca,'xlim',[4.0842 4.0892]*10^4)
%set(gca,'xlim',[4.298 4.302]*10^4)
% set(gca,'xlim',[4.243 4.248]*10^4)
% set(gca,'xlim',[4.183 4.188]*10^4)
 
 


% --- Executes on button press in syncfirst.
function syncfirst_Callback(hObject, eventdata, handles)
% hObject    handle to syncfirst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.synclast,'value',0)
% Hint: get(hObject,'Value') returns toggle state of syncfirst


% --- Executes on button press in synclast.
function synclast_Callback(hObject, eventdata, handles)
% hObject    handle to synclast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.syncfirst,'value',0)
% Hint: get(hObject,'Value') returns toggle state of synclast



function toedit_Callback(hObject, eventdata, handles)
% hObject    handle to toedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h=get(hObject,'String');
handles.hto=str2double(h(1:2));%initial hour
handles.mto=str2double(h(4:5));%initial minute
handles.sto=str2double(h(7:8));%initial second
%set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of toedit as text
%        str2double(get(hObject,'String')) returns contents of toedit as a double


% --- Executes during object creation, after setting all properties.
function toedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to toedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10



function nperiods_Callback(hObject, eventdata, handles)
% hObject    handle to nperiods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nperiods as text
%        str2double(get(hObject,'String')) returns contents of nperiods as a double


% --- Executes during object creation, after setting all properties.
function nperiods_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nperiods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in fixEMG.
function fixEMG_Callback(hObject, eventdata, handles)
% hObject    handle to fixEMG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fixEMG
axes(handles.axes5)
axis tight
minmax=get(gca,'ylim');
handles.limemg=minmax;
guidata(hObject, handles);



% --- Executes on button press in lma.
function lma_Callback(hObject, eventdata, handles)
% hObject    handle to lma (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.edf'},'Pick the EDF file with the LMA');
handles.fnamLMA=filename;
handles.pathLMA=pathname;
cd (pathname);
guidata(hObject, handles);


% --- Executes on key press with focus on figure1 or any of its controls.
function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
