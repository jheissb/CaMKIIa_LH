function varargout = edfview(varargin)
% EDFVIEW M-file for edfview.fig
%      EDFVIEW, by itself, creates a new EDFVIEW or raises the existing
%      singleton*.
%
%      H = EDFVIEW returns the handle to a new EDFVIEW or the handle to
%      the existing singleton*.
%
%      EDFVIEW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EDFVIEW.M with the given input arguments.
%
%      EDFVIEW('Property','Value',...) creates a new EDFVIEW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before edfview_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to edfview_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help edfview

% Last Modified by GUIDE v2.5 23-Jul-2012 16:37:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @edfview_OpeningFcn, ...
    'gui_OutputFcn',  @edfview_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before edfview is made visible.
function edfview_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to edfview (see VARARGIN)

% Choose default command line output for edfview
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes edfview wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = edfview_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadedf.
function loadedf_Callback(hObject, eventdata, handles)
% hObject    handle to loadedf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

cla
%cd ('C:\Users\E26903\Documents\My Dropbox\laptopsleep\anushka')
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file to analyze');
handles.fn=filename;
cd (pathname)
EDF=sdfopen(filename);
set(handles.chanlist,'string',EDF.Label);
nhrs=str2num(get(handles.edit12,'string'));
if get(handles.checkbox2,'value')
    %[s,edfs]=sdfread(EDF,nhrs*3600,(EDF.NRec*EDF.Dur)-(nhrs*3600));%Only reads some hours.
    [s,edfs]=sdfread(EDF,round(nhrs*3600));
else
    [s,edfs]=sdfread(EDF,inf);
    ls=length(s);
    
    if exist(strcat('nNOS',handles.fn(1:end-3),'txt'))
        handles.scoring=load (strcat('nNOS',handles.fn(1:end-3),'txt'));
        %calculating RMS for different stages
    end
    
    selchan=get(handles.chanlist,'value');
    sr=edfs.SampleRate(selchan);
    set(handles.edit14,'string',num2str(sr));
    handles.sr=sr;
    dur=str2num(get(handles.edit4,'string'));
    handles.dur=dur;
    %t0=str2num(get(handles.t0,'string'));
    t0=str2num(get(handles.edit5,'string'));
    set(handles.edit6,'string',num2str(size(s,1)/(60*sr)));
    tf=str2num(get(handles.edit6,'string'));
    
    tvent=str2num(get(handles.tevent,'string'));
    sr=edfs.SampleRate(selchan);
    
    skip=(t0*60*sr)+1;
    lastp=floor((floor(tf)*60*sr));
    splc=str2num(get(handles.startpmnt,'string'));
    eplc=str2num(get(handles.endpmnt,'string'));
    
    %deleting the data during placement of the internals
    %     ti=round(handles.sr*60*splc);
    %     tf=round(handles.sr*60*eplc);
    %     s(ti:tf,:)=0;
    handles.hto=EDF.T0(4);%initial hour
    handles.mto=EDF.T0(5);%initial minute
    handles.sto=EDF.T0(6);%initial second
    handles.s=s;
    handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
    handles.h=handles.axes1;
    handles.x=(0:length(handles.news)-1)/sr;
    %smart scaling:
    % if dur>10
    %     handles.x=handles.x*dur;%scale in min.
    % else
    %     handles.x=handles.x*(dur*60);%scale in s
    % end
    % if get(handles.plotm,'value')
    handles.x=handles.x/60;
    % end
    axis(handles.axes1);
    %plot(hand,handles.x,handles.news(:,selchan))
    %     plot(handles.x,handles.news(:,selchan))
    plot(handles.x,handles.news(:,selchan))
    
    % if dur>10
    xlabel(handles.h,'min','fontsize',14)
    % else
    %      xlabel(handles.h,'s','fontsize',14)
    % end
    %set(handles.tevent,'string',(length(handles.news)/(60*handles.sr))-120);
    set(handles.filename,'string',filename);
    if tvent>0
        minmax=get(gca,'ylim')
        hold on
        plot([tvent tvent]',minmax','g--')
    end
    %reading and processing the scoring
    %to load staging: W=87, NR=78, R=82, crap=85
    %In many cases the scoring starts before the data.
    
    if exist(strcat('nNOS',handles.fn(1:end-3),'txt'))
        handles.scoring=load(strcat('nNOS',handles.fn(1:end-3),'txt'));
        %prunning the first n epochs to match the data size
        cl=length(handles.scoring);
        nepochsindata=floor(length(handles.s)/(sr*10));
        if nepochsindata>cl
            aux0=handles.scoring;
            handles.scoring=zeros(nepochsindata,2);
            handles.scoring(1:nepochsindata-cl,1)=0:nepochsindata-cl-1;
            handles.scoring(1:nepochsindata-cl,2)=85;
            handles.scoring(nepochsindata-cl+1:nepochsindata,:)=aux0;
        else
            handles.scoring=handles.scoring(cl-nepochsindata:cl,:);
        end
        %Now plotting the whole EEG epoch by epoch and calculating RMS for different stages
        nw=0;nr=0;nn=0;nc=0;
        figure
        
        ntr=eegfilter(handles.s(:,selchan),5,0);
        
        xaxis=(0:length(ntr)-1)/sr;
        plot(xaxis,ntr,'k-');
        hold on
        rmsr=0;
        for i=1:length(handles.scoring)-1
            ti=1+(10*(i-1))*sr;
            tf=min(length(ntr),ti+(10*sr));
            if ti>tf
                disp('Error')
                break
            end
            aux=rms(ntr(ti:tf));
            switch handles.scoring(i,2)
                case 87
                    nw=nw+1;
                    rmswa(nw)=aux;
                case 78
                    nn=nn+1;
                    rmsnr(nn)=aux;
                    plot(xaxis(ti:tf),ntr(ti:tf),'r-')
                case 82
                    nr=nr+1;
                    rmsr(nr)=aux;
                    plot(xaxis(ti:tf),ntr(ti:tf),'g-')
                case 85
                    plot(xaxis(ti:tf),ntr(ti:tf),'b-')
            end
        end
        figure
        bar([5000*mean(rmswa) 5000*mean(rmsnr) 5000*mean(rmsr) mean(rmswa)/mean(rmsnr)])
        
        xlabel('WA      NREM   REM     WA/NREM')
        disp('WA, NREM and REM')
        mean(rmswa)
        std(rmswa)
        mean(rmsnr)
        std(rmsnr)
        mean(rmsr)
        std(rmsr)
        
        
        figure;
        subplot(2,1,1)
        plot(rmsnr,'.-')
        subplot(2,1,2)
        plot(rmswa,'.-')
        
        
        
        
    end
    
    
end
handles.hedf=EDF;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function chanlist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chanlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in chanlist.
function chanlist_Callback(hObject, eventdata, handles)
% hObject    handle to chanlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selchan=get(hObject,'value');
t0=str2num(get(handles.t0,'string'));
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));
axis(handles.axes1);
handles.x=(0:length(handles.news)-1)/handles.sr;
handles.x=handles.x/60;
%plot(hand,handles.x,handles.news(:,selchan))
cla
plot(handles.x,handles.news(:,selchan))

% if dur>10
%     xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
if tvent>0
    minmax=get(gca,'ylim')
    hold on
    plot([tvent tvent]',minmax','g--')
    
end
guidata(hObject, handles);

% Hints: contents = get(hObject,'String') returns chanlist contents as cell array
%        contents{get(hObject,'Value')} returns selected item from chanlist


% --- Executes during object creation, after setting all properties.
function t0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to t0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function t0_Callback(hObject, eventdata, handles)
% hObject    handle to t0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
t0=str2num(get(handles.t0,'string'));
skip=(t0*60*handles.sr)+1;
handles.news=handles.s(skip:end,:);%get(handles.chanlist,'value'));%Only 2 hours
guidata(hObject, handles);


% Hints: get(hObject,'String') returns contents of t0 as text
%        str2double(get(hObject,'String')) returns contents of t0 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function tevent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tevent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function tevent_Callback(hObject, eventdata, handles)
% hObject    handle to tevent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tevent as text
%        str2double(get(hObject,'String')) returns contents of tevent as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes on button press in normalize.
function normalize_Callback(hObject, eventdata, handles)
% hObject    handle to normalize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of normalize


% --- Executes on button press in plotbands.
function plotbands_Callback(hObject, eventdata, handles)
% hObject    handle to plotbands (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%t0=str2num(get(handles.t0,'string'));
%in this case the event is the end of sleep dep, which is 2 hours before
%the end of the recording

disp('Grande la U')
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

if handles.sr<200
    handles.sr=250;
end

tevent=str2num(get(handles.tevent,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%news=s(1+round(t0*60)*handles.sr:round((t0+2)*60)*handles.sr,:);%Only 2 hours
%plotting the power and the trace of the whole EEG
winsize=floor(handles.sr*fftwindow);
e1=handles.news(1:winsize*floor(length(handles.news)/winsize),get(handles.chanlist,'value'));
e1=eegfilter(e1,6,0);
e1=eegfilter(e1,7,0);
%stp=handles.news(:,get(handles.chanlist,'value'));
%stp=eegfilter(stp,0);%get rid of artifacts
%stp=eegfilter(stp,0);
figure
subplot(2,1,1)
p=getthepower(e1,(length(e1)/handles.sr),15,1);
disp('Delta power:')
delta=getpband(e1,length(handles.news)/handles.sr,0.5,4)
disp('power of 0.1-60 Hz band:')
toSixty=getpband(e1,length(handles.news)/handles.sr,0.1,60)
%xlabel('Time (s)');
%xlabel('Frequency (Hz)');
subplot(2,1,2)
xscl=(0:length(e1)-1)/(60*handles.sr);
plot(xscl, e1)
title('EEG1')
box off
xlabel('t (s)')
ylabel('V')


%using built in function
% figure;
% %[S,F,T,P] = spectrogram(stp,2048,256,2048,handles.sr,'yaxis');
% [S,F,T,P] = spectrogram(stp,2048,256,[0:0.05:20],handles.sr);
% figure
% surf(T,F,10*log10(abs(P)),'edgecolor','none')
% colormap(jet); axis tight;
% view(0,90);
% xlabel('Time'); ylabel('Hz');
%
% figure
% X=0:size(P(:,1))-1;
% Y=0:size(P(:,2))-1;
% surf(X,Y,P,'FaceColor','interp',...
% 	'EdgeColor','none',...
% 	'FaceLighting','phong')
% daspect([5 5 1])
% axis tight
% view(-50,30)
% camlight left


%getthepower(news(:,2),(length(news)/sr),10,1);
%title('EEG2')
% [B,f,t]=specgram(handles.news(:,get(handles.chanlist,'value')),4096,1024,2);
% bmin=max(max(abs(B)))/300;
%imagesc(t,f,20*log10(max(abs(B),bmin)/bmin));
%axis xy;
%colormap(jet);

eeg1=reshape(e1,winsize,length(e1)/winsize);
%eeg2=reshape(e2,sr*fftwindow,floor(length(news)/(sr*fftwindow)));
[c,r]=size(eeg1);
m1=zeros(1,r);
m2=m1;
%ranges for the oscilations
initial=[0.5 4];
final=[4 8];
%initial=[0.5 4 8 15 30 50];
%final=[4 8 15 30 50 80];

figure
cnt=0;
tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'}];
%tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];

lim=[0 1];
for i=1:length(initial)
    % disp(char(tit(i)));
    
    for k=1:r
        
        
        m1(k)=getpband(eeg1(:,k),fftwindow,initial(i),final(i));
        %     m2(k)=getpband(eeg2(:,k),fftwindow,initial(i),final(i));
        if i==1
            psig1(k)=rms(eeg1(:,k));
            allpow(:,k)=getthepower(eeg1(:,k),fftwindow,10,0);%This plots eeg and fft of each subtrace
            %    	psig2(k)=rms(eeg2(:,k));
        end
        
        
        
        % m1(k)=getpband(eeg1(:,k),fftwindow,4,4.7);
        %m2(k)=getpband(eeg2(:,k),fftwindow,4,4.7);
        
    end
    cnt=cnt+1;%number of current plot
    %m1=eegfilter(m1,2);
    %m1=eegfilter(m1,2);
    %m1=eegfilter(m1,2);
    t=(0:length(m1)-1)/(60/fftwindow);
    %tevent=[5 10 14 68 114]-t0;%Time of events:saline injection & anestheia tp 0.8, Changing syringes pump,EKG placement, refilling iso tank,injecting SP
    
    subplot(2,ceil(length(initial)/2),cnt)
    %figure
    minp=min(m1);%basel(m1);
    maxp=max(m1);%ibasel(m1);
    minmax=[minp maxp];
    %    plot(t,m1)
    %   hold on
    %
    %   axis tight
    %    set(gca,'ylim',(1E-10)*[0 8])
    %    deltatime=3600*1/fftwindow;%the last 1 hours to get the max of the figure
    %    minmax=[0 max(m1(end-deltatime:end))];
    
    %plot(t,m1,'k-',[tevent' tevent']',minmax,'g--',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--',[splc splc]',minmax','c--',[eplc eplc]',minmax','c--')
    plot(t,m1,'k-')
    set(gca,'fontsize',14)
    %set(gca,'xlim',[stinj-30 stinj+30])
    %set(gca,'ylim',minmax)
    %     if i==1
    %         lim=minmax;
    %     end
    %        set(gca,'ylim',lim)
    %          hold on
    %    plot([tinj' tinj'],minmax,'b--')
    %legend('Ket. Injection',14)
    xlabel('[min.]','fontsize',18)
    ylabel('Power','fontsize',18)
    
    %legend('EEG1','EEG2','saline inj.','Syringes manip.','EKG placement','refilling iso','injecting SP')
    title(char(tit(cnt)),'fontsize',24)
    
    %disp(mean(m1))
end
figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow);
if l>w
    sortedp=sort(allpow,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow=allpow/normf;

allpow=allpow/max(max(allpow));
%allpow(find(allpow>1))=1;
allpow=allpow*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow(1:round(l*limf/(0.5*handles.sr)),:)')
colormap(jet)
guidata(hObject, handles);







% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on button press in savepar.
function savepar_Callback(hObject, eventdata, handles)
% hObject    handle to savepar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
newfn=strcat(handles.fn(1:end-3),'mat')
t0=str2num(get(handles.t0,'string'));
tevent=str2num(get(handles.tevent,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
dur=handles.dur;
save (newfn,'t0','tevent','fftwindow','dur');
helpdlg('Parameters saved')


% --- Executes on button press in plots.
function plots_Callback(hObject, eventdata, handles)
% hObject    handle to plots (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plots


% --- Executes on button press in plotm.
function plotm_Callback(hObject, eventdata, handles)
% hObject    handle to plotm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plotm



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
tf=str2num(get(handles.edit6,'string'));
t0=str2num(get(handles.edit5,'string'));
skip=(t0*60*handles.sr)+1;
lastp=(tf*60*handles.sr)+1;
handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
handles.h=handles.axes1;
handles.x=(0:length(handles.news)-1)/handles.sr;
handles.x=handles.x/60;
axis(handles.axes1);
cla
plot(handles.x,handles.news(:,get(handles.chanlist,'value')))
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
tf=str2num(get(handles.edit6,'string'));
t0=str2num(get(handles.edit5,'string'));
skip=(t0*60*handles.sr)+1;
lastp=(tf*60*handles.sr)+1;
handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
handles.h=handles.axes1;
handles.x=(0:length(handles.news)-1)/handles.sr;
handles.x=handles.x/60;
axis(handles.axes1);
cla
plot(handles.x,handles.news(:,get(handles.chanlist,'value')))
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figure
trace=handles.news((str2num(get(handles.edit5,'string'))*60*handles.sr):(str2num(get(handles.edit6,'string'))*60*handles.sr),get(handles.chanlist,'value'));
dur=(str2num(get(handles.edit6,'string'))*60)-(str2num(get(handles.edit5,'string'))*60);
getthepower(trace,dur,25,1);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%this plots the EEG and Power before and after an event, leaving a blank in
%between.
%getting the info from gui
start1=str2num(get(handles.edit5,'string'))*60*handles.sr;
end1=str2num(get(handles.edit6,'string'))*60*handles.sr;
npoints=end1-start1;
trace1=handles.news(start1:end1,get(handles.chanlist,'value'));
tevent=str2num(get(handles.tevent,'string'))*60*handles.sr;
lblank=str2num(get(handles.t0,'string'))*60*handles.sr;
start2=tevent+lblank;
end2=start2+npoints-1;
trace2=handles.news(start2:end2,get(handles.chanlist,'value'));
dur=(str2num(get(handles.edit6,'string'))*60)-(str2num(get(handles.edit5,'string'))*60);
f1=figure;
getthepower(trace1,dur,5,1);
title('Before Injection','fontsize',16)
f2=figure;
getthepower(trace2,dur,5,1);
title('After Injection','fontsize',16)
figs2subplots([f1 f2],[2 2])




function maxf_Callback(hObject, eventdata, handles)
% hObject    handle to maxf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxf as text
%        str2double(get(hObject,'String')) returns contents of maxf as a double


% --- Executes during object creation, after setting all properties.
function maxf_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startpmnt_Callback(hObject, eventdata, handles)
% hObject    handle to startpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startpmnt as text
%        str2double(get(hObject,'String')) returns contents of startpmnt as a double


% --- Executes during object creation, after setting all properties.
function startpmnt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endpmnt_Callback(hObject, eventdata, handles)
% hObject    handle to endpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endpmnt as text
%        str2double(get(hObject,'String')) returns contents of endpmnt as a double


% --- Executes during object creation, after setting all properties.
function endpmnt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startinj_Callback(hObject, eventdata, handles)
% hObject    handle to startinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startinj as text
%        str2double(get(hObject,'String')) returns contents of startinj as a double


% --- Executes during object creation, after setting all properties.
function startinj_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endinj_Callback(hObject, eventdata, handles)
% hObject    handle to endinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endinj as text
%        str2double(get(hObject,'String')) returns contents of endinj as a double


% --- Executes during object creation, after setting all properties.
function endinj_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

f=figure;
selchan=get(handles.chanlist,'value');
t0=str2num(get(handles.t0,'string'));
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

plot(handles.x,handles.news(:,selchan))
minmax=get(gca,'ylim')
hold on
plot([stinj stinj]',minmax','m--')
plot([einj einj]',minmax','m--')
plot([splc splc]',minmax','c--')
plot([eplc eplc]',minmax','c--')

% if dur>10
%     xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
if tvent>0
    plot([tvent tvent]',minmax','g--')
    
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in sloper.
function sloper_Callback(hObject, eventdata, handles)
% hObject    handle to sloper (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Identifies the prescnece of waves within a range and charactrize the slope
%for early and late phase and positive and negative deflections.
%Steps:
%   1- Filter data in the range of the desired wave
%   2- Find zero corssing and peaks
%   3- Calculate the slopes

if handles.sr<200
    handles.sr=250;
end
startd=60*handles.sr*str2num(get(handles.edit5,'string'));
endd=60*handles.sr*str2num(get(handles.edit6,'string'));
stp=handles.s(startd:endd,get(handles.chanlist,'value'));
news=resample(stp,1,5);
news=news-mean(news);
snews=sort(abs(news));
normfactor=snews(round(0.999*length(news)));
news=news./normfactor;
s=1;std(news);
minstd=0.5;
maxstd=2;
% figure
% subplot(2,1,1)
% plot(news)
% subplot(2,1,2)
% plot(stp)
figure
xvec=(0:(length(news)-1))/(handles.sr/5);
hold on
plot(xvec,ones(size(news))*minstd*s);
plot(xvec,ones(size(news))*-minstd*s);
plot(xvec,ones(size(news))*maxstd*s,'k-');
plot(xvec,ones(size(news))*-maxstd*s,'k-');

y=diff(sign(news))*max(news)/2;
%plot(y,'r-')
zcrsp=find(y>1E-4);
zcrsn=find(y<-1E-4);
durp=diff(zcrsn)/(handles.sr/5);
%plot (news)
minmax=get(gca,'ylim');
indd=find(durp>0.25 & durp<2);
deltamatrix=zeros(length(indd),2*round(handles.sr/5));
sampler=handles.sr/5;
k=0;
for t=1:length(indd)
    t0=zcrsn(indd(t));
    tf=zcrsn(1+indd(t));
    tm=zcrsp(1+indd(t));
    if tm>tf
        tm=zcrsp(indd(t));
    end
    
    %      if zcrsp(indd(t))>tf
    %         tm=zcrsp(indd(t-1));
    %      elseif zcrsp(indd(t))>t0
    %      tm=zcrsp(indd(t));
    %      else
    %          tm=zcrsp(indd(t+1));
    %      end
    if (max(news(t0:tf))>minstd*s && max(news(t0:tf))<maxstd*s && min(news(t0:tf)>-maxstd*s) )|| (min(news(t0:tf)<-minstd*s) && min(news(t0:tf)>-maxstd*s) && max(news(t0:tf))<maxstd*s)
        k=k+1;
        dto(k)=t0;
        dtm(k)=tm;
        dtf(k)=tf;
        plot(xvec(t0:tf),news(t0:tf),'r-','linewidth',3)
        %centering on the zero crossing tm
        posi=round(sampler)-(tm-t0);
        if posi<1
            posi=1;
        end
        posf=posi+(tf-t0);
        if posf>round(2*sampler)%last point cannot be beyond 2 sec.
            posf=round(2*sampler);
        end
        if posf==100
            deltamatrix(k,posi:posf)=news(t0:t0+(posf-posi));
        else
            deltamatrix(k,posi:posf)=news(t0:tf);
        end
    end
end
deltamatrix=deltamatrix(1:k,:);
plot(xvec,news,'k-')
figure
xvd=(0:size(deltamatrix,2)-1)/(handles.sr/5);

plot(xvd,mean(deltamatrix))
fn=strcat(get(handles.filename,'string'),'.mat');
save(fn,'deltamatrix','dto','dtm','dtf','sampler','news')
helpdlg('File saved')
%  sdmx=sort(deltamatrix);
%  nrdm=size(deltamatrix,1);
%  smaller=round(nrdm*0.05);
%  larger=round(nrdm*0.95);
%  plot(xvd,sdmx(smaller,:),'g-')
%  plot(xvd,sdmx(larger,:),'g-')



% --- Executes on button press in compadre.
function compadre_Callback(hObject, eventdata, handles)
% hObject    handle to compadre (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This one compares ch1 and ch2

tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

if handles.sr<200
    handles.sr=250;
end

tevent=str2num(get(handles.tevent,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%news=s(1+round(t0*60)*handles.sr:round((t0+2)*60)*handles.sr,:);%Only 2 hours
%plotting the power and the trace of the whole EEG
selchan=get(handles.chanlist,'value');
% disp('1&2')
% corrcoef(handles.news(:,1),handles.news(:,2))
% disp('1&3')
% corrcoef(handles.news(:,1),handles.news(:,3))
% disp('1&4')
% corrcoef(handles.news(:,1),handles.news(:,4))
% disp('2&3')
% corrcoef(handles.news(:,2),handles.news(:,3))
% disp('2&4')
% corrcoef(handles.news(:,2),handles.news(:,4))
% disp('3&4')
% corrcoef(handles.news(:,3),handles.news(:,4))

e1=handles.news(1:round(handles.sr*fftwindow)*floor(length(handles.news)/(handles.sr*fftwindow)),selchan);
%stp1=handles.news(:,selchan);
e2=handles.news(1:round(handles.sr*fftwindow)*floor(length(handles.news)/(handles.sr*fftwindow)),selchan+1);
%stp2=handles.news(:,1+get(handles.chanlist,'value'));

%e1=eegfilter(e1,2,0);%get rid of artifacts
%e2=eegfilter(e2,2,0);
e1=eegfilter(e1,5.5,0);%get rid of artifacts
e2=eegfilter(e2,5.5,0);
%stp1=eegfilter(stp1,0);
%stp2=eegfilter(stp2,0);%get rid of artifacts
%stp2=eegfilter(stp2,0);
figure
subplot(2,1,1)
p=getthepower(e1,(length(e1)/handles.sr),150,1);
hold on
p=getthepower(e2,(length(e2)/handles.sr),150,1);
% disp('Delta power:')
% delta1=getpband(e1,length(handles.news)/handles.sr,0.1,4)
% delta2=getpband(e2,length(handles.news)/handles.sr,0.1,4)
% disp('power of 0.1-60 Hz band:')
% toSixty=getpband(e1,length(handles.news)/handles.sr,0.1,60)
% toSixty=getpband(e2,length(handles.news)/handles.sr,0.1,60)
%xlabel('Time (s)');
%xlabel('Frequency (Hz)');
subplot(2,1,2)
xscl=(0:length(e1)-1)/(60*handles.sr);
plot(xscl, e1)
hold on
plot(xscl, e2,'r-')
title('EEG1')
box off
xlabel('t (s)')
ylabel('V')


%using built in function
% figure;
% %[S,F,T,P] = spectrogram(stp,2048,256,2048,handles.sr,'yaxis');
% [S,F,T,P] = spectrogram(stp,2048,256,[0:0.05:20],handles.sr);
% figure
% surf(T,F,10*log10(abs(P)),'edgecolor','none')
% colormap(jet); axis tight;
% view(0,90);
% xlabel('Time'); ylabel('Hz');
%
% figure
% X=0:size(P(:,1))-1;
% Y=0:size(P(:,2))-1;
% surf(X,Y,P,'FaceColor','interp',...
% 	'EdgeColor','none',...
% 	'FaceLighting','phong')
% daspect([5 5 1])
% axis tight
% view(-50,30)
% camlight left


%getthepower(news(:,2),(length(news)/sr),10,1);
%title('EEG2')
% [B,f,t]=specgram(handles.news(:,get(handles.chanlist,'value')),4096,1024,2);
% bmin=max(max(abs(B)))/300;
%imagesc(t,f,20*log10(max(abs(B),bmin)/bmin));
%axis xy;
%colormap(jet);

eeg1=reshape(e1,round(handles.sr*fftwindow),floor(length(handles.news)/(handles.sr*fftwindow)));
eeg2=reshape(e2,round(handles.sr*fftwindow),floor(length(handles.news)/(handles.sr*fftwindow)));
%eeg2=reshape(e2,sr*fftwindow,floor(length(news)/(sr*fftwindow)));
[c,r]=size(eeg1);
m1=zeros(1,r);
m2=m1;
%ranges for the oscilations
initial=[0.5 4 8 15 30];
final=[4 8 15 30 80];
figure
cnt=0;
tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'Gama (30-80)'}];
lim=[0 1];
for i=1:length(initial)
    % disp(char(tit(i)));
    
    for k=1:r
        
        if k<r
            m1(k)=getpband2(eeg1(:,k),eeg1(:,k+1),fftwindow,initial(i),final(i));
            m2(k)=getpband2(eeg2(:,k),eeg2(:,k+1),fftwindow,initial(i),final(i));
        else
            m1(k)=getpband2(eeg1(:,k),eeg1(:,k),fftwindow,initial(i),final(i));
            m2(k)=getpband2(eeg2(:,k),eeg2(:,k),fftwindow,initial(i),final(i));
        end
        %             m1(k)=getpband(eeg1(:,k),fftwindow,initial(i),final(i));
        %             m2(k)=getpband(eeg2(:,k),fftwindow,initial(i),final(i));
    end
    
    if i==1
        psig1(k)=rms(eeg1(:,k));
        psig2(k)=rms(eeg2(:,k));
        allpow1(:,k)=getthepower(eeg1(:,k),fftwindow,10,0);%This plots eeg and fft of each subtrace
        allpow2(:,k)=getthepower(eeg2(:,k),fftwindow,10,0);
        
        %end
        
        
        
        % m1(k)=getpband(eeg1(:,k),fftwindow,4,4.7);
        %m2(k)=getpband(eeg2(:,k),fftwindow,4,4.7);
        
    end
    fm1=medfilt1(m1,5);
    fm2=medfilt1(m2,5);
    cnt=cnt+1;%number of current plot
    %     m1=eegfilter(m1,2);
    %     m1=eegfilter(m1,2);
    %     m2=eegfilter(m2,2);
    %     m2=eegfilter(m2,2);
    t=(0:length(fm1)-1)/(60/fftwindow);
    %tevent=[5 10 14 68 114]-t0;%Time of events:saline injection & anestheia tp 0.8, Changing syringes pump,EKG placement, refilling iso tank,injecting SP
    
    %subplot(2,ceil(length(initial)/2),cnt)
    figure
    minp=min(min(fm1,fm2));%basel(m1);
    maxp=max(max(fm1,fm2));%ibasel(m1);
    minmax=[minp maxp];
    %    plot(t,m1)
    %   hold on
    %
    %   axis tight
    %    set(gca,'ylim',(1E-10)*[0 8])
    %    deltatime=3600*1/fftwindow;%the last 1 hours to get the max of the figure
    %    minmax=[0 max(m1(end-deltatime:end))];
    
    plot(t,fm1,'k-',[tevent' tevent']',minmax,'g--',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--',[splc splc]',minmax','c--',[eplc eplc]',minmax','c--')
    hold on
    plot(t,fm2,'r-')
    set(gca,'fontsize',14)
    %set(gca,'xlim',[stinj-30 stinj+30])
    %set(gca,'ylim',minmax)
    %     if i==1
    %         lim=minmax;
    %     end
    %        set(gca,'ylim',lim)
    %          hold on
    %    plot([tinj' tinj'],minmax,'b--')
    %legend('Ket. Injection',14)
    xlabel('min','fontsize',18)
    ylabel('Power','fontsize',18)
    
    %legend('EEG1','EEG2','saline inj.','Syringes manip.','EKG placement','refilling iso','injecting SP')
    title(char(tit(cnt)),'fontsize',24)
    
    %disp(mean(m1))
    figure
    minp=min(fm1./fm2);%basel(m1);
    maxp=max(fm1./fm2);%ibasel(m1);
    minmax=[minp maxp];
    plot(t,fm1./fm2,'.--',[tevent' tevent']',minmax,'g--',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--',[splc splc]',minmax','c--',[eplc eplc]',minmax','c--')
    set(gca,'fontsize',14)
    %set(gca,'xlim',[stinj-30 stinj+30])
    %set(gca,'ylim',minmax)
    %     if i==1
    %         lim=minmax;
    %     end
    %        set(gca,'ylim',lim)
    %          hold on
    %    plot([tinj' tinj'],minmax,'b--')
    %legend('Ket. Injection',14)
    xlabel('min','fontsize',18)
    ylabel('Power Ch1/Ch2','fontsize',18)
    
    %legend('EEG1','EEG2','saline inj.','Syringes manip.','EKG placement','refilling iso','injecting SP')
    title(char(tit(cnt)),'fontsize',24)
    
    
    
end
figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow1);
if l>w
    sortedp=sort(allpow1,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow1,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow1=allpow1/normf;

allpow1=allpow1/max(max(allpow1));
%allpow(find(allpow>1))=1;
allpow1=allpow1*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow1(1:round(l*limf/(0.5*handles.sr)),:)')
colormap(jet)
title('CH1')

figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow2);
if l>w
    sortedp=sort(allpow2,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow2,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow2=allpow2/normf;

allpow2=allpow2/max(max(allpow2));
%allpow(find(allpow>1))=1;
allpow2=allpow2*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow2(1:round(l*limf/(0.5*handles.sr)),:)')
colormap(jet)
title('CH2')
guidata(hObject, handles);




% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.txt', 'Pick the text file to analyze');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid, '%s %s %s %s %s %s %s %s %s %s %s %s %s',17)
for t=2:length(C)
    EDF.Label(t-1)=strcat('ch',num2str(t-1),' ',C{t}(end));
end
disp('Reading file...')
C2 = textscan(fid, '%s %s %f %f %f');
handles.s=[];
set(handles.text15,'string',C2{2}(1))
handles.time0=char(C2{2}(1))
handles.date0=char(C2{1}(1))
for t=3:length(C2)
    %filter EEG making 0 if MT is too high or it goies larger than 5 std
    if get(handles.checkbox3,'value')
        if t-2==1%filter for ch1
            i=find(abs(C2{t+1})>500);
            C2{t}(i)=0;
            i=find(abs(C2{t})>5*std(C2{t}));
            C2{t}(i)=0;
            i=find(abs(C2{t})>5*std(C2{t}));
            C2{t}(i)=0;
            i=find(abs(C2{t})>5*std(C2{t}));
            C2{t}(i)=0;
            
        end
        
    end
    %Lowpass EEG
    if get(handles.checkbox4,'value')
        if t-2==1%filter for ch1
            C2{t}=lowpass2(C2{t});
        end
    end
    handles.news(:,t-2)=C2{t};
end

% figure
% sf=128;
% alm=C2{14};
% veh=C2{12};
% l=length(C2{14});
% subplot(2,1,1)
% x=(0:l-1)/(60*sf);
% plot(x(1:round(l/2)),alm(1:round(l/2)),'k-')
% axis tight
% Title('ALM')
% xlabel('min')
% subplot(2,1,2)
% plot(x(round(l/2):l),veh(round(l/2):l),'k-')
% axis tight
% xlabel('min')
% title('VEH')
% box off
fclose(fid);
set(handles.chanlist,'string',EDF.Label);
nhrs=str2num(get(handles.edit12,'string'));
ls=length(handles.news);

selchan=get(handles.chanlist,'value');
sr=128;
handles.sr=sr;
t0=str2num(get(handles.t0,'string'));
tvent=str2num(get(handles.tevent,'string'));
skip=(t0*60*sr)+1;
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

%deleting the data during placement of the internals
ti=round(handles.sr*60*splc);
tf=round(handles.sr*60*eplc);
%     handles.news(ti:tf,:)=0;
handles.h=handles.axes1;

handles.x=(0:length(handles.news)-1)/(60*sr);
%smart scaling:
% if dur>10
%     handles.x=handles.x*dur;%scale in min.
% else
%     handles.x=handles.x*(dur*60);%scale in s
% end
% if get(handles.plotm,'value')
% end
axis(handles.axes1);
%plot(hand,handles.x,handles.news(:,selchan))
plot(handles.x,handles.news(:,selchan))
hold on
plot(handles.x,5*std(handles.news(:,selchan))*ones(size(handles.news(:,selchan))),'r--')
plot(handles.x,5*std(handles.news(:,selchan))*ones(size(handles.news(:,selchan))),'r--')

% if dur>10
xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
%set(handles.tevent,'string',(length(handles.news)/(60*handles.sr))-120);
set(handles.filename,'string',filename);
if tvent>0
    minmax=get(gca,'ylim')
    hold on
    plot([tvent tvent]',minmax','g--')
end


guidata(hObject, handles);



% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
x=handles.news;
[v,nch]=size(x);
% x = randn(10000,6)+(1:1e4)'*ones(1,6); % test data
% x = (1:1e4)'*ones(1,6)/1000; % test data
% x = reshape(mod(1:6e4,100),6,1e4)'; x(:,6)=NaN;

clear HDR;

VER   = version;
cname = computer;

% select file format
%HDR.TYPE='GDF';
HDR.TYPE='EDF';
%HDR.TYPE='BDF';
%HDR.TYPE='CFWB';
%HDR.TYPE='CNT';

% set Filename
HDR.FileName = [handles.fn(1:end-4),'_.',HDR.TYPE];
%HDR.FileName = [handles.fn(1:end-4),VER([1,3]),cname(1:3),'_e1.',HDR.TYPE];
% person identification, max 80 char
HDR.Patient.ID = 'Raton';
HDR.Patient.Sex = 'F';
HDR.Patient.Birthday = [1951 05 13 0 0 0];
HDR.Patient.Name = 'X';		% for privacy protection
HDR.Patient.Handedness = 0; 	% unknown, 1:left, 2:right, 3: equal

% description of recording device
HDR.Manufacturer.Name = 'BioSig';
HDR.Manufacturer.Model = 'demo3.m';
HDR.Manufacturer.Version = '$Revision$';
HDR.Manufacturer.SerialNumber = '666';

% recording identification, max 80 char.
HDR.RID = 'From sleepsign'; %StudyID/Investigation [consecutive number];
HDR.REC.Hospital   = 'NIPS';
HDR.REC.Techician  = 'Lord Inario';
HDR.REC.Equipment  = 'biosig';
HDR.REC.IPaddr	   = [127,0,0,1];	% IP address of recording system
HDR.Patient.Name   = 'anonymous';
HDR.Patient.Id     = '007';
HDR.Patient.Weight = 0; 	% undefined
HDR.Patient.Height = 0; 	% undefined
HDR.Patient.Sex    = 0; 	% 0: undefined,	1: male, 2: female
HDR.Patient.Birthday = zeros(1,6); %    undefined
HDR.Patient.Impairment.Heart = 0;  %	0: unknown 1: NO 2: YES 3: pacemaker
HDR.Patient.Impairment.Visual = 0; %	0: unknown 1: NO 2: YES 3: corrected (with visual aid)
HDR.Patient.Smoking = 0;           %	0: unknown 1: NO 2: YES
HDR.Patient.AlcoholAbuse = 0; 	   %	0: unknown 1: NO 2: YES
HDR.Patient.DrugAbuse = 0; 	   %	0: unknown 1: NO 2: YES
HDR.Patient.Handedness = 0; 	   % 	unknown, 1:left, 2:right, 3: equal

% recording time [YYYY MM DD hh mm ss.ccc]
HDR.T0 =[str2num(handles.date0(1:4)) str2num(handles.date0(6:7)) str2num(handles.date0(9:10)) str2num(handles.time0(1:2)) str2num(handles.time0(4:5)) str2num(handles.time0(7:12))];
%clock;

% number of channels
HDR.NS = nch;

% Duration of one block in seconds
HDR.SampleRate = str2num(get(handles.edit14,'string'));
HDR.SPR = v;
HDR.Dur = HDR.SPR/HDR.SampleRate;

% Samples within 1 block
HDR.AS.SPR = [v;v;v];	% samples per block;
%HDR.AS.SampleRate = [1000;100;200;100;20;0];	% samplerate of each channel

% channel identification, max 80 char. per channel
HDR.Label=get(handles.chanlist,'string');%{'chan 1  ';'chan 2  ';'chan 3  ';'chan 4  ';'chan 5  ';'chan 6  ';'chan 7  ';'chan 8  '};

% Transducer, mx 80 char per channel
HDR.Transducer = {'Ag-AgCl ';'Ag-AgCl ';'Ag-AgCl '};

% define datatypes (GDF only, see GDFDATATYPE.M for more details)
HDR.GDFTYP = 3*ones(1,HDR.NS);

% define scaling factors
HDR.PhysMax = [10;10; 0.001];
HDR.PhysMin =-[10;10; 0];% -10*ones(nch,1);
HDR.DigMax  = ones(nch,1);
HDR.DigMin  = zeros(nch,1);
HDR.Filter.Lowpass = 0.5*ones(nch,1);
HDR.Filter.Highpass = 45*ones(nch,1);
HDR.Filter.Notch = zeros(nch,1);


% define physical dimension
%HDR.PhysDim
HDR.PhysDim = {'V';'V';'V'};
disp(num2str(size(HDR.PhysDim)));
HDR.Impedance = ones(nch,1);         % electrode impedance (in Ohm) for voltage channels
HDR.fZ = ones(nch,1); ;                % probe frequency in Hz for Impedance channel

t = [10:10:size(x,1)]';
%HDR.NRec = 100;
HDR.VERSION = 2.21;        % experimental
HDR = sopen(HDR,'w');
%HDR.SIE.RAW = 0; % [default] channel data mode, one column is one channel
%HDR.SIE.RAW = 1; % switch to raw data mode, i.e. one column for one EDF-record

HDR = swrite(HDR,x);

HDR.EVENT.POS = t;
HDR.EVENT.TYP = t/100;
if 1,
    HDR.EVENT.CHN = repmat(0,size(t));
    HDR.EVENT.DUR = repmat(1,size(t));
    HDR.EVENT.VAL = repmat(NaN,size(t));
    ix = 6:5:60;
    HDR.EVENT.CHN(ix) = 6;
    HDR.EVENT.VAL(ix) = 373+round(100*rand(size(ix))); % HDR.EVENT.TYP(ix) becomes 0x7fff
    ix = 8;
    HDR.EVENT.CHN(ix) = 5; % not valid because #5 is not sparse sampleing
    HDR.EVENT.VAL(ix) = 374;
end;

HDR = sclose(HDR);


%
[s0,HDR0] = sload(HDR.FileName);	% test file

HDR0=sopen(HDR0.FileName,'r');
[s0,HDR0]=sread(HDR0);
HDR0=sclose(HDR0);
% plot(s0-x)





function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton11. %reads and merge text files
% with EDF for Anushka
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This merges the current EDf file with data extracted from a txt file with a fix configuration.
%Steps:
%1- extract initial time of EDF
%2- Sync clock with system time ms by pairing the ms value witht he first
%time in the longest series of events happening within the same seccond.
%3- make nil vectors with Correct	Incorrect	CausedReward
%CausedPunishment and fill ones at the corresponding time with ms
%precision.
%Save original EDF with this 4 new vectors added

EDF=handles.hedf;
HDR0=sopen(strcat(EDF.FILE.Name,'.',EDF.FILE.Ext),'r');
HDR=HDR0;
HDR0 = sclose(HDR0);
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the rsults');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
k=0;
nlabels= size(EDF.Label,1);
%Editing the fields of the EDf file, starting by the ch. Labels

for t=length(C)-3:length(C)
    k=k+1;
    HDR.Label{nlabels+k}=char(C{t});%Add data labels in the EDF
    HDR.PhysDim{nlabels+k}='Bin';
    HDR.PhysMin(nlabels+k)=min(HDR.PhysMin);
    HDR.PhysMax(nlabels+k)=1;
    HDR.DigMin(nlabels+k)=min(HDR.DigMin);%EDF.DigMin(nlabels);
    HDR.DigMax(nlabels+k)=1;%EDF.DigMax(nlabels);
    HDR.PhysDimCode(nlabels+k)=0;
    HDR.THRESHOLD(nlabels+k,:)=HDR.THRESHOLD(nlabels,:);
    HDR.Transducer{nlabels+k}=HDR.Transducer{nlabels};
    %HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));
    
    HDR.Cal(nlabels+k)=1;
    HDR.Off(nlabels+k)=0;
end

disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %s %s %f %f %f %s %s %s %s');
%Get the timing to synchronize files
strgtime=char(C2{5});
vecsec=3600*str2num(strgtime(:,2:3))+60*str2num(strgtime(:,5:6))+str2num(strgtime(:,8:9));
[v,p]=mode(vecsec);
indvec=find(vecsec==v);%The timing of indvec(1) will be used to sync seconds and ms
sect0=3600*EDF.T0(4)+60*EDF.T0(5)+EDF.T0(6);
msect0= C2{6}(indvec(1))-1000*(vecsec(indvec(1))-sect0);%This is the first milisecond
msectf=msect0+1000*round(size(handles.s,1)/handles.sr);
tvect=(msectf-msect0)*((0:size(handles.s,1)-1)/(size(handles.s,1)-1));%tvect has the same number of data points than the data but they have the ms
tvect=tvect+msect0;
%tvect=msect0:2:C2{6}(end);
%tvect=msect0:2:msect0+2*size(handles.s,1)-1;%this is wrong
%Now generating the data to be merged:
disp('Generating data...')
%Getting the time in ms of the 'Y'(1) and 'N'(0) else 0.5.
v1=0.5 *ones(1,length(tvect));
v2=0.5 *ones(1,length(tvect));
v3=0.5 *ones(1,length(tvect));
v4=0.5 *ones(1,length(tvect));

ind=find(char(C2{9})=='Y');
t1=C2{6}(ind);
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    v1(p)=1;
end
disp('...')
ind=find(char(C2{9})=='N');
t1=C2{6}(ind);
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    v1(p)=0;
end
disp('...')
ind=find(char(C2{10})=='Y');
t2=C2{6}(ind);
for i=1:length(t2)
    [v,p]=min(abs(tvect-t2(i)));
    v2(p)=1;
end
disp('...')
ind=find(char(C2{10})=='N');
t2=C2{6}(ind);
for i=1:length(t2)
    [v,p]=min(abs(tvect-t2(i)));
    v2(p)=0;
end
disp('...')
ind=find(char(C2{11})=='Y');
t3=C2{6}(ind);
for i=1:length(t3)
    [v,p]=min(abs(tvect-t3(i)));
    v3(p)=1;
end
disp('...')
ind=find(char(C2{11})=='N');
t3=C2{6}(ind);
for i=1:length(t3)
    [v,p]=min(abs(tvect-t3(i)));
    v3(p)=0;
end

disp('...')

ind=find(char(C2{12})=='Y');
t4=C2{6}(ind);
for i=1:length(t4)
    [v,p]=min(abs(tvect-t4(i)));
    v4(p)=1;
end
disp('One More...')
ind=find(char(C2{12})=='N');
t4=C2{6}(ind);
for i=1:length(t4)
    [v,p]=min(abs(tvect-t4(i)));
    v4(p)=0;
end
disp('...')
beep
osize=size(handles.s,2);%The original number of sgnals
handles.s=[handles.s v1' v2' v3' v4'];
fclose(fid);
nlabels=nlabels+4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now reading the second file:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with stim time');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
%Editing the fields of the EDf file, starting by the ch. Labels
%Adding one more signals to the EDF: the stim. time and type
HDR.Label{nlabels+1}=char(C{t});%Add data labels in the EDF
HDR.PhysDim{nlabels+1}='Int';
HDR.PhysMin(nlabels+1)=min(HDR.PhysMin);
HDR.PhysMax(nlabels+1)=max(HDR.PhysMax);
HDR.DigMin(nlabels+1)=min(HDR.DigMin);%EDF.DigMin(nlabels);
HDR.DigMax(nlabels+1)=1;%EDF.DigMax(nlabels);
HDR.PhysDimCode(nlabels+1)=0;
HDR.THRESHOLD(nlabels+1,:)=HDR.THRESHOLD(nlabels,:);
HDR.Transducer{nlabels+1}=HDR.Transducer{nlabels};
%HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));

HDR.Cal(nlabels+1)=1;
HDR.Off(nlabels+1)=0;
HDR.FILE.Name=strcat(EDF.FILE.Name,'mrgd');
HDR.FileName=strcat(pathname,HDR.FILE.Name,'.',HDR.FILE.Ext);
HDR.reserved1='EDF merged with behavioral data';

disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %f %f %f %s %f %f %s %s %f %f %s %s %s %s %s %s %s %f %f %f %f %f %s');

%Now generating the data to be merged (columns 6  and 7):
disp('Generating data...')
%sa=char(C2{7});
%Getting the time in ms of the stim, that can be Yellow_rectangle, Blue_rectangle and White_rectangle
stim=zeros(1,length(tvect));
ind=find(strcmp(C2{7},'Yellow_rectangle'));
t1=C2{6}(ind);%times of stim 1
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    stim(p)=0.25;
end

ind=find(strcmp(C2{7},'Blue_rectangle'));
t1=C2{6}(ind);%times of stim 1
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    stim(p)=0.5;
end

ind=find(strcmp(C2{7},'White_rectangle'));
t1=C2{6}(ind);%times of stim 1
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    stim(p)=0.75;
end

handles.s=[handles.s stim'];

figure
subplot(6,1,1)
plot(tvect/1000,handles.s(:,2))
ylabel(HDR.Label(2,:))
subplot(6,1,2)
plot(tvect/1000,handles.s(:,osize+1),'k.-')
ylabel(HDR.Label(osize+1,:))
subplot(6,1,3)
plot(tvect/1000,handles.s(:,osize+2),'k.-')
ylabel(HDR.Label(osize+2,:))
subplot(6,1,4)
plot(tvect/1000,handles.s(:,osize+3),'k.-')
ylabel(HDR.Label(osize+3,:))
subplot(6,1,5)
plot(tvect/1000,handles.s(:,osize+4),'k.-')
ylabel(HDR.Label(osize+4,:))
subplot(6,1,6)
plot(tvect/1000,handles.s(:,osize+5),'k.-')
ylabel(HDR.Label(osize+5,:))


fclose(fid);
disp('saving...')
data=handles.s';
[nch,v]=size(data);
HDR.Dur = HDR.SPR/EDF.SampleRate;
VER   = version;
cname = computer;

% select file format
HDR.TYPE='EDF';
% number of channels
HDR.NS = nch;
HDR.GDFTYP=3*ones(1,nch);

% Duration of one block in seconds
HDR.Dur = HDR.SPR/HDR.SampleRate;

HDR.VERSION = 2.21;        % experimental
HDR.InChanSelect=1:nch;
HDR.LeadIdCode=NaN*ones(nch,1)
HDR=rmfield(HDR,'AS')
HDR = sopen(HDR,'w');
HDR = swrite(HDR,data');
HDR = sclose(HDR);
helpdlg('Done!')
guidata(hObject, handles);



% --- Executes on button press in compbands.
function compbands_Callback(hObject, eventdata, handles)
% hObject    handle to compbands (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.sr<200
    handles.sr=250;
end

fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%plotting the power and the trace of the whole EEG
winsize=floor(handles.sr*fftwindow);
e1=handles.news(1:winsize*floor(length(handles.news)/winsize),get(handles.chanlist,'value'));
e2=handles.news(1:winsize*floor(length(handles.news)/winsize),1+get(handles.chanlist,'value'));
e1=eegfilter(e1,7);
e2=eegfilter(e2,7);

%Zeroing the first minute:
% e1(1:round(60*handles.sr))=0;
% e2(1:round(60*handles.sr))=0;
% stp=handles.news(:,get(handles.chanlist,'value'));
% stp=eegfilter(stp,0);%get rid of artifacts
% stp=eegfilter(stp,0);
figure
subplot(2,1,1)
p=getthepowerc(e1,(length(e1)/handles.sr),20,1,'k-');
hold on
p2=getthepowerc(e2,(length(e1)/handles.sr),20,1,'r-');
legend('Ch1','Ch2')
disp('Delta power:')
delta=getpband(e1,length(e1)/handles.sr,0.5,5)
% disp('power of 0.1-60 Hz band:')
% toSixty=getpband(e1,length(handles.news)/handles.sr,0.1,60)
%xlabel('Time (s)');
%xlabel('Frequency (Hz)');
subplot(2,1,2)
xscl=(0:length(e1)-1)/(60*handles.sr);
plot(xscl, e1)
title('EEG1')
box off
xlabel('t (s)')
ylabel('V')
eeg1=reshape(e1,winsize,length(e1)/winsize);
eeg2=reshape(e2,winsize,length(e2)/winsize);
[c,r]=size(eeg1);
m1=zeros(1,r);
m2=m1;
%ranges for the oscilations
initial=[0.5 5];
final=[5 8];
figure
cnt=0;
tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
initial=[0.5 4 8 15 30 50];
final=[4 8 15 30 50 80];
lim=[0 1];
for i=1:length(initial)
    % disp(char(tit(i)));
    
    for k=1:r
        
        
        m1(k)=getpband(eeg1(:,k),fftwindow,initial(i),final(i));
        m2(k)=getpband(eeg2(:,k),fftwindow,initial(i),final(i));
        if i==1
            psig1(k)=rms(eeg1(:,k));
            allpow1(:,k)=getthepower(eeg1(:,k),fftwindow,20,0);
            psig2(k)=rms(eeg2(:,k));
            allpow2(:,k)=getthepower(eeg2(:,k),fftwindow,20,0);
        end
        
    end
    cnt=cnt+1;%number of current plot
    %     m1=eegfilter(m1,2);
    %     m1=eegfilter(m1,2);
    %     m1=eegfilter(m1,2);
    t=(0:length(m1)-1)/(60/fftwindow);
    %tevent=[5 10 14 68 114]-t0;%Time of events:saline injection & anestheia tp 0.8, Changing syringes pump,EKG placement, refilling iso tank,injecting SP
    
    %subplot(2,ceil(length(initial)/2),cnt)
    figure
    minp=min(m1);%basel(m1);
    maxp=max(m1);%ibasel(m1);
    minmax=[minp maxp];
    plot(t,m1,'k-')
    hold on
    plot(t,m2,'r-')
    set(gca,'fontsize',14)
    xlabel('[min.]','fontsize',18)
    ylabel('Power','fontsize',18)
    title(char(tit(cnt)),'fontsize',24)
    legend('Ch1','Ch2')
    box off
    i=find(m2<=0);
    m2(i)=0.000001;
    figure
    minp=min(m1./m2);%basel(m1);
    maxp=max(m1./m2);%ibasel(m1);
    minmax=[minp maxp];
    plot(t,m1./m2,'k-')
    set(gca,'fontsize',14)
    xlabel('[min.]','fontsize',18)
    ylabel('Power ratio','fontsize',18)
    title(char(tit(cnt)),'fontsize',24)
    legend('Ch1/Ch2')
    box off
    
    %disp(mean(m1))
end
figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow1);
if l>w
    sortedp=sort(allpow1,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow1,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow1=allpow1/normf;

allpow=allpow1/max(max(allpow1));
%allpow(find(allpow>1))=1;
allpow=allpow*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow(1:round(l*limf/(0.5*handles.sr)),:)')
colormap(jet)
title('Heatmap for Ch1')
guidata(hObject, handles);


% --- Executes on button press in filter.
function filter_Callback(hObject, eventdata, handles)
% hObject    handle to filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.sr<200
    handles.sr=250;
end
winsize=4;%analizing 4 seconds around stim presentation (2 before and 2 after)
e1=handles.news(:,get(handles.chanlist,'value'));
handles.news(:,end)=round(100*handles.news(:,end))/100;

posg1=find(handles.news(:,end-3)==1);
posg2=find(handles.news(:,end-2)==1);
posg3=find(handles.news(:,end-1)==1);
posg4=find(handles.news(:,end)==1);
%ignoring events when EEG was too high
newposg1=[];
newposg2=[];
newposg3=[];
newposg4=[];

disp('thres:')
%thres=5*std(e1)
figure
x=(0:length(e1)-1)/handles.sr;
plot(x,e1)
box off
minmax=get(gca,'ylim');
ind1=posg1/handles.sr;
ind2=posg2/handles.sr;
ind3=posg3/handles.sr;
ind4=posg4/handles.sr;


hold on
plot([ind1 ind1],minmax,'g--')
plot([ind2 ind2],minmax,'b--')
plot([ind3 ind3],minmax,'r--')
plot([ind4 ind4],minmax,'k--')
% strarr=(get(handles.chanlist,'string'));
% legend(strarr(:,end-4:end))

thres=1.7E-4;
k=0;

for i=1:length(posg1)
    if max(abs(e1(posg1(i)-2*handles.sr:posg1(i)+2*handles.sr)))<thres
        k=k+1;
        newposg1(k)=posg1(i);
    end
end

k=0;
for i=1:length(posg2)
    if max(abs(e1(posg2(i)-2*handles.sr:posg2(i)+2*handles.sr)))<thres
        k=k+1;
        newposg2(k)=posg2(i);
    end
end

k=0;
for i=1:length(posg3)
    if max(abs(e1(posg3(i)-2*handles.sr:posg3(i)+2*handles.sr)))<thres
        k=k+1;
        newposg3(k)=posg3(i);
    end
end

k=0;
for i=1:length(posg4)
    if max(abs(e1(posg4(i)-2*handles.sr:posg4(i)+2*handles.sr)))<thres
        k=k+1;
        newposg4(k)=posg4(i);
    end
end

mateeg1=zeros(ceil(4*handles.sr),length((newposg1)));
mateeg2=zeros(ceil(4*handles.sr),length((newposg2)));
mateeg3=zeros(ceil(4*handles.sr),length((newposg3)));
mateeg4=zeros(ceil(4*handles.sr),length((newposg4)));

s=size(mateeg1);
switch get(handles.chanlist,'value')
    case 1
        cd eeg1
    case 2
        cd eeg2
    case 3
        cd eeg3
end
r1=length(newposg1)
if r1>1
    for i=1:r1
        mateeg1(:,i)=e1(floor(newposg1(i)-(winsize/2)*handles.sr):floor(newposg1(i)-(winsize/2)*handles.sr)+s(1)-1);
    end
else
    mateeg1=0;
end


s=size(mateeg2);
r2=length(newposg2)
if r2>1
    for i=1:r2
        mateeg2(:,i)=e1(floor(newposg2(i)-(winsize/2)*handles.sr):floor(newposg2(i)-(winsize/2)*handles.sr)+s(1)-1);
    end
else
    mateeg2=0;
end

s=size(mateeg3);
r3=length(newposg3)
if r3>1
    for i=1:r3
        mateeg3(:,i)=e1(floor(newposg3(i)-(winsize/2)*handles.sr):floor(newposg3(i)-(winsize/2)*handles.sr)+s(1)-1);
    end
else
    mateeg3=0;
end

s=size(mateeg4);
r4=length(newposg4)
if r4>1
    for i=1:r4
        mateeg4(:,i)=e1(floor(newposg4(i)-(winsize/2)*handles.sr):floor(newposg4(i)-(winsize/2)*handles.sr)+s(1)-1);
    end
else
    mateeg4=0;
end


figure
plot(mateeg1)
title('mateeg1')
figure
plot(mateeg2)
title('mateeg2')
figure
plot(mateeg3)
title('mateeg3')
figure
plot(mateeg4)
title('mateeg4')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now getting the powerbands
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tevent=str2num(get(handles.tevent,'string'));
%fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
chlstrings=get(handles.chanlist,'string');
cnt=0;
tit=[{'Theta (4-8 Hz)'},{'Alpha (8-12 Hz)'},{'Beta (16-24 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%initial=[0.5 4 8 15 30 50];
%final=[4 8 15 30 50 80];
initial=[4 8 16 30 50];
final=[8 12 24 50 80];
lim=[0 1];
time1=round(handles.sr/2);
npoints=16;%number of points for the plots showing the average power at different frequency bands. The power will be calculated with two segments with 50% overlap
for i=1:length(initial)
    figure
    if r1>1

        for k=1:r1
            trace=mateeg1(:,k);
            lt=length(trace);
            trace=trace(1:npoints*floor(lt/npoints));
            trs=reshape(trace,floor(lt/npoints),npoints);
            
            for ki=1:npoints-1
                if ki<npoints
                m1(ki,k)=getpband3([trs(:,ki)' trs(:,ki+1)'],2*winsize/npoints,initial(i),final(i));
                else
                    m1(ki,k)=getpband3(trs(:,ki)',winsize/npoints,initial(i),final(i));
                end
            end
                    
            
        end
        cnt=cnt+1;%number of current plot
        %     t=(0:length(m1)-1)/(60/fftwindow);
        subplot(2,2,1)
        x0=[-winsize/2:winsize/npoints:winsize/2];
        %now skipping the zero
        x=[x0(1:floor(npoints/2)) x0(2+floor(npoints/2):end)]; 
        x=x(1:end-1);
        errorbar(x,mean(m1'),sem(m1'),'k-');
        hold on
        plot(x,mean(m1'),'ko-','linewidth',2)
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(5,:),' N=',num2str(r1)))
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
        
        %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(5,:),'.txt');
        save(fname,'m1','-ascii')
        axis tight
        set(gca,'xlim',[-2 2])
    end
    
    if r2>1
        m1=[];
        m2=[];
        m3=[];
        m4=[];
        m5=[];
        m6=[];
        m7=[];
        m8=[];
        for k=1:r2
            m1(k)=getpband3(mateeg2(1:time1,k),1,initial(i),final(i));
            m2(k)=getpband3(mateeg2(time1:handles.sr,k),1,initial(i),final(i));
            m3(k)=getpband3(mateeg2(handles.sr:handles.sr+time1,k),1,initial(i),final(i));
            m4(k)=getpband3(mateeg2(handles.sr+time1:2*handles.sr,k),1,initial(i),final(i));
            m5(k)=getpband3(mateeg2(2*handles.sr:(2*handles.sr)+time1,k),1,initial(i),final(i));
            m6(k)=getpband3(mateeg2((2*handles.sr)+time1:3*handles.sr,k),1,initial(i),final(i));
            m7(k)=getpband3(mateeg2(3*handles.sr:time1+3*handles.sr,k),1,initial(i),final(i));
            m8(k)=getpband3(mateeg2(time1+3*handles.sr:4*handles.sr,k),1,initial(i),final(i));
        end
        
        %     t=(0:length(m1)-1)/(60/fftwindow);
        %figure
        %subplot(3,ceil(length(initial)),2+cnt)
       subplot(2,2,2)

        x=[-2 -1.5 -1 -0.5 0.5 1 1.5 2];
        errorbar(x,[mean(m1) mean(m2) mean(m3) mean(m4) mean(m5) mean(m6) mean(m7) mean(m8)],[sem(m1) sem(m2) sem(m3) sem(m4) sem(m5) sem(m6) sem(m7) sem(m8)],'k-');
        hold on
        plot(x,[mean(m1) mean(m2) mean(m3) mean(m4) mean(m5) mean(m6) mean(m7) mean(m8)],'ko-','linewidth',2)
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(6,:),' N=',num2str(r2)))
        %     if cnt==1
        %         set(gca,'ylim',[0 1E-11])
        %     else
        %             set(gca,'ylim',[0 0.5E-11])
        %     end
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
        %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(6,:),'.txt');
        bigm=[m1' m2' m3' m4' m5' m6' m7' m8'];
        save(fname,'bigm','-ascii')

        
    end
    if r3>1
        m1=[];
        m2=[];
        m3=[];
        m4=[];
        m5=[];
        m6=[];
        m7=[];
        m8=[];

        for k=1:r3
            m1(k)=getpband3(mateeg3(1:time1,k),1,initial(i),final(i));
            m2(k)=getpband3(mateeg3(time1:handles.sr,k),1,initial(i),final(i));
            m3(k)=getpband3(mateeg3(handles.sr:handles.sr+time1,k),1,initial(i),final(i));
            m4(k)=getpband3(mateeg3(handles.sr+time1:2*handles.sr,k),1,initial(i),final(i));
            m5(k)=getpband3(mateeg3(2*handles.sr:(2*handles.sr)+time1,k),1,initial(i),final(i));
            m6(k)=getpband3(mateeg3((2*handles.sr)+time1:3*handles.sr,k),1,initial(i),final(i));
            m7(k)=getpband3(mateeg3(3*handles.sr:time1+3*handles.sr,k),1,initial(i),final(i));
            m8(k)=getpband3(mateeg3(time1+3*handles.sr:4*handles.sr,k),1,initial(i),final(i));
        end
        
        %     t=(0:length(m1)-1)/(60/fftwindow);
        %subplot(3,ceil(length(initial)),4+cnt)
        %figure
        subplot(2,2,3)

        x=[-2 -1.5 -1 -0.5 0.5 1 1.5 2];
        errorbar(x,[mean(m1) mean(m2) mean(m3) mean(m4) mean(m5) mean(m6) mean(m7) mean(m8)],[sem(m1) sem(m2) sem(m3) sem(m4) sem(m5) sem(m6) sem(m7) sem(m8)],'k-');
        hold on
        plot(x,[mean(m1) mean(m2) mean(m3) mean(m4) mean(m5) mean(m6) mean(m7) mean(m8)],'ko-','linewidth',2)
        
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(7,:),' N=',num2str(r3)))
        %     if cnt==1
        %         set(gca,'ylim',[0 1E-11])
        %     else
        %             set(gca,'ylim',[0 0.5E-11])
        %     end
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
                %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(7,:),'.txt');
        bigm=[m1' m2' m3' m4' m5' m6' m7' m8'];
        save(fname,'bigm','-ascii')

    end
    if r4>1
        m1=[];
        m2=[];
        m3=[];
        m4=[];
        m5=[];
        m6=[];
        m7=[];
        m8=[];

        for k=1:r4
            m1(k)=getpband3(mateeg4(1:time1,k),1,initial(i),final(i));
            m2(k)=getpband3(mateeg4(time1:handles.sr,k),1,initial(i),final(i));
            m3(k)=getpband3(mateeg4(handles.sr:handles.sr+time1,k),1,initial(i),final(i));
            m4(k)=getpband3(mateeg4(handles.sr+time1:2*handles.sr,k),1,initial(i),final(i));
            m5(k)=getpband3(mateeg4(2*handles.sr:(2*handles.sr)+time1,k),1,initial(i),final(i));
            m6(k)=getpband3(mateeg4((2*handles.sr)+time1:3*handles.sr,k),1,initial(i),final(i));
            m7(k)=getpband3(mateeg4(3*handles.sr:time1+3*handles.sr,k),1,initial(i),final(i));
            m8(k)=getpband3(mateeg4(time1+3*handles.sr:4*handles.sr,k),1,initial(i),final(i));
        end
        
        %     t=(0:length(m1)-1)/(60/fftwindow);
        %subplot(3,ceil(length(initial)),4+cnt)
        %figure
        subplot(2,2,4)

        x=[-2 -1.5 -1 -0.5 0.5 1 1.5 2];
        errorbar(x,[mean(m1) mean(m2) mean(m3) mean(m4) mean(m5) mean(m6) mean(m7) mean(m8)],[sem(m1) sem(m2) sem(m3) sem(m4) sem(m5) sem(m6) sem(m7) sem(m8)],'k-');
        hold on
        plot(x,[mean(m1) mean(m2) mean(m3) mean(m4) mean(m5) mean(m6) mean(m7) mean(m8)],'ko-','linewidth',2)
        
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(8,:),' N=',num2str(r4)))
        %     if cnt==1
        %         set(gca,'ylim',[0 1E-11])
        %     else
        %             set(gca,'ylim',[0 0.5E-11])
        %     end
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
                %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(8,:),'.txt');
        bigm=[m1' m2' m3' m4' m5' m6' m7' m8'];
        save(fname,'bigm','-ascii')
    end 
end
cd ..
disp([r1 r2 r3 r4]);






% --- Executes on button press in merge.
function merge_Callback(hObject, eventdata, handles)
% hObject    handle to merge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This merges the current EDf file with data extracted from a txt file with a fix configuration.
%Steps:
%1- extract initial time of EDF with second file
%2- Sync clock with system time ms by pairing the ms value witht he first
%time in the most spread series of events happening within the same seccond.
%3- make nil vectors with Correct	Incorrect	CausedReward
%CausedPunishment and fill ones at the corresponding time with ms
%precision using the data form the other text file.
%Save original EDF with this 4 new vectors added

EDF=handles.hedf;
HDR0=sopen(strcat(EDF.FILE.Name,'.',EDF.FILE.Ext),'r');
HDR=HDR0;
HDR0 = sclose(HDR0);
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the timing');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
k=0;
nlabels= size(EDF.Label,1);
%Editing the fields of the EDf file, starting by the ch. Labels


disp('Reading text file with timing info...')
C2 = textscan(fid, '%f %f %f %s %s %f %f %f %s %s %s %s');
%Get the timing to synchronize files
strgtime=char(C2{5});
vecsec=3600*str2num(strgtime(:,2:3))+60*str2num(strgtime(:,5:6))+str2num(strgtime(:,8:9));
[v,p]=mode(vecsec);
indvec=find(vecsec==v);%The timing of indvec(1) will be used to sync seconds and ms
sect0=3600*EDF.T0(4)+60*EDF.T0(5)+EDF.T0(6);
msect0= C2{6}(indvec(1))-1000*(vecsec(indvec(1))-sect0);%This is the first milisecond
msectf=msect0+1000*round(size(handles.s,1)/handles.sr);
tvect=(msectf-msect0)*((0:size(handles.s,1)-1)/(size(handles.s,1)-1));%tvect has the same number of data points than the data but they have the ms
tvect=tvect+msect0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now reading the text file with data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with stim time');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
%Editing the fields of the EDf file, starting by the ch. Labels
k=0;
for t=15:18
    k=k+1;
    HDR.Label{nlabels+k}=char(C{t});%Add data labels in the EDF
    HDR.PhysDim{nlabels+k}='Bin';
    HDR.PhysMin(nlabels+k)=min(HDR.PhysMin);
    HDR.PhysMax(nlabels+k)=1;
    HDR.DigMin(nlabels+k)=min(HDR.DigMin);%EDF.DigMin(nlabels);
    HDR.DigMax(nlabels+k)=1;%EDF.DigMax(nlabels);
    HDR.PhysDimCode(nlabels+k)=0;
    HDR.THRESHOLD(nlabels+k,:)=HDR.THRESHOLD(nlabels,:);
    HDR.Transducer{nlabels+k}=HDR.Transducer{nlabels};
    %HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));
    
    HDR.Cal(nlabels+k)=1;
    HDR.Off(nlabels+k)=0;
end


%Adding one more signals to the EDF: the stim. time and type
%     HDR.Label{nlabels+1}=char(C{t});%Add data labels in the EDF
%     HDR.PhysDim{nlabels+1}='Int';
%     HDR.PhysMin(nlabels+1)=min(HDR.PhysMin);
%     HDR.PhysMax(nlabels+1)=max(HDR.PhysMax);
%     HDR.DigMin(nlabels+1)=min(HDR.DigMin);%EDF.DigMin(nlabels);
%     HDR.DigMax(nlabels+1)=1;%EDF.DigMax(nlabels);
%     HDR.PhysDimCode(nlabels+1)=0;
%     HDR.THRESHOLD(nlabels+1,:)=HDR.THRESHOLD(nlabels,:);
%     HDR.Transducer{nlabels+1}=HDR.Transducer{nlabels};
%HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));

%     HDR.Cal(nlabels+1)=1;
%     HDR.Off(nlabels+1)=0;
HDR.FILE.Name=strcat(EDF.FILE.Name,'mrgd');
HDR.FileName=strcat(pathname,HDR.FILE.Name,'.',HDR.FILE.Ext);
HDR.reserved1='EDF merged with behavioral data';

disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %f %f %f %s %f %f %s %s %f %f %s %s %s %s %s %s %s %f %f %f %f %f %s');

%Now generating the data to be merged (columns 15 - 18):
disp('Generating data...')
%sa=char(C2{7});
%Getting the time in ms of the stim, that can be Yellow_rectangle, Blue_rectangle and White_rectangle
stim=zeros(4,length(tvect));
for k=1:4
    ind=find(strcmp(C2{k+14},'Y'));
    t1=C2{6}(ind);%times of stim 1
    for i=1:length(t1)
        [v,p]=min(abs(tvect-t1(i)));
        stim(k,p)=1;
    end
end
osize=size(handles.s,2);%The original number of sgnals
handles.s=[handles.s stim'];

figure
subplot(5,1,1)
plot(tvect/1000,handles.s(:,2))
ylabel(HDR.Label(2,:))
subplot(5,1,2)
plot(tvect/1000,handles.s(:,osize+1),'k.-')
ylabel(HDR.Label(osize+1,:))
subplot(5,1,3)
plot(tvect/1000,handles.s(:,osize+2),'k.-')
ylabel(HDR.Label(osize+2,:))
subplot(5,1,4)
plot(tvect/1000,handles.s(:,osize+3),'k.-')
ylabel(HDR.Label(osize+3,:))
subplot(5,1,5)
plot(tvect/1000,handles.s(:,osize+4),'k.-')
ylabel(HDR.Label(osize+4,:))



fclose(fid);
disp('saving...')
data=handles.s';
[nch,v]=size(data);
HDR.Dur = HDR.SPR/EDF.SampleRate;
VER   = version;
cname = computer;

% select file format
HDR.TYPE='EDF';
% number of channels
HDR.NS = nch;
HDR.GDFTYP=3*ones(1,nch);

% Duration of one block in seconds
HDR.Dur = HDR.SPR/HDR.SampleRate;

HDR.VERSION = 2.21;        % experimental
HDR.InChanSelect=1:nch;
HDR.LeadIdCode=NaN*ones(nch,1)
HDR=rmfield(HDR,'AS')
HDR = sopen(HDR,'w');
HDR = swrite(HDR,data');
HDR = sclose(HDR);
helpdlg('Done!')
guidata(hObject, handles);


