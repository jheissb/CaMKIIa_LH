function varargout = iscore(varargin)
%Graphic interface to score and analyze EEG data in EDF format
%By Jaime Heiss, March 2013
% ISCORE MATLAB code for iscore.fig
%      ISCORE, by itself, creates a new ISCORE or raises the existing
%      singleton
%
%      H = ISCORE returns the handle to a new ISCORE or the handle to
%      the existing singleton*.
%
%      ISCORE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ISCORE.M with the given input arguments.
%
%      ISCORE('Property','Value',...) creates a new ISCORE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before iscore_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to iscore_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help iscore

% Last Modified by GUIDE v2.5 24-Feb-2014 14:39:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @iscore_OpeningFcn, ...
    'gui_OutputFcn',  @iscore_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before iscore is made visible.
function iscore_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to iscore (see VARARGIN)

% Choose default command line output for iscore
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes iscore wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = iscore_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in load_edf.
function load_edf_Callback(hObject, eventdata, handles)
% hObject    handle to load_edf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cla
axes(handles.axes2)
cla
% box off
% axis off
axes(handles.axes3)
cla
box off
axis off
set(handles.raw_signals,'value',1)
cla
cn=getComputerName();
cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     cd ('D:\jhexp\2013\vivo')
% end
if strcmp('laptopjh',cn)
    cd ('C:\Users\john\Documents\My Dropbox\Jaime')
end


%cd ('C:\Users\E26903\Documents\My Dropbox\laptopsleep\anushka')
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file to analyze');
handles.fn=filename;
handles.pathEDF=pathname;
cd (pathname)
set(handles.text8,'BackgroundColor',[1 0 0])
set(handles.text8,'string','Reading File')
handles.EDF=sdfopen(filename);
%handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
set(handles.filename,'string',filename)
handles.dur=handles.EDF.NRec*handles.EDF.Dur;%duration in secs of the whole thing
set(handles.raw_signals,'string',handles.EDF.Label);
handles.selchan=get(handles.raw_signals,'value');
handles.hto=handles.EDF.T0(4);%initial hour
handles.mto=handles.EDF.T0(5);%initial minute
handles.sto=handles.EDF.T0(6);%initial second
set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));
nh=floor(handles.dur/3600);
handles.nh=nh;
nm=floor((handles.dur-(nh*3600))/60);
ns=handles.dur-(nh*3600)-(nm*60);
sf=mod(handles.sto+ns,60);
mf=mod((handles.mto+floor((handles.sto+ns)/60)+nm),60);
hf=mod(handles.hto+nh+floor((handles.mto+floor((handles.sto+ns)/60)+nm)/60),24);
nd=floor((handles.hto+nh+floor((handles.mto+floor((handles.sto+ns)/60)+nm)/60))/24);
ht0_str=num2str(handles.hto);
if length(ht0_str)==1
    ht0_str=strcat('0',ht0_str);
end
mt0_str=num2str(handles.mto);
if length(mt0_str)==1
    mt0_str=strcat('0',mt0_str);
end

st0_str=num2str(handles.sto);
if length(st0_str)==1
    st0_str=strcat('0',st0_str);
end

handles.emgscale=[0 10^-6];%Fixed scale for FFT

set(handles.endtime,'string',strcat('Tf:',num2str(hf),':',num2str(mf),':',num2str(round(ns))));
set(handles.toedit,'string',strcat(ht0_str,':',mt0_str,':',st0_str));
set(handles.stdate,'string',strcat('D0:',num2str(handles.EDF.T0(3)),'/',num2str(handles.EDF.T0(2)),'/',num2str(handles.EDF.T0(1))));
set(handles.enddate,'string',strcat('Df:',num2str(handles.EDF.T0(3)+nd),'/',num2str(handles.EDF.T0(2)),'/',num2str(handles.EDF.T0(1))));
handles.d0=0.5;
handles.df=4;
handles.tet0=4;
handles.tetf=8;
ltrace=round(600);
set(handles.endp,'string',num2str(floor(handles.dur)))
set(handles.startp,'string','0')

[handles.s,edfs]=sdfread(handles.EDF,ltrace,ltrace);
if get(handles.dsi,'value')
    handles.cht=1;%channel with highest theta
    handles.chfft=1;%channel used for FFT
    handles.chemg=2;%channel with EMG
else
    if size(handles.s,2)>2
        if size(handles.s,2)>3
            handles.cht=3;%channel with highest theta
            handles.chfft=1;%channel used for FFT
            handles.chemg=4;%channel with EMG
        else
            handles.cht=2;%channel with highest theta
            handles.chfft=1;%channel used for FFT
            handles.chemg=3;%channel with EMG
        end
    else
        handles.cht=1;%channel with highest theta
        handles.chfft=1;%channel used for FFT
        handles.chemg=2;%channel with EMG
    end
end
if get(handles.mt,'value')
    num=str2double(get(handles.limemg2,'string'));
    handles.limemg=num*std(handles.s(:,handles.chemg));
else
    handles.limemg=0;
end

%Making the vector with the epoch times and score for the whole register
handles.el=str2double(get(handles.edit7,'string'));%Duration of the epoch
handles.nepochs=floor(handles.dur/handles.el);
handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
handles.score=ones(size(handles.epocht));
handles.score(:)=NaN;
%Now getting the EMG and RMS per epoch and user defined threshold for wake
handles.emgpe=[];%zeros(1,handles.nepochs);
handles.rms=[];%zeros(1,handles.nepochs);
handles.powbands=[];
handles.distance=8;%distance between traces
disp('reading channel')
stdeeg=[];
if nh>0
    for i=0:(6*nh)-1%reading in 10 min. chunks except the last one
        [handles.EDF]=sdfclose(handles.EDF);
        handles.EDF=sdfopen(get(handles.filename,'string'));
        
        [handles.s,edfs]=sdfread(handles.EDF,ltrace,i*ltrace);
        largo=floor(handles.el*edfs.SampleRate(handles.selchan))*floor(length(handles.s(:,handles.selchan))/(handles.el*edfs.SampleRate(handles.selchan)));
        if get(handles.mt,'value')
            auxmt=rms(reshape(handles.s(1:largo,handles.chemg),floor(handles.el*edfs.SampleRate(handles.selchan)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.selchan)))));
        else
            auxmt=0;
        end
        eegtrs=reshape(handles.s(1:largo,handles.selchan),floor(handles.el*edfs.SampleRate(handles.selchan)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.selchan))));
        ltr=length(eegtrs)/edfs.SampleRate(handles.selchan);
        auxeeg=rms(eegtrs);
        handles.emgpe=[handles.emgpe auxmt];
        handles.rms=[handles.rms auxeeg];
        stdeeg=[stdeeg std(handles.s(1:largo,handles.selchan))];
        if get(handles.chbx_theta,'value')
            %getting the average power for each band for each epoch
            for kqk=1:size(eegtrs,2)
                pbands(kqk,:)=getpbands(eegtrs(:,kqk),ltr);%To do: add the duration of the trace. {'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
            end
            handles.powbands=[handles.powbands pbands'];
        end
            
    end
    startr=ceil(6*nh*ltrace);
    if handles.dur-startr>0
        [handles.s,edfs]=sdfread(handles.EDF,handles.dur-startr,startr);
        largo=floor(handles.el*edfs.SampleRate(handles.selchan))*floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.selchan)));
        if get(handles.mt,'value')
            auxmt=rms(reshape(handles.s(1:largo,handles.chemg),floor(handles.el*edfs.SampleRate(handles.chemg)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.chemg)))));
        else
            auxmt=0;
        end
        eegtrs=reshape(handles.s(1:largo,handles.selchan),floor(handles.el*edfs.SampleRate(handles.selchan)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.selchan))));
        ltr=length(eegtrs)/edfs.SampleRate(handles.selchan);
        auxeeg=rms(eegtrs);
        handles.emgpe=[handles.emgpe auxmt];
        handles.rms=[handles.rms auxeeg];
        if get(handles.chbx_theta,'value')
            pbands=[];
           %getting the average power for each band for each epoch
            for kqk=1:size(eegtrs,2)
                pbands(kqk,:)=getpbands(eegtrs(:,kqk),ltr);%{'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
            end
            handles.powbands=[handles.powbands pbands'];
        end

    end
    
else
    [handles.s,edfs]=sdfread(handles.EDF,inf);
    largo=floor(handles.el*edfs.SampleRate(handles.chemg))*floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.chemg)));
    if get(handles.mt,'value')
        auxmt=rms(reshape(handles.s(1:largo,handles.chemg),floor(handles.el*edfs.SampleRate(handles.chemg)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.chemg)))));
    else
        auxmt=0;
    end
    eegtrs=reshape(handles.s(1:largo,handles.selchan),floor(handles.el*edfs.SampleRate(handles.selchan)),floor(length(handles.s)/(handles.el*edfs.SampleRate(handles.selchan))));
    ltr=length(eegtrs)/edfs.SampleRate(handles.selchan);
    auxeeg=rms(eegtrs);
    handles.emgpe=auxmt;
    handles.rms=auxeeg;
    if get(handles.chbx_theta,'value')
            pbands=[];
           %getting the average power for each band for each epoch
            for kqk=1:size(eegtrs,2)
                pbands(kqk,:)=getpbands(eegtrs(:,kqk),ltr);%{'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
            end
            handles.powbands=pbands';
        end

    
end

f=figure
wthres=0;
if get(handles.mt,'value')
    xvec=(0:length(handles.emgpe)-1)*(handles.el/3600);
    set(f, 'Position', get(0,'Screensize')); % Maximize figure.
    plot(xvec,handles.emgpe)
    ylabel('EMG','fontsize',16)
    title('Set threshold for wake','fontsize',18)
    [xpos,wthres]=ginput(1);
end
xvec=(0:length(handles.rms)-1)*(handles.el/3600);
cla
plot(xvec+8,handles.rms)
ylabel('RMS EEG','fontsize',16)
title('Set threshold for movement artifact','fontsize',18)
[xpos,mthres]=ginput(1);
cla
plot(xvec,handles.rms)
ylabel('RMS EEG','fontsize',16)
title('Set threshold for NREM','fontsize',18)
[xpos,nrem]=ginput(1);
handles.eegrange=7*mean(stdeeg);%nrem;%range for plotting EEG (minmax=[-eegrange +eegrange])
close
%0:W, 0.1:WA, , 0.05:Systematic WA, 1:NR, 1.1:NRA, 2:R, 2.1:RA, -0.1:C1, -0.2:C2, -0.3:U
if get(handles.mt,'value')
    handles.score(find(handles.emgpe>wthres & handles.rms<(nrem/1.5)))=0;
    handles.score(find(handles.emgpe>wthres & handles.rms>nrem))=0.1;
    handles.score(find(handles.rms>nrem & handles.emgpe<(wthres/2)))=1;
end
handles.ascore=handles.score;
handles.validatedsc=zeros(size(handles.score));
axes(handles.axes3)
cla
guidata(hObject, handles);
plot(ep2zt(handles.epocht,handles),handles.score,'k-')
axis tight
box off
set(gca,'xcolor','g')
%axis off

if get(handles.chbx_theta,'value')
    xv=14.3756+(1:length(handles.powbands'))*(handles.el/3600);
    %xv=xv*0.0028;%xvector in hours
    mtp=normat_one(handles.powbands')+(diag(1:6)'*ones(size(handles.powbands'))')';%shift each row by one more than previous for visualization
    figure
    plot(xv,mtp);
    %legend('D', 'T', 'A', 'B', 'lG', 'hG')
    legend('30-40 Hz', '40-50 Hz', '50-60 Hz', '60-70 Hz', '70-80 Hz', '80-90 Hz')
    xlabel('h')
end
%reading the trace
handles.ltrace=str2double(get(handles.lengthtrace,'string'));
handles.neptpl=floor(handles.ltrace/handles.el);
if handles.neptpl<1
    set(handles.lengthtrace,'string',num2str(handles.el))
    handles.ltrace=handles.el;
    handles.neptpl=1;
end
[handles.EDF]=sdfclose(handles.EDF);
handles.EDF=sdfopen(filename);
[handles.s,edfs]=sdfread(handles.EDF,ltrace,0);
handles.sr=edfs.SampleRate;
set(handles.text6,'string',strcat('SR: ',num2str(handles.sr(handles.selchan))));
handles.x=handles.ltrace*(0:length(handles.s(:,handles.selchan))-1)/(length(handles.s(:,handles.selchan))-1);
handles.xi=1/handles.sr(handles.selchan);
handles.t0=0;%Initial time to plot in s
handles.ce=1;%current epoch
handles.tf=handles.t0+handles.ltrace;%final time to plot in s
handles.maxf=12;%maxfrec for plotting when scoringplot_traces(handles);
handles.step=handles.el*handles.sr(handles.selchan);%number of points of each epoch
plot_traces(handles)
set(handles.text8,'BackgroundColor',[0 1 0])
set(handles.text8,'string','Ready')
handles.NOWscoring=0;%Flag for scoring mode
guidata(hObject, handles);

function plot_traces(handles)
set(handles.edit6,'string',num2str(handles.ce))
%disp(handles.ce*handles.el)
%disp(handles.epocht(handles.ce))
axes(handles.axes1)
cla
xlabel('s','fontsize',14)
%set(handles.slider1,'max',tl);
%getting the max in the slider
nchtp=length(handles.selchan);%number of channels to plot
for i=1:nchtp
    selchan=handles.selchan(i);
    handles.x=handles.ltrace*(0:length(handles.s(:,selchan))-1)/(length(handles.s(:,selchan))-1);
    handles.x=handles.x+handles.t0;
    if selchan==2 & size(handles.s,2)>2
        plot(handles.x,(handles.distance*(i-1)*std(handles.s(:,handles.selchan(1))))+(handles.s(:,1)-handles.s(:,3)),'k-')
    else
        plot(handles.x,(handles.distance*(i-1)*std(handles.s(:,handles.selchan(1))))+handles.s(:,selchan),'k-')
    end
    %plot(handles.x,handles.s(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.raw_signals,'value')))
    axis tight
    if nchtp==1
        set(gca,'ylim',[-handles.eegrange handles.eegrange])
    end
end
xi=handles.x(1);
xf=handles.x(end);
minmax=get(gca,'ylim');
p=find(handles.epocht>=xi);%(xi/handles.sr(selchan)));
firstep=p(1);
p=find(handles.epocht<=xf);%;(xf/handles.sr(selchan)));
lastep=p(end);
hold on
plot([handles.epocht(firstep:lastep)' handles.epocht(firstep:lastep)'],minmax,'g--')
%writing the scoring
posytxt=minmax(1)+0.95*(minmax(2)-minmax(1));
posxtxt=0.05*handles.el;
for i=firstep:lastep
    %  text(handles.epocht(i)+posxtxt,posytxt,strcat('EMG:',num2str(handles.emgpe(i)),scr2txt(handles.score(i))),'fontsize',14,'color','r');
    if handles.validatedsc(i)==1
        text(handles.epocht(i)+posxtxt,posytxt,scr2txt(handles.score(i)),'fontsize',14,'color','r');
    else
        text(handles.epocht(i)+posxtxt,posytxt,scr2txt(handles.score(i)),'fontsize',14,'color','g');
    end
    
end

%Finally marking h=the active epoch
xv=[handles.epocht(handles.ce) handles.epocht(handles.ce+1)];
einf=[minmax(1) minmax(1)];
emax=[minmax(2) minmax(2)];
X=[xv,fliplr(xv)];                %create continuous x value array for plotting
Y=[einf,fliplr(emax)];              %create y values for out and then back
%hl=fill(X,Y,[0.97 0.97 0.95],'EdgeColor','none');                  %plot filled area
hl=fill(X,Y,[0.92 0.92 0.95],'EdgeColor','none');   
uistack(hl,'bottom')


%Now plot MT
if get(handles.mt,'value')
    axes(handles.axes5)
    cla
    plot(handles.x,(handles.s(:,handles.chemg).^2)-mean(handles.s(:,handles.chemg).^2),'b-')
    axis tight
    if get(handles.fixEMG,'value')
        set(gca,'ylim',handles.limemg)
    end
    %set(gca,'ylim',[mean(handles.s(:,handles.chemg))-handles.limemg mean(handles.s(:,handles.chemg))+handles.limemg])
%     set(gca,'ylim',[0 mean(handles.s(:,handles.chemg).^2)+handles.limemg])
    axis off
    if str2double(get(handles.lengthtrace,'string'))<=120
        plot_FFT(handles);
    else
        axes(handles.axes2)
        cla
        axis off
        axes(handles.axes4)
        cla
        axis off
        
    end
end

%Now plotting the the current position
%figure
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
newt0=mod(h0-zt0,24);

axes(handles.axes3)
cla
plot([newt0+(handles.epocht(handles.ce)/3600) newt0+(handles.epocht(handles.ce)/3600)],[0 2],'r.-')
box off
hold on
plot(newt0+(handles.epocht/3600),handles.score,'k-')
axis tight
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str(mod(xlabl,24)))
%now plotting the stimulus (sync signal)
if isfield(handles,'stimoff')
    plot([(newt0+handles.stimoff)' (newt0+handles.stimoff)'],[0 2]','c--')
end
if isfield(handles,'stimon')
    plot([(newt0+handles.stimon)' (newt0+handles.stimon)'],[0 2]','m--')
end





function plot_FFT(handles)
%plotting the FFT and the bar plots with delta and teta
axes(handles.axes2)
cla
axis on
pvec=[];
N = floor(handles.el*handles.sr(handles.chfft)); %% number of points
T = handles.el; %% define time of interval
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
df=freq(2)-freq(1);
xpvec=[];
for i=0:floor(handles.ltrace/handles.el)-1
    aux=getthepower(handles.s(floor(1+(i*(handles.el*handles.sr(handles.cht)):(1+i)*(handles.el*handles.sr(handles.cht))))),handles.el,handles.maxf-df,0);
    pvec=[pvec aux];
    if i==0
        xpvec=freq(1:length(aux));
    else
        xpvec=[xpvec 2*xpvec(end)-xpvec(end-1)+freq(1:length(aux))];
    end
end
plot(xpvec,pvec)
axis tight;
set(gca,'ylim',handles.emgscale)
minmax=handles.emgscale;
hold on
plot([(0:handles.maxf:length(pvec))' (0:handles.maxf:length(pvec))'],minmax,'g--','linewidth',2)
set(gca,'XTick',0:2:length(pvec));
set(gca,'XTickLabel',num2str((0:2:handles.maxf-0.1)'))
grid on

%Now the bar plots with the ratios of frequncies: delta=delta power/total
%power of the epoch. Teta=teta power/delta power (both for the epoch)
% axes(handles.axes4)
% [v,xi]=min(abs(handles.x-handles.ti));
% [v,xf]=min(abs(handles.x-handles.tf));
% cla
% for kk=0:handles.neptpl-1
%     trace=handles.s((xi*kk)+1:(xi*kk)+handles.step,handles.chfft);
%     tracet=handles.s((xi*kk)+1:(xi*kk)+handles.step,handles.cht);
%     delta(kk+1)=getpband(trace,handles.el,handles.d0,handles.df)/getpband(trace,handles.el,handles.d0,handles.tetf);
%     teta(kk+1)=getpband(tracet,handles.el,handles.tet0,handles.tetf)/getpband(trace,handles.el,handles.d0,handles.df);
% end
% %bar([(delta-min(delta))',(teta-min(teta))'])
%
% %x=1:length(delta);
% bar([delta',teta'])
%
% set(gca,'xticklabel','')
%axis tight
%axis off
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, ~, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in begin.
function begin_Callback(hObject, eventdata, handles)
% hObject    handle to begin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.begin,'BackgroundColor',[0 0.5 0])
set(handles.stop,'BackgroundColor',[1 0 0])
handles.NOWscoring=1;
while handles.NOWscoring
    c=getkey;
    disp(c)
end
guidata(hObject, handles);



% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.begin,'BackgroundColor',[0 1 0])
set(handles.stop,'BackgroundColor',[0.5 0 0])
handles.NOWscoring=0;
guidata(hObject, handles);

% --- Executes on selection change in raw_signals.
function raw_signals_Callback(hObject, eventdata, handles)
% hObject    handle to raw_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns raw_signals contents as cell array
%        contents{get(hObject,'Value')} returns selected item from raw_signals
handles.selchan=get(hObject,'Value');
guidata(hObject, handles);
plot_traces(handles);

% --- Executes during object creation, after setting all properties.
function raw_signals_CreateFcn(hObject, eventdata, handles)
% hObject    handle to raw_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in devsignals.
function devsignals_Callback(hObject, eventdata, handles)
% hObject    handle to devsignals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns devsignals contents as cell array
%        contents{get(hObject,'Value')} returns selected item from devsignals


% --- Executes during object creation, after setting all properties.
function devsignals_CreateFcn(hObject, eventdata, handles)
% hObject    handle to devsignals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lengthtrace_Callback(hObject, eventdata, handles)
% hObject    handle to lengthtrace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lengthtrace as text
%        str2double(get(hObject,'String')) returns contents of lengthtrace as a double
if isfield (handles,'el')
if str2double(get(handles.lengthtrace,'string'))<handles.el
    set(handles.lengthtrace,'string',num2str(handles.el))
end
handles.ltrace=min(240,str2double(get(handles.lengthtrace,'string')));
handles.tf=handles.t0+handles.ltrace;
[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
robot = java.awt.Robot;
  pos = get(handles.axes1, 'Position');
  set(0, 'PointerLocation', [pos(1:2)+100]);
  robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
  robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

guidata(hObject, handles);
plot_traces(handles)
end
% --- Executes during object creation, after setting all properties.
function lengthtrace_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lengthtrace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in stats.
function stats_Callback(hObject, eventdata, handles)
% hObject    handle to stats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%getting the Nepochs by state
startsec=str2double(get(handles.startp,'string'));
endsec=str2double(get(handles.endp,'string'));
[v,startep]=min(abs(handles.epocht-startsec));
[v,endep]=min(abs(handles.epocht-endsec));
indwa=startep-1+find(handles.score(startep:endep)>=0 & handles.score(startep:endep)<1);
indnr=startep-1+find(handles.score(startep:endep)>=1 & handles.score(startep:endep)<2);
indr=startep-1+find(handles.score(startep:endep)>=2);
%Calculating stats: Percentage in each state, distribution of bout lenghts,
%power spect by state and Heatmap.3876-7416
if length(indwa)<2
    indwa=[1 2];
end
if length(indnr)<2 %This is not the right way to fix this
    indnr=[1 2];
end
if length(indr)<2
    indr=[1 2];
end
boutwa=getbout(indwa)*handles.el;
boutnr=getbout(indnr)*handles.el;
boutr=getbout(indr)*handles.el;

figure
subplot (4,3,[4 7 10])
neps=length(indwa)+ length(indnr)+ length(indr);
bar(100*[length(indwa)/neps length(indnr)/neps length(indr)/neps]);
set(gca,'fontsize',14)
set(gca,'xticklabel',{'WA','NR','REM'})
title('% Time','fontsize',21)
box off

subplot (4,3,[4 7 10]+1)
bar([mean(boutwa) mean(boutnr) mean(boutr)]);
set(gca,'xticklabel',{'WA','NR','REM'})
set(gca,'fontsize',14)
title('Mean Bout Duration (s)','fontsize',21)
box off

%Calculating the average FFT by state from channels 1, 3 and 1-3:
%edit 3 and edit 2 have the start and end of the perid under stimulation
startp=str2double(get(handles.startp,'string'));
endp=str2double(get(handles.endp,'string'));
[v,ep0]=min(abs(handles.epocht-startp));
[v,epf]=min(abs(handles.epocht-endp));
%initializing matrices with the power spectrum
maxfrec=20;
nEDF=sdfopen(handles.fn);
[eegtrace,edfs]=sdfread(nEDF,handles.el,1);
%[nEDF]=sdfclose(nEDF);
aux=getthepower(eegtrace(:,handles.selchan),handles.el,maxfrec,0);
N = length(eegtrace); %% number of points
T = handles.el; %% define time of interval, 3.4 seconds
t = [0:N-1]/N; %% define time
t = t*T; %% define time in seconds
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
freq=freq(1:length(aux));

kWA=0;kNR=0;kREM=0;k=0;
%nEDF=sdfopen(handles.fn);
if get(handles.do_all,'value')
    newep0=1;
    newepf=handles.nepochs-2;
else
    newep0=ep0;
    newepf=epf;
end
nwa=(find(handles.score(newep0:newepf)==0));
nr=(find(handles.score(newep0:newepf)==2));
nnr=(find(handles.score(newep0:newepf)==1));
matpowerWA=zeros(length(nwa),length(aux));
matpowerNR=zeros(length(nnr),length(aux));
matpowerREM=zeros(length(nr),length(aux));

matheatmap=zeros(newepf-newep0+1,length(aux));

for currep=newep0:newepf
    [nEDF]=sdfclose(nEDF);
    nEDF=sdfopen(handles.fn);


    [eegtrace,edfs]=sdfread(nEDF,handles.el,handles.epocht(currep));
%     if handles.selchan==2
%         aux2=getthepower(1000*(eegtrace(:,1)-eegtrace(:,3)),handles.el,maxfrec,0);
%     else
        aux2=getthepower(1000*eegtrace(:,handles.selchan),handles.el,maxfrec,0);
%     end
    
    if handles.score(currep)==0
        kWA=kWA+1;
        matpowerWA(kWA,:)=aux2;
    end
    if handles.score(currep)==1
        kNR=kNR+1;
        matpowerNR(kNR,:)=aux2;  
    end
    if handles.score(currep)==2
        kREM=kREM+1;
        matpowerREM(kREM,:)=aux2;  
    end
    k=k+1;
    matheatmap(k,:)=aux2;
end
subplot (4,3,[4 7 10]+2)
plot(freq,mean(matpowerWA),'k-','linewidth',2);
box off
hold on
plot(freq,mean(matpowerNR),'b-','linewidth',2);
xlabel('Hz','fontsize',21)

plot(freq,mean(matpowerREM),'r-','linewidth',2);
set(gca,'fontsize',14)
xlabel('Frequency (Hz)','fontsize',21)
box off
ylabel('Power (\muV^2)','fontsize',21)
legend('W','NR','REM')

subplot (4,3,1:3)
zt0=get(handles.edit4,'string');
plot(handles.EDF.T0(4)+(handles.EDF.T0(5)/60)+(handles.EDF.T0(6)/3600)-str2double(zt0(1:2))-(str2double(zt0(4:5))/60)-(str2double(zt0(7:7))/3600)+(handles.epocht(newep0)/3600)+(handles.epocht(newep0:newepf)/3600),round(handles.score(newep0:newepf)),'k-','linewidth',1.5);
set(gca,'YTick',[0 1 2])
set(gca,'YTicklabel',{'W','NREM','REM'})
box off
set(gca,'fontsize',14)
xlabel('ZT (Hours)','fontsize',16)
figure
%changing the range of heatmap to [0 64]
minhm=min(min(matheatmap));
maxhm=max(max(matheatmap));
matheatmap=matheatmap-minhm;
matheatmap=matheatmap/(maxhm-minhm);
matheatmap=matheatmap*64;
%shifting heatmap so the plot saturates at 99% of max val
v=sort(matheatmap(:));
chosen_val=v(round(0.99*length(v)));
fact=64/chosen_val;
matheatmap=fact*matheatmap;
image(matheatmap');
axis xy
colormap('jet')
minmax=get(gca,'xlim');
set(gca,'xlim',10*round(minmax./10));
minmax=get(gca,'xlim');
set(gca,'XTick',[min(minmax):(minmax(2)-minmax(1))/10:max(minmax)]);
xlabl=str2num(get(gca,'Xticklabel'));
%each x point is one epoch

set(gca,'Xticklabel',num2str(0.1*round(10*ep2zt(10*xlabl+handles.epocht(newep0),handles))));
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(ylabl/10))
xlabel('ZT (hours)','fontsize',21)
ylabel('Hz','fontsize',21)

%adding a stim bar
if get(handles.do_all,'value')
    hold on
    plot(6*[startp/60 endp/60],[5 5],'w-','linewidth',3)
end
%title('Heatmap')
set(gca,'fontsize',14)
c=colorbar;
ylablcb=str2num(get(c,'Yticklabel'));
set(c,'Yticklabel',num2str(0.1*round(10*((ylablcb./64)*(maxhm-minhm)+minhm))));
set(gca,'fontsize',14)
%saving data
fndata=strcat(handles.fn(1:end-4),'_',num2str(startsec),'_',num2str(endsec),'_data.mat');
sc=handles.score;
pwa=100*length(indwa)/neps; 
pnr=length(indnr)/neps;
pr=length(indr)/neps;

mboutwa=mean(boutwa);mboutnr=mean(boutnr);mboutr=mean(boutr);
save(fndata,'zt0','sc','pwa','pnr','pr','startsec','endsec','matpowerWA','matpowerNR','matpowerREM','freq','mboutwa','mboutnr','mboutr')
helpdlg('Data file saved')
[nEDF]=sdfclose(nEDF);
%Now the power spectra


%ylabel('mV^2')

function newt=ep2zt(time_points,handles)
%Convert a set of time points in sec. to their respective ZT times in hours
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
aux2=h0+(time_points/3600);
newt=mod(aux2-zt0,24);



% --- Executes on button press in calcsignals.
function calcsignals_Callback(hObject, eventdata, handles)
% hObject    handle to calcsignals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.nsr=25;%subsampling slected channel and getting his RMS value in 2 s bins.
ct=1/handles.nsr;%time point at the begining of the read operation
disp('Subsampling trace at 25  Hz')
%initialize matrices
aux=zeros(1,nsec*handles.nsr);
%newsig=[];
newsig=zeros(EDF.NS,handles.dur*handles.nsr);
%builds new signal
k=0;
tic
while ct<handles.dur
    if k==0
        [aux,edfs]=sdfread(EDF,round(nsec),0);
    else
        [aux,edfs]=sdfread(EDF,round(nsec),ct);
    end
    newsig=[newsig;aux];
    ct=ct+nsec;
    if ct>=handles.dur
        ct=handles.dur;
    end
    k=k+1;
    %     if (k/10)-round(k/10)==0
    %         disp((handles.dur/60)-(ct/60))
    %     end
end
toc

handles.ls=length(handles.s);
handles.selchan=1;%get(handles.chanlist,'value');
handles.sr=edfs.SampleRate;

%Now subsampling at 30 Hz:
news=subsam(handles.s(:,handles.selchan),handles.sr(handles.selchan),30);
% handles.s=news;
% handles.sr=30;

set(handles.text6,'string',num2str(handles.sr(handles.selchan)));
handles.hto=EDF.T0(4);%initial hour
handles.mto=EDF.T0(5);%initial minute
handles.sto=EDF.T0(6);%initial second
set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));

%handles.ltrace=length(handles.s(:,handles.selchan))/handles.sr(handles.selchan);%total length in s
handles.x=handles.ltrace*(0:length(handles.s(:,handles.selchan))-1)/(length(handles.s(:,handles.selchan))-1);
handles.xi=1/handles.sr(handles.selchan);
xlabel('s','fontsize',14)
%set(handles.slider1,'max',tl);
%getting the max in the slider
axes(handles.axes1)

ti=0;
tf=ti+str2double(get(handles.lengthtrace,'string'));
[v,xi]=min(abs(handles.x-ti));
[v,xf]=min(abs(handles.x-tf));
plot(handles.x(xi:xf),handles.s(xi:xf,handles.selchan),'k-')

%plot(handles.x,handles.s(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.raw_signals,'value')))
axis tight


set(handles.filename,'string',filename);


guidata(hObject, handles);


% --- Executes on button press in dsi.
function dsi_Callback(hObject, eventdata, handles)
% hObject    handle to dsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dsi


% --- Executes on button press in chkbx_rmsemg.
function chkbx_rmsemg_Callback(hObject, eventdata, handles)
% hObject    handle to chkbx_rmsemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chkbx_rmsemg


% --- Executes on button press in chbx_theta.
function chbx_theta_Callback(hObject, eventdata, handles)
% hObject    handle to chbx_theta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of chbx_theta


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6


% --- Executes on button press in do_all.
function do_all_Callback(hObject, eventdata, handles)
% hObject    handle to do_all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of do_all


% --- Executes on button press in mt.
function mt_Callback(hObject, eventdata, handles)
% hObject    handle to mt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mt


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9


% --- Executes on scroll wheel click while the figure is in focus.
function figure1_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)
l=str2double(get(handles.lengthtrace,'string'));
if eventdata.VerticalScrollCount==1
    if l>5
        set(handles.lengthtrace,'string',num2str(round(l-5)))
    end
else
    if l<handles.dur
        set(handles.lengthtrace,'string',num2str(min(handles.dur,round(l+5))))
    end
end
guidata(hObject, handles);


function endp_Callback(hObject, eventdata, handles)
% hObject    handle to endp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endp as text
%        str2double(get(hObject,'String')) returns contents of endp as a double


% --- Executes during object creation, after setting all properties.
function endp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startp_Callback(hObject, eventdata, handles)
% hObject    handle to startp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startp as text
%        str2double(get(hObject,'String')) returns contents of startp as a double


% --- Executes during object creation, after setting all properties.
function startp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

%
% % --- Executes on key press with focus on figure1 or any of its controls.
% function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% % hObject    handle to figure1 (see GCBO)
% % eventdata  structure with the following fields (see FIGURE)
% %	Key: name of the key that was pressed, in lower case
% %	Character: character interpretation of the key(s) that was pressed
% %	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% % handles    structure with handles and user data (see GUIDATA)
% set(handles.text8,'BackgroundColor',[1 0 0])
% set(handles.text8,'string','Reading File')
% handles.EDF=sdfopen(get(handles.filename,'string'));
% %handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
%
% switch eventdata.Key
%
%     case 'rightarrow'
%         handles.ce=min(handles.ce+1,handles.nepochs);
%         %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
%         handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
%         handles.tf=handles.t0+handles.ltrace;
%         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
%         guidata(hObject, handles);
%         plot_traces(handles);
%     case 'leftarrow'
%         handles.ce=(max(1,handles.ce-1));
%         handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
%         disp('t0=')
%         disp(handles.t0)
%         disp('CEpoch=')
%         disp(handles.ce)
%         handles.tf=handles.t0+handles.ltrace;
%         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
%         guidata(hObject, handles);
%         plot_traces(handles);
% end
% %disp(handles.ce)
%pause(0.01);
% set(handles.text8,'BackgroundColor',[0 1 0])
% set(handles.text8,'string','Ready')
%





function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text

%        str2double(get(hObject,'String')) returns contents of edit6 as a double
handles.ce=str2double(get(hObject,'String'));
robot = java.awt.Robot;
  pos = get(handles.axes1, 'Position');
  set(0, 'PointerLocation', [pos(1:2)+100]);
  robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
  robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key release with focus on figure1 or any of its controls.
function figure1_WindowKeyReleaseFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was released, in lower case
%	Character: character interpretation of the key(s) that was released
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) released
% handles    structure with handles and user data (see GUIDATA)

%iscore('figure1_WindowKeyReleaseFcn',hObject,eventdata,guidata(hObject))
set(handles.text8,'BackgroundColor',[1 0 0])
set(handles.text8,'string','Reading File')
if isfield(handles,'EDF')
handles.EDF=sdfclose(handles.EDF);
handles.EDF=sdfopen(get(handles.filename,'string'));
%handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
switch eventdata.Key
    
    case 'rightarrow'
        handles.ce=(min(handles.nepochs,handles.ce+1));
        handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
        
        
        
        
        %         handles.ce=min(handles.ce+1,handles.nepochs);
        %         %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
        %         handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        %         handles.tf=handles.t0+handles.ltrace;
        %         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        %         guidata(hObject, handles);
        %         plot_traces(handles);
    case 'leftarrow'
        handles.ce=(max(1,handles.ce-1));
        handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'uparrow'
        handles.ce=min(handles.ce+floor(handles.ltrace/handles.el),handles.nepochs);
        %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+(floor(handles.ltrace/handles.el)*handles.el));
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'downarrow'
        handles.ce=(max(1,handles.ce-floor(handles.ltrace/handles.el)));
        handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        %now for the scoring:
        %0:W, 0.1:WA, , 0.05:Systematic WA, 1:NR, 1.1:NRA, 2:R, 2.1:RA, -0.1:C1, -0.2:C2, -0.3:U
        
    case 'numpad7'
        handles.score(handles.ce)=1.1;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'numpad8'
        handles.score(handles.ce)=2.1;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'numpad9'
        handles.score(handles.ce)=0.1;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'numpad4'
        handles.score(handles.ce)=-0.1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'numpad5'
        handles.score(handles.ce)=2;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'numpad6'
        handles.score(handles.ce)=-0.3;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'numpad1'
        handles.score(handles.ce)=1;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'numpad2'
        handles.score(handles.ce)=-0.2;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'numpad3'
        handles.score(handles.ce)=2;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'numpad0'
        handles.score(handles.ce)=0;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
        
    case 'decimal'
        handles.score(handles.ce)=0.05;
        handles.validatedsc(handles.ce)=1;
        handles.ce=min(handles.ce+1,handles.nepochs);
        handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'v'
        handles.validatedsc(handles.ce)=1;
        handles.ce=(min(handles.nepochs,handles.ce+1));
        handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
    case 'n'
        handles.ce=min(find(isnan(handles.score)));
        handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
        handles.tf=handles.t0+handles.ltrace;
        [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
        guidata(hObject, handles);
        plot_traces(handles);
end
%disp(handles.ce)
set(handles.edit6,'string',num2str(handles.ce))
% axes(handles.axes3)
% cla
% plot([(handles.epocht(handles.ce)/3600) (handles.epocht(handles.ce))/3600],[0 2],'r.-')
% box off
% hold on
% plot(handles.epocht/3600,handles.score,'k-')
% axis tight
% set(gca,'xcolor','g')
%
pause(0.01);
set(handles.text8,'BackgroundColor',[0 1 0])
set(handles.text8,'string','Ready')
plot_traces(handles)
end
guidata(hObject, handles);



% --- Executes on button press in savescore.
function savescore_Callback(hObject, eventdata, handles)
% hObject    handle to savescore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'.mat');
if isnan(handles.score(end))
    handles.score(end)=handles.score(end-1);
end
startp=str2double(get(handles.startp,'string'));
endp=str2double(get(handles.endp,'string'));
sc=handles.score;
vali=handles.validatedsc;
scalefft=get(handles.limemg2,'string');
zt0=get(handles.edit4,'string');
rangefft=handles.emgscale;
epocl=handles.el;
save(fn,'sc','vali','startp','endp','zt0','scalefft','rangefft','epocl');
helpdlg('Score saved')

% --- Executes on button press in loadscore.
function loadscore_Callback(hObject, eventdata, handles)
% hObject    handle to loadscore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'.mat');
dat=load(fn);
if isfield(dat,'scalefft')
    set(handles.limemg2,'string',dat.scalefft);
    set(handles.edit4,'string',dat.zt0);
    handles.emgscale=dat.rangefft;
end
if isfield(dat,'epocl')
    handles.el=dat.epocl;
    if handles.el~=str2num(get(handles.edit7,'string'));
        set(handles.edit,'string',num2str(dat.epocl));
        handles.nepochs=floor(handles.dur/handles.el);
        handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);

    end
end

handles.score(1:length(dat.sc))=dat.sc;
handles.validatedsc(1:length(dat.vali))=dat.vali;
if isfield(dat,'endp')
    set(handles.endp,'string',num2str(dat.endp));
    set(handles.startp,'string',num2str(dat.startp));
end
handles.ce=1;
helpdlg('Score loaded')
if exist('imagingtime.mat') & get(handles.checkbox10,'value') %loading sync signal with onset and ofset of imaging
    imgt=load('imagingtime.mat')
    handles.stimoff=imgt.stopimg;
    handles.stimon=imgt.startimg;
    handles.origimgon=handles.stimon;
    handles.origimgoff=handles.stimoff;
end
guidata(hObject, handles);
plot_traces(handles);


% --- Executes on button press in goto.
function goto_Callback(hObject, eventdata, handles)
% hObject    handle to goto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%TO dO: hide all other plots
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
newt0=mod(h0-zt0,24);

axes(handles.axes3)
[xpos,nrem]=ginput(1);
xpos=xpos-newt0;
[v,p]=min(abs(handles.epocht-xpos*3600));
handles.ce=p;
handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
handles.tf=handles.t0+handles.ltrace;
[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
guidata(hObject, handles);
plot_traces(handles);


% --- Executes on button press in readsync.
function readsync_Callback(hObject, eventdata, handles)
% hObject    handle to readsync (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%Read a sync signal and shows the timepoints in the hypnogram.
mindist=10;% distance between frames
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file with the SYNC data');
cd (pathname)
EDF=sdfopen(filename);
dur=EDF.NRec*EDF.Dur;%duration in secs of the whole thing
ltrace=3600;
handles.stimon=[];
handles.stimoff=[];
handles.subs=[];
disp('Reading Sync data...')
%[s,edfs]=sdfread(EDF,ltrace,ltrace);
syncsignal=[];
newsrsync=EDF.SampleRate;
% if EDF.SampleRate>2500 %if sampling rate is too high, subsamplin to 1 KHz
%     newsrsync=1000;
%calculating stim on and stim off in 1h chuncks
figure
if dur>ltrace
     tempstimon=[];
     tempstimoff=[];
    for nchunk=0:(ceil(dur/ltrace))-1%reading in 60 min. chunks except the last one
        disp(strcat('H=',num2str(nchunk)))
        EDF=sdfclose(EDF);
        EDF=sdfopen(filename);
        [s,edfs]=sdfread(EDF,ltrace,nchunk*ltrace);%,ltrace,nchunk*ltrace);
        auxs=s(2:end);
        indon=[];
        indoff=[];
        auxindon=[];
        auxindoff=[];
        auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
        auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
        sr=1./diff(auxindon/newsrsync);
        plot(sr,'k.-')
        %Getting only the first and last edge within a series of edges
        k=1;
        if ~isempty(auxindon)
            for i=1:length(auxindon)
                if i==1
                    indon(k)=auxindon(i);
                else
                    %if (auxindon(i)-indon(k))>(mindist*newsrsync)
                    if (auxindon(i)-auxindon(i-1))>(mindist*newsrsync)
                        k=k+1;
                        indon(k)=auxindon(i);
                    end
                end
            end
        end
        if ~isempty(auxindoff)
            k=1;
            for i=length(auxindoff):-1:1
                if i==length(auxindoff)
                    indoff(k)=auxindoff(i);
                else
                    if auxindoff(i+1)-auxindoff(i)>mindist*newsrsync
                        k=k+1;
                        indoff(k)=auxindoff(i);
                    end
                end
            end
            indoff=fliplr(indoff);
        end
        %Converting into time (in hours)
        if ~isempty(indon)
            for k=1:length(indon)
                %nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
                nextv=(indon(k)/(3600*newsrsync));
                tempstimon=[tempstimon nextv+nchunk];
            end
        end
        if ~isempty(indoff)
            for k=1:length(indoff)
                %nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
                nextv=(indoff(k)/(3600*newsrsync));
                tempstimoff=[tempstimoff nextv+nchunk];
            end
        end
    end
    
    %     if nchunk == 1
    %         syncsignal=[syncsignal subsam(s,EDF.SampleRate,newsrsync)'];
    %REading the remainder
%     nchunk=nchunk+1;
%     EDF=sdfclose(EDF);
%     EDF=sdfopen(filename);
%     [s,edfs]=sdfread(EDF,ltrace,nchunk*ltrace);
%     syncsignal=[syncsignal subsam(s,EDF.SampleRate,newsrsync)'];
%     s=syncsignal;
%     auxs=s(2:end);
%     indon=[];
%     indoff=[];
%     auxindon=[];
%     auxindoff=[];
%     auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
%     auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
%     sr=1./diff(auxindon/newsrsync);
%     figure;plot(sr,'k.-')
%     %Getting only the first and last edge within a series of edges
%     k=1;
%     if ~isempty(auxindon)
%         for i=1:length(auxindon)
%             if i==1
%                 indon(k)=auxindon(i);
%             else
%                 %if (auxindon(i)-indon(k))>(mindist*newsrsync)
%                 if (auxindon(i)-auxindon(i-1))>(mindist*newsrsync)
%                     k=k+1;
%                     indon(k)=auxindon(i);
%                 end
%             end
%         end
%     end
%     if ~isempty(auxindoff)
%         k=1;
%         for i=length(auxindoff):-1:1
%             if i==length(auxindoff)
%                 indoff(k)=auxindoff(i);
%             else
%                 if auxindoff(i+1)-auxindoff(i)>mindist*newsrsync
%                     k=k+1;
%                     indoff(k)=auxindoff(i);
%                 end
%             end
%         end
%         indoff=fliplr(indoff);
%     end
%     %Converting into time (in hours)
%     if ~isempty(indon)
%         for k=1:length(indon)
%             %nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
%             nextv=(indon(k)/(3600*newsrsync));
%             tempstimon=[tempstimon nextv+nchunk];
%         end
%     end
%     if ~isempty(indoff)
%         for k=1:length(indoff)
%             %nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
%             nextv=(indoff(k)/(3600*newsrsync));
%             tempstimoff=[tempstimoff nextv+nchunk];
%         end
%     end
else
    EDF=sdfclose(EDF);
    EDF=sdfopen(filename);
    [s,edfs]=sdfread(EDF,inf);%,ltrace,nchunk*ltrace);
    auxs=s(2:end);
    indon=[];
    indoff=[];
    auxindon=[];
    auxindoff=[];
    auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
    auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
    sr=1./diff(auxindon/newsrsync);
    figure;plot(sr,'k.-')
    %Getting only the first and last edge within a series of edges
    k=1;
    if ~isempty(auxindon)
        for i=1:length(auxindon)
            if i==1
                indon(k)=auxindon(i);
            else
                %if (auxindon(i)-indon(k))>(mindist*newsrsync)
                if (auxindon(i)-auxindon(i-1))>(mindist*newsrsync)
                    k=k+1;
                    indon(k)=auxindon(i);
                end
            end
        end
    end
    if ~isempty(auxindoff)
        k=1;
        for i=length(auxindoff):-1:1
            if i==length(auxindoff)
                indoff(k)=auxindoff(i);
            else
                if auxindoff(i+1)-auxindoff(i)>mindist*newsrsync
                    k=k+1;
                    indoff(k)=auxindoff(i);
                end
            end
        end
        indoff=fliplr(indoff);
    end
    %Converting into time (in hours)
    if ~isempty(indon)
        for k=1:length(indon)
            %nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
            nextv=(indon(k)/(3600*newsrsync));
            tempstimon=[tempstimon nextv];
        end
    end
    if ~isempty(indoff)
        for k=1:length(indoff)
            %nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
            nextv=(indoff(k)/(3600*newsrsync));
            tempstimoff=[tempstimoff nextv];
        end
    end
end
handles.stimon=tempstimon;
handles.stimoff=tempstimoff;

%     end
%handles.subs=[handles.subs subsam(s,EDF.SampleRate,handles.sr(handles.selchan)/20)'];

%getting the position of the onset and offset of the sync signal
%(or stimuluas)
%     handles.indon=find(s(1:end-1)<0.5 & auxs>0.5);
%     handles.indoff=find(s(1:end-1)>0.5 & auxs<0.5);

%end
%now the remaining time
% EDF=sdfclose(EDF);
% EDF=sdfopen(filename);
% [s,edfs]=sdfread(EDF,dur-((nchunk+1)*ltrace),(nchunk+1)*ltrace);
% %handles.subs=[handles.subs subsam(s,EDF.SampleRate,handles.sr(handles.selchan)/20)'];
% auxs=s(2:end);
% %getting the position of the onset and offset of the sync signal
% %(or stimulus)
% auxindon=find(s(1:end-1)<1.5 & auxs>1.5);
% auxindoff=find(s(1:end-1)>1.5 & auxs<1.5);
%     k=1;
%     for i=1:length(auxindon)
%         if i==1
%             indon(k)=auxindon(i);
%         else
%             if auxindon(i)-indon(k)>mindist*EDF.SampleRate
%                 k=k+1;
%                 indon(k)=auxindon(i);
%             end
%         end
%     end
%     k=1;
%     for i=length(auxindoff):-1:1
%         if i==length(auxindoff)
%             indoff(k)=auxindoff(i);
%         else
%             if indoff(k)-auxindoff(i)>mindist*EDF.SampleRate
%                 k=k+1;
%                 indoff(k)=auxindoff(i);
%             end
%         end
%     end
%     indoff=fliplr(indoff)
% %Converting into time (in hours)
%     if length(indon)>0
%         for k=1:length(indon)
%             nextv=(nchunk*ltrace/3600)+(indon(k)/(3600*EDF.SampleRate));
%             handles.stimon=[handles.stimon nextv];
%         end
%     end
%     if length(indoff)>0
%         for k=1:length(indoff)
%             nextv=(nchunk*ltrace/3600)+(indoff(k)/(3600*EDF.SampleRate));
%             handles.stimoff=[handles.stimoff nextv];
%         end
%     end
guidata(hObject, handles);
disp('Ready!')
% ximaging=(0:length(handles.subs)-1)*(dur/length(handles.subs));
% imaging=handles.subs;
%ximaging=(0:length(s)-1)*(dur/length(s));
%imaging=s;

score=handles.score;
xscore=(0:length(score)-1)*handles.el;

ston=handles.stimon*3600;
stoff=handles.stimoff*3600;
% figure
% plot(ximaging,imaging,'r-')
% axis tight
% hold on
% plot(xscore,2*round(score),'k-','linewidth',2)
% set(gca,'yticklabel',{'WA','','','','NR','','','','REM'})
% xlabel('s','fontsize',18)
% set(gca,'fontsize',14)
startimg=handles.stimon;
stopimg=handles.stimoff;
save('imagingtime.mat','score','xscore','startimg','stopimg')%fle for sharing the data
handles.origimgon=handles.stimon;
handles.origimgoff=handles.stimoff;
guidata(hObject, handles);
plot_traces(handles)

% --- Executes on button press in gcamp.
    function gcamp_Callback(hObject, eventdata, handles)
        % hObject    handle to gcamp (see GCBO)
        % eventdata  reserved - to be defined in a future version of MATLAB
        % handles    structure with handles and user data (see GUIDATA)
        %Load traces from calcium imaging and display the analysis
        %we will calculate the area above the 3 std line, the number of times it
        %goes above the line, the average length of each event, the max peak value and the number of
        %correlated pairs
        [filename, pathname] = uigetfile('*.txt','Pick the trace file with the calcium imaging');
        cd (pathname)
        matinfile=load(filename);
        handles.traces=matinfile(:,2:end);
        handles.stimon=handles.origimgon;
        handles.stimoff=handles.origimgoff;
        guidata(hObject, handles);
        load timestamp.txt
        htstamp=floor(timestamp(:,1)./10000);
        remstamp=rem(timestamp(:,1),10000);
        minstamp=floor(remstamp./100);
        segstamp=rem(remstamp,100);
        newstamp=(htstamp*3600+(minstamp*60)+segstamp);
        nston=length(handles.stimon);
        nstoff=length(handles.stimon);
        if strcmp ('tracesg6f8recovery.txt',filename)
            handles.stimon=handles.stimon(nston-133:nston);
            handles.stimoff=handles.stimoff(nstoff-133:nston);
            %handles.traces=handles.traces((228*2)+1:end,:);%taking out the first two movies.
            minmaxeeg=[-0.6 0.6];
            minmaxemg=[-0.2 0.2];
            newstamp=(htstamp*3600+(minstamp*60)+segstamp-(8*3600)-(4*60)-11.76)';
            %newstamp=newstamp-0;
            startrs=1;
            endsd=1;
            %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
        end
        
        if strcmp ('tracesG6F10ZT0.txt',filename)
            handles.traces=handles.traces((228*2)+1:end,:);%taking out the first two movies.
            minmaxeeg=[-0.6 0.6];
            minmaxemg=[-0.2 0.2];
            handles.stimon=handles.stimon(2:end);
            handles.stimoff=handles.stimoff(2:end);
            newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600)-(58*60)-12)';
            %newstamp=newstamp-0;
            startrs=2;
            endsd=1;
            %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
        end
        if strcmp ('tracesg6f8sd.txt',filename)
            aux=[handles.traces(1:3342,:)' handles.traces(3647:6686,:)' handles.traces(6990:10028,:)' handles.traces(10333:end,:)']';
            handles.traces=aux;
            newstamp=(htstamp*3600+(minstamp*60)+segstamp-(8*3600)-(4*60)-11.655)';%could be also 11.865
            newstamp=[newstamp(1:11) newstamp(13:22) newstamp(24:33) newstamp(35:95)];
            minmaxeeg=[-0.6 0.6];
            minmaxemg=[-0.2 0.2];
            handles.stimon=[handles.stimon(40:83) handles.stimon(128) handles.stimon(143:170) handles.stimon(215:233)];
            handles.stimoff=[handles.stimoff(40:83) handles.stimoff(128) handles.stimoff(143:170) handles.stimoff(215:233)];
            %newstamp=newstamp-0;s
            endsd=92;
            %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
        end
        
        
        if strcmp ('traces_5_27_13.txt',filename)
            handles.traces=handles.traces(1+476+141:end,:);%taking out the first two movies.
            minmaxeeg=[-0.6 0.6];
            minmaxemg=[-0.2 0.2];
            handles.stimon=handles.stimon(4:end);
            handles.stimoff=handles.stimoff(4:end);
            newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600+(11*60)+30))';
            newstamp=newstamp-17;
            startrs=31;
            endsd=31;
            %newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
        end
        
        if strcmp ('traces_5_28_13.txt',filename)
            handles.traces=[handles.traces(1:3601,:)' handles.traces(3843:11042,:)' handles.traces(11170:end,:)']';%taking out the shorter movies to avoid sync issues. remove also 3.412 and 5.834
            handles.stimon=[handles.stimon(1:8) handles.stimon(10:25) handles.stimon(27:end)];
            handles.stimoff=[handles.stimoff(1:8) handles.stimoff(10:25) handles.stimoff(27:end)];
            handles.stimon=[handles.stimon(1:24) handles.stimon(34:end)];
            handles.stimoff=[handles.stimoff(1:24) handles.stimoff(34:end)];
            newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600+(8*60)+30))';
            newstamp=newstamp-17.712;
            newstamp=newstamp-(newstamp(3)-(handles.stimon(3)*3600));
            startrs=1%length(handles.stimon)-24;
            endsd=length(handles.stimon)-24;
            minmaxeeg=1E-4*[-6 6];
            minmaxemg=[-2*1E-4 2*1E-3];
            
        end
        
        
        if strcmp ('traces_5_21_13.txt',filename)
            newstamp=(htstamp*3600+(minstamp*60)+segstamp-(9*3600+10))';
            handles.stimon=handles.stimon(5:end);
            handles.stimoff=handles.stimoff(5:end);
            %     handles.stimon=[handles.stimon(1:19) handles.stimon(21:33) handles.stimon(35:end)];
            %     handles.stimoff=[handles.stimoff(1:19) handles.stimoff(21:33) handles.stimoff(35:end)];
            minmaxeeg=1E-4*[-6 6];
            minmaxemg=[-2*1E-4 2*1E-3];
            
            newstamp=newstamp-(newstamp(2)-handles.stimon(2)*3600)+10;
            %     handles.stimon=[handles.stimon(1:34) handles.stimon(36:end)];
            %     handles.stimoff=[handles.stimoff(1:34) handles.stimoff(36:end)];    .
            startrs=1;%length(handles.stimon)-23;
            endsd=length(handles.stimon)-23;
        end
        figure
        plot([(newstamp/3600)' (newstamp/3600)'],[0 2]','c--')
        hold on
        plot([(handles.stimon)' (handles.stimon)'],[0 2]','m--')
        plot([(handles.stimoff)' (handles.stimoff)'],[0 2]','k--')
        srcalcium=median(timestamp(:,2))/(median(handles.stimoff-handles.stimon)*3600);
        totpoints=size(handles.traces,1);
        totimagtime=sum(handles.stimoff-handles.stimon)*3600;%in s
        ltrace=floor((handles.stimoff-handles.stimon)*3600*srcalcium);%vector with the length of each video in points of calcium imaging data (i.e. frames).
        if sum(ltrace)<totpoints
            ltrace(end)=ltrace(end)+totpoints-sum(ltrace);%correction for rounding error
        end
        handles.ncells=size(handles.traces,2);
        %     if i<9
        %         [r,p]=corrcoef(newmat');
        %         nsigcorr(i)=length(find(p<1E-8))/2;%number of cells significantly correlated
        %     end
        %     ltrace(i)=length(newmat);
        %     handles.traces=[handles.traces newmat];
        %     %concatenating each trace
        % end
        
        %binmat=zeros(size(handles.traces(:,2:end)));
        %Getting the threshold values using all traces for each cell
        %figure
%for k=1:handles.ncells
%     threscell(k)=mean(handles.traces(:,k))+3*std((handles.traces(:,k)));SInce
%     all traces have std = 1, the threshold can be the same for everybody.
%     Let's fix it as 90% of the peak for the trace with lowest maximum
threscell=ones(1,handles.ncells)*min(3,0.9*min(max(handles.traces)));
%     plot(handles.traces(:,k+1))
%     hold on
%     plot(threscell(k)*ones(size(handles.traces(:,k+1))),'k--')
%     pause
%     cla
%end

% for i=1:length(handles.stimon)
%    if i==1
%        newmat=handles.traces(1:ltrace(1),:);
%    else
%        indx=sum(ltrace(1:i-1));%starting pos of the matrix
%        newmat=handles.traces(indx:indx+ltrace(i)-1,:);
%         for j=1:handles.ncells
%             [nevents(i,j),peakevent(i,j),meanevent(i,j),areaevents(i,j),maxarea(i,j),maxdurevent(i,j),meandurevent(i,j)]=getnevents(newmat(:,j)',threscell(j),srcalcium);
%         end
%    end
% end

%Making continuous heatmap
cheeg=1;
chemg=2;
cd (handles.pathEDF)
allmovspow=[];
allraster=[];
xhypno=[];
allepochs=[];
%[handles.EDF]=sdfclose(handles.EDF);
k=0
for chunk=startrs:length(handles.stimon)%Chunk of EEG to do the heatmap
    durimag=3600*(handles.stimoff(chunk)-handles.stimon(chunk));%seconds of EEG + imaging
    %figure
    nEDF=sdfopen(handles.fn);
    [eegtrace,edfs]=sdfread(nEDF,durimag,3600*handles.stimon(chunk));
    [nEDF]=sdfclose(nEDF);
    sr=max(nEDF.SampleRate);
    for nepoch=1:floor(durimag/handles.el)
        p(:,nepoch)=getthepower(eegtrace(1+(floor(sr*handles.epocht(nepoch)):ceil(sr*handles.epocht(nepoch+1))),cheeg),handles.el,16,0);
    end
    allmovspow=[allmovspow p];
    k=k+1;
    xeeg=(0:length(eegtrace)-1)/sr;
    subplot(15,1,[1 2])
    plot(xeeg,eegtrace(:,cheeg),'k-');
    axis tight
    set(gca,'ylim',minmaxeeg)
    title(num2str(handles.stimon(chunk)),'fontsize',21)
    subplot(15,1,[3 4])
    plot(xeeg,eegtrace(:,chemg),'k-');
    axis tight
    set(gca,'ylim',minmaxemg)
    %     subplot(9,1,[5 6])
    %     p=p-min(min(p));%Normalizing the power within [0 1]
    %     p=p/max(max(p));
    %     image(p*75)
    %     axis xy
    %     colormap('jet')
    %     xlabl=str2num(get(gca,'Xticklabel'));
    %     set(gca,'Xticklabel',num2str(xlabl*4))
    %     set(gca,'YTick',([0 4 8 12 16]+0.1231)./0.2462)
    %     ylabl=str2num(get(gca,'Yticklabel'))
    %     set(gca,'Yticklabel',num2str(round(0.2462*ylabl-0.1231)));%takeng from eq. of the line that passes thru 0.5,0 and 65.5,16
    %     xlabel('S')
    %     ylabel('Hz')
    %     %now the raster
    currep=round(3600*handles.stimon(chunk)/handles.el);
    if k==1
        xhypno=handles.epocht(currep:currep+round(durimag/handles.el))-handles.epocht(currep);
        imgstart(k)=0;
        
    else
        newelem=xhypno(end)+handles.el+handles.epocht(currep:currep+round(durimag/handles.el))-handles.epocht(currep);
        xhypno=[xhypno newelem];
        imgstart(k)=newelem(1);
        
    end
    allepochs=[allepochs currep:currep+round(durimag/handles.el)];
    %     subplot(9,1,[7 8])
    subplot(15,1,[5 6])
    
    %     plot(x,raster,'k.')
    %     subplot(9,1,9)
    tp=round(handles.score(currep:currep+round(durimag/handles.el)));
    xtp=(0:length(tp)-1)*180/(length(tp)-1);
    plot(xtp,round(handles.score(currep:currep+round(durimag/handles.el))),'k-','linewidth',1);
    set(gca,'ylim',[0 2.1])
    set(gca,'YTick',[0 1 2])
    set(gca,'Yticklabel',{'W','NREM','REM'})
    axis tight
    %Now the traces:
    %subplot(15,1,[7 15])
    if chunk>1
        newmat=handles.traces(sum(ltrace(1:chunk-1)):sum(ltrace(1:chunk)),1:20);
    else
        newmat=handles.traces(1:sum(ltrace(1)),1:20);
    end
    %[vwv,posim]=sort(std(newmat),'descend');
    %newmat2=newmat(:,posim(1:20));
    for i=1:20
        newmat(:,i)=newmat(:,i)+(i-1)*8;
    end
    xnewmat=(0:length(newmat)-1)/srcalcium;
    %plot(xnewmat,newmat)
    %for kk=1:20
    %    text(xnewmat(1),(kk-1)*8,num2str(kk))
    %end
    %set(gca,'ylim',[-1 160])
    %axis tight
    
    aa=0;
end
%plotting the heatmap, raster and hipnogram for the whole thing
%allraster=binmatfpl(handles.traces(sum(ltrace(1:endsd-1)):end,:),median(threscell));
%allraster=binmatfpl(handles.traces(sum(ltrace(1:startrs)):end,:),median(threscell));
allraster=binmatfpl(handles.traces,0.9);

disp('Making traces for NREM, REM and WA point by point')
matWA=[];
matWAsd=[];
matWArs=[];
matREM=[];
matNREM=[];
matWAsd=[];%Matrixes of n points in the state x ncells in chronological order
syncp=zeros(1,totpoints);%This vector has the corresponding time in sec for every point in the imaging
pos=1;

for i1=1:length(ltrace)
    %durtr=ltrace(i1)/srcalcium;%Duration in seconds of the current video
    durtr=(handles.stimoff(i1)-handles.stimon(i1))*3600;
    syncp(pos:pos+ltrace(i1)-1)=handles.stimon(i1)*3600+((0:ltrace(i1)-1)/(ltrace(i1)-1))*durtr;%Vector with the time in seconds where there was imaging
    pos=pos+ltrace(i1);
end

%matWASD
for i=1:sum(ltrace(1:endsd))
    if state(syncp(i),handles)==0
        matWAsd=[matWAsd; handles.traces(i,:)];
    end
end
%matWArs
%for i=sum(ltrace(1:endsd)):totpoints
for i=1:totpoints
    if state(syncp(i),handles)==0
        matWArs=[matWArs; handles.traces(i,:)];
    end
end

for i=1:totpoints%sum(ltrace(1:32))+1:totpoints
    if state(syncp(i),handles)==0
        matWA=[matWA; handles.traces(i,:)];
    end
    if state(syncp(i),handles)==1
        matNREM=[matNREM; handles.traces(i,:)];
    end
    if state(syncp(i),handles)==2
        matREM=[matREM; handles.traces(i,:)];
    end
end
%making rasters for REM and NREM
allrasterREM=binmatfpl(matREM,0.9);
allrasterNREM=binmatfpl(matNREM,0.9);
allrasterWAsd=binmatfpl(matWAsd,0.9);
allrasterWArs=binmatfpl(matWArs,0.9);
figure;
subplot(5,1,1:4)
plot(allrasterNREM,'k.')
title('NREM')
subplot(5,1,5)
%Now converting to binary matrices
minREM=zeros(size(allrasterREM));
minREM(find(allrasterREM>0))=1;
minNREM=zeros(size(allrasterNREM));
minNREM(find(allrasterNREM>0))=1;
minWAsd=zeros(size(allrasterWAsd));
minWAsd(find(allrasterWAsd>0))=1;
minWArs=zeros(size(allrasterWArs));
minWArs(find(allrasterWArs>0))=1;

%Now making a vector of events/s
vsum=sum(minNREM,2)/size(minNREM,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newNREM=mean(newsum*srcalcium,1);
hpNREM=mean(newNREM(1:3));
lpNREM=mean(newNREM(end-2:end));
plot(newNREM,'k')
vsum=sum(minREM,2)/size(minREM,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newREM=mean(newsum*srcalcium,1);
if length(newREM)>1
    hpREM=mean(newREM(1:3));
    lpREM=mean(newREM(end-2:end));
else
    hpREM=0;
    lpREM=0;
end

vsum=sum(minWAsd,2)/size(minWAsd,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
if endsd>1
newWAsd=mean(newsum*srcalcium,1);
lpWAsd=mean(newWAsd(1:3));
hpWAsd=mean(newWAsd(end-2:end))
else
    newWAsd=0;
    lpWAsd=0;
    hpWAsd=0;
end
vsum=sum(minWArs,2)/size(minWArs,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newWArs=mean(newsum*srcalcium,1);
hpWArs=mean(newWArs(1:3));
lpWArs=mean(newWArs(end-2:end))

figure
%bar([[hpREM lpREM]' [hpNREM lpNREM]' [hpWArs lpWArs]' [hpWAsd lpWAsd]' ])
bar([[hpREM hpNREM hpWArs hpWAsd]' [lpREM lpNREM lpWArs lpWAsd]'])
set(gca,'XTick',[1 2 3 4])
set(gca,'XTicklabel',{'REM','NREM','WA-Rec','WA-SD'})
legend('HP','LP')
colormap bone
set(gca,'fontsize',14)
box off
xlabel('State','fontsize',21)
ylabel('Mean Events/s','fontsize',21)
ind1=find(matREM>0.9)
for ncell=1:handles.ncells
    if length(matREM)>1
        remevents(ncell)=length(find(matREM(:,ncell)>0.9));
        remrat(ncell)=(remevents(ncell)/(size(matREM,1))*srcalcium);
    else
        remevents(ncell)=0;
        remrat(ncell)=0;
    end
     nremevents(ncell)=length(find(matNREM(:,ncell)>0.9));
    wavents(ncell)=length(find(matWA(:,ncell)>0.9));
   
    nremrat(ncell)=(nremevents(ncell)/(size(matNREM,1))*srcalcium);
    warat(ncell)=(wavents(ncell)/(size(matWA,1))*srcalcium);
end

%ploting raster WA SD
figure
subplot(5,1,1:4)
xras=(0:length(allrasterWAsd)-1)/(srcalcium*60);
plot(xras,allrasterWAsd,'k.','markersize',6)
axis tight
set(gca,'fontsize',14)
box off
ylabel('Cell #','fontsize',21)
set(gca,'XTicklabel','')
subplot(5,1,5)
plot(newWAsd,'k','linewidth',1.5)
xlabel('Time(min)','fontsize',21)
axis tight
minmax=get(gca,'ylim')
set(gca,'ylim',[0 max(minmax)])
set(gca,'fontsize',14)
box off

%ploting it as a scatter plot
figure
plot(newWAsd,'ko')
xlabel('Time(min)','fontsize',21)
axis tight
ylabel('Mean Events/s','fontsize',21)
set(gca,'fontsize',14)
box off
figure
title(num2str(handles.stimon(endsd)))
nplots=length(find(max([warat' nremrat' remrat']')>0));
q1=1;
k=1;
% while q1<nplots
%     if max([warat(k) nremrat(k) remrat(k)])>0
%         subplot(9,ceil(nplots/9),q1)
%         bar([warat(k) nremrat(k) remrat(k)])
%         set(gca,'XTick',[1 2 3])
%         set(gca,'Xticklabel',{'W','N','R'})
%         q1=q1+1;
%     end
%     k=k+1;
% end

% figure
% bar([remrat' nremrat' warat'])
remcells=find(remrat>(max(nremrat,warat))*2);
figure
tobar=[mean(warat) mean(nremrat) mean(remrat)];
toerr=[sem(warat) sem(nremrat) sem(remrat)];
errorbar(tobar,toerr,'k.')
hold on
bar(tobar)
set(gca,'XTick',[1 2 3])
set(gca,'Xticklabel',{'WA','NREM','REM'})
set(gca,'fontsize',14)
ylabel('Events/sec','fontsize',21)
figure
subplot(4,1,1)
xhyp=xhypno/60;
plot(xhyp,round(handles.score(allepochs)),'k-','linewidth',1)
set(gca,'ylim',[0 2.1])
set(gca,'YTick',[0 1 2])
set(gca,'Yticklabel',{'W','NREM','REM'})
set(gca,'fontsize',14)
eps=round(3600*handles.stimon(31:end)/handles.el);
set(gca,'xticklabel','')
%xlabel('Time (min)','fontsize',24)
keysc=round(handles.score(allepochs));
% epochs=[];
% for i=1:length(handles.stimon)
%     [v,st]=min(abs(3600*handles.stimon(i)-handles.epocht));
%     [v,en]=min(abs(3600*handles.stimoff(i)-handles.epocht));
%     epochs=[epochs st:en];
% end
%     plot((handles.epocht(epochs)-handles.epocht(epochs(1)))/60,round(handles.score(epochs)),'k-','linewidth',2)
%     set(gca,'ylim',[0 2.1])
%     set(gca,'YTick',[0 1 2])
%     set(gca,'Yticklabel',{'WA','NREM','REM'})
%     set(gca,'fontsize',14)
%     xlabel('m','fontsize',24)
hold on
plot([imgstart'/60 imgstart'/60],[0 2.1],'g:','linewidth',1)
axis tight
plot(xhyp,round(handles.score(allepochs)),'k-','linewidth',1)
data.hypno=round(handles.score(allepochs));
data.hypnox=xhyp;
data.hypnoingstart=imgstart'/60;
box off
% subplot(6,1,1:2)
% allmovspow=allmovspow-min(min(p));%Normalizing the power within [0 1]
% aux=sort(allmovspow(:));
% maxi=aux(round(0.995*length(aux)));%normalizing by the 85% largest value
% allmovspow=allmovspow/maxi;
% image(allmovspow*60)
% axis xy
% colormap('jet')
% xlabl=str2num(get(gca,'Xticklabel'));
% set(gca,'Xticklabel',num2str(xlabl*4))
% set(gca,'YTick',([0 4 8 12 16]+0.1231)./0.2462)
% ylabl=str2num(get(gca,'Yticklabel'))
% set(gca,'Yticklabel',num2str(round(0.2462*ylabl-0.1231)));%taken from eq. of the line that passes thru 0.5,0 and 65.5,16
% box off
% set(gca,'Xticklabel','')
% %xlabel('S')
% ylabel('Hz','fontsize',21)
% set(gca,'Xticklabel','')

subplot(4,1,[2:3])
x=(0:length(allraster)-1)/(60*srcalcium);
plot(x,allraster,'k.','markersize',6)
axis tight
set(gca,'Xticklabel','')
set(gca,'fontsize',14)
ylabel('Cell #','fontsize',18)
box off
axis tight
set(gca,'Xticklabel','')
hold on
%plot(x,allraster(:,remcells),'r.','markersize',5)
data.rasterd=allraster;
data.rasterx=x;

% %finding rem only cells
% remcells=[];
% for ncell=1:handles.ncells
%     posev=find(allraster(:,ncell)>0)/srcalcium;%in secs
%     posev=round(posev/4);%in epochs
%     ratio(ncell)=length(find(keysc(posev)==2))/length(posev);%fraction of events during REM
% end
% figure
% bar (ratio)



subplot(4,1,4)
newmp=zeros(size(allraster));
ind1=find(~isnan(allraster));
newmp(ind1)=1;
vsum=sum(newmp,2)*srcalcium/handles.ncells;
xv=(0:length(vsum)-1)/(60*srcalcium);


newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
%plot(mean(newsum,1),'k-')
plot(xv,vsum,'k-')
xlabel('Time (min)','fontsize',24)
set(gca,'fontsize',14)
ylabel('Events/s','fontsize',21)
box off
axis tight

%newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
%plot(mean(newsum,1),'k.-','linewidth',2)
% plot(xv,vsum,'k')
% xlabel('Time (min)','fontsize',24)
% set(gca,'fontsize',14)
% ylabel('Events/min','fontsize',21)
% box off
% axis tight

mwasd=binmatfpl(matWAsd,3.5);
x=(0:length(mwasd)-1)/srcalcium;

figure;
subplot(5,1,1:4)
plot(x,mwasd,'k.')
set(gca,'fontsize',14)
%xlabel('s','fontsize',18)
ylabel('Cell #','fontsize',21)
%xlabel('s','fontsize',18)
box off
axis tight
set(gca,'Xticklabel','')
%Plotting raster for WA SD
newmp=zeros(size(mwasd));
ind1=find(mwasd>0);
newmp(ind1)=1;
subplot(5,1,5)
vsum=sum(newmp,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
plot(mean(newsum,1),'k-')
xlabel('Time (min)','fontsize',24)
set(gca,'fontsize',14)
ylabel('Events/min','fontsize',21)
box off
axis tight

% %NOw WA during RS
% mwasd=binmatfpl(matWA,3);
% x=(0:length(mwasd)-1)/srcalcium;
% figure;
% subplot(5,1,1:4)
% plot(x,mwasd,'k.')
% set(gca,'fontsize',14)
% %xlabel('s','fontsize',18)
% ylabel('Cell #','fontsize',18)
% %xlabel('s','fontsize',18)
% box off
% axis tight
%
% newmp=zeros(size(mwasd));
% ind1=find(mwasd>0);
% newmp(ind1)=1;
% subplot(5,1,5)
% vsum=sum(newmp,2);
% newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
% plot(mean(newsum,1),'k-')
% xlabel('m','fontsize',21)
% set(gca,'fontsize',14)
% ylabel('Mean No Spikes WA RS','fontsize',21)
% box off
% axis tight
%
% figure
% hist(vsum,max(vsum))
% ylabel('Frequency','fontsize',21)
% xlabel('# Simultaneous events (WA RS)','fontsize',21)



%Plotting NREM
% mwasd=binmatfpl(matNREM,3);
% x=(0:length(mwasd)-1)/srcalcium;
% figure;
% subplot(5,1,1:4)
% plot(x,mwasd,'k.')
% set(gca,'fontsize',14)
% %xlabel('s','fontsize',18)
% ylabel('Cell #','fontsize',18)
% %xlabel('s','fontsize',18)
% box off
% axis tight
%
% newmp=zeros(size(mwasd));
% ind1=find(mwasd>0);
% newmp(ind1)=1;
% subplot(5,1,5)
% vsum=sum(newmp,2);
% newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
% plot(mean(newsum,1),'k-')
% xlabel('m','fontsize',21)
% set(gca,'fontsize',14)
% ylabel('Mean No Spikes NREM','fontsize',21)
% box off
% axis tight
%
% figure
% hist(vsum,max(vsum));
% ylabel('Frequency','fontsize',21)
% xlabel('# Simultaneous events (NREM)','fontsize',21)
%


%Finally REM
% mwasd=binmatfpl(matREM,3);
% x=(0:length(mwasd)-1)/srcalcium;
% figure;
% subplot(5,1,1:4)
% plot(x,mwasd,'k.')
% set(gca,'fontsize',14)
% %xlabel('s','fontsize',18)
% ylabel('Cell #','fontsize',18)
% %xlabel('s','fontsize',18)
% box off
% axis tight
%
% newmp=zeros(size(mwasd));
% ind1=find(mwasd>0);
% newmp(ind1)=1;
% subplot(5,1,5)
% vsum=sum(newmp,2);
% newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
% plot(mean(newsum,1),'k-')
% xlabel('m','fontsize',21)
% set(gca,'fontsize',14)
% ylabel('Mean No Spikes REM','fontsize',21)
% box off
% axis tight
%
% figure
% hist(vsum,max(vsum));
% ylabel('Frequency','fontsize',21)
% xlabel('# Simultaneous events (REM)','fontsize',21)





% [r,p]=corrcoef(matWA);
% sigcorrWA=length(find(p<1E-8))/2;
% [r,p]=corrcoef(matNREM);
% sigcorrNREM=length(find(p<1E-8))/2;
% [r,p]=corrcoef(matREM);
% sigcorrREM=length(find(p<1E-8))/2;
%
%  for j=1:handles.ncells
%             [neventsWA(j),peakeventWA(j),meaneventWA(j),areaeventsWA(j),maxareaWA(j),maxdureventWA(j),meandureventWA(j)]=getnevents(matWA(j,:),threscell(j),srcalcium);
%             [neventsNREM(j),peakeventNREM(j),meaneventNREM(j),areaeventsNREM(j),maxareaNREM(j),maxdureventNREM(j),meandureventNREM(j)]=getnevents(matNREM(j,:),threscell(j),srcalcium);
%             [neventsREM(j),peakeventREM(j),meaneventREM(j),areaeventsREM(j),maxareaREM(j),maxdureventREM(j),meandureventREM(j)]=getnevents(matREM(j,:),threscell(j),srcalcium);
%  end
% nsimWA=getsimev(matWA',threscell,1,srcalcium);%calculating the number of simultaneous events in a matrix with traces (1 s window)
% nsimNREM=getsimev(matNREM',threscell,1,srcalcium);
% nsimREM=getsimev(matREM',threscell,1,srcalcium);
% figure
% errorv=[sem(nsimWA) sem(nsimNREM) sem(nsimREM)];
% datav=[mean(nsimWA) mean(nsimNREM) mean(nsimREM)];
% errorbar(datav,errorv,'k.');
% hold on
% bar(datav)
% set(gca,'XTick',[1 ;2; 3])
% set(gca,'XTickLabel',{'WA','NREM','REM'})
% set(gca,'fontsize',14)
% box off
% ylabel('Sim. events/N events','fontsize',21)
%
% figure
% % subplot(2,1,1)
% % bar(nsigcorr)
% % subplot(2,1,1)
% bar([sigcorrWA sigcorrNREM sigcorrREM]);
% figure
% title('Event frequency')
% for ploti=1:handles.ncells
%     subplot(round(sqrt(handles.ncells)),ceil(sqrt(handles.ncells)),ploti)
%     bar([neventsWA(ploti) neventsNREM(ploti) neventsREM(ploti)]);
%    % set(gca,'fontsize',14)
%     set(gca,'XTickLabel',{'WA','NREM','REM'})
% end
% figure
% subplot(1,2,1)
% error=[sem(neventsWA) sem(neventsNREM) sem(neventsREM)];
% neventstp=[mean(neventsWA) mean(neventsNREM) mean(neventsREM)];
% errorbar(neventstp,error,'k.')
% hold on
% bar(neventstp)
%    % set(gca,'fontsize',14)
%    set(gca,'XTick',[1 ;2; 3])
% set(gca,'XTickLabel',{'WA','NREM','REM'})
% set(gca,'fontsize',14)
% box off
% ylabel('Mean Events/sec','fontsize',21)
%  m=[neventsWA' neventsNREM' neventsREM'];
%  [v,p]=max(m');
%  pwa=100*length(find(p==1))/64;
%  pnrem=100*length(find(p==2))/64;
%  prem=100*length(find(p==3))/64 ;
%  subplot(1,2,2)
%  bar([pwa pnrem prem]);
%    % set(gca,'fontsize',14)
%    set(gca,'XTick',[1 ;2; 3])
% set(gca,'XTickLabel',{'WA','NREM','REM'})
% set(gca,'fontsize',14)
% box off
% ylabel('% of population with max event rate','fontsize',21)
% set(gca,'ylim',[0 100])

% figure
% subplot(4,2,1)
% plot([peakeventWA; peakeventNREM; peakeventREM],'.-');
% hold on
% plot(mean([peakeventWA' peakeventNREM' peakeventREM']),'o-','linewidth',2)
% axis tight
% title('Peak Event','fontsize',16)
%
% subplot(4,2,2)
% plot(nevents,'.-');
% hold on
% plot(mean(nevents'),'o-','linewidth',2)
% axis tight
% title('N Events','fontsize',16)
%
%
% subplot(4,2,3)
% plot(meanevent,'.-');
% hold on
% plot(mean(meanevent'),'o-','linewidth',2)
% axis tight
% title('Mean events','fontsize',16)
%
% subplot(4,2,4)
% plot(areaevents,'.-');
% hold on
% plot(mean(areaevents'),'o-','linewidth',2)
% axis tight
% title('Area Events','fontsize',16)
%
% subplot(4,2,5)
% plot(maxarea,'.-');
% hold on
% plot(mean(maxarea'),'o-','linewidth',2)
% axis tight
% title('Max area','fontsize',16)
%
% subplot(4,2,6)
% plot(maxdurevent,'.-');
% hold on
% plot(mean(maxdurevent'),'o-','linewidth',2)
% axis tight
% title('Max Dur Event','fontsize',16)
%
% subplot(4,2,7)
% plot(meandurevent,'.-');
% hold on
% plot(mean(meandurevent'),'o-','linewidth',2)
% axis tight
% title('Mean Dur Event','fontsize',16)

% figure
%subplot(2,1,1)
%for ploti=1:8
%ploti=6;
%subplot(4,2,ploti)
% plot(nevents(:,(1+8*(ploti-1)):(1+8*(ploti-1))+7),'o-');
% hold on
% plot(mean(nevents(:,(1+8*(ploti-1)):(1+8*(ploti-1))+7),2),'kd-','linewidth',2)
% axis tight
% ylabel('N Events (4 cells)','fontsize',21)
% set(gca,'fontsize',14)
% xlabel('Period of SD','fontsize',21)

% box off
% %end
% subplot(2,1,2)
% plot(nevents(1,:),nevents(8,:),'ko')
% hold on
% plot([0 max(nevents(8,:))],[0 max(nevents(8,:))],'g--')
% set(gca,'fontsize',14)
% xlabel('N Events SD 1','fontsize',21)
% ylabel('N Events SD 8','fontsize',21)
% axis tight
% box off
%

%end
% axes(handles.axes2)
%plot(handles.traces')
% hold on
% v=ones(1,size(handles.traces,2));
% for i=1:size(handles.traces,1)
%     %cla
%     plot(handles.traces(i,:)')
%     top=std(handles.traces(i,:))*3*v;
%     plot(top,'k--')
%     %pause
% end
%Dividing the traces in 11 groups: SD 1-8, NREM, WA and REM
% handles.sttimes4tr=syncp([1 find(diff(syncp)>10)]);
% handles.edtimes4tr=syncp([find(diff(syncp)>10)]);
data.warate=warat;
data.nremrate=nremrat;
data.remrate=remrat;
data.hp=[hpREM hpNREM hpWArs hpWAsd]';
data.lp=[lpREM lpNREM lpWArs lpWAsd]';
fname2=strcat(filename(1:end-3),'dat.mat');
save(fname2,'data')
helpdlg('Data saved!')
guidata(hObject, handles);


function st=state(timeinp,handles)
%returns the state for a given time in s
ind=round(timeinp/handles.el);
st=round(handles.score(ind));



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
robot = java.awt.Robot;
  pos = get(handles.axes1, 'Position');
  set(0, 'PointerLocation', [pos(1:2)+100]);
  robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
  robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in incemg.
function incemg_Callback(hObject, eventdata, handles)
% hObject    handle to incemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.emgscale=handles.emgscale*2;
guidata(hObject, handles);


% --- Executes on button press in decemg.
function decemg_Callback(hObject, eventdata, handles)
% hObject    handle to decemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.emgscale=handles.emgscale/2;
guidata(hObject, handles);



function limemg2_Callback(hObject, eventdata, handles)
% hObject    handle to limemg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of limemg2 as text
%        str2double(get(hObject,'String')) returns contents of limemg2 as a double
num=str2double(get(hObject,'String'));
handles.limemg=num*std(handles.s(:,handles.chemg));
robot = java.awt.Robot;
  pos = get(handles.axes1, 'Position');
  set(0, 'PointerLocation', [pos(1:2)+100]);
  robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
  robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);
guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function limemg2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to limemg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in gcamp2.
function gcamp2_Callback(hObject, eventdata, handles)
% hObject    handle to gcamp2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load events from calcium imaging and display the analysis
%Perform the following analysys for each group, for each cell:
%1- mean event rate/epoch for each sleep state and correlation with the
%power of the different bands
%pairwise correlations??

%Selecting the start and end epochs of every period to be analyzed
if ~isfield(handles,'startpz')
    zt0=time2h(get(handles.edit4,'string'));%The time for lights on
    aux1=get(handles.toedit,'string');
    h0=time2h(aux1(1:8));%the time of the first recorded data point
    newt0=mod(h0-zt0,24);
    handles.nump=str2double(get(handles.nperiods,'string'));
    axes(handles.axes3)
    for i=1:handles.nump%Getting the start and end epochs for the periods of imaging to be analized
        set(handles.text8,'BackgroundColor',[0.5 0.7 0.7])
        set(handles.text8,'string',strcat('Start of period ',num2str(i)));
        [xpos,nrem]=ginput(1);
        xpos=xpos-newt0;
        [v,p]=min(abs(handles.epocht-xpos*3600));
        handles.startpz(i)=p;
        set(handles.text8,'BackgroundColor',[0.5 0.3 0.3])
        set(handles.text8,'string',strcat('End of period ',num2str(i)));
        [xpos,nrem]=ginput(1);
        xpos=xpos-newt0;
        [v,p]=min(abs(handles.epocht-xpos*3600));
        handles.endpz(i)=p;
    end
    disp(handles.startpz)%starting epoch
    disp(handles.endpz)%ending epoch
end
set(handles.text8,'BackgroundColor',[0 1 0])
set(handles.text8,'string','');
eval('cd textfiles') 
filename=dir('*.txt');

%Making a vector with the times in seconds of the starting of each video:
nmovs=length(filename);
disp('Reading time of videos...')
for k=1:nmovs
    auxs=filename(k).name;
    l=length(auxs);
    day=str2num(auxs(l-12:l-11));
    h0=num2str(handles.EDF.T0(4));
    m0=num2str(handles.EDF.T0(5));
    s0=num2str(handles.EDF.T0(6));
    if length(h0)<2
        h0=strcat('0',h0);
    end
    if length(m0)<2
        m0=strcat('0',m0);
    end
    if length(s0)<2
        s0=strcat('0',s0);
    end
    timev(k)=time2secs(strcat(h0,m0,s0),auxs(l-9:l-4));
    if day~=handles.EDF.T0(3)
        timev(k)=timev(k)+86400;
    end
    %Getting the duration of the video from the txt file
    fileid=fopen(auxs);
    ss=fscanf(fileid,'%s');
     tp=strfind(ss,'TIME');
     aproxd=str2num(ss(tp+4+(1:2)))*60+str2num(ss(tp+4+(4:5)));
     tp=strfind(ss,'FPS');
     fpsvid=str2num(ss(tp+3+(1:12)));
     if aproxd>61 
         nlim=4;
     else
         nlim=3;
     end
     tp=strfind(ss,'FRAMES');
     frmvid(k)=str2num(ss(tp+6+(1:nlim)));
     durvi(k)=frmvid(k)/fpsvid;
%      if k<nmovs
%          durvi(k)=durvi(k)+2;%adding 2s added artificially during concat
%      end

    fclose(fileid);
end
liminf=(min(handles.startpz)-1)*handles.el;%First second to consider
limsup=(max(handles.endpz)+1)*handles.el;%Last second to consider
ind1=find(handles.origimgon*3600>liminf & handles.origimgon*3600<limsup);
tempstimon=handles.origimgon(ind1)*3600;
tempstimoff=handles.origimgoff(ind1)*3600;
figure;plot(durvi,'.-')
%Automatic deletion of the tempstims that were not used in the video
%using the first to adjust the timings
[v,p]=min(abs(tempstimon-timev(1)));
timev=timev-(timev(1)-tempstimon(p));
timevoff=timev+durvi;
[v,p]=min(abs(tempstimoff-timevoff(1)));
timevoff=timevoff-(timevoff(1)-tempstimoff(p));
figure
subplot(2,1,1)
xvec=1:round((tempstimon(end))+200);
tracedet=zeros(size(xvec));
tracevid=tracedet;
handles.stimon=[];
handles.stimoff=[];
%deleting stimtimes
for i=1:length(tempstimon)
    if min(abs(tempstimon(i)-timev))<2
        handles.stimon=[handles.stimon tempstimon(i)];
        handles.stimoff=[handles.stimoff tempstimoff(i)];
    end
end
%fixing stimoff times
ind=find(abs(timevoff-handles.stimoff)>3)
handles.stimoff(ind)=timevoff(ind);
%plotting

for i=1:length(handles.stimoff)
    tracedet(round(handles.stimon(i)):round(handles.stimoff(i)))=1;
end
for i=1:length(timev)
    tracevid(round(timev(i)):round(timevoff(i)))=1;
end
plot(xvec,tracedet,'k-','linewidth',2);
hold on
plot(xvec,tracevid,'r-');
box off
subplot(2,1,2)
for i=1:length(handles.stimon)
    v(i)=sum(tracevid(round(handles.stimon(i)):round(handles.stimoff(i))));
end
subplot(2,1,2)
plot(v,'.')

% %Making matrix with time of events
eval('cd ..')
eval('cd events') 
filename=dir('*.mat');
ncells=length(filename);
firstevent=load(filename(1).name);
tvect=firstevent.Object.XVector;
binevents=zeros(ncells,length(tvect));
matevents=binevents;
disp('Reading Events');
for k=1:ncells
    filread=load(filename(k).name);
    p1=strfind(filename(k).name,'_');
    p1=p1(1)+1;
    p2=strfind(filename(k).name,' - ');
    p2=p2(1)-1;
    numfilt=str2double(filename(k).name(p1:p2));
    filread=load(filename(k).name);
    events=filread.Object.DataStorage;
    indx=find(events>0.1);
    matevents(numfilt,:)=events;
    binevents(numfilt,indx)=1;
end
figure;plot(matevents)
newmatevnts=[];
totimagtime=sum(handles.stimoff-handles.stimon);%total video time in s
if abs((totimagtime/length(handles.stimon))-(mean(durvi)))>1%difference in average duration of videos vs detected must be less than 1 s
    helpdlg('Error. Event time different than sync time')
    return
end
srcalcium=length(tvect)/totimagtime;
disp(strcat('sr video=',num2str(srcalcium)))
handles.stimon=handles.stimon/3600;
handles.stimoff=handles.stimoff/3600;
handles.events=binevents';
handles.ncells=size(handles.events,2);
totpoints=size(handles.events,1);
ltrace=floor((handles.stimoff-handles.stimon)*3600*srcalcium);%vector with the length of each video in points of calcium imaging data (i.e. frames).
if sum(ltrace)<totpoints
    ltrace(end)=ltrace(end)+totpoints-sum(ltrace);%correction for rounding error
end

%loading cell images
th=5;%Threshold to isolate the cells form the noise
eval('cd ..') 
eval('cd filters') 
filename=dir('*.mat');
ncells=length(filename);
firstfilt=load(filename(1).name);
matfilt=firstfilt.Object.DataStorage;
matfilt=thres(matfilt,th);
image(matfilt);
disp('Reading filters');
filtmat=zeros(size(matfilt,1),size(matfilt,2),ncells);
for k=1:ncells
    p=strfind(filename(k).name,'_');%looks for the identifier of the filter number in the filename
    numfilt=str2double(filename(k).name(p(1)+1:p(2)-1));
    filread=load(filename(k).name);
    filtmat(:,:,numfilt)=thres(filread.Object.DataStorage,th);
    filtmat(:,:,numfilt)=filtmat(:,:,numfilt)./max(max(filtmat(:,:,numfilt)));
end
disp('done!')

%reading traces
eval('cd ..')
eval('cd traces')  
filename=dir('*.mat');
ncells=length(filename);
firstr=load(filename(1).name);
mattr=firstr.Object.DataStorage;
disp('Reading traces');
trmat=zeros(length(mattr),ncells);
for k=1:ncells
    p=strfind(filename(k).name,'_');%looks for the identifier of the filter number in the filename
    numfilt=str2double(filename(k).name(p(1)+1:p(2)-1));
    filread=load(filename(k).name);
    trmat(:,numfilt)=filread.Object.DataStorage-basel(filread.Object.DataStorage);
    indaux=find(trmat(:,numfilt)<0);
    trmat(indaux,numfilt)=0;
    trmat(:,numfilt)=trmat(:,numfilt)/std(trmat(:,numfilt));
end
disp('done!')
eval('cd ..')

%Now making structure for each video. Each cell will have the traces,
%events,time vector, epochs and score
%first, checking if the number of frames matches:
thr=5;%Threshold for event detection = 5 stds
disp('Making struct with video data')
if sum(frmvid)==size(trmat,1)
    for currmov=1:nmovs
        viddata(currmov).frames=1:frmvid(currmov);
        viddata(currmov).time=3600*(handles.stimon(currmov):(handles.stimoff(currmov)-handles.stimon(currmov))/(frmvid(currmov)-1):handles.stimoff(currmov));%timepoints in sec
        viddata(currmov).epochs=ceil(viddata(currmov).time(1)/handles.el):floor((viddata(currmov).time(end)-handles.el)/handles.el);
        viddata(currmov).score=handles.score(viddata(currmov).epochs);
        st=round(handles.score(ind));
        if currmov>1
            viddata(currmov).traces=trmat(sum(frmvid(1:currmov-1))+1:sum(frmvid(1:currmov-1))+frmvid(currmov),:);
            %viddata(currmov).events=binevents(:,sum(frmvid(1:currmov-1))+1:sum(frmvid(1:currmov-1))+frmvid(currmov));
        else
            viddata(currmov).traces=trmat(1:frmvid(currmov),:);
            %viddata(currmov).events=binevents(:,1:frmvid(currmov));e
        end
        viddata(currmov).events=detect_events(viddata(currmov).traces,thr);
        %now reshaping and cutting the edges to get the mean event rate
        %/epoch
        neps=length(viddata(currmov).epochs);
        fp=viddata(currmov).time(1);
        [vs,ps]=min(abs(viddata(currmov).time-fp-10));
        frmov=(ps-1)/10;
        [vmin,pmin]=min(abs(handles.el*ceil(viddata(currmov).time(1)/handles.el)-viddata(currmov).time));%identifying the timepoint when the 1st epoch starts
        pmax=pmin+round(neps*floor(handles.el*frmov))-1;%the number of points must be multiple of neps
        %[vmax,pmax]=min(abs(handles.el*(floor(viddata(currmov).time(end)/handles.el))-viddata(currmov).time));%identifying the timepoint when the last epoch ends
        
        
        s=size(viddata(currmov).events(pmin:pmax,:));
        viddata(currmov).meanevrate=fixdim(sum(reshape(viddata(currmov).events(pmin:pmax,:),neps,floor(s(1)/neps),s(2)),2)/handles.el);%mean events/sec for each epoch
    end
else
    disp('sum(frmvid)~=size(trmat,1)')
    return
end
            
%Make matrix with average firing rate for every epoch for every cell
nframesep=floor(handles.el*srcalcium);%number of video frames in each epoch
for k=1:ncells
        auxv=reshape(handles.events(1:nframesep*floor(totimagtime/handles.el),k),nframesep,floor(totimagtime/handles.el));
        matfrate(k,:)=sum(auxv)/handles.el;
end

%making vector with the epoch number of each frame
vecnumepvid=[];
for j=1:length(handles.stimon)
    aux4=round((3600*handles.stimon(j):1/srcalcium:3600*handles.stimoff(j))/handles.el);
    vecnumepvid=[vecnumepvid aux4(1:end-1)];
end
figure;plot(trmat(:,1:100))
hold on
plot(100*vecnumepvid./max(vecnumepvid),'r-','linewidth',3)
vecnumepvid=vecnumepvid(1:min(size(trmat,1),length(vecnumepvid)));




%Now makin a matrix with event rate per epoch for each state, for each
%period
waz=zeros(1,handles.nump);%number of epochs of WA without artifacts in the event trace of each period
nremz=zeros(1,handles.nump);
remz=zeros(1,handles.nump);
nwa=length(find(handles.score==0));
nnrem=length(find(handles.score==1));
nrem=length(find(handles.score==2));
matfratewa=zeros(ncells,nwa,handles.nump);
matfratenrem=zeros(ncells,nnrem,handles.nump);
matfraterem=zeros(ncells,nrem,handles.nump);
totwa=0;
totnrem=0;
totrem=0;
for i=1:length(vecnumepvid)
    nperiod=length(find((handles.startpz-vecnumepvid(i))<0));%The period of the epoch
    if handles.score(vecnumepvid(i))==0%WA
        totwa=totwa+1;
        waz(nperiod)=waz(nperiod)+1;
        matfratewa(:,totwa,nperiod)=matfrate(:,i);
    end
    if handles.score(vecnumepvid(i))==1%NREM
        totnrem=totnrem+1;
        nremz(nperiod)=nremz(nperiod)+1;
        matfratenrem(:,totnrem,nperiod)=matfrate(:,i);
    end
    if handles.score(vecnumepvid(i))==2%REM
        totrem=totrem+1;
        remz(nperiod)=remz(nperiod)+1;
        matfraterem(:,totrem,nperiod)=matfrate(:,i);
    end        
end
topwa=zeros(1,handles.nump);
topnrem=zeros(1,handles.nump);
toprem=zeros(1,handles.nump);
for q=1:handles.nump
    topwa(q)=mean(mean(matfratewa(:,:,q)));
    toprem(q)=mean(mean(matfraterem(:,:,q)));
    topnrem(q)=mean(mean(matfratenrem(:,:,q)));
end
figure
subplot(3,1,1)
bar(topwa)
xlabel('Period')
ylabel('Mean firing rate')
title('WA')
subplot(3,1,2)
bar(topnrem)
xlabel('Period')
ylabel('Mean firing rate')
title('NREM')
subplot(3,1,3)
bar(toprem)
xlabel('Period')
ylabel('Mean firing rate')
title('REM')
guidata(hObject, handles);
%Making continuous heatmap
cheeg=1;
chemg=2;
cd (handles.pathEDF)
allmovspow=[];
allraster=[];
xhypno=[];
allepochs=[];
%[handles.EDF]=sdfclose(handles.EDF);
k=0

p=[];
for chunk=1:length(handles.stimon)%Chunk of EEG to do the heatmap. One for each video chunk
    durimag=3600*(handles.stimoff(chunk)-handles.stimon(chunk));%seconds of EEG + imaging
    nEDF=sdfopen(handles.fn);
    [eegtrace,edfs]=sdfread(nEDF,durimag,3600*handles.stimon(chunk));
    [nEDF]=sdfclose(nEDF);
    sr=max(nEDF.SampleRate);
    for nepoch=1:floor(durimag/handles.el)
        p(:,nepoch)=getthepower(eegtrace(1+floor(sr*handles.epocht(nepoch)):ceil(sr*handles.epocht(nepoch+1)),cheeg),handles.el,16,0);
    end
    allmovspow=[allmovspow p];
    
    currep=round(3600*handles.stimon(chunk)/handles.el);
    if max(handles.score(currep:currep+round(durimag/handles.el)))>1.5
        k=k+1;
        figure
        xeeg=(0:length(eegtrace)-1)/sr;
        subplot(15,1,[1 2])
        plot(xeeg,eegtrace(:,cheeg),'k-');
        axis tight
        %set(gca,'ylim',minmaxeeg)
        title(num2str(handles.stimon(chunk)),'fontsize',21)
        box off
        subplot(15,1,[3 4])
        plot(xeeg,eegtrace(:,chemg),'k-');
        axis tight
        
        if k==1
            xhypno=handles.epocht(currep:currep+round(durimag/handles.el))-handles.epocht(currep);
            imgstart(k)=0;
            
        else
            newelem=xhypno(end)+handles.el+handles.epocht(currep:currep+round(durimag/handles.el))-handles.epocht(currep);
            xhypno=[xhypno newelem];
            imgstart(k)=newelem(1);
            
        end
        allepochs=[allepochs currep:currep+round(durimag/handles.el)];
        %     subplot(9,1,[7 8])
        box off
        subplot(15,1,[5 6])
        
        %     plot(x,raster,'k.')
        %     subplot(9,1,9)
        tp=round(handles.score(currep:currep+round(durimag/handles.el)));
        dp=length(eegtrace)/sr;
        xtp=(0:length(tp)-1)*dp/(length(tp)-1);
        plot(xtp,round(handles.score(currep:currep+round(durimag/handles.el))),'k-','linewidth',1);
        axis tight
        set(gca,'ylim',[0 2.1])
        set(gca,'YTick',[0 1 2])
        set(gca,'Yticklabel',{'W','NREM','REM'})
        box off
        %Now the traces:
        subplot(15,1,[7 15])
        
        %Selecting the 20 most responsive:
        %Selecting hte chunk
        if chunk>1
            newmat=trmat(sum(ltrace(1:chunk-1)):sum(ltrace(1:chunk)),:);
            newmate=handles.events(sum(ltrace(1:chunk-1)):sum(ltrace(1:chunk)),:);
        else
            newmat=trmat(1:sum(ltrace(1)),1:20);
            newmate=handles.events(1:sum(ltrace(1)),1:20);
        end
        %deleting low values for ranking purposes
        valsmat=sum(newmate);
        [v,indtra]=sort(valsmat,'descend');
        
        
        %[vwv,posim]=sort(std(newmat),'descend');
        %newmat2=newmat(:,posim(1:20));
        newmat2=zeros(size(newmat,1),20);
        for i=1:20
            newmat2(1:size(newmat,1),i)=newmat(:,indtra(i))+(i-1)*100;
        end
        xnewmat=(0:length(newmat2)-1)/srcalcium;
        plot(xnewmat,newmat2,'k-','color',[0 0.5 0],'linewidth',2)
        %     for kk=1:20
        %        text(xnewmat(1),(kk-1)*8,num2str(kk))
        %     end
        %set(gca,'ylim',[-1 160])
        axis tight
        scalebar(5,100)
    end
    aa=0;
end
%plotting the heatmap, raster and hipnogram for the whole thing
%allraster=binmatfpl(handles.events(sum(ltrace(1:endsd-1)):end,:),median(threscell));
allraster=binmatfpl(handles.events,0.9);

disp('Making traces for NREM, REM and WA point by point')
matWA=zeros(ceil(totwa*handles.el*srcalcium),size(handles.events,2));
matREM=zeros(ceil(totwa*handles.el*srcalcium),size(handles.events,2));
matNREM=zeros(ceil(totwa*handles.el*srcalcium),size(handles.events,2));
%Matrixes of n points in the state x ncells in chronological order
syncp=zeros(1,totpoints);%This vector has the corresponding time in sec for every point in the imaging
pos=1;

for i1=1:length(ltrace)
    %durtr=ltrace(i1)/srcalcium;%Duration in seconds of the current video
    durtr=(handles.stimoff(i1)-handles.stimon(i1))*3600;
    syncp(pos:pos+ltrace(i1)-1)=handles.stimon(i1)*3600+((0:ltrace(i1)-1)/(ltrace(i1)-1))*durtr;%Vector with the time in seconds where there was imaging
    pos=pos+ltrace(i1);
end
poswa=0;
posrem=0;
posnrem=0;
%handles.events(sum(ltrace):end,:);

for i=1:totpoints%sum(ltrace(1:32))+1:totpoints
    if state(syncp(i),handles)==0
        poswa=poswa+1;
        matWA(poswa,:)=handles.events(i,:);
    end
    if state(syncp(i),handles)==1
        posnrem=posnrem+1;
        matNREM(posnrem,:)=handles.events(i,:);
    end
    if state(syncp(i),handles)==2
        posrem=posrem+1;
        matREM(posrem,:)=handles.events(i,:);
    end
end
%making rasters for REM and NREM
allrasterREM=binmatfpl(matREM,0.9);
allrasterNREM=binmatfpl(matNREM,0.9);
allrasterWA=binmatfpl(matWA,0.9);
figure;
subplot(5,1,1:4)
plot(allrasterNREM,'k.')
title('NREM')
subplot(5,1,5)
%Now converting to binary matrices
minREM=zeros(size(allrasterREM));
minREM(find(allrasterREM>0))=1;
minNREM=zeros(size(allrasterNREM));
minNREM(find(allrasterNREM>0))=1;
minWA=zeros(size(allrasterWA));
minWA(find(allrasterWA>0))=1;

%Now making a vector of events/s
vsum=sum(minNREM,2)/size(minNREM,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newNREM=mean(newsum*srcalcium,1);
hpNREM=mean(newNREM(1:3));
lpNREM=mean(newNREM(end-2:end));
plot(newNREM,'k')
vsum=sum(minREM,2)/size(minREM,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newREM=mean(newsum*srcalcium,1);
hpREM=mean(newREM(1:3));
lpREM=mean(newREM(end-2:end));

vsum=sum(minWA,2)/size(minWA,2);
newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
newWA=mean(newsum*srcalcium,1);
lpWA=mean(newWA(1:3));
hpWA=mean(newWA(end-2:end))



figure;
subplot(5,1,1:4)
plot(allrasterREM,'k.')
title('REM')
subplot(5,1,5)
plot(newREM,'k')

figure;
subplot(5,1,1:4)
plot(allrasterWA,'k.')
title('WA')
subplot(5,1,5)
plot(newWA,'k')



figure
%bar([[hpREM lpREM]' [hpNREM lpNREM]' [hpWArs lpWArs]' [hpWAsd lpWAsd]' ])
bar([[hpREM hpNREM hpWA]' [lpREM lpNREM lpWA ]'])
set(gca,'XTick',[1 2 3])
set(gca,'XTicklabel',{'REM','NREM','WA'})
legend('HP','LP')
colormap bone
set(gca,'fontsize',14)
box off
xlabel('State','fontsize',21)
ylabel('Mean Events/s','fontsize',21)
%ind1=find(matREM>median(threscell))
for ncell=1:handles.ncells
    remevents(ncell)=length(find(matREM(:,ncell)>0.9));
    nremevents(ncell)=length(find(matNREM(:,ncell)>0.9));
    wavents(ncell)=length(find(matWA(:,ncell)>0.9));
    remrat(ncell)=(remevents(ncell)/(size(matREM,1))*srcalcium);
    nremrat(ncell)=(nremevents(ncell)/(size(matNREM,1))*srcalcium);
    warat(ncell)=(wavents(ncell)/(size(matWA,1))*srcalcium);
end

%ploting raster WA SD
figure
subplot(5,1,1:4)
xras=(0:length(allrasterWA)-1)/(srcalcium*60);
plot(xras,allrasterWA,'k.','markersize',6)
axis tight
set(gca,'fontsize',14)
box off
ylabel('Cell #','fontsize',21)
set(gca,'XTicklabel','')
subplot(5,1,5)
plot(newWA,'k','linewidth',1.5)
xlabel('Time(min)','fontsize',21)
axis tight
minmax=get(gca,'ylim')
set(gca,'ylim',[0 max(minmax)])
set(gca,'fontsize',14)
box off

%ploting it as a scatter plot
figure
plot(newWA,'ko')
xlabel('Time(min)','fontsize',21)
axis tight
ylabel('Mean Events/s','fontsize',21)
set(gca,'fontsize',14)
box off
figure
title(num2str(handles.stimon(end)))
nplots=length(find(max([warat' nremrat' remrat']')>0));
q1=1;
k=1;
remcells=find(remrat>(max(nremrat,warat))*2);
figure
tobar=[mean(warat) mean(nremrat) mean(remrat)];
toerr=[sem(warat) sem(nremrat) sem(remrat)];
errorbar(tobar,toerr,'k.')
hold on
bar(tobar)
set(gca,'XTick',[1 2 3])
set(gca,'Xticklabel',{'WA','NREM','REM'})
set(gca,'fontsize',14)
ylabel('Events/sec','fontsize',21)
figure
subplot(4,1,1)
xhyp=xhypno/60;
plot(xhyp,round(handles.score(allepochs)),'k-','linewidth',1)
set(gca,'ylim',[0 2.1])
set(gca,'YTick',[0 1 2])
set(gca,'Yticklabel',{'W','NREM','REM'})
set(gca,'fontsize',14)
eps=round(3600*handles.stimon(31:end)/handles.el);
set(gca,'xticklabel','')
%xlabel('Time (min)','fontsize',24)
keysc=round(handles.score(allepochs));
hold on
plot([imgstart'/60 imgstart'/60],[0 2.1],'g:','linewidth',1)
axis tight
plot(xhyp,round(handles.score(allepochs)),'k-','linewidth',1)
data.hypno=round(handles.score(allepochs));
data.hypnox=xhyp;
data.hypnoingstart=imgstart'/60;
box off

subplot(4,1,[2:3])
x=(0:length(allraster)-1)/(60*srcalcium);
plot(x,allraster,'k.','markersize',6)
axis tight
set(gca,'Xticklabel','')
set(gca,'fontsize',14)
ylabel('Cell #','fontsize',18)
box off
axis tight
set(gca,'Xticklabel','')
hold on
%plot(x,allraster(:,remcells),'r.','markersize',5)
data.rasterd=allraster;
data.rasterx=x;

subplot(4,1,4)
newmp=zeros(size(allraster));
ind1=find(~isnan(allraster));
newmp(ind1)=1;
vsum=sum(newmp,2)*srcalcium/handles.ncells;
xv=(0:length(vsum)-1)/(60*srcalcium);


newsum=reshape(vsum(1:round(60*srcalcium)*floor(length(vsum)/round(60*srcalcium))),round(60*srcalcium),floor(length(vsum)/round(60*srcalcium)));
%plot(mean(newsum,1),'k-')
plot(xv,vsum,'k-')
xlabel('Time (min)','fontsize',24)
set(gca,'fontsize',14)
ylabel('Events/s','fontsize',21)
box off
axis tight
data.warate=warat;
data.nremrate=nremrat;
data.remrate=remrat;
hpWArs=hpWA;
hpWAsd=hpWA;
lpWArs=lpWA;
lpWAsd=lpWA;
data.hp=[hpREM hpNREM hpWArs hpWAsd]';
data.lp=[lpREM lpNREM lpWArs lpWAsd]';
fname2=strcat(auxs(1:end-3),'dat.mat');
save(fname2,'data')
helpdlg('Data saved!')

f=figure

%making color array for REM
colormap jet;
m=colormap;
rangerem=max(data.remrate);
rangewa=max(data.warate);
%The color is given by m(round(((length(m)-1)/rangerem)*remrate(i))+1,:)
for i=1:length(data.remrate)
    plot(data.warate(i),data.nremrate(i),'ko','markersize',6,'MarkerFaceColor',m(round(((length(m)-1)/rangerem)*data.remrate(i))+1,:))
    hold on
    plot((i/length(data.warate))*rangewa,(i/length(data.warate))*rangewa,'.','markersize',12,'color',m(round(((length(m)-1)/rangerem)*(i/length(data.warate))*rangewa)+1,:))
end
box off
xlabel('WAKE','fontsize',21)
ylabel('NREM','fontsize',21)
colorbar
set(gca,'fontsize',14)
%converting colobrar ticks in event rate
colorbarticks=get(colorbar,'YTick');
newlabels=(colorbarticks/length(m))*rangerem;
newticks=cellstr(num2str((round(newlabels*100)/100)'));
set(colorbar,'Yticklabel',newticks,'fontsize',14)

%Now the figure with the cells:
%making merged figures with the right colors
figcells=zeros(size(filtmat,1),size(filtmat,2),3);%3-D matrix with all the cells color coded according to firing preference
%Red:REM, Green:WA, Blue:NREM
for i=1:ncells
    frate=[data.remrate(i) data.warate(i) data.nremrate(i)];
    frate=frate./sum(frate);%This will be hte normalized color values (sum of the 3 colors =1)
    auxmat=1.2*fixdim(filtmat(:,:,i));%image with the cell (normalized filter)
%     indaux=find(auxmat>0);
%     auxmat(indaux)=1;
    for q1=1:3
        m1=fixdim(figcells(:,:,q1));
        m2=auxmat*frate(q1);%red
        sfc=size(m1);
        newmatf=max([m1(:)' ;m2(:)']);
        figcells(:,:,q1)=reshape(newmatf,sfc);
    end
 
end
figure
ind2=find(figcells>1);
figcells(ind2)=1;
image(figcells)
axis off
guidata(hObject, handles);


% --- Executes on button press in syncfirst.
function syncfirst_Callback(hObject, eventdata, handles)
% hObject    handle to syncfirst (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.synclast,'value',0)
% Hint: get(hObject,'Value') returns toggle state of syncfirst


% --- Executes on button press in synclast.
function synclast_Callback(hObject, eventdata, handles)
% hObject    handle to synclast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.syncfirst,'value',0)
% Hint: get(hObject,'Value') returns toggle state of synclast



function toedit_Callback(hObject, eventdata, handles)
% hObject    handle to toedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h=get(hObject,'String');
handles.hto=str2double(h(1:2));%initial hour
handles.mto=str2double(h(4:5));%initial minute
handles.sto=str2double(h(7:8));%initial second
%set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of toedit as text
%        str2double(get(hObject,'String')) returns contents of toedit as a double


% --- Executes during object creation, after setting all properties.
function toedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to toedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10



function nperiods_Callback(hObject, eventdata, handles)
% hObject    handle to nperiods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nperiods as text
%        str2double(get(hObject,'String')) returns contents of nperiods as a double


% --- Executes during object creation, after setting all properties.
function nperiods_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nperiods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in fixEMG.
function fixEMG_Callback(hObject, eventdata, handles)
% hObject    handle to fixEMG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fixEMG
 axes(handles.axes5)
 axis tight
 minmax=get(gca,'ylim');
 handles.limemg=minmax;
 guidata(hObject, handles);
 


% --- Executes on button press in gc3.
function gc3_Callback(hObject, eventdata, handles)
% hObject    handle to gc3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile({'*.txt;*.mat'},'Pick the txt files with the video info','MultiSelect', 'on');
cd (pathname)
%Making a vector with the times in seconds of the starting of each video:
nmovs=length(filename);
disp('Reading time of videos...')
for k=1:nmovs
    auxs=filename{k};
    l=length(auxs);
    day=str2num(auxs(l-12:l-11));
    h0=num2str(handles.EDF.T0(4));
    m0=num2str(handles.EDF.T0(5));
    s0=num2str(handles.EDF.T0(6));
    if length(h0)<2
        h0=strcat('0',h0);
    end
    if length(m0)<2
        m0=strcat('0',m0);
    end
    if length(s0)<2
        s0=strcat('0',s0);
    end
    timev(k)=time2secs(strcat(h0,m0,s0),auxs(l-9:l-4));
    if day~=handles.EDF.T0(3)
        timev(k)=timev(k)+86400;
    end
    %Getting the duration of the video from the txt file
    fileid=fopen(auxs);
    ss=fscanf(fileid,'%s');
    tp=strfind(ss,'TIME');
    durvi(k)=str2num(ss(tp+4+(1:2)))*60+str2num(ss(tp+4+(4:5)));
    fclose(fileid);
end
%1- Detected on-off periods when there is no txt file describing a video at
%that time
%Eliminating detected ON-OFF periods when there is no video starting in a 3-s vecinity
% tempstimon=[];
% tempstimoff=[];
% for i=1:length(handles.origimgon)
%     if min(abs(handles.origimgon(i)*3600-timev))<3
%         tempstimon=[tempstimon handles.origimgon(i)*3600];
%         tempstimoff=[tempstimoff handles.origimgoff(i)*3600];
%     end
% end

%2- Actual recorded video having different duration that the detected
%On-off timing
%Assuming on time is ok and off time detected is longer than video duration
%Now replacing the value of stim off by the duration of the movie when the
%off times don't match. This video should be removed from the events since
%it contains frames sampled at odd times.
% for i=1:length(tempstimoff)
%     if min(abs(tempstimoff(i)-(timev+durvi)))>3
%         tempstimoff(i)=tempstimon(i)+durvi(i);
%     end
% end
% if length(tempstimon)>length(durvi)
%     disp('Error. More videos detected than recorded')
% elseif length(tempstimon)>length(durvi)
%     disp('Error. More videos recorded than detected')
% end
tempstimon=handles.origimgon*3600;
tempstimoff=handles.origimgoff*3600;
figure
subplot(2,1,1)
xvec=1:ceil(max(tempstimon));
tracedet=zeros(size(xvec));
tracevid=tracedet;
for i=1:length(tempstimoff)
    tracedet(round(tempstimon(i)):round(tempstimoff(i)))=1;
end
for i=1:length(timev)
    tracevid(round(timev(i)):round(timev(i)+durvi(i)-1))=1;
end
plot(xvec,tracedet,'k-','linewidth',2);
hold on
plot(xvec,tracevid,'r-');
box off
subplot(2,1,2)
for i=1:length(tempstimon)
    v(i)=sum(tracevid(round(tempstimon(i)):round(tempstimoff(i))));
end
subplot(2,1,2)
plot(v,'.')

