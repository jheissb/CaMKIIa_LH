function varargout = inscopix(varargin)
% INSCOPIX MATLAB code for inscopix.fig
%      INSCOPIX, by itself, creates a new INSCOPIX or raises the existing
%      singleton*.
%
%      H = INSCOPIX returns the handle to a new INSCOPIX or the handle to
%      the existing singleton*.
%
%      INSCOPIX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in INSCOPIX.M with the given input arguments.
%
%      INSCOPIX('Property','Value',...) creates a new INSCOPIX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before inscopix_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to inscopix_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help inscopix

% Last Modified by GUIDE v2.5 07-May-2013 10:51:16

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @inscopix_OpeningFcn, ...
                   'gui_OutputFcn',  @inscopix_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before inscopix is made visible.
function inscopix_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to inscopix (see VARARGIN)

% Choose default command line output for inscopix
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes inscopix wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = inscopix_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Sync.
function Sync_Callback(hObject, eventdata, handles)
% hObject    handle to Sync (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
chsz=180;%reading 3 min. chunks
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF with the Sync signal');
cd (pathname)
EDF=sdfopen(filename);
handles.syncp=[];
handles.syncn=[];
dur=EDF.NRec*EDF.Dur;%duration in secs of the whole thing
disp('Reading sync')

for i=2:(floor(dur/chsz))-1%reading chunks, skipping the first 2        
    [s0,edfs]=sdfread(EDF,chsz,i*chsz);
    s=s0(1:end-1);
    s2=s0(2:end);
    handles.syncp=[handles.syncp ((i*chsz)+(find(s<2 & s2>2))/edfs.SampleRate)'];%finding positive edges
    handles.syncn=[handles.syncn ((i*chsz)+(find(s>2 & s2<2))/edfs.SampleRate)'];%finding negative edges

end
[s0,edfs]=sdfread(EDF,dur-(i*chsz),1+(i+1)*chsz);
s=s0(1:end-1);
s2=s0(2:end);
handles.syncp=[handles.syncp ((i+1)*chsz+(find(s<2 & s2>2))/edfs.SampleRate)'];%finding positive edges
handles.syncp=handles.syncp(1:4:length(handles.syncp));
handles.syncn=[handles.syncn ((i+1)*chsz+(find(s>2 & s2<2))/edfs.SampleRate)'];%finding negative edges
handles.syncn=handles.syncn(1:4:length(handles.syncn));
handles.hf=figure
axes(handles.axes1)
disp(length(handles.syncp))
cla
% plot(handles.syncp,ones(size(handles.syncp)),'.')
hold on
plot(handles.syncn,-ones(size(handles.syncn)),'.')
guidata(hObject, handles);


% --- Executes on button press in load_tr.
function load_tr_Callback(hObject, eventdata, handles)
% hObject    handle to load_tr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%we will calculate the area above the 3 std line, the number of times it
%goes above the line, the average length of each event, the max peak value and the number of
%correlated pairs
[filename, pathname] = uigetfile('*traces.txt','Pick the trace file with the scoring','MultiSelect','on');
cd (pathname)
handles.traces=[];
for i=1:length(filename)
    fn=char(filename(i));
    timeim(i)=time2secs('111330',fn(length(fn)-16:length(fn)-11));
    newmat=load(fn)';
    if i<9
        [r,p]=corrcoef(newmat');
        nsigcorr(i)=length(find(p<1E-8))/2;%number of cells significantly correlated
    end
    ltrace(i)=length(newmat);
    handles.traces=[handles.traces newmat];
    %concatenating each trace
end
handles.ncells=size(newmat,1);
%Getting the threshold values using all traces for each cell
for k=1:handles.ncells
    threscell(k)=mean(handles.traces(k,:))+3*std((handles.traces(k,:)));
%     plot(handles.traces(k,:))
%     hold on
%     plot(threscell(k)*ones(size(handles.traces(k,:))),'k--')
%     pause
%     cla
end
    
for i=1:8
   if i==1
       newmat=handles.traces(:,1:ltrace(1));
   else
       indx=sum(ltrace(1:i-1));%starting pos of the matrix
       newmat=handles.traces(:,indx:indx+ltrace(i)-1);
        for j=1:handles.ncells
            [nevents(i,j),peakevent(i,j),meanevent(i,j),areaevents(i,j),maxarea(i,j),maxdurevent(i,j),meandurevent(i,j)]=getnevents(newmat(j,:),threscell(j));
        end
   end
end


disp('Making traces for NREM, REM and WA point by point')
traceWA=[];
traceREM=[];
traceNREM=[];
for i=sum(ltrace(1:8)):min(length(handles.traces),length(handles.syncp))%skipping the first 8
    if state(handles.syncp(i),handles)==0
        traceWA=[traceWA handles.traces(:,i)];
    end
    if state(handles.syncp(i),handles)==1
        traceNREM=[traceNREM handles.traces(:,i)];
    end
    if state(handles.syncp(i),handles)==2
        traceREM=[traceREM handles.traces(:,i)];
    end
end
[r,p]=corrcoef(traceWA(:,2000:2000+size(traceREM,2))');
sigcorrWA=length(find(p<1E-8))/2;
[r,p]=corrcoef(traceNREM(:,2000:2000+size(traceREM,2))');
sigcorrNREM=length(find(p<1E-8))/2;
[r,p]=corrcoef(traceREM');
sigcorrREM=length(find(p<1E-8))/2;

 for j=1:size(traceWA,1)
            [neventsWA(j),peakeventWA(j),meaneventWA(j),areaeventsWA(j),maxareaWA(j),maxdureventWA(j),meandureventWA(j)]=getnevents(traceWA(j,:),threscell(j));
            [neventsNREM(j),peakeventNREM(j),meaneventNREM(j),areaeventsNREM(j),maxareaNREM(j),maxdureventNREM(j),meandureventNREM(j)]=getnevents(traceNREM(j,:),threscell(j));
            [neventsREM(j),peakeventREM(j),meaneventREM(j),areaeventsREM(j),maxareaREM(j),maxdureventREM(j),meandureventREM(j)]=getnevents(traceREM(j,:),threscell(j));
 end
nsimWA=getsimev(traceWA,threscell,1,3);%calculating the number of simultaneous events in a matrix with traces (1 s window)
nsimNREM=getsimev(traceNREM,threscell,1,3);
nsimREM=getsimev(traceREM,threscell,1,3);
figure
errorv=[sem(nsimWA) sem(nsimNREM) sem(nsimREM)];
datav=[mean(nsimWA) mean(nsimNREM) mean(nsimREM)];
errorbar(datav,errorv,'k.')
hold on
bar(datav)
set(gca,'XTick',[1 ;2; 3])
set(gca,'XTickLabel',{'WA','NREM','REM'})
set(gca,'fontsize',14)
box off
ylabel('Sim. events/N events','fontsize',21)

figure
subplot(3,1,1)
bar(nsigcorr)
subplot(3,1,2)
bar([sigcorrWA sigcorrNREM sigcorrREM])
figure
title('Event frequency')
for ploti=1:64
    subplot(8,8,ploti)
    bar([neventsWA(ploti) neventsNREM(ploti) neventsREM(ploti)])
   % set(gca,'fontsize',14)
    set(gca,'XTickLabel',{'WA','NREM','REM'})
end
figure
subplot(1,2,1)
error=[sem(neventsWA) sem(neventsNREM) sem(neventsREM)]
neventstp=[mean(neventsWA) mean(neventsNREM) mean(neventsREM)];
errorbar(neventstp,error,'k.')
hold on
bar(neventstp)
   % set(gca,'fontsize',14)
   set(gca,'XTick',[1 ;2; 3])
set(gca,'XTickLabel',{'WA','NREM','REM'})
set(gca,'fontsize',14)
box off
ylabel('Mean Events/sec','fontsize',21)
 m=[neventsWA' neventsNREM' neventsREM'];
 [v,p]=max(m');
 pwa=100*length(find(p==1))/64
 pnrem=100*length(find(p==2))/64
 prem=100*length(find(p==3))/64 
 subplot(1,2,2)
 bar([pwa pnrem prem])
   % set(gca,'fontsize',14)
   set(gca,'XTick',[1 ;2; 3])
set(gca,'XTickLabel',{'WA','NREM','REM'})
set(gca,'fontsize',14)
box off
ylabel('% of population with max event rate','fontsize',21)
set(gca,'ylim',[0 100])

% figure
% subplot(4,2,1)
% plot([peakeventWA; peakeventNREM; peakeventREM],'.-');
% hold on
% plot(mean([peakeventWA' peakeventNREM' peakeventREM']),'o-','linewidth',2)
% axis tight
% title('Peak Event','fontsize',16)
% 
% subplot(4,2,2)
% plot(nevents,'.-');
% hold on
% plot(mean(nevents'),'o-','linewidth',2)
% axis tight
% title('N Events','fontsize',16)
% 
% 
% subplot(4,2,3)
% plot(meanevent,'.-');
% hold on
% plot(mean(meanevent'),'o-','linewidth',2)
% axis tight
% title('Mean events','fontsize',16)
% 
% subplot(4,2,4)
% plot(areaevents,'.-');
% hold on
% plot(mean(areaevents'),'o-','linewidth',2)
% axis tight
% title('Area Events','fontsize',16)
% 
% subplot(4,2,5)
% plot(maxarea,'.-');
% hold on
% plot(mean(maxarea'),'o-','linewidth',2)
% axis tight
% title('Max area','fontsize',16)
% 
% subplot(4,2,6)
% plot(maxdurevent,'.-');
% hold on
% plot(mean(maxdurevent'),'o-','linewidth',2)
% axis tight
% title('Max Dur Event','fontsize',16)
% 
% subplot(4,2,7)
% plot(meandurevent,'.-');
% hold on
% plot(mean(meandurevent'),'o-','linewidth',2)
% axis tight
% title('Mean Dur Event','fontsize',16)

figure
%subplot(2,1,1)
%for ploti=1:8
ploti=6;
%subplot(4,2,ploti)
plot(nevents(:,(1+8*(ploti-1)):(1+8*(ploti-1))+7),'o-');
hold on
plot(mean(nevents(:,(1+8*(ploti-1)):(1+8*(ploti-1))+7),2),'kd-','linewidth',2)
axis tight
ylabel('N Events (4 cells)','fontsize',21)
set(gca,'fontsize',14)
xlabel('Period of SD','fontsize',21)

box off
%end
subplot(2,1,2)
plot(nevents(1,:),nevents(8,:),'ko')
hold on
plot([0 max(nevents(8,:))],[0 max(nevents(8,:))],'g--')
set(gca,'fontsize',14)
xlabel('N Events SD 1','fontsize',21)
ylabel('N Events SD 8','fontsize',21)
axis tight
box off
% 

%end
axes(handles.axes2)
%plot(handles.traces')
% hold on
% v=ones(1,size(handles.traces,2));
% for i=1:size(handles.traces,1)
%     %cla
%     plot(handles.traces(i,:)')
%     top=std(handles.traces(i,:))*3*v;
%     plot(top,'k--')
%     %pause
% end
%Dividing the traces in 11 groups: SD 1-8, NREM, WA and REM
handles.sttimes4tr=handles.syncp([1 find(diff(handles.syncp)>10)]);
handles.edtimes4tr=handles.syncn([find(diff(handles.syncp)>10)]);
guidata(hObject, handles);


function st=state(timeinp,handles)
%returns the state for a given time in s
ind=round(timeinp/4);
st=round(handles.score(ind));

% --- Executes on button press in load_score.
function load_score_Callback(hObject, eventdata, handles)
% hObject    handle to load_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.mat', 'Pick the MAT file with the scoring');
cd (pathname)
load (filename)
axes(handles.axes1)
hold on
handles.score=sc;
xsc=0:4:4*length(sc);
plot(xsc(1:end-1),sc,'k-')
guidata(hObject, handles);



% --- Executes on button press in set_thres.
function set_thres_Callback(hObject, eventdata, handles)
% hObject    handle to set_thres (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save_btn.
function save_btn_Callback(hObject, eventdata, handles)
% hObject    handle to save_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
score=handles.score;
posedge=handles.syncp;
negedge=handles.syncn;
save('data.mat','score','posedge','negedge');
helpdlg('Data saved')
