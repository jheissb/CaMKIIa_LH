function [thresh,error_flag,lo_pos,Hi_pos]=findthreshold2(handles,parameter,index,namepar)
%Finds the threshold to consider a parameter high or low by asking the user
%index has the position of the parameters in the
%corresponding epoch number. If length paramter == nepochs, index =
%1:nepochs.lo_pos,Hi_pos have the state values corresponding to low and
%high values of the parameter
%Unscorable epochs must be previously identified by making te parameter -1 for that epoch.
error_flag=0;%Becomes 1 if user press redo.
parameter(find(isnan(parameter)))=0;
%finding the low and hi states
auxscore=nan(size(handles.scorea));
[sorted,p]=sort(parameter);
%ask for scoring of the extremes
ltrace=str2num(get(handles.lengthtrace,'string'));
If=[];
I0=[];
I0(1)=min(find(sorted>0))%I0 and If are the intial and final value in ascendent order of parameter.
If(1)=floor(0.99*length(parameter));
handles.ce=index(p(I0(1)));
k=1;
while parameter(p(I0(k)))<parameter(p(If(k))) %This has the problem that if the step is too large, it can overshoot and assign a value too large
    k=k+1;
    nextpossorted=I0(k-1)+floor((If(k-1)-I0(k-1))/2);%binary search
    %assigning to If or I0 according to the scoring
    handles.ce=index(p(nextpossorted));
    handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
    handles.tf=handles.t0+handles.ltrace;
    dat2plot=handles.edfdata(:,:,min(size(handles.edfdata,3),(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
    plot_traces(handles);
    colorb='rgbkcmgkr'
%     set(handles.text8,'backgroundcolor',colorb(ceil(10*rand)));
%     disp(['max:' num2str(max(parameter)) ' min:' num2str(min(parameter(handles.ce))) 'median:' num2str(median(parameter)) 'current:' num2str(parameter(handles.ce))]);
%     set(handles.text8,'string',['Scoring for ',namepar]);
%     axes(handles.axes1)
%     xminmax=get(gca,'xlim');
%     yminmax=get(gca,'ylim');
%     ry=yminmax(2)-yminmax(1);
%     text(xminmax(1)+1,yminmax(1)+0.1*ry,'High','fontsize',16,'color','r')
%     text(xminmax(1)+1,yminmax(2)-0.1*ry,'Low','fontsize',16,'color','r')
%     text(xminmax(2)-3,yminmax(2)-0.1*ry,'Redo','fontsize',16,'color','r')
%     text(xminmax(2)-3,yminmax(1)+0.1*ry,'Unscorable','fontsize',16,'color','m')
%     answer=ginput(1);
    if answer(2)>mean(yminmax)/2
        if answer(1)<xminmax(1)+3 %press on low
            auxscore(handles.ce)=1;
            disp(1)
        else
            %press on redo
            disp('Redo')
            error_flag=1;
        end
    else
        if answer(1)<xminmax(1)+3 %press on high
            auxscore(handles.ce)=0;
            disp(0)
        else
            %press on skip
            disp('Unscorable in 2s')
            auxscore(handles.ce)=-1;
        end
    end
    
    if error_flag
        thresh=-1;
        lo_pos=index(p(max(I0)));
        Hi_pos=index(p(min(If)));
        break
    else
        if auxscore(handles.ce)<0.5
            If(k)=nextpossorted;%If the value with smaller EMG still scores as W (<0.5), then assign the value as the upper limit and keep the lower limit
            I0(k)=I0(k-1);
        else
            I0(k)=nextpossorted;%%If the value with smaller EMG scores as NR or R (>0.5), then assign the value as the lower limit and keep the upper limit
            If(k)=If(k-1);
        end
        axes(handles.axes4)
        plot(I0,'b.-','linewidth',2)
        hold on
        plot(If,'r.-','linewidth',2)
        
        disp(strcat('lower lim=',num2str(parameter(p(I0(k)))),' upper limit=',num2str(parameter(p(If(k))))))
    end
    %Now establishing the threshold
    thresh=(parameter(p(min(If)))+parameter(p(max(I0))))/2;
    lo_pos=index(p(max(I0)));
    Hi_pos=index(p(min(If)));
end


disp(thresh)
guidata(gca, handles);
