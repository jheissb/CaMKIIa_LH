function varargout = edfview(varargin)
% EDFVIEW M-file for edfview.fig
%      EDFVIEW, by itself, creates a new EDFVIEW or raises the existing
%      singleton*.
%
%      H = EDFVIEW returns the handle to a new EDFVIEW or the handle to
%      the existing singleton*.
%
%      EDFVIEW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EDFVIEW.M with the given input arguments.
%
%      EDFVIEW('Property','Value',...) creates a new EDFVIEW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before edfview_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to edfview_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help edfview

% Last Modified by GUIDE v2.5 17-Feb-2016 13:25:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @edfview_OpeningFcn, ...
    'gui_OutputFcn',  @edfview_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before edfview is made visible.
function edfview_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to edfview (see VARARGIN)

% Choose default command line output for edfview
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes edfview wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = edfview_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadedf.
function loadedf_Callback(hObject, eventdata, handles)
% hObject    handle to loadedf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.chanlist,'value',1)
cla
cn=getComputerName();
cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     cd ('C:\Users\E26903\Documents\My Dropbox\Jaime')
% end
% if strcmp('laptopjh',cn)
%     cd ('C:\Users\john\Documents\My Dropbox\Jaime')
% end

if isfield(handles,'EDF')
    [EDF]=sdfclose(handles.EDF)
    disp('Closing previous file')
end
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file to analyze');
handles.fn=filename;
cd (pathname)
tic
EDF=sdfopen(filename,'r');
handles.EDF=EDF;
set(handles.chanlist,'string',EDF.Label);
nhrs=str2num(get(handles.edit12,'string'));
if get(handles.checkbox2,'value')
    %[s,edfs]=sdfread(EDF,nhrs*3600,(EDF.NRec*EDF.Dur)-(nhrs*3600));%Only reads some hours.
    [s,edfs]=sdfread(EDF,round(nhrs*3600),0);%
else
    [s,edfs]=sdfread(EDF,inf);
end
ls=length(s);
toc
if exist(strcat('nNOS',handles.fn(1:end-3),'txt'))
    handles.scoring=load (strcat('nNOS',handles.fn(1:end-3),'txt'));
    %calculating RMS for different stages
end

selchan=get(handles.chanlist,'value');
sr=edfs.SampleRate;
if length(sr)>3
    if length(s(:,1))==length(s(:,4))
        sr(4)=sr(1);
    end
end
set(handles.edit14,'string',num2str(sr(selchan)));
handles.sr=sr;
%dur=str2num(get(handles.edit4,'string'));
%handles.dur=dur;
%t0=str2num(get(handles.t0,'string'));
t0=str2num(get(handles.edit5,'string'));
set(handles.edit6,'string',num2str(size(s,1)/(60*sr(selchan))));
tf=str2num(get(handles.edit6,'string'));

tvent=str2num(get(handles.tevent,'string'));
skip=(t0*60*sr(selchan))+1;
lastp=floor((floor(tf)*60*sr(selchan)));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));
% set(handles.slider1,'Max',length(handles.s)/60);
%
% set(handles.slider1,'Min',0);

%deleting the data during placement of the internals
%     ti=round(handles.sr(selchan)*60*splc);
%     tf=round(handles.sr(selchan)*60*eplc);
%     s(ti:tf,:)=0;
handles.hto=EDF.T0(4);%initial hour
handles.mto=EDF.T0(5);%initial minute
handles.sto=EDF.T0(6);%initial second
handles.s=s;
handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
handles.h=handles.axes1;
%handles.x=(0:length(handles.news)-1)/sr(selchan);
set(handles.text15,'string',strcat('T0=',num2str(handles.hto),':',num2str(handles.mto),':',num2str(handles.sto)));
handles.dur=length(handles.news)/handles.sr(selchan);

%smart scaling:
% if dur>10
%     handles.x=handles.x*dur;%scale in min.
% else
%     handles.x=handles.x*(dur*60);%scale in s
% end
% if get(handles.plotm,'value')
%handles.x=handles.x/60;
% end
axis(handles.axes1);
tl=length(handles.news)/handles.sr(selchan);%total length in s
if get(handles.showall,'value')
    handles.ltrace=tl;
    handles.x=tl*(0:length(handles.news)-1)/(length(handles.news)-1);
    handles.xi=1/handles.sr(selchan);
else
    handles.ltrace=str2num(get(handles.edit4,'string'));%length in s
    handles.xi=get(handles.slider1,'value');
    handles.x=(handles.xi:handles.xi+(handles.ltrace*handles.sr(selchan))-1)/handles.sr(selchan);
end
xlabel(handles.h,'s','fontsize',14)
set(handles.slider1,'max',tl);
%getting the max in the slider
if get(handles.plotm,'value')
    %handles.x=handles.x/60;
    set(handles.slider1,'max',tl/60);
    xlabel(handles.h,'min','fontsize',14)
end
%cla
if get(handles.plotm,'value')
    plot(handles.x/60,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
else
    plot(handles.x,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
end
axis tight


%plot(hand,handles.x,handles.news(:,selchan))
%     plot(handles.x,handles.news(:,selchan))
%plot(handles.x,handles.news(:,selchan))

% if dur>10
xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
%set(handles.tevent,'string',(length(handles.news)/(60*handles.sr(selchan)))-120);
set(handles.filename,'string',filename);
if tvent>0
    minmax=get(gca,'ylim')
    hold on
    plot([tvent tvent]',minmax','g--')
end
%reading and processing the scoring
%to load staging: W=87, NR=78, R=82, crap=85
%In many cases the scoring starts before the data.
if exist(strcat('nNOS',handles.fn(1:end-3),'txt'))
    handles.scoring=load(strcat('nNOS',handles.fn(1:end-3),'txt'));
    %prunning the first n epochs to match the data size
    cl=length(handles.scoring);
    nepochsindata=floor(length(handles.s)/(sr(selchan)*10));
    if nepochsindata>cl
        aux0=handles.scoring;
        handles.scoring=zeros(nepochsindata,2);
        handles.scoring(1:nepochsindata-cl,1)=0:nepochsindata-cl-1;
        handles.scoring(1:nepochsindata-cl,2)=85;
        handles.scoring(nepochsindata-cl+1:nepochsindata,:)=aux0;
    else
        handles.scoring=handles.scoring(cl-nepochsindata:cl,:);
    end
    %Now plotting the whole EEG epoch by epoch and calculating RMS for different stages
    nw=0;nr=0;nn=0;nc=0;
    figure
    
    ntr=eegfilter(handles.s(:,selchan),5,0);
    
    xaxis=(0:length(ntr)-1)/sr(selchan);
    plot(xaxis,ntr,'k-');
    hold on
    rmsr=0;
    for i=1:length(handles.scoring)-1
        ti=1+(10*(i-1))*sr(selchan);
        tf=min(length(ntr),ti+(10*sr(selchan)));
        if ti>tf
            disp('Error')
            break
        end
        aux=rms(ntr(ti:tf));
        switch handles.scoring(i,2)
            case 87
                nw=nw+1;
                rmswa(nw)=aux;
            case 78
                nn=nn+1;
                rmsnr(nn)=aux;
                plot(xaxis(ti:tf),ntr(ti:tf),'r-')
            case 82
                nr=nr+1;
                rmsr(nr)=aux;
                plot(xaxis(ti:tf),ntr(ti:tf),'g-')
            case 85
                plot(xaxis(ti:tf),ntr(ti:tf),'b-')
        end
    end
    figure
    bar([5000*mean(rmswa) 5000*mean(rmsnr) 5000*mean(rmsr) mean(rmswa)/mean(rmsnr)])
    
    xlabel('WA      NREM   REM     WA/NREM')
    disp('WA, NREM and REM')
    mean(rmswa)
    std(rmswa)
    mean(rmsnr)
    std(rmsnr)
    mean(rmsr)
    std(rmsr)
    
    
    figure;
    subplot(2,1,1)
    plot(rmsnr,'.-')
    subplot(2,1,2)
    plot(rmswa,'.-')
    
    
    
    
end
handles.selchan=selchan;
handles.fn
handles.hedf=EDF;
set(handles.slider1,'value',1);
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function chanlist_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chanlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in chanlist.
function chanlist_Callback(hObject, eventdata, handles)
% hObject    handle to chanlist (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~isfield(handles,'sr')
    handles.sr=250;
end
selchan=get(handles.chanlist,'value');
set(handles.edit14,'string',num2str(handles.sr(selchan)));
t0=str2num(get(handles.t0,'string'));
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));
axis(handles.axes1);
%handles.ltrace=str2num(get(handles.edit4,'string'));%length in s
%handles.xi=get(handles.slider1,'value');
tl=length(handles.news)/handles.sr(1);%total length in s
if get(handles.showall,'value')
    handles.ltrace=tl;
    handles.x=(tl*(0:length(handles.news)-1))/(length(handles.news)-1);
    handles.xi=1/handles.sr(1);
else
    handles.ltrace=str2num(get(handles.edit4,'string'));%length in s
    handles.xi=get(handles.slider1,'value');
    handles.x=(handles.xi:handles.xi+(handles.ltrace*handles.sr(selchan))-1)/handles.sr(selchan);
end
cla
if get(handles.plotm,'value')
    plot(handles.x/60,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
else
    plot(handles.x,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
end
guidata(hObject, handles);

% if dur>10
%     xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
if tvent>0
    minmax=get(gca,'ylim')
    hold on
    plot([tvent tvent]',minmax','g--')
    
end
handles.selchan=get(handles.chanlist,'value');
guidata(hObject, handles);

% Hints: contents = get(hObject,'String') returns chanlist contents as cell array
%        contents{get(hObject,'Value')} returns selected item from chanlist


% --- Executes during object creation, after setting all properties.
function t0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to t0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function t0_Callback(hObject, eventdata, handles)
% hObject    handle to t0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
t0=str2num(get(handles.t0,'string'));
selchan=get(handles.chanlist,'value');
skip=(t0*60*handles.sr(selchan))+1;
handles.news=handles.s(skip:end,:);%get(handles.chanlist,'value'));%Only 2 hours
guidata(hObject, handles);


% Hints: get(hObject,'String') returns contents of t0 as text
%        str2double(get(hObject,'String')) returns contents of t0 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function tevent_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tevent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function tevent_Callback(hObject, eventdata, handles)
% hObject    handle to tevent (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of tevent as text
%        str2double(get(hObject,'String')) returns contents of tevent as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double
axis(handles.axes1);
selchan=get(handles.chanlist,'value');
handles.xi=get(handles.slider1,'value');%start time of the trace to plot
handles.xf=handles.xi+str2double(get(handles.edit4,'string'));%end time of the trace to plot
indx=handles.xi*handles.sr(selchan):handles.xf*handles.sr(selchan);
handles.x=indx/handles.sr(selchan);
handles.x=handles.x/60;

%plot(hand,handles.x,handles.news(:,selchan))
cla
if get(handles.plotm,'value')
    plot(handles.x/60,handles.news(indx,selchan));
else
    plot(handles.x,handles.news(indx,selchan));
end
guidata(hObject, handles);


% --- Executes on button press in normalize.
function normalize_Callback(hObject, eventdata, handles)
% hObject    handle to normalize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of normalize


% --- Executes on button press in plotbands.
function plotbands_Callback(hObject, eventdata, handles)
% hObject    handle to plotbands (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%t0=str2num(get(handles.t0,'string'));
%in this case the event is the end of sleep dep, which is 2 hours before
%the end of the recording
selchan=get(handles.chanlist,'value');
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));
handles.sr(selchan)=str2num(get(handles.edit14,'string'));
if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end

tevent=str2num(get(handles.tevent,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%news=s(1+round(t0*60)*handles.sr:round((t0+2)*60)*handles.sr,:);%Only 2 hours
%plotting the power and the trace of the whole EEG
winsize=floor(handles.sr(selchan)*fftwindow);
e1=handles.news(1:winsize*floor(length(handles.news)/winsize),get(handles.chanlist,'value'));
e1=e1-mean(e1);
%e1=eegfilter2(e1,6,round(handles.sr(selchan)/3),handles.sr(selchan),0);
% if size(handles.news,2)>3
%     doemg=1;
% else
    doemg=0;
% end
% if doemg emg=handles.news(1:winsize*floor(length(handles.news)/winsize),4);%EMG must be channel 4
% end
%e1=eegfilter(e1,6,0);
%e1=eegfilter(e1,7,0);
%stp=handles.news(:,get(handles.chanlist,'value'));
%stp=eegfilter(stp,0);%get rid of artifacts
%stp=eegfilter(stp,0);
% figure
% subplot(2,1,1)
% p=getthepower(e1,(length(e1)/handles.sr(selchan)),15,0);
% disp('Delta power:')
% delta=getpband(e1,length(handles.news)/handles.sr(selchan),0.5,4)
% disp('power of 0.1-60 Hz band:')
% toSixty=getpband(e1,length(handles.news)/handles.sr(selchan),0.1,60)
%xlabel('Time (s)');
%xlabel('Frequency (Hz)');
% subplot(2,1,2)
% xscl=(0:length(e1)-1)/(60*handles.sr(selchan));
% plot(xscl, e1)
% title('EEG1')
% box off
% xlabel('t (s)')
% ylabel('V')


%using built in function
% figure;
% %[S,F,T,P] = spectrogram(stp,2048,256,2048,handles.sr,'yaxis');
% [S,F,T,P] = spectrogram(stp,2048,256,[0:0.05:20],handles.sr);
% figure
% surf(T,F,10*log10(abs(P)),'edgecolor','none')
% colormap(jet); axis tight;
% view(0,90);
% xlabel('Time'); ylabel('Hz');
%
% figure
% X=0:size(P(:,1))-1;
% Y=0:size(P(:,2))-1;
% surf(X,Y,P,'FaceColor','interp',...
% 	'EdgeColor','none',...
% 	'FaceLighting','phong')
% daspect([5 5 1])
% axis tight
% view(-50,30)
% camlight left


%getthepower(news(:,2),(length(news)/sr),10,1);
%title('EEG2')
% [B,f,t]=specgram(handles.news(:,get(handles.chanlist,'value')),4096,1024,2);
% bmin=max(max(abs(B)))/300;
%imagesc(t,f,20*log10(max(abs(B),bmin)/bmin));
%axis xy;
%colormap(jet);

eeg1=reshape(e1,winsize,length(e1)/winsize);
if doemg
    emg1=reshape(emg,winsize,length(e1)/winsize);
    for jk=1:size(emg1,2)
        rms1(jk)=rms(emg1(:,jk));
    end
    aux=eeg1(:,find(rms1>str2double(get(handles.tmt,'string'))));%selecting the points during quiet for normalization
    eegvec=reshape(aux,1,size(aux,1)*size(aux,2));
    eegvec=sort(eegvec);
    normval=4*std(eegvec);
end
figure
plot(eeg1,'r-')
hold on
if doemg
    eeg1=eeg1/normval;
end
plot(eeg1,'k-')
%eeg2=reshape(e2,sr*fftwindow,floor(length(news)/(sr*fftwindow)));
[c,r]=size(eeg1);
m1=zeros(1,r);
m2=m1;
%ranges for the oscilations
% initial=[0.5];
% final=[4];
initial=[0.5 4 8 15 30 50];
final=[4.5 8 15 30 50 80];

cnt=0;
%tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)/delta'}];
tit=[{'Delta (0.5-2 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];

lim=[0 1];
for i=1:length(initial)
    % disp(char(tit(i)));
    indnot=zeros(1,r);%index of windows twith high MT
    for k=1:r
        
        
        m1(k)=getpband(eeg1(:,k),fftwindow,initial(i),final(i));
        %         if m1(k)>1E-8
        %             m1(k)=0;
        %         end
        %     m2(k)=getpband(eeg2(:,k),fftwindow,initial(i),final(i));
        if i==1
            psig1(k)=rms(eeg1(:,k));
            allpow(:,k)=getthepower(eeg1(:,k),fftwindow,10,0);%This plots eeg and fft of each subtrace
            %    	psig2(k)=rms(eeg2(:,k));
        end
        if doemg
            
            if rms1(k)>str2double(get(handles.tmt,'string'))
                indnot(k)=1;
                if i==1
                    m1(k)=1E-10;%-m1(k);
                else
                    m1(k)=0;
                end
            else
                if psig1(k)>str2double(get(handles.edit15,'string'))
                    indnot(k)=1;
                    if i==1
                        m1(k)=1E-10;%-m1(k);
                    else
                        m1(k)=0;
                    end
                end
            end
            
        end
        
        % m1(k)=getpband(eeg1(:,k),fftwindow,4,4.7);
        %m2(k)=getpband(eeg2(:,k),fftwindow,4,4.7);
        
    end
    cnt=cnt+1;%number of current plot
    %m1=eegfilter(m1,2);
    %m1=eegfilter(m1,2);
    %m1=eegfilter(m1,2);
    t=(0:length(m1)-1)/(60/fftwindow);
    %tevent=[5 10 14 68 114]-t0;%Time of events:saline injection & anestheia tp 0.8, Changing syringes pump,EKG placement, refilling iso tank,injecting SP
    
    %subplot(ceil(length(initial)/2),2,cnt)
    figure
    %     minp=min(m1);%basel(m1);
    %     maxp=max(m1);%ibasel(m1);
    %     minmax=[minp maxp];
    
    plot(t,m1,'k-');
    
    %   hold on
    %
    axis tight
    %    set(gca,'ylim',(1E-10)*[0 8])
    %    deltatime=3600*1/fftwindow;%the last 1 hours to get the max of the figure
        minmax=[0 max(m1)];
      plot(t,m1,'k-',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--')
  
    %plot(t,m1,'k-',[tevent' tevent']',minmax,'g--',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--',[splc splc]',minmax','c--',[eplc eplc]',minmax','c--')
    
    %legend('EEG1','EEG2','saline inj.','Syringes manip.','EKG placement','refilling iso','injecting SP')
    title(char(tit(cnt)),'fontsize',18)
    xlabel('Min.','fontsize',16);
    ylabel('SWA','fontsize',16);
    set(gca,'fontsize',14)
    box off
    %     if doemg
    %         if cnt==1
    %             figure
    % %             subplot(2,1,1)
    % %             plot(t,rms1,'k-')
    % %             set(gca,'fontsize',14)
    % %             xlabel('[min.]','fontsize',18)
    % %             ylabel('RMS','fontsize',18)
    %
    %             %subplot(2,1,2)
    %             plot(t,m1./rms1,'k-')
    %             set(gca,'fontsize',14)
    %             xlabel('[min.]','fontsize',18)
    %             ylabel('SWA/RMS MT','fontsize',18)
    %             axis tight
    %         end
    % %         m1=m1/max(m1);
    % %         m1(find((rms1>1.7E-3) & m1>0.16))=rand/10;
    % %         m1=m1/max(m1);
    %     end
    %     figure
    %
    %         plot(t,m1,'k-')
    %     set(gca,'fontsize',14)
    %     xlabel('[min.]','fontsize',18)
    %     ylabel('Power','fontsize',18)
    
    %disp(mean(m1))
    if i==1
        delta=m1;
    end
end
figure
N = size(eeg1,1); %% number of points
T = fftwindow; %% define time of interval, 3.4 seconds
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
mfft=mean((allpow(:,find(indnot==0)))');
%plot(freq,mfft/max(mfft(1:300)));
plot(freq,mfft);
set(gca,'xlim',[0 15])
title('Mean FFT during quiet')
box off
set(gca,'XTick',1:15)
% figure
% plot(t,rms1)
% title('RMS mt')
figure
plot(t,psig1)
title('RMS eeg')
figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow);
if l>w
    sortedp=sort(allpow,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow=allpow/normf;

allpow=allpow/max(max(allpow));
%allpow(find(allpow>1))=1;
allpow=allpow*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow(1:round(l*limf/(0.5*handles.sr(selchan))),:))
colormap(jet)
sprintf('SWE:%f',sum(m1))
guidata(hObject, handles);







% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
% if get(handles.plots,'value')
%     set(hObject,'SliderStep',[str2num(get(handles.edit4,'string')) 10*str2num(get(handles.edit4,'string'))])
% else
%     set(hObject,'SliderStep',[str2num(get(handles.edit4,'string')) 10*str2num(get(handles.edit4,'string'))]/60)
% end
selchan=get(handles.chanlist,'value');
set(hObject,'Max',length(handles.s)/60)
set(hObject,'Min',0);
axis(handles.axes1);
handles.ltrace=min(handles.dur/60,str2num(get(handles.edit4,'string')));%length in minutes
handles.xi=get(handles.slider1,'value');
handles.x=(handles.xi:handles.xi+(handles.ltrace*handles.sr(selchan))-1);
handles.x=handles.x/60;

%plot(hand,handles.x,handles.news(:,selchan))
set(handles.text17,'string',num2str(get(handles.slider1,'value')))
cla
if get(handles.plotm,'value')
    plot(handles.x/60,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.xi))-1,get(handles.chanlist,'value')))
else
    plot(handles.x,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.xi))-1,get(handles.chanlist,'value')))
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.5 .5 .9]);
end
guidata(hObject, handles);

% --- Executes on button press in savepar.
function savepar_Callback(hObject, eventdata, handles)
% hObject    handle to savepar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
newfn=strcat(handles.fn(1:end-3),'mat')
t0=str2num(get(handles.t0,'string'));
tevent=str2num(get(handles.tevent,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
dur=handles.dur;
save (newfn,'t0','tevent','fftwindow','dur');
helpdlg('Parameters saved')


% --- Executes on button press in plots.
function plots_Callback(hObject, eventdata, handles)
% hObject    handle to plots (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plots
if get(handles.plots,'value')==0
    set(handles.plotm,'value',1)
else
    set(handles.plotm,'value',0)
end
plotm_Callback(hObject, eventdata, handles)



% --- Executes on button press in plotm.
function plotm_Callback(hObject, eventdata, handles)
% hObject    handle to plotm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plotm
selchan=get(handles.chanlist,'value');
axis(handles.axes1);
tl=length(handles.news)/handles.sr(selchan);%total length in s
handles.ltrace=str2num(get(handles.edit4,'string'));%length in s
handles.xi=get(handles.slider1,'value');
handles.x=(handles.xi:handles.xi+(handles.ltrace*handles.sr(selchan))-1)/handles.sr(selchan);
xlabel(handles.h,'s','fontsize',14)
set(handles.slider1,'max',tl);

if get(handles.plotm,'value')==0
    set(handles.plots,'value',1)
else
    set(handles.plots,'value',0)
    %handles.x=handles.x/60;
    set(handles.slider1,'max',tl/60);
    xlabel(handles.h,'min','fontsize',14)
end

%getting the max in the slider



%cla
if get(handles.plotm,'value')
    plot(handles.x/60,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
else
    plot(handles.x,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
end
axis tight
guidata(hObject, handles);




function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double
selchan=get(handles.chanlist,'value');
tf=str2num(get(handles.edit6,'string'));
t0=str2num(get(handles.edit5,'string'));
skip=(t0*60*handles.sr(selchan))+1;
lastp=(tf*60*handles.sr(selchan))+1;
handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
handles.h=handles.axes1;
handles.x=(0:length(handles.news)-1)/handles.sr(selchan);
%handles.x=handles.x/60;
axis(handles.axes1);
cla
plot(handles.x/60,handles.news(:,get(handles.chanlist,'value')))
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double
selchan=get(handles.chanlist,'value');
tf=str2num(get(handles.edit6,'string'));
t0=str2num(get(handles.edit5,'string'));
skip=(t0*60*handles.sr(selchan))+1;
lastp=(tf*60*handles.sr(selchan))+1;
handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
handles.h=handles.axes1;
handles.x=(0:length(handles.news)-1)/handles.sr(selchan);
%handles.x=handles.x/60;
axis(handles.axes1);
cla
plot(handles.x/60,handles.news(:,get(handles.chanlist,'value')))
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
figure
selchan=get(handles.chanlist,'value');
trace=handles.news(:,selchan);%handles.news(max(1,(str2num(get(handles.edit5,'string'))*60*handles.sr(selchan))):min(length(handles.news),floor(str2num(get(handles.edit6,'string'))*60*handles.sr(selchan))),get(handles.chanlist,'value'));
dur=(str2num(get(handles.edit6,'string'))*60)-(str2num(get(handles.edit5,'string'))*60);
getthepower(trace,dur,handles.sr(1)/2,1);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%this plots the EEG and Power before and after an event, leaving a blank in
%between.
%getting the info from gui
selchan=get(handles.chanlist,'value');
start1=str2num(get(handles.edit5,'string'))*60*handles.sr(selchan);
end1=str2num(get(handles.edit6,'string'))*60*handles.sr(selchan);
npoints=end1-start1;
trace1=handles.news(start1:end1,get(handles.chanlist,'value'));
tevent=str2num(get(handles.tevent,'string'))*60*handles.sr(selchan);
lblank=str2num(get(handles.t0,'string'))*60*handles.sr(selchan);
start2=tevent+lblank;
end2=start2+npoints-1;
trace2=handles.news(start2:end2,get(handles.chanlist,'value'));
dur=(str2num(get(handles.edit6,'string'))*60)-(str2num(get(handles.edit5,'string'))*60);
f1=figure;
getthepower(trace1,dur,5,1);
title('Before Injection','fontsize',16)
f2=figure;
getthepower(trace2,dur,5,1);
title('After Injection','fontsize',16)
figs2subplots([f1 f2],[2 2])




function maxf_Callback(hObject, eventdata, handles)
% hObject    handle to maxf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of maxf as text
%        str2double(get(hObject,'String')) returns contents of maxf as a double


% --- Executes during object creation, after setting all properties.
function maxf_CreateFcn(hObject, eventdata, handles)
% hObject    handle to maxf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startpmnt_Callback(hObject, eventdata, handles)
% hObject    handle to startpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startpmnt as text
%        str2double(get(hObject,'String')) returns contents of startpmnt as a double


% --- Executes during object creation, after setting all properties.
function startpmnt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endpmnt_Callback(hObject, eventdata, handles)
% hObject    handle to endpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endpmnt as text
%        str2double(get(hObject,'String')) returns contents of endpmnt as a double


% --- Executes during object creation, after setting all properties.
function endpmnt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endpmnt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startinj_Callback(hObject, eventdata, handles)
% hObject    handle to startinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startinj as text
%        str2double(get(hObject,'String')) returns contents of startinj as a double


% --- Executes during object creation, after setting all properties.
function startinj_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function endinj_Callback(hObject, eventdata, handles)
% hObject    handle to endinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endinj as text
%        str2double(get(hObject,'String')) returns contents of endinj as a double


% --- Executes during object creation, after setting all properties.
function endinj_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endinj (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

f=figure;
selchan=get(handles.chanlist,'value');
t0=str2num(get(handles.t0,'string'));
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

plot(handles.x,handles.news(1:length(handles.x),selchan))
minmax=get(gca,'ylim')
hold on
plot([stinj stinj]',minmax','m--')
plot([einj einj]',minmax','m--')
plot([splc splc]',minmax','c--')
plot([eplc eplc]',minmax','c--')

% if dur>10
%     xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
if tvent>0
    plot([tvent tvent]',minmax','g--')
    
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in sloper.
function sloper_Callback(hObject, eventdata, handles)
% hObject    handle to sloper (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Identifies the prescnece of waves within a range and charactrize the slope
%for early and late phase and positive and negative deflections.
%Steps:
%   1- Filter data in the range of the desired wave
%   2- Find zero corssing and peaks
%   3- Calculate the slopes
selchan=get(handles.chanlist,'value');
if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end
startd=60*handles.sr(selchan)*str2num(get(handles.edit5,'string'));
endd=60*handles.sr(selchan)*str2num(get(handles.edit6,'string'));
stp=handles.s(startd:endd,get(handles.chanlist,'value'));
news=resample(stp,1,5);
news=news-mean(news);
snews=sort(abs(news));
normfactor=snews(round(0.999*length(news)));
news=news./normfactor;
s=1;std(news);
minstd=0.5;
maxstd=2;
% figure
% subplot(2,1,1)
% plot(news)
% subplot(2,1,2)
% plot(stp)
figure
xvec=(0:(length(news)-1))/(handles.sr(selchan)/5);
hold on
plot(xvec,ones(size(news))*minstd*s);
plot(xvec,ones(size(news))*-minstd*s);
plot(xvec,ones(size(news))*maxstd*s,'k-');
plot(xvec,ones(size(news))*-maxstd*s,'k-');

y=diff(sign(news))*max(news)/2;
%plot(y,'r-')
zcrsp=find(y>1E-4);
zcrsn=find(y<-1E-4);
durp=diff(zcrsn)/(handles.sr(selchan)/5);
%plot (news)
minmax=get(gca,'ylim');
indd=find(durp>0.25 & durp<2);
deltamatrix=zeros(length(indd),2*round(handles.sr(selchan)/5));
sampler=handles.sr(selchan)/5;
k=0;
for t=1:length(indd)
    t0=zcrsn(indd(t));
    tf=zcrsn(1+indd(t));
    tm=zcrsp(1+indd(t));
    if tm>tf
        tm=zcrsp(indd(t));
    end
    
    %      if zcrsp(indd(t))>tf
    %         tm=zcrsp(indd(t-1));
    %      elseif zcrsp(indd(t))>t0
    %      tm=zcrsp(indd(t));
    %      else
    %          tm=zcrsp(indd(t+1));
    %      end
    if (max(news(t0:tf))>minstd*s && max(news(t0:tf))<maxstd*s && min(news(t0:tf)>-maxstd*s) )|| (min(news(t0:tf)<-minstd*s) && min(news(t0:tf)>-maxstd*s) && max(news(t0:tf))<maxstd*s)
        k=k+1;
        dto(k)=t0;
        dtm(k)=tm;
        dtf(k)=tf;
        plot(xvec(t0:tf),news(t0:tf),'r-','linewidth',3)
        %centering on the zero crossing tm
        posi=round(sampler)-(tm-t0);
        if posi<1
            posi=1;
        end
        posf=posi+(tf-t0);
        if posf>round(2*sampler)%last point cannot be beyond 2 sec.
            posf=round(2*sampler);
        end
        if posf==100
            deltamatrix(k,posi:posf)=news(t0:t0+(posf-posi));
        else
            deltamatrix(k,posi:posf)=news(t0:tf);
        end
    end
end
deltamatrix=deltamatrix(1:k,:);
plot(xvec,news,'k-')
figure
xvd=(0:size(deltamatrix,2)-1)/(handles.sr(selchan)/5);

plot(xvd,mean(deltamatrix))
fn=strcat(get(handles.filename,'string'),'.mat');
save(fn,'deltamatrix','dto','dtm','dtf','sampler','news')
helpdlg('File saved')
%  sdmx=sort(deltamatrix);
%  nrdm=size(deltamatrix,1);
%  smaller=round(nrdm*0.05);
%  larger=round(nrdm*0.95);
%  plot(xvd,sdmx(smaller,:),'g-')
%  plot(xvd,sdmx(larger,:),'g-')



% --- Executes on button press in compadre.
function compadre_Callback(hObject, eventdata, handles)
% hObject    handle to compadre (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This one compares ch1 and ch2
selchan=get(handles.chanlist,'value');
tvent=str2num(get(handles.tevent,'string'));
stinj=str2num(get(handles.startinj,'string'));
einj=str2num(get(handles.endinj,'string'));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end

tevent=str2num(get(handles.tevent,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%news=s(1+round(t0*60)*handles.sr(selchan):round((t0+2)*60)*handles.sr(selchan),:);%Only 2 hours
%plotting the power and the trace of the whole EEG
selchan=get(handles.chanlist,'value');
% disp('1&2')
% corrcoef(handles.news(:,1),handles.news(:,2))
% disp('1&3')
% corrcoef(handles.news(:,1),handles.news(:,3))
% disp('1&4')
% corrcoef(handles.news(:,1),handles.news(:,4))
% disp('2&3')
% corrcoef(handles.news(:,2),handles.news(:,3))
% disp('2&4')
% corrcoef(handles.news(:,2),handles.news(:,4))
% disp('3&4')
% corrcoef(handles.news(:,3),handles.news(:,4))
newsr=60;
e1=handles.news(1:round(handles.sr(selchan)*fftwindow)*floor(length(handles.news)/(handles.sr(selchan)*fftwindow)),selchan);
e1=subsam(e1,handles.sr(selchan),newsr);

%stp1=handles.news(:,selchan);
e2=handles.news(1:round(handles.sr(selchan)*fftwindow)*floor(length(handles.news)/(handles.sr(selchan)*fftwindow)),selchan+1);
e2=subsam(e2,handles.sr(selchan),newsr);
handles.sr(selchan)=newsr;
%stp2=handles.news(:,1+get(handles.chanlist,'value'));
%e1=eegfilter(e1,2,0);%get rid of artifacts
%e2=eegfilter(e2,2,0);
% e1=eegfilter(e1,5.5,0);%get rid of artifacts
% e2=eegfilter(e2,5.5,0);
%stp1=eegfilter(stp1,0);
%stp2=eegfilter(stp2,0);%get rid of artifacts
%stp2=eegfilter(stp2,0);
figure
subplot(2,1,1)
p=getthepower(e1,(length(e1)/handles.sr(selchan)),20,1);
hold on
p=getthepower(e2,(length(e2)/handles.sr(selchan)),20,1);
% disp('Delta power:')
% delta1=getpband(e1,length(handles.news)/handles.sr(selchan),0.1,4)
% delta2=getpband(e2,length(handles.news)/handles.sr(selchan),0.1,4)
% disp('power of 0.1-60 Hz band:')
% toSixty=getpband(e1,length(handles.news)/handles.sr(selchan),0.1,60)
% toSixty=getpband(e2,length(handles.news)/handles.sr(selchan),0.1,60)
%xlabel('Time (s)');
%xlabel('Frequency (Hz)');
subplot(2,1,2)
cla;
xscl=(0:length(e1)-1)/(60*handles.sr(selchan));
plot(xscl, e1)
hold on
xscl=(0:length(e2)-1)/(60*handles.sr(selchan));

plot(xscl, e2,'r-')
title('EEG1')
box off
xlabel('t (s)')
ylabel('V')


%using built in function
% figure;
% %[S,F,T,P] = spectrogram(stp,2048,256,2048,handles.sr(selchan),'yaxis');
% [S,F,T,P] = spectrogram(stp,2048,256,[0:0.05:20],handles.sr(selchan));
% figure
% surf(T,F,10*log10(abs(P)),'edgecolor','none')
% colormap(jet); axis tight;
% view(0,90);
% xlabel('Time'); ylabel('Hz');
%
% figure
% X=0:size(P(:,1))-1;
% Y=0:size(P(:,2))-1;
% surf(X,Y,P,'FaceColor','interp',...
% 	'EdgeColor','none',...
% 	'FaceLighting','phong')
% daspect([5 5 1])
% axis tight
% view(-50,30)
% camlight left


%getthepower(news(:,2),(length(news)/sr),10,1);
%title('EEG2')
% [B,f,t]=specgram(handles.news(:,get(handles.chanlist,'value')),4096,1024,2);
% bmin=max(max(abs(B)))/300;
%imagesc(t,f,20*log10(max(abs(B),bmin)/bmin));
%axis xy;
%colormap(jet);

eeg1=reshape(e1,round(handles.sr(selchan)*fftwindow),floor(length(e1)/(handles.sr(selchan)*fftwindow)));
eeg2=reshape(e2,round(handles.sr(selchan)*fftwindow),floor(length(e1)/(handles.sr(selchan)*fftwindow)));

%now selecting traces without artifacts for e1 using the number in thres. MT:
inde1=find(max(abs(eeg1))<str2num(get(handles.tmt,'string')));
neweeg1=eeg1(:,inde1);
eeg1=neweeg1;
% inde2=find(max(abs(eeg2))<str2num(get(handles.tmt,'string')));
% neweeg2=eeg2(:,inde2);
eeg2=neweeg1;
figure
t=(0:round(size(eeg1,1)*size(eeg1,2))-1)/(60*handles.sr(selchan));
%plotting the new eeg without artifacts
plot(t,reshape(eeg1,length(t),1))


%eeg2=reshape(e2,sr*fftwindow,floor(length(news)/(sr*fftwindow)));
[c,r]=size(eeg1);
m1=zeros(1,r);
m2=m1;
%ranges for the oscilations
initial=[0.5 4 8 15 30];
final=[4 8 15 30 80];
figure
cnt=0;
tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'Gama (30-80)'}];
lim=[0 1];
for i=1:1%length(initial)
    % disp(char(tit(i)));
    
    for k=1:r
        
        if k<r
            m1(k)=getpband2(eeg1(:,k),eeg1(:,k+1),fftwindow,initial(i),final(i));
            m2(k)=getpband2(eeg2(:,k),eeg2(:,k+1),fftwindow,initial(i),final(i));
        else
            m1(k)=getpband2(eeg1(:,k),eeg1(:,k),fftwindow,initial(i),final(i));
            m2(k)=getpband2(eeg2(:,k),eeg2(:,k),fftwindow,initial(i),final(i));
        end
        %             m1(k)=getpband(eeg1(:,k),fftwindow,initial(i),final(i));
        %             m2(k)=getpband(eeg2(:,k),fftwindow,initial(i),final(i));
    end
    
    if i==1
        psig1(k)=rms(eeg1(:,k));
        psig2(k)=rms(eeg2(:,k));
        allpow1(:,k)=getthepower(eeg1(:,k),fftwindow,10,0);%This plots eeg and fft of each subtrace
        allpow2(:,k)=getthepower(eeg2(:,k),fftwindow,10,0);
        
        %end
        
        
        
        % m1(k)=getpband(eeg1(:,k),fftwindow,4,4.7);
        %m2(k)=getpband(eeg2(:,k),fftwindow,4,4.7);
        
    end
    fm1=medfilt1(m1,5);
    fm2=medfilt1(m2,5);
    cnt=cnt+1;%number of current plot
    %     m1=eegfilter(m1,2);
    %     m1=eegfilter(m1,2);
    %     m2=eegfilter(m2,2);
    %     m2=eegfilter(m2,2);
    t=(0:length(fm1)-1)/(60/fftwindow);
    %tevent=[5 10 14 68 114]-t0;%Time of events:saline injection & anestheia tp 0.8, Changing syringes pump,EKG placement, refilling iso tank,injecting SP
    
    %subplot(2,ceil(length(initial)/2),cnt)
    figure
    minp=min(min(fm1,fm2));%basel(m1);
    maxp=max(max(fm1,fm2));%ibasel(m1);
    minmax=[minp maxp];
    %    plot(t,m1)
    %   hold on
    %
    %   axis tight
    %    set(gca,'ylim',(1E-10)*[0 8])
    %    deltatime=3600*1/fftwindow;%the last 1 hours to get the max of the figure
    %    minmax=[0 max(m1(end-deltatime:end))];
    
    plot(t,fm1,'k-');%,[tevent' tevent']',minmax,'g--',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--',[splc splc]',minmax','c--',[eplc eplc]',minmax','c--')
    hold on
    plot(t,fm2,'r-')
    set(gca,'fontsize',14)
    %set(gca,'xlim',[stinj-30 stinj+30])
    %set(gca,'ylim',minmax)
    %     if i==1
    %         lim=minmax;
    %     end
    %        set(gca,'ylim',lim)
    %          hold on
    %    plot([tinj' tinj'],minmax,'b--')
    legend('Ket. Injection',14)
    xlabel('min','fontsize',18)
    ylabel('Power','fontsize',18)
    
    legend('EEG1','EEG2')
    title(char(tit(cnt)),'fontsize',24)
    
    %disp(mean(m1))
    figure
    minp=min(fm1./fm2);%basel(m1);
    maxp=max(fm1./fm2);%ibasel(m1);
    minmax=[minp maxp];
    plot(t,fm1./fm2,'.--',[tevent' tevent']',minmax,'g--',[stinj stinj]',minmax,'m--',[einj einj]',minmax','m--',[splc splc]',minmax','c--',[eplc eplc]',minmax','c--')
    set(gca,'fontsize',14)
    %set(gca,'xlim',[stinj-30 stinj+30])
    %set(gca,'ylim',minmax)
    %     if i==1
    %         lim=minmax;
    %     end
    %        set(gca,'ylim',lim)
    %          hold on
    %    plot([tinj' tinj'],minmax,'b--')
    %legend('Ket. Injection',14)
    xlabel('min','fontsize',18)
    ylabel('Power Ch1/Ch2','fontsize',18)
    
    %legend('EEG1','EEG2','saline inj.','Syringes manip.','EKG placement','refilling iso','injecting SP')
    title(char(tit(cnt)),'fontsize',24)
    
    if i==1 %Scatter plot for delta for the first 60 min * 6 wind/min = 360 pointa
        figure
        plot(fm1,fm2,'k.')
        hold on
        minmax=get(gca,'ylim');
        plot([0 minmax(2)],[0 minmax(2)],'g--')
        xlabel('Delta Ch1')
        ylabel('Delta Ch2')
    end
    
    
end
figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow1);
if l>w
    sortedp=sort(allpow1,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow1,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow1=allpow1/normf;

allpow1=allpow1/max(max(allpow1));
%allpow(find(allpow>1))=1;
allpow1=allpow1*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow1(1:round(l*limf/(0.5*handles.sr(selchan))),:)')
colormap(jet)
title('CH1')

%Now grouping hte FFts in 8 groups in chronological order.
nw=8;
nsegm=floor(size(allpow1,2)/8);
figure
for i=1:8
    subplot(2,4,i)
    if i==1
        plot(log(mean(allpow1(:,1:nsegm)')))
    else
        plot(log(mean(allpow1(:,(i*nsegm)+1:(i+1)*nsegm)')))
    end
end

figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow2);
if l>w
    sortedp=sort(allpow2,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow2,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow2=allpow2/normf;

allpow2=allpow2/max(max(allpow2));
%allpow(find(allpow>1))=1;
allpow2=allpow2*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow2(1:round(l*limf/(0.5*handles.sr(selchan))),:)')
colormap(jet)
title('CH2')
guidata(hObject, handles);




% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename, pathname] = uigetfile('*.txt', 'Pick the text file to analyze');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid, '%s %s %s %s %s %s %s %s %s %s %s %s %s',17)
for t=2:length(C)
    EDF.Label(t-1)=strcat('ch',num2str(t-1),' ',C{t}(end));
end
disp('Reading file...')
C2 = textscan(fid, '%s %s %f %f %f');
handles.s=[];
set(handles.text15,'string',C2{2}(1))
handles.time0=char(C2{2}(1))
handles.date0=char(C2{1}(1))
for t=3:length(C2)
    %filter EEG making 0 if MT is too high or it goies larger than 5 std
    if get(handles.checkbox3,'value')
        if t-2==1%filter for ch1
            i=find(abs(C2{t+1})>500);
            C2{t}(i)=0;
            i=find(abs(C2{t})>5*std(C2{t}));
            C2{t}(i)=0;
            i=find(abs(C2{t})>5*std(C2{t}));
            C2{t}(i)=0;
            i=find(abs(C2{t})>5*std(C2{t}));
            C2{t}(i)=0;
            
        end
        
    end
    %Lowpass EEG
    if get(handles.checkbox4,'value')
        if t-2==1%filter for ch1
            C2{t}=lowpass2(C2{t});
        end
    end
    handles.news(:,t-2)=C2{t};
end

% figure
% sf=128;
% alm=C2{14};
% veh=C2{12};
% l=length(C2{14});
% subplot(2,1,1)
% x=(0:l-1)/(60*sf);
% plot(x(1:round(l/2)),alm(1:round(l/2)),'k-')
% axis tight
% Title('ALM')
% xlabel('min')
% subplot(2,1,2)
% plot(x(round(l/2):l),veh(round(l/2):l),'k-')
% axis tight
% xlabel('min')
% title('VEH')
% box off
fclose(fid);
set(handles.chanlist,'string',EDF.Label);
nhrs=str2num(get(handles.edit12,'string'));
ls=length(handles.news);

selchan=get(handles.chanlist,'value');
sr=handles.sr(selchan);
handles.sr(selchan)=sr(selchan);
t0=str2num(get(handles.t0,'string'));
tvent=str2num(get(handles.tevent,'string'));
skip=(t0*60*sr)+1;
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

%deleting the data during placement of the internals
ti=round(handles.sr(selchan)*60*splc);
tf=round(handles.sr(selchan)*60*eplc);
%     handles.news(ti:tf,:)=0;
handles.h=handles.axes1;

handles.x=(0:length(handles.news)-1)/(60*sr);
%smart scaling:
% if dur>10
%     handles.x=handles.x*dur;%scale in min.
% else
%     handles.x=handles.x*(dur*60);%scale in s
% end
% if get(handles.plotm,'value')
% end
axis(handles.axes1);
%plot(hand,handles.x,handles.news(:,selchan))
plot(handles.x,handles.news(:,selchan))
hold on
plot(handles.x,5*std(handles.news(:,selchan))*ones(size(handles.news(:,selchan))),'r--')
plot(handles.x,5*std(handles.news(:,selchan))*ones(size(handles.news(:,selchan))),'r--')

% if dur>10
xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
%set(handles.tevent,'string',(length(handles.news)/(60*handles.sr(selchan)))-120);
set(handles.filename,'string',filename);
if tvent>0
    minmax=get(gca,'ylim')
    hold on
    plot([tvent tvent]',minmax','g--')
end


guidata(hObject, handles);



% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
x=handles.news;
[v,nch]=size(x);
% x = randn(10000,6)+(1:1e4)'*ones(1,6); % test data
% x = (1:1e4)'*ones(1,6)/1000; % test data
% x = reshape(mod(1:6e4,100),6,1e4)'; x(:,6)=NaN;

clear HDR;

VER   = version;
cname = computer;

% select file format
%HDR.TYPE='GDF';
HDR.TYPE='EDF';
%HDR.TYPE='BDF';
%HDR.TYPE='CFWB';
%HDR.TYPE='CNT';

% set Filename
HDR.FileName = [handles.fn(1:end-4),'_.',HDR.TYPE];
%HDR.FileName = [handles.fn(1:end-4),VER([1,3]),cname(1:3),'_e1.',HDR.TYPE];
% person identification, max 80 char
HDR.Patient.ID = 'Raton';
HDR.Patient.Sex = 'F';
HDR.Patient.Birthday = [1951 05 13 0 0 0];
HDR.Patient.Name = 'X';		% for privacy protection
HDR.Patient.Handedness = 0; 	% unknown, 1:left, 2:right, 3: equal

% description of recording device
HDR.Manufacturer.Name = 'BioSig';
HDR.Manufacturer.Model = 'demo3.m';
HDR.Manufacturer.Version = '$Revision$';
HDR.Manufacturer.SerialNumber = '666';

% recording identification, max 80 char.
HDR.RID = 'From sleepsign'; %StudyID/Investigation [consecutive number];
HDR.REC.Hospital   = 'NIPS';
HDR.REC.Techician  = 'Lord Inario';
HDR.REC.Equipment  = 'biosig';
HDR.REC.IPaddr	   = [127,0,0,1];	% IP address of recording system
HDR.Patient.Name   = 'anonymous';
HDR.Patient.Id     = '007';
HDR.Patient.Weight = 0; 	% undefined
HDR.Patient.Height = 0; 	% undefined
HDR.Patient.Sex    = 0; 	% 0: undefined,	1: male, 2: female
HDR.Patient.Birthday = zeros(1,6); %    undefined
HDR.Patient.Impairment.Heart = 0;  %	0: unknown 1: NO 2: YES 3: pacemaker
HDR.Patient.Impairment.Visual = 0; %	0: unknown 1: NO 2: YES 3: corrected (with visual aid)
HDR.Patient.Smoking = 0;           %	0: unknown 1: NO 2: YES
HDR.Patient.AlcoholAbuse = 0; 	   %	0: unknown 1: NO 2: YES
HDR.Patient.DrugAbuse = 0; 	   %	0: unknown 1: NO 2: YES
HDR.Patient.Handedness = 0; 	   % 	unknown, 1:left, 2:right, 3: equal

% recording time [YYYY MM DD hh mm ss.ccc]
HDR.T0 =[str2num(handles.date0(1:4)) str2num(handles.date0(6:7)) str2num(handles.date0(9:10)) str2num(handles.time0(1:2)) str2num(handles.time0(4:5)) str2num(handles.time0(7:12))];
%clock;

% number of channels
HDR.NS = nch;

% Duration of one block in seconds
HDR.SampleRate = str2num(get(handles.edit14,'string'));
HDR.SPR = v;
HDR.Dur = HDR.SPR/HDR.SampleRate;

% Samples within 1 block
HDR.AS.SPR = [v;v;v];	% samples per block;
%HDR.AS.SampleRate = [1000;100;200;100;20;0];	% samplerate of each channel

% channel identification, max 80 char. per channel
HDR.Label=get(handles.chanlist,'string');%{'chan 1  ';'chan 2  ';'chan 3  ';'chan 4  ';'chan 5  ';'chan 6  ';'chan 7  ';'chan 8  '};

% Transducer, mx 80 char per channel
HDR.Transducer = {'Ag-AgCl ';'Ag-AgCl ';'Ag-AgCl '};

% define datatypes (GDF only, see GDFDATATYPE.M for more details)
HDR.GDFTYP = 3*ones(1,HDR.NS);

% define scaling factors
HDR.PhysMax = [10;10; 0.001];
HDR.PhysMin =-[10;10; 0];% -10*ones(nch,1);
HDR.DigMax  = ones(nch,1);
HDR.DigMin  = zeros(nch,1);
HDR.Filter.Lowpass = 0.5*ones(nch,1);
HDR.Filter.Highpass = 45*ones(nch,1);
HDR.Filter.Notch = zeros(nch,1);


% define physical dimension
%HDR.PhysDim
HDR.PhysDim = {'V';'V';'V'};
disp(num2str(size(HDR.PhysDim)));
HDR.Impedance = ones(nch,1);         % electrode impedance (in Ohm) for voltage channels
HDR.fZ = ones(nch,1); ;                % probe frequency in Hz for Impedance channel

t = [10:10:size(x,1)]';
%HDR.NRec = 100;
HDR.VERSION = 2.21;        % experimental
HDR = sopen(HDR,'w');
%HDR.SIE.RAW = 0; % [default] channel data mode, one column is one channel
%HDR.SIE.RAW = 1; % switch to raw data mode, i.e. one column for one EDF-record

HDR = swrite(HDR,x);

HDR.EVENT.POS = t;
HDR.EVENT.TYP = t/100;
if 1,
    HDR.EVENT.CHN = repmat(0,size(t));
    HDR.EVENT.DUR = repmat(1,size(t));
    HDR.EVENT.VAL = repmat(NaN,size(t));
    ix = 6:5:60;
    HDR.EVENT.CHN(ix) = 6;
    HDR.EVENT.VAL(ix) = 373+round(100*rand(size(ix))); % HDR.EVENT.TYP(ix) becomes 0x7fff
    ix = 8;
    HDR.EVENT.CHN(ix) = 5; % not valid because #5 is not sparse sampleing
    HDR.EVENT.VAL(ix) = 374;
end;

HDR = sclose(HDR);


%
[s0,HDR0] = sload(HDR.FileName);	% test file

HDR0=sopen(HDR0.FileName,'r');
[s0,HDR0]=sread(HDR0);
HDR0=sclose(HDR0);
% plot(s0-x)





function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double
selchan=get(handles.chanlist,'value');
handles.sr(selchan)=str2double(get(hObject,'String'));
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton11. %reads and merge text files
% with EDF for Anushka
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This merges the current EDf file with data extracted from a txt file with a fix configuration.
%Steps:
%1- extract initial time of EDF
%2- Sync clock with system time ms by pairing the ms value witht he first
%time in the longest series of events happening within the same seccond.
%3- make nil vectors with Correct	Incorrect	CausedReward
%CausedPunishment and fill ones at the corresponding time with ms
%precision.
%Save original EDF with this 4 new vectors added

EDF=handles.hedf;
HDR0=sopen(strcat(EDF.FILE.Name,'.',EDF.FILE.Ext),'r');
HDR=HDR0;
HDR0 = sclose(HDR0);
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the rsults');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
k=0;
nlabels= size(EDF.Label,1);
%Editing the fields of the EDf file, starting by the ch. Labels
selchan=get(handles.chanlist,'value');
for t=length(C)-3:length(C)
    k=k+1;
    HDR.Label{nlabels+k}=char(C{t});%Add data labels in the EDF
    HDR.PhysDim{nlabels+k}='Bin';
    HDR.PhysMin(nlabels+k)=min(HDR.PhysMin);
    HDR.PhysMax(nlabels+k)=1;
    HDR.DigMin(nlabels+k)=min(HDR.DigMin);%EDF.DigMin(nlabels);
    HDR.DigMax(nlabels+k)=1;%EDF.DigMax(nlabels);
    HDR.PhysDimCode(nlabels+k)=0;
    HDR.THRESHOLD(nlabels+k,:)=HDR.THRESHOLD(nlabels,:);
    HDR.Transducer{nlabels+k}=HDR.Transducer{nlabels};
    %HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));
    
    HDR.Cal(nlabels+k)=1;
    HDR.Off(nlabels+k)=0;
end

disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %s %s %f %f %f %s %s %s %s');
%Get the timing to synchronize files
strgtime=char(C2{5});
vecsec=3600*str2num(strgtime(:,2:3))+60*str2num(strgtime(:,5:6))+str2num(strgtime(:,8:9));
[v,p]=mode(vecsec);
indvec=find(vecsec==v);%The timing of indvec(1) will be used to sync seconds and ms
sect0=3600*EDF.T0(4)+60*EDF.T0(5)+EDF.T0(6);
msect0= C2{6}(indvec(1))-1000*(vecsec(indvec(1))-sect0);%This is the first milisecond
msectf=msect0+1000*round(size(handles.s,1)/handles.sr(selchan));
tvect=(msectf-msect0)*((0:size(handles.s,1)-1)/(size(handles.s,1)-1));%tvect has the same number of data points than the data but they have the ms
tvect=tvect+msect0;
%tvect=msect0:2:C2{6}(end);
%tvect=msect0:2:msect0+2*size(handles.s,1)-1;%this is wrong
%Now generating the data to be merged:
disp('Generating data...')
%Getting the time in ms of the 'Y'(1) and 'N'(0) else 0.5.
v1=0.5 *ones(1,length(tvect));
v2=0.5 *ones(1,length(tvect));
v3=0.5 *ones(1,length(tvect));
v4=0.5 *ones(1,length(tvect));

ind=find(char(C2{9})=='Y');
t1=C2{6}(ind);
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    v1(p)=1;
end
disp('...')
ind=find(char(C2{9})=='N');
t1=C2{6}(ind);
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    v1(p)=0;
end
disp('...')
ind=find(char(C2{10})=='Y');
t2=C2{6}(ind);
for i=1:length(t2)
    [v,p]=min(abs(tvect-t2(i)));
    v2(p)=1;
end
disp('...')
ind=find(char(C2{10})=='N');
t2=C2{6}(ind);
for i=1:length(t2)
    [v,p]=min(abs(tvect-t2(i)));
    v2(p)=0;
end
disp('...')
ind=find(char(C2{11})=='Y');
t3=C2{6}(ind);
for i=1:length(t3)
    [v,p]=min(abs(tvect-t3(i)));
    v3(p)=1;
end
disp('...')
ind=find(char(C2{11})=='N');
t3=C2{6}(ind);
for i=1:length(t3)
    [v,p]=min(abs(tvect-t3(i)));
    v3(p)=0;
end

disp('...')

ind=find(char(C2{12})=='Y');
t4=C2{6}(ind);
for i=1:length(t4)
    [v,p]=min(abs(tvect-t4(i)));
    v4(p)=1;
end
disp('One More...')
ind=find(char(C2{12})=='N');
t4=C2{6}(ind);
for i=1:length(t4)
    [v,p]=min(abs(tvect-t4(i)));
    v4(p)=0;
end
disp('...')
beep
osize=size(handles.s,2);%The original number of sgnals
handles.s=[handles.s v1' v2' v3' v4'];
fclose(fid);
nlabels=nlabels+4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now reading the second file:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with stim time');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
%Editing the fields of the EDf file, starting by the ch. Labels
%Adding one more signals to the EDF: the stim. time and type
HDR.Label{nlabels+1}=char(C{t});%Add data labels in the EDF
HDR.PhysDim{nlabels+1}='Int';
HDR.PhysMin(nlabels+1)=min(HDR.PhysMin);
HDR.PhysMax(nlabels+1)=max(HDR.PhysMax);
HDR.DigMin(nlabels+1)=min(HDR.DigMin);%EDF.DigMin(nlabels);
HDR.DigMax(nlabels+1)=1;%EDF.DigMax(nlabels);
HDR.PhysDimCode(nlabels+1)=0;
HDR.THRESHOLD(nlabels+1,:)=HDR.THRESHOLD(nlabels,:);
HDR.Transducer{nlabels+1}=HDR.Transducer{nlabels};
%HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));

HDR.Cal(nlabels+1)=1;
HDR.Off(nlabels+1)=0;
HDR.FILE.Name=strcat(EDF.FILE.Name,'mrgd');
HDR.FileName=strcat(pathname,HDR.FILE.Name,'.',HDR.FILE.Ext);
HDR.reserved1='EDF merged with behavioral data';

disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %f %f %f %s %f %f %s %s %f %f %s %s %s %s %s %s %s %f %f %f %f %f %s');

%Now generating the data to be merged (columns 6  and 7):
disp('Generating data...')
%sa=char(C2{7});
%Getting the time in ms of the stim, that can be Yellow_rectangle, Blue_rectangle and White_rectangle
stim=zeros(1,length(tvect));
ind=find(strcmp(C2{7},'Yellow_rectangle'));
t1=C2{6}(ind);%times of stim 1
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    stim(p)=0.25;
end

ind=find(strcmp(C2{7},'Blue_rectangle'));
t1=C2{6}(ind);%times of stim 1
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    stim(p)=0.5;
end

ind=find(strcmp(C2{7},'White_rectangle'));
t1=C2{6}(ind);%times of stim 1
for i=1:length(t1)
    [v,p]=min(abs(tvect-t1(i)));
    stim(p)=0.75;
end

handles.s=[handles.s stim'];

figure
subplot(6,1,1)
plot(tvect/1000,handles.s(:,2))
ylabel(HDR.Label(2,:))
subplot(6,1,2)
plot(tvect/1000,handles.s(:,osize+1),'k.-')
ylabel(HDR.Label(osize+1,:))
subplot(6,1,3)
plot(tvect/1000,handles.s(:,osize+2),'k.-')
ylabel(HDR.Label(osize+2,:))
subplot(6,1,4)
plot(tvect/1000,handles.s(:,osize+3),'k.-')
ylabel(HDR.Label(osize+3,:))
subplot(6,1,5)
plot(tvect/1000,handles.s(:,osize+4),'k.-')
ylabel(HDR.Label(osize+4,:))
subplot(6,1,6)
plot(tvect/1000,handles.s(:,osize+5),'k.-')
ylabel(HDR.Label(osize+5,:))


fclose(fid);
disp('saving...')
data=handles.s';
[nch,v]=size(data);
HDR.Dur = HDR.SPR/EDF.SampleRate;
VER   = version;
cname = computer;

% select file format
HDR.TYPE='EDF';
% number of channels
HDR.NS = nch;
HDR.GDFTYP=3*ones(1,nch);

% Duration of one block in seconds
HDR.Dur = HDR.SPR/HDR.SampleRate;

HDR.VERSION = 2.21;        % experimental
HDR.InChanSelect=1:nch;
HDR.LeadIdCode=NaN*ones(nch,1)
HDR=rmfield(HDR,'AS')
HDR = sopen(HDR,'w');
HDR = swrite(HDR,data');
HDR = sclose(HDR);
helpdlg('Done!')
guidata(hObject, handles);



% --- Executes on button press in compbands.
function compbands_Callback(hObject, eventdata, handles)
% hObject    handle to compbands (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selchan=get(handles.chanlist,'value');
if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end

fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%plotting the power and the trace of the whole EEG
winsize=floor(handles.sr(selchan)*fftwindow);
e1=handles.news(1:winsize*floor(length(handles.news)/winsize),get(handles.chanlist,'value'));
e2=handles.news(1:winsize*floor(length(handles.news)/winsize),1+get(handles.chanlist,'value'));
e1=eegfilter(e1,7);
e2=eegfilter(e2,7);

%Zeroing the first minute:
% e1(1:round(60*handles.sr(selchan)))=0;
% e2(1:round(60*handles.sr(selchan)))=0;
% stp=handles.news(:,get(handles.chanlist,'value'));
% stp=eegfilter(stp,0);%get rid of artifacts
% stp=eegfilter(stp,0);
figure
subplot(2,1,1)
p=getthepowerc(e1,(length(e1)/handles.sr(selchan)),20,1,'k-');
hold on
p2=getthepowerc(e2,(length(e1)/handles.sr(selchan)),20,1,'r-');
legend('Ch1','Ch2')
disp('Delta power:')
delta=getpband(e1,length(e1)/handles.sr(selchan),0.5,5)
% disp('power of 0.1-60 Hz band:')
% toSixty=getpband(e1,length(handles.news)/handles.sr(selchan),0.1,60)
%xlabel('Time (s)');
%xlabel('Frequency (Hz)');
subplot(2,1,2)
xscl=(0:length(e1)-1)/(60*handles.sr(selchan));
plot(xscl, e1)
title('EEG1')
box off
xlabel('t (s)')
ylabel('V')
eeg1=reshape(e1,winsize,length(e1)/winsize);
eeg2=reshape(e2,winsize,length(e2)/winsize);
[c,r]=size(eeg1);
m1=zeros(1,r);
m2=m1;
%ranges for the oscilations
initial=[0.5 5];
final=[5 8];
figure
cnt=0;
tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
initial=[0.5 4 8 15 30 50];
final=[4 8 15 30 50 80];
lim=[0 1];
for i=1:length(initial)
    % disp(char(tit(i)));
    
    for k=1:r
        
        
        m1(k)=getpband(eeg1(:,k),fftwindow,initial(i),final(i));
        m2(k)=getpband(eeg2(:,k),fftwindow,initial(i),final(i));
        if i==1
            psig1(k)=rms(eeg1(:,k));
            allpow1(:,k)=getthepower(eeg1(:,k),fftwindow,20,0);
            psig2(k)=rms(eeg2(:,k));
            allpow2(:,k)=getthepower(eeg2(:,k),fftwindow,20,0);
        end
        
    end
    cnt=cnt+1;%number of current plot
    %     m1=eegfilter(m1,2);
    %     m1=eegfilter(m1,2);
    %     m1=eegfilter(m1,2);
    t=(0:length(m1)-1)/(60/fftwindow);
    %tevent=[5 10 14 68 114]-t0;%Time of events:saline injection & anestheia tp 0.8, Changing syringes pump,EKG placement, refilling iso tank,injecting SP
    
    %subplot(2,ceil(length(initial)/2),cnt)
    figure
    minp=min(m1);%basel(m1);
    maxp=max(m1);%ibasel(m1);
    minmax=[minp maxp];
    plot(t,m1,'k-')
    hold on
    plot(t,m2,'r-')
    set(gca,'fontsize',14)
    xlabel('[min.]','fontsize',18)
    ylabel('Power','fontsize',18)
    title(char(tit(cnt)),'fontsize',24)
    legend('Ch1','Ch2')
    box off
    i=find(m2<=0);
    m2(i)=0.000001;
    figure
    minp=min(m1./m2);%basel(m1);
    maxp=max(m1./m2);%ibasel(m1);
    minmax=[minp maxp];
    plot(t,m1./m2,'k-')
    set(gca,'fontsize',14)
    xlabel('[min.]','fontsize',18)
    ylabel('Power ratio','fontsize',18)
    title(char(tit(cnt)),'fontsize',24)
    legend('Ch1/Ch2')
    box off
    
    %disp(mean(m1))
end
figure
axis off
%normalizing the matrix for imaging it using the 5% of max vals
[l,w]=size(allpow1);
if l>w
    sortedp=sort(allpow1,1);
    normf=max(sortedp(round(0.95*l),:));
else
    sortedp=sort(allpow1,2);
    normf=max(sortedp(:,round(0.95*w)));
end
allpow1=allpow1/normf;

allpow=allpow1/max(max(allpow1));
%allpow(find(allpow>1))=1;
allpow=allpow*400;
limf=str2num(get(handles.maxf,'string'));%curring the power to the max freq from gui
image(allpow(1:round(l*limf/(0.5*handles.sr(selchan))),:)')
colormap(jet)
title('Heatmap for Ch1')
guidata(hObject, handles);


% --- Executes on button press in filter.
function filter_Callback(hObject, eventdata, handles)
% hObject    handle to filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selchan=get(handles.chanlist,'value');
if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end
winsize=4;%analizing 4 seconds around stim presentation (2 before and 2 after)
stepsize=0.25;
winsize=winsize+2*stepsize;
%actually the first point should be from 2.25 before until 1.75 before and
%the last from 1.75 after to 2.25 after, since every chunk is 0.5 s.
e1=handles.news(:,get(handles.chanlist,'value'));
handles.news(:,end)=round(100*handles.news(:,end))/100;
%identifying the position of the events
posg1=find(handles.news(:,end-3)==1);
posg2=find(handles.news(:,end-2)==1);
posg3=find(handles.news(:,end-1)==1);
posg4=find(handles.news(:,end)==1);
%ignoring events when EEG was too high
newposg1=[];
newposg2=[];
newposg3=[];
newposg4=[];

disp('thres:')
%thres=5*std(e1)
figure
x=(0:length(e1)-1)/handles.sr(selchan);
plot(x,e1)
box off
minmax=get(gca,'ylim');
ind1=posg1/handles.sr(selchan);
ind2=posg2/handles.sr(selchan);
ind3=posg3/handles.sr(selchan);
ind4=posg4/handles.sr(selchan);


hold on
plot([ind1 ind1],minmax,'g--')
plot([ind2 ind2],minmax,'b--')
plot([ind3 ind3],minmax,'r--')
plot([ind4 ind4],minmax,'k--')
% strarr=(get(handles.chanlist,'string'));
% legend(strarr(:,end-4:end))

thres=1.7E-4;
k=0;
linf=(winsize/2);%We add at each side of the window 0.25 s
for i=1:length(posg1)
    if max(abs(e1(floor(posg1(i)-linf*handles.sr(selchan)):ceil(posg1(i)+linf*handles.sr(selchan)-1))))<thres
        k=k+1;
        newposg1(k)=posg1(i);
    end
end

k=0;
for i=1:length(posg2)
    if max(abs(e1(floor(posg2(i)-linf*handles.sr(selchan)):ceil(posg2(i)+linf*handles.sr(selchan)-1))))<thres
        k=k+1;
        newposg2(k)=posg2(i);
    end
end

k=0;
for i=1:length(posg3)
    if max(abs(e1(floor(posg3(i)-linf*handles.sr(selchan)):ceil(posg3(i)+linf*handles.sr(selchan)-1))))<thres
        k=k+1;
        newposg3(k)=posg3(i);
    end
end

k=0;
for i=1:length(posg4)
    if max(abs(e1(floor(posg4(i)-linf*handles.sr(selchan)):ceil(posg4(i)+linf*handles.sr(selchan)-1))))<thres
        k=k+1;
        newposg4(k)=posg4(i);
    end
end

mateeg1=zeros(ceil((winsize)*handles.sr(selchan)),length((newposg1)));
mateeg2=zeros(ceil((winsize)*handles.sr(selchan)),length((newposg2)));
mateeg3=zeros(ceil((winsize)*handles.sr(selchan)),length((newposg3)));
mateeg4=zeros(ceil((winsize)*handles.sr(selchan)),length((newposg4)));

s=size(mateeg1);
switch get(handles.chanlist,'value')
    case 1
        cd eeg1
    case 2
        cd eeg2
    case 3
        cd eeg3
end
r1=length(newposg1)
if r1>1
    for i=1:r1
        mateeg1(:,i)=e1(floor(newposg1(i)-linf*handles.sr(selchan)):ceil(newposg1(i)-linf*handles.sr(selchan))+s(1)-1);
    end
else
    mateeg1=0;
end


s=size(mateeg2);
r2=length(newposg2)
if r2>1
    for i=1:r2
        mateeg2(:,i)=e1(floor(newposg2(i)-linf*handles.sr(selchan)):ceil(newposg2(i)-linf*handles.sr(selchan))+s(1)-1);
    end
else
    mateeg2=0;
end

s=size(mateeg3);
r3=length(newposg3)
if r3>1
    for i=1:r3
        mateeg3(:,i)=e1(floor(newposg3(i)-linf*handles.sr(selchan)):ceil(newposg3(i)-linf*handles.sr(selchan))+s(1)-1);
    end
else
    mateeg3=0;
end

s=size(mateeg4);
r4=length(newposg4)
if r4>1
    for i=1:r4
        mateeg4(:,i)=e1(floor(newposg4(i)-linf*handles.sr(selchan)):ceil(newposg4(i)-linf*handles.sr(selchan))+s(1)-1);
    end
else
    mateeg4=0;
end

figure
plot(mateeg1)
title('mateeg1')
figure
plot(mateeg2)
title('mateeg2')
figure
plot(mateeg3)
title('mateeg3')
figure
plot(mateeg4)
title('mateeg4')

%Now getting the rms of the signal filtered in the different bands. First,
%LG only
wsize=0.1;
ny=bandpassfilter(mateeg1,handles.sr(selchan),[30 50]);
figure;
t=(winsize*(0:length(ny)-1)/(length(ny)-1))-(winsize/2);
plot(t,(ny'))
figure
plot(t,mean(abs(ny')),'k-')
minmax=get(gca,'ylim');
hold on
plot([0 0],minmax,'g--')
for w=1:size(mateeg1,2)
    aux=ny(1:floor(wsize*handles.sr(selchan))*floor(length(mateeg1)/(wsize*handles.sr(selchan))),w);
    nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(mateeg1)/(wsize*handles.sr(selchan))));
    rmsm1(w,:)=rms(nm);
end
mm=mean(rmsm1);
%figure
nt=(winsize*(0:length(mm)-1)/(length(mm)-1))-(winsize/2);
plot(nt,mm,'r.-')
hold on
minmax=get(gca,'ylim');
plot([0 0],minmax,'r--')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now getting the powerbands
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tevent=str2num(get(handles.tevent,'string'));
%fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
chlstrings=get(handles.chanlist,'string');
cnt=0;
tit=[{'Theta (4-8 Hz)'},{'Alpha (8-12 Hz)'},{'Beta (16-24 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%tit=[{'Delta (0.5-4 Hz)'},{'Theta (4-8 Hz)'},{'Alpha (8-15 Hz)'},{'Beta (15-30 Hz)'},{'LowG (30-50)'},{'High G (50-80)'}];
%initial=[0.5 4 8 15 30 50];
%final=[4 8 15 30 50 80];
initial=[4 8 16 30 50];
final=[8 12 24 50 80];
%lim=[0 1];
%time1=round(handles.sr(selchan)/2);
npoints=winsize/stepsize;
%number of points for the plots showing the average power at different frequency bands. The power will be calculated with two segments with 50% overlap
m1=[];
m2=[];
m3=[];
m4=[];
for i=1:length(initial)
    cnt=cnt+1;
    figure
    if r1>1
        
        for k=1:r1
            trace=mateeg1(:,k);
            lt=length(trace);
            trace=trace(1:npoints*floor(lt/npoints));
            trs=reshape(trace,floor(lt/npoints),npoints);
            
            for ki=1:npoints-1
                if ki<npoints
                    m1(ki,k)=getpband3([trs(:,ki)' trs(:,ki+1)'],2*winsize/npoints,initial(i),final(i));
                else
                    m1(ki,k)=getpband3(trs(:,ki)',winsize/npoints,initial(i),final(i));%Not used for now
                end
            end
            
            
        end
        %cnt=cnt+1;%number of current plot
        %     t=(0:length(m1)-1)/(60/fftwindow);
        subplot(2,2,1)
        x0=[-linf:winsize/npoints:linf];
        %now skipping the zero
        x=x0(2:end-1);
        errorbar(x,mean(m1'),sem(m1'),'k-');
        hold on
        plot(x,mean(m1'),'ko-','linewidth',2)
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(5,:),' N=',num2str(r1)))
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
        
        %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(5,:),'.txt');
        m1t=m1';
        save(fname,'m1t','-ascii')
        axis tight
        set(gca,'xlim',[-2 2])
    end
    
    if r2>1
        
        for k=1:r2
            trace=mateeg2(:,k);
            lt=length(trace);
            trace=trace(1:npoints*floor(lt/npoints));
            trs=reshape(trace,floor(lt/npoints),npoints);
            
            for ki=1:npoints-1
                if ki<npoints
                    m2(ki,k)=getpband3([trs(:,ki)' trs(:,ki+1)'],2*winsize/npoints,initial(i),final(i));
                else
                    m2(ki,k)=getpband3(trs(:,ki)',winsize/npoints,initial(i),final(i));
                end
            end
        end
        %cnt=cnt+1;%number of current plot
        %     t=(0:length(m1)-1)/(60/fftwindow);
        subplot(2,2,2)
        x0=[-linf:winsize/npoints:linf];
        %now skipping the zero
        x=x0(2:end-1);
        errorbar(x,mean(m2'),sem(m2'),'k-');
        hold on
        plot(x,mean(m2'),'ko-','linewidth',2)
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(6,:),' N=',num2str(r2)))
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
        
        %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(6,:),'.txt');
        m2t=m2';
        save(fname,'m2t','-ascii')
        axis tight
        set(gca,'xlim',[-2 2])
    end
    
    if r3>1
        for k=1:r3
            trace=mateeg3(:,k);
            lt=length(trace);
            trace=trace(1:npoints*floor(lt/npoints));
            trs=reshape(trace,floor(lt/npoints),npoints);
            
            for ki=1:npoints-1
                if ki<npoints
                    m3(ki,k)=getpband3([trs(:,ki)' trs(:,ki+1)'],2*winsize/npoints,initial(i),final(i));
                else
                    m3(ki,k)=getpband3(trs(:,ki)',winsize/npoints,initial(i),final(i));
                end
            end
            
            
        end
        %cnt=cnt+1;%number of current plot
        %     t=(0:length(m1)-1)/(60/fftwindow);
        subplot(2,2,3)
        x0=[-linf:winsize/npoints:linf];
        %now skipping the zero
        x=x0(2:end-1);
        errorbar(x,mean(m3'),sem(m3'),'k-');
        hold on
        plot(x,mean(m3'),'ko-','linewidth',2)
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(7,:),' N=',num2str(r3)))
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
        
        %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(7,:),'.txt');
        m3t=m3';
        save(fname,'m3t','-ascii')
        axis tight
        set(gca,'xlim',[-2 2])
    end
    
    if r4>1
        for k=1:r4
            trace=mateeg4(:,k);
            lt=length(trace);
            trace=trace(1:npoints*floor(lt/npoints));
            trs=reshape(trace,floor(lt/npoints),npoints);
            
            for ki=1:npoints-1
                if ki<npoints
                    m4(ki,k)=getpband3([trs(:,ki)' trs(:,ki+1)'],2*winsize/npoints,initial(i),final(i));
                else
                    m4(ki,k)=getpband3(trs(:,ki)',winsize/npoints,initial(i),final(i));
                end
            end
            
            
        end
        %cnt=cnt+1;%number of current plot
        %     t=(0:length(m1)-1)/(60/fftwindow);
        subplot(2,2,4)
        x0=[-linf:winsize/npoints:linf];
        %now skipping the zero
        x=x0(2:end-1);
        errorbar(x,mean(m4'),sem(m4'),'k-');
        hold on
        plot(x,mean(m4'),'ko-','linewidth',2)
        set(gca,'fontsize',14)
        xlabel('s','fontsize',18)
        ylabel('Mean Power','fontsize',18)
        title(char(tit(cnt)),'fontsize',24)
        legend(strcat(chlstrings(8,:),' N=',num2str(r4)))
        minmax=get(gca,'ylim');
        plot([tevent' tevent']',minmax,'g--')
        
        %now saving data in ascii
        tname=char(tit(cnt));
        fname=strcat(tname(1:4),chlstrings(8,:),'.txt');
        m4t=m4';
        save(fname,'m4t','-ascii')
        axis tight
        set(gca,'xlim',[-2 2])
    end
    
end
cd ..
disp([r1 r2 r3 r4]);






% --- Executes on button press in merge.
function merge_Callback(hObject, eventdata, handles)
% hObject    handle to merge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This merges the current EDf file with data extracted from a txt file with a fix configuration.
%Steps:
%1- extract initial time of EDF with second file
%2- Sync clock with system time ms by pairing the ms value witht he first
%time in the most spread series of events happening within the same seccond.
%3- make nil vectors with Correct	Incorrect	CausedReward
%CausedPunishment and fill ones at the corresponding time with ms
%precision using the data form the other text file.
%Save original EDF with this 4 new vectors added

EDF=handles.hedf;
HDR0=sopen(strcat(EDF.FILE.Name,'.',EDF.FILE.Ext),'r');
HDR=HDR0;
HDR0 = sclose(HDR0);
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the timing');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
k=0;
nlabels= size(EDF.Label,1);
%Editing the fields of the EDf file, starting by the ch. Labels


disp('Reading text file with timing info...')
C2 = textscan(fid, '%f %f %f %s %s %f %f %f %s %s %s %s');
%Get the timing to synchronize files
strgtime=char(C2{5});
vecsec=3600*str2num(strgtime(:,2:3))+60*str2num(strgtime(:,5:6))+str2num(strgtime(:,8:9));
[v,p]=mode(vecsec);
indvec=find(vecsec==v);%The timing of indvec(1) will be used to sync seconds and ms
sect0=3600*EDF.T0(4)+60*EDF.T0(5)+EDF.T0(6);
msect0= C2{6}(indvec(1))-1000*(vecsec(indvec(1))-sect0);%This is the first milisecond
msectf=msect0+1000*round(size(handles.s,1)/handles.sr(selchan));
tvect=(msectf-msect0)*((0:size(handles.s,1)-1)/(size(handles.s,1)-1));%tvect has the same number of data points than the data but they have the ms
tvect=tvect+msect0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Now reading the text file with data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with stim time');
handles.fn=filename;
handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
%Editing the fields of the EDf file, starting by the ch. Labels
k=0;
for t=15:18
    k=k+1;
    HDR.Label{nlabels+k}=char(C{t});%Add data labels in the EDF
    HDR.PhysDim{nlabels+k}='Bin';
    HDR.PhysMin(nlabels+k)=min(HDR.PhysMin);
    HDR.PhysMax(nlabels+k)=1;
    HDR.DigMin(nlabels+k)=min(HDR.DigMin);%EDF.DigMin(nlabels);
    HDR.DigMax(nlabels+k)=1;%EDF.DigMax(nlabels);
    HDR.PhysDimCode(nlabels+k)=0;
    HDR.THRESHOLD(nlabels+k,:)=HDR.THRESHOLD(nlabels,:);
    HDR.Transducer{nlabels+k}=HDR.Transducer{nlabels};
    %HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));
    
    HDR.Cal(nlabels+k)=1;
    HDR.Off(nlabels+k)=0;
end


%Adding one more signals to the EDF: the stim. time and type
%     HDR.Label{nlabels+1}=char(C{t});%Add data labels in the EDF
%     HDR.PhysDim{nlabels+1}='Int';
%     HDR.PhysMin(nlabels+1)=min(HDR.PhysMin);
%     HDR.PhysMax(nlabels+1)=max(HDR.PhysMax);
%     HDR.DigMin(nlabels+1)=min(HDR.DigMin);%EDF.DigMin(nlabels);
%     HDR.DigMax(nlabels+1)=1;%EDF.DigMax(nlabels);
%     HDR.PhysDimCode(nlabels+1)=0;
%     HDR.THRESHOLD(nlabels+1,:)=HDR.THRESHOLD(nlabels,:);
%     HDR.Transducer{nlabels+1}=HDR.Transducer{nlabels};
%HDR.SPR(nlabels+k)=max(EDF.SPR(nlabels));

%     HDR.Cal(nlabels+1)=1;
%     HDR.Off(nlabels+1)=0;
HDR.FILE.Name=strcat(EDF.FILE.Name,'mrgd');
HDR.FileName=strcat(pathname,HDR.FILE.Name,'.',HDR.FILE.Ext);
HDR.reserved1='EDF merged with behavioral data';

disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %f %f %f %s %f %f %s %s %f %f %s %s %s %s %s %s %s %f %f %f %f %f %s');

%Now generating the data to be merged (columns 15 - 18):
disp('Generating data...')
%sa=char(C2{7});
%Getting the time in ms of the stim, that can be Yellow_rectangle, Blue_rectangle and White_rectangle
stim=zeros(4,length(tvect));
for k=1:4
    ind=find(strcmp(C2{k+14},'Y'));
    t1=C2{6}(ind);%times of stim 1
    for i=1:length(t1)
        [v,p]=min(abs(tvect-t1(i)));
        stim(k,p)=1;
    end
end
osize=size(handles.s,2);%The original number of sgnals
handles.s=[handles.s stim'];

figure
subplot(5,1,1)
plot(tvect/1000,handles.s(:,2))
ylabel(HDR.Label(2,:))
subplot(5,1,2)
plot(tvect/1000,handles.s(:,osize+1),'k.-')
ylabel(HDR.Label(osize+1,:))
subplot(5,1,3)
plot(tvect/1000,handles.s(:,osize+2),'k.-')
ylabel(HDR.Label(osize+2,:))
subplot(5,1,4)
plot(tvect/1000,handles.s(:,osize+3),'k.-')
ylabel(HDR.Label(osize+3,:))
subplot(5,1,5)
plot(tvect/1000,handles.s(:,osize+4),'k.-')
ylabel(HDR.Label(osize+4,:))



fclose(fid);
disp('saving...')
data=handles.s';
[nch,v]=size(data);
HDR.Dur = HDR.SPR/EDF.SampleRate;
VER   = version;
cname = computer;

% select file format
HDR.TYPE='EDF';
% number of channels
HDR.NS = nch;
HDR.GDFTYP=3*ones(1,nch);

% Duration of one block in seconds
HDR.Dur = HDR.SPR/HDR.SampleRate;

HDR.VERSION = 2.21;        % experimental
HDR.InChanSelect=1:nch;
HDR.LeadIdCode=NaN*ones(nch,1)
HDR=rmfield(HDR,'AS')
HDR = sopen(HDR,'w');
HDR = swrite(HDR,data');
HDR = sclose(HDR);
helpdlg('Done!')
guidata(hObject, handles);




% --- Executes on button press in showall.
function showall_Callback(hObject, eventdata, handles)
% hObject    handle to showall (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of showall


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.chanlist,'value',1)
cla
%cd ('C:\Users\E26903\Documents\My Dropbox\laptopsleep\anushka')
[filename, pathname] = uigetfile('*.mat', 'Pick the mat file to analyze');
%MAT file must contain 3 fields: data, sf and T0
handles.fn=filename;
cd (pathname)
load(filename);
%labels:
if isfield(newedf,'labels')
    EDF.Label=newedf.labels;
else
    for i=1:size(newedf.data,2);
        EDF.Label{i}=strcat('Ch',num2str(i));
    end
end
set(handles.chanlist,'string',EDF.Label);

s=newedf.data;
ls=length(s);

if exist(strcat('nNOS',handles.fn(1:end-3),'txt'))
    handles.scoring=load (strcat('nNOS',handles.fn(1:end-3),'txt'));
    %calculating RMS for different stages
end

selchan=get(handles.chanlist,'value');
sr=newedf.sf(selchan);
set(handles.edit14,'string',num2str(sr));
handles.sr(selchan)=sr;
dur=str2num(get(handles.edit4,'string'));
handles.dur=dur;
%t0=str2num(get(handles.t0,'string'));
t0=str2num(get(handles.edit5,'string'));
set(handles.edit6,'string',num2str(size(s,1)/(60*sr)));
tf=str2num(get(handles.edit6,'string'));

tvent=str2num(get(handles.tevent,'string'));

skip=(t0*60*sr)+1;
lastp=floor((floor(tf)*60*sr));
splc=str2num(get(handles.startpmnt,'string'));
eplc=str2num(get(handles.endpmnt,'string'));

%deleting the data during placement of the internals
%     ti=round(handles.sr(selchan)*60*splc);
%     tf=round(handles.sr(selchan)*60*eplc);
%     s(ti:tf,:)=0;
handles.hto=newedf.T0(4);%initial hour
handles.mto=newedf.T0(5);%initial minute
handles.sto=newedf.T0(6);%initial second
handles.s=s;
handles.news=handles.s(skip:lastp,:);%,get(handles.chanlist,'value'));%Only 2 hours% axes(handles.axes1)
handles.h=handles.axes1;
selchan=get(handles.chanlist,'value');
%handles.x=(0:length(handles.news)-1)/sr;

%smart scaling:
% if dur>10
%     handles.x=handles.x*dur;%scale in min.
% else
%     handles.x=handles.x*(dur*60);%scale in s
% end
% if get(handles.plotm,'value')
%handles.x=handles.x/60;
% end
axis(handles.axes1);
tl=length(handles.news)*handles.sr(selchan);%total length in s
if get(handles.showall,'value')
    handles.ltrace=tl;
    handles.x=tl*(0:length(handles.news)-1)/(length(handles.news)-1);
    handles.xi=1/handles.sr(selchan);
else
    handles.ltrace=str2num(get(handles.edit4,'string'));%length in s
    handles.xi=get(handles.slider1,'value');
    handles.x=(handles.xi:handles.xi+(handles.ltrace*handles.sr(selchan))-1)/handles.sr(selchan);
end
xlabel(handles.h,'s','fontsize',14)
set(handles.slider1,'max',tl);
%getting the max in the slider
if get(handles.plotm,'value')
    %handles.x=handles.x/60;
    set(handles.slider1,'max',tl/60);
    xlabel(handles.h,'min','fontsize',14)
end
%cla
if get(handles.plotm,'value')
    plot(handles.x/60,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
else
    plot(handles.x,handles.news(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.chanlist,'value')))
end
axis tight


%plot(hand,handles.x,handles.news(:,selchan))
%     plot(handles.x,handles.news(:,selchan))
%plot(handles.x,handles.news(:,selchan))

% if dur>10
xlabel(handles.h,'min','fontsize',14)
% else
%      xlabel(handles.h,'s','fontsize',14)
% end
%set(handles.tevent,'string',(length(handles.news)/(60*handles.sr(selchan)))-120);
set(handles.filename,'string',filename);
if tvent>0
    minmax=get(gca,'ylim')
    hold on
    plot([tvent tvent]',minmax','g--')
end
%reading and processing the scoring
%to load staging: W=87, NR=78, R=82, crap=85
%In many cases the scoring starts before the data.
if exist(strcat('nNOS',handles.fn(1:end-3),'txt'))
    handles.scoring=load(strcat('nNOS',handles.fn(1:end-3),'txt'));
    %prunning the first n epochs to match the data size
    cl=length(handles.scoring);
    nepochsindata=floor(length(handles.s)/(sr*10));
    if nepochsindata>cl
        aux0=handles.scoring;
        handles.scoring=zeros(nepochsindata,2);
        handles.scoring(1:nepochsindata-cl,1)=0:nepochsindata-cl-1;
        handles.scoring(1:nepochsindata-cl,2)=85;
        handles.scoring(nepochsindata-cl+1:nepochsindata,:)=aux0;
    else
        handles.scoring=handles.scoring(cl-nepochsindata:cl,:);
    end
    %Now plotting the whole EEG epoch by epoch and calculating RMS for different stages
    nw=0;nr=0;nn=0;nc=0;
    figure
    
    ntr=eegfilter(handles.s(:,selchan),5,0);
    
    xaxis=(0:length(ntr)-1)/sr;
    plot(xaxis,ntr,'k-');
    hold on
    rmsr=0;
    for i=1:length(handles.scoring)-1
        ti=1+(10*(i-1))*sr;
        tf=min(length(ntr),ti+(10*sr));
        if ti>tf
            disp('Error')
            break
        end
        aux=rms(ntr(ti:tf));
        switch handles.scoring(i,2)
            case 87
                nw=nw+1;
                rmswa(nw)=aux;
            case 78
                nn=nn+1;
                rmsnr(nn)=aux;
                plot(xaxis(ti:tf),ntr(ti:tf),'r-')
            case 82
                nr=nr+1;
                rmsr(nr)=aux;
                plot(xaxis(ti:tf),ntr(ti:tf),'g-')
            case 85
                plot(xaxis(ti:tf),ntr(ti:tf),'b-')
        end
    end
    figure
    bar([5000*mean(rmswa) 5000*mean(rmsnr) 5000*mean(rmsr) mean(rmswa)/mean(rmsnr)])
    
    xlabel('WA      NREM   REM     WA/NREM')
    disp('WA, NREM and REM')
    mean(rmswa)
    std(rmswa)
    mean(rmsnr)
    std(rmsnr)
    mean(rmsr)
    std(rmsr)
    
    
    figure;
    subplot(2,1,1)
    plot(rmsnr,'.-')
    subplot(2,1,2)
    plot(rmswa,'.-')
    
    
    
    
end

set(handles.slider1,'value',1);
guidata(hObject, handles);




% --- Executes on button press in monkey.
function monkey_Callback(hObject, eventdata, handles)
% hObject    handle to monkey (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%This doeas the RMS analysis for the data using the voltage info for stim
%time and the text file witht he result of each stim
%Steps:
%1- read text file
%2- read timing and make matrices with 6 sec. traces around stim
%3- get the binned RMS value of the filtered traces
%4- plot and save
cn=getComputerName();
cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     p=[2656 333 560 420];
%     set(0, 'DefaultFigurePosition', p)
% end
%reading text file
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the stim data');
handles.fn=filename;
%handles.news=[];
cd (pathname)
fid = fopen(filename);
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s',1);%Read headers
k=0;
disp('Reading text file with results...')
C2 = textscan(fid, '%f %f %f %f %f %f %s %f %f %s %s %f %f %s %s %s %s %s %s %s %f %f %f %f %f %s');
%making vectors with the text data
%mattask=zeros(4,length(C2{1}));
indhit=char(C2{15})=='Y';
indmiss=char(C2{16})=='Y';
indcrej=char(C2{17})=='Y';
indfalm=char(C2{18})=='Y';
selchan=get(handles.chanlist,'value');
fclose(fid)
%now getting the timings of each stim presentation from the voltage (must
%be the last channel)
timestim=zeros(size(indhit));
%dvec=diff(handles.news(:,end));
ldata=length(handles.news(:,end));
vec=handles.news(1:ldata-1,end);
vec2=handles.news(2:ldata,end);
times=find(vec<=4.3 & vec2>4.3);
timestim=times/handles.sr(end);
ch1data=[];ch2data=[];ch3data=[];
timehit=timestim(find(indhit==1));
timemiss=timestim(find(indmiss==1));
timecrej=timestim(find(indcrej==1));
timefalm=timestim(find(indfalm==1));
lth=length(timehit);
ltm=length(timemiss);
ltc=length(timecrej);
ltf=length(timefalm);

%for selchan=1:3
for selchan=2:2
    e1=handles.news(:,selchan);
    newtimehit=[];
    newtimemiss=[];
    newtimecrej=[];
    newtimefalm=[];
    
    % e2=handles.news(:,2);
    % e3=handles.news(:,3);
    %Now making the matrices. First rebuild the timing only for the artifact free ones.
    thres=1.7E-4;
    linf=1.5;%1.5 s of artifact free data around stim time s
    k=0;
    if lth>0
        for i=1:lth
            if (max(abs(e1(floor((timehit(i)-linf)*handles.sr(selchan)):ceil(timehit(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timehit(i)-linf)*handles.sr(selchan)):ceil(timehit(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimehit(k)=timehit(i);
            end
        end
    end
    
    k=0;
    if ltm>0
        for i=1:ltm
            if (max(abs(e1(floor((timemiss(i)-linf)*handles.sr(selchan)):ceil(timemiss(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timemiss(i)-linf)*handles.sr(selchan)):ceil(timemiss(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimemiss(k)=timemiss(i);
            end
        end
    end
    
    k=0;
    if ltc>0
        for i=1:ltc
            if (max(abs(e1(floor((timecrej(i)-linf)*handles.sr(selchan)):ceil(timecrej(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timecrej(i)-linf)*handles.sr(selchan)):ceil(timecrej(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimecrej(k)=timecrej(i);
            end
        end
    end
    
    
    k=0;
    if ltf>0
        for i=1:ltf
            if (max(abs(e1(floor((timefalm(i)-linf)*handles.sr(selchan)):ceil(timefalm(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timefalm(i)-linf)*handles.sr(selchan)):ceil(timefalm(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimefalm(k)=timefalm(i);
            end
        end
    end
    
    chlstrings={'Hit','Miss','C_rej.','F_alarm'};
    
    %Now making the matrices twice longer to avoid artifacts caused by the
    %bandpass filter
    mathit=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimehit)));
    matmiss=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimemiss)));
    matcrej=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimecrej)));
    matfalm=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimefalm)));
    s=ceil(4*linf*handles.sr(selchan));
    % figure
    % plot([0 1],[1 1],'g:')
    % hold on
    % plot([0 1],[2 2],'r:')
    % plot([0 1],[3 3],'b:')
    % legend('C. rej.','Hit','Miss')
    %     figure
    %     plot(handles.x,e1,'k')
    %     hold on
    %     o1=0;o2=0;o3=0;o4=0;
    %     if length(timecrej)>0
    %         o1=vline(timecrej./60,'g--');
    %         set(o1,'linewidth',1.5)
    %     end
    %     if length(timehit)>0
    %         o2=vline(timehit./60,'r--');
    %         set(o2,'linewidth',1.5)
    %     end
    %     if length(timefalm)>0
    %         o3=vline(timefalm./60,'m--');
    %         set(o3,'linewidth',1.5)
    %     end
    %     if length(timemiss)>0
    %         o4=vline(timemiss./60,'b--');
    %         set(o4,'linewidth',1.5)
    %     end
    %     plot(handles.x,e1,'k')
    %
    %
    %
    %     %legend('C. Rej.','Hit','Miss','F. Alarm')
    %     axis tight
    switch selchan;%get(handles.chanlist,'value')
        case 1
            cd eeg
        case 2
            cd eeg-1
        case 3
            cd eeg-2
    end
    %     title(get(handles.filename,'string'),'fontsize',16)
    %     xlabel('Min.')
    %     box off
    r1=length(newtimehit)
    if r1>1
        for i=1:r1
            mathit(:,i)=e1(floor((newtimehit(i)-(2*linf))*handles.sr(selchan)):floor((newtimehit(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        mathit=0;
    end
    
    r2=length(newtimemiss)
    if r2>1
        for i=1:r2
            matmiss(:,i)=e1(floor((newtimemiss(i)-(2*linf))*handles.sr(selchan)):floor((newtimemiss(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        matmiss=0;
    end
    
    r3=length(newtimecrej)
    if r3>1
        for i=1:r3
            matcrej(:,i)=e1(floor((newtimecrej(i)-(2*linf))*handles.sr(selchan)):floor((newtimecrej(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        matcrej=0;
    end
    
    r4=length(newtimefalm)
    if r4>1
        for i=1:r4
            matfalm(:,i)=e1(floor((newtimefalm(i)-(2*linf))*handles.sr(selchan)):floor((newtimefalm(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        matfalm=0;
    end
    
    %storing the matrices in the comon structure
    switch selchan
        case 1
            ch1data.mathit=mathit;
            ch1data.matmiss=matmiss;
            ch1data.matcrej=matcrej;
            ch1data.matfalm=matfalm;
        case 2
            ch2data.mathit=mathit;
            ch2data.matmiss=matmiss;
            ch2data.matcrej=matcrej;
            ch2data.matfalm=matfalm;
        case 3
            ch3data.mathit=mathit;
            ch3data.matmiss=matmiss;
            ch3data.matcrej=matcrej;
            ch3data.matfalm=matfalm;
    end
    
    
    %     figure
    %     subplot(2,2,1)
    %     plot(mathit)
    %     subplot(2,2,2)
    %     plot(matmiss)
    %     subplot(2,2,3)
    %     plot(matcrej)
    %     subplot(2,2,4)
    %     plot(matfalm)
    %Implementing ananlysis using fieldtrip functions for mathit:
    %First making mathit in the CTF format with one channel (mathit).
    %     data.hdr.Fs=handles.sr(selchan);
    %     data.hdr.nChans=1;
    %     data.hdr.nSamples=length(mathit);
    %     data.hdr.nSamplesPre=floor(length(mathit)/2);
    %     data.hdr.nTrials=size(mathit,2);
    %     data.hdr.label={'Mathit'};
    mat2sav=reshape(mathit,1,size(mathit,1)*size(mathit,2));
    save('datamathit.mat','mat2sav')
    mat2sav=reshape(matmiss,1,size(matmiss,1)*size(matmiss,2));
    save('datamatmiss.mat','mat2sav')
    mat2sav=reshape(matcrej,1,size(matcrej,1)*size(matcrej,2));
    save('datamatcrej.mat','mat2sav')
    
    %     data.label={'Mathit'};
    %     data.fsample=handles.sr(selchan);
    %     ca={mat2cell(mathit,[length(mathit)],ones(size(mathit,2),1))};
    %     vect=-3:1/2000:3;
    %     vect=vect(1:length(vect)-1);
    %     for i=1:size(mathit,2)
    %         ca{1}(i)=mat2cell(cell2mat(ca{1}(i))')
    %         data.time{i}=vect;
    %     end
    %     data.trial=ca;
    
    %     data.hdr.nChans=1;
    %     data.hdr.nSamples=length(mathit);
    %     data.hdr.nSamplesPre=floor(length(mathit)/2);
    %     data.hdr.nTrials=size(mathit,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% COmenting the plotting:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %     sx=0:ceil(4*linf*handles.sr(selchan))-1;
    %     sx=sx*4*linf/(ceil(4*linf*handles.sr(selchan))-1);
    %     sx=sx-2*linf;
    %     fa=figure
    %     set(fa, 'Position', get(0,'Screensize')); % Maximize figure.
    %     hold on
    %     plegend={};
    %     if r1>1
    %         plot(sx,mean(mathit'),'k-')
    %         plegend{1}='Hit';
    %         fname='meanhit.txt';
    %         aux=mean(mathit');
    %         save(fname,'aux','-ascii')
    %     end
    %     hold on
    %     if r2>1
    %         plot(sx,mean(matmiss'),'r-')
    %         plegend{length(plegend)+1}='Miss';
    %         fname='meanmiss.txt';
    %         aux=mean(matmiss');
    %         save(fname,'aux','-ascii')
    
    
    %     end
    %     if r3>1
    %         plot(sx,mean(matcrej'),'b-')
    %         plegend{length(plegend)+1}='Crect. Rej.';
    %         fname='meancrej.txt';
    %         aux=mean(matcrej');
    %         save(fname,'aux','-ascii')
    %
    %     end
    %     if r4>1
    %         plot(sx,mean(matfalm'),'g-')
    %         plegend{length(plegend)+1}='F. Alarm';
    %         fname='meanfalm.txt';
    %         aux=mean(matfalm');
    %         save(fname,'aux','-ascii')
    %
    %     end
    %     set(gca,'fontsize',12)
    %     minmax=get(gca,'ylim');
    %     plot([0 0],minmax,'c--')
    %     title('Average','fontsize',16)
    %     legend(plegend)
    %     set(gca,'xlim',[-0.1 1.5])
    %     saveas(fa,'average.jpg')
    %Now getting the RMS value in the power bands.
    
    tit=[{'RMS Alpha_ (8-12 Hz)'},{'RMS Beta__ (16-24 Hz)'},{'RMS LowG__ (30-50)'},{'RMS HighG (50-80)'}];
    initial=[8 16 30 50];
    final=[12 24 50 80];
    %close
    for q=1:length(initial)
        %wsize=1/initial(q);
        wsize=0.1;
        ny1=[];ny2=[];ny3=[];ny4=[];rmsm1=[];rmsm2=[];rmsm3=[];rmsm4=[];
        ff=figure %this is the fig for the respective frequency band
        set(ff, 'Position', get(0,'Screensize')); % Maximize figure.
        if r1>1
            %ny1=bandpassfilter(mathit,handles.sr(selchan),[initial(q) final(q)]);
            for ii=1:size(mathit,2)
                ny1(:,ii)=bandpassfilter(mathit(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            
            ny1=ny1(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny1,2)
                %binning each row:
                aux1=ny1(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm1=reshape(aux1,floor(wsize*handles.sr(selchan)),floor(length(ny1)/(wsize*handles.sr(selchan))));
                rmsm1(w,:)=rms(nm1);
            end
            mm1=mean(rmsm1);
            
            x0=(2*linf*(0:length(mm1)-1)/(length(mm1)-1))-(linf);
            % plot(nt,mm,'r.-')
            % hold on
            % minmax=get(gca,'ylim');
            % plot([0 0],minmax,'r--')
            subplot(2,2,1)
            %     x0=[0:wsize/(2*linf):2*linf];
            %     x0=x0-linf;
            errorbar(x0,mean(rmsm1),sem(rmsm1),'k-');
            hold on
            %plot(x0,rmsm1,'g-')
            plot(x0,mean(rmsm1),'ko-','linewidth',2)
            [xd,yd]=size(rmsm1);
            %          for ii=1:xd
            %              plot(x0,rmsm1(ii,:),'color',0.7*[ii/yd ii/yd ii/yd])
            %          end
            %             set(gca,'fontsize',14)
            %             xlabel('s','fontsize',16)
            %             ylabel('V','fontsize',16)
            %             title(char(tit(q)),'fontsize',18)
            %             legend(strcat(chlstrings{1},' N=',num2str(r1)))
            %             minmax=get(gca,'ylim');
            %             plot([0 0]',minmax,'g--')
            %             set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
            %             %now saving data in ascii
            %             tname=char(tit(q));
            %             fname=strcat(tname(1:10),chlstrings{1},'.txt');
            %             axis tight
            %             saveas(ff,strcat(fname(5:9),'.jpg'))
            m1t=rmsm1;
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.hit_rmsalpha=m1t';
                        case 2
                            ch2data.hit_rmsalpha=m1t';
                        case 3
                            ch3data.hit_rmsalpha=m1t';
                    end
                    %             save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.hit_rmsbeta=m1t';
                        case 2
                            ch2data.hit_rmsbeta=m1t';
                        case 3
                            ch3data.hit_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.hit_rmsLowG=m1t';
                        case 2
                            ch2data.hit_rmsLowG=m1t';
                        case 3
                            ch3data.hit_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.hit_rmshighG=m1t';
                        case 2
                            ch2data.hit_rmshighG=m1t';
                        case 3
                            ch3data.hit_rmshighG=m1t';
                    end
            end
            
            
        else
            mm1=0;
        end
        
        if r2>1
            for ii=1:size(matmiss,2)
                ny2(:,ii)=bandpassfilter(matmiss(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            ny2=ny2(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny2,2)
                %binning each row:
                aux=ny2(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(ny2)/(wsize*handles.sr(selchan))));
                rmsm2(w,:)=rms(nm);
            end
            mm2=mean(rmsm2);
            
            %             x0=(2*linf*(0:length(mm2)-1)/(length(mm2)-1))-(linf);
            %             subplot(2,2,2)
            %             errorbar(x0,mean(rmsm2),sem(rmsm2),'k-');
            %             hold on
            %             %plot(x0,rmsm2,'g-')
            %             plot(x0,mean(rmsm2),'ko-','linewidth',2)
            %             set(gca,'fontsize',14)
            %             xlabel('s','fontsize',16)
            %             ylabel('V','fontsize',16)
            %             title(char(tit(q)),'fontsize',18)
            %             legend(strcat(chlstrings{2},' N=',num2str(r2)))
            %             minmax=get(gca,'ylim');
            %             plot([0 0]',minmax,'g--')
            %
            %             %now saving data in ascii
            %             tname=char(tit(q));
            %             fname=strcat(tname(1:10),chlstrings{2},'.txt')
            m1t=rmsm2;
            %             axis tight
            %             saveas(ff,strcat(fname(5:9),'.jpg'))
            %
            %             save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.mises_rmsalpha=m1t';
                        case 2
                            ch2data.mises_rmsalpha=m1t';
                        case 3
                            ch3data.mises_rmsalpha=m1t';
                    end
                    %             save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.mises_rmsbeta=m1t';
                        case 2
                            ch2data.mises_rmsbeta=m1t';
                        case 3
                            ch3data.mises_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.mises_rmsLowG=m1t';
                        case 2
                            ch2data.mises_rmsLowG=m1t';
                        case 3
                            ch3data.mises_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.mises_rmshighG=m1t';
                        case 2
                            ch2data.mises_rmshighG=m1t';
                        case 3
                            ch3data.mises_rmshighG=m1t';
                    end
            end
            
        else
            mm2=0;
        end
        
        
        if r3>1
            for ii=1:size(matcrej,2)
                ny3(:,ii)=bandpassfilter(matcrej(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            ny3=ny3(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny3,2)
                %binning each row:
                aux=ny3(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(ny3)/(wsize*handles.sr(selchan))));
                rmsm3(w,:)=rms(nm);
            end
            mm3=mean(rmsm3);
            
            %             x0=(2*linf*(0:length(mm3)-1)/(length(mm3)-1))-(linf);
            %             subplot(2,2,3)
            %             errorbar(x0,mean(rmsm3),sem(rmsm3),'k-');
            %             hold on
            %             %plot(x0,rmsm3,'g-')
            %             plot(x0,mean(rmsm3),'ko-','linewidth',2)
            %             set(gca,'fontsize',14)
            %             xlabel('s','fontsize',16)
            %             ylabel('V','fontsize',16)
            %             title(char(tit(q)),'fontsize',18)
            %             legend(strcat(chlstrings{3},' N=',num2str(r3)))
            %             minmax=get(gca,'ylim');
            %             plot([0 0]',minmax,'g--')
            %
            %             %now saving data in ascii
            %             tname=char(tit(q));
            %             fname=strcat(tname(1:10),'Crej','.txt');
            %             axis tight
            %             saveas(ff,strcat(fname(5:9),'.jpg'))
            m1t=rmsm3;
            %
            %             save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.crej_rmsalpha=m1t';
                        case 2
                            ch2data.crej_rmsalpha=m1t';
                        case 3
                            ch3data.crej_rmsalpha=m1t';
                    end
                    %             save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.crej_rmsbeta=m1t';
                        case 2
                            ch2data.crej_rmsbeta=m1t';
                        case 3
                            ch3data.crej_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.crej_rmsLowG=m1t';
                        case 2
                            ch2data.crej_rmsLowG=m1t';
                        case 3
                            ch3data.crej_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.crej_rmshighG=m1t';
                        case 2
                            ch2data.crej_rmshighG=m1t';
                        case 3
                            ch3data.crej_rmshighG=m1t';
                    end
            end
        else
            mm3=0;
        end
        
        if r4>1
            for ii=1:size(matfalm,2)
                ny4(:,ii)=bandpassfilter(matfalm(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            
            %ny4=bandpassfilter(matfalm,handles.sr(selchan),[initial(q) final(q)]);
            ny4=ny4(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny4,2)
                %binning each row:
                aux=ny4(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(ny4)/(wsize*handles.sr(selchan))));
                rmsm4(w,:)=rms(nm);
            end
            mm4=mean(rmsm4);
            
            %             x0=(2*linf*(0:length(mm4)-1)/(length(mm4)-1))-(linf);
            %             subplot(2,2,4)
            %             errorbar(x0,mean(rmsm4),sem(rmsm4),'k-');
            %             hold on
            %             %plot(x0,rmsm4,'g-')
            %             plot(x0,mean(rmsm4),'ko-','linewidth',2)
            %             set(gca,'fontsize',14)
            %             xlabel('s','fontsize',16)
            %             ylabel('V','fontsize',16)
            %             title(char(tit(q)),'fontsize',18)
            %             legend(strcat(chlstrings{4},' N=',num2str(r4)))
            %             minmax=get(gca,'ylim');
            %             plot([0 0]',minmax,'g--')
            %
            %             %now saving data in ascii
            %             tname=char(tit(q));
            %             fname=strcat(tname(1:10),'Falarm','.txt');
            %             axis tight
            %             saveas(ff,strcat(fname(5:9),'.jpg'))
            m1t=rmsm4;
            %             save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.falm_rmsalpha=m1t';
                        case 2
                            ch2data.falm_rmsalpha=m1t';
                        case 3
                            ch3data.falm_rmsalpha=m1t';
                    end
                    %             save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.falm_rmsbeta=m1t';
                        case 2
                            ch2data.falm_rmsbeta=m1t';
                        case 3
                            ch3data.falm_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.falm_rmsLowG=m1t';
                        case 2
                            ch2data.falm_rmsLowG=m1t';
                        case 3
                            ch3data.falm_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.falm_rmshighG=m1t';
                        case 2
                            ch2data.falm_rmshighG=m1t';
                        case 3
                            ch3data.falm_rmshighG=m1t';
                    end
            end
        else
            mm4=0;
        end
        %     figure
        %     subplot(2,2,1)
        %     plot(mean(ny1'));
        %         subplot(2,2,2)
        %     plot(mean(ny2'));
        %
        %         subplot(2,2,3)
        %     plot(mean(ny3'));
        %
        %         subplot(2,2,4)
        %     plot(mean(ny4'));
        %
        %Nowthe FFTs
        
        
        close(ff)
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%
    %% NOW THE REAL DEAL %%
    %%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%
    kqk=1;
    if kqk==1
      %  Read mat file, convert it to EDf, plot ERP , save EDF and calculate power of each band per trial and average time-freq. heatmap
              if r3>1
                    clipboard('copy','2000 4500')
                  eegout=pop_importdata('setname','crej','data','datamatcrej.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
%         pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
%                     pop_erpimage(eegout,1);
                    f=gca;
                    title('ERP Crej')
                    set(f, 'Position', get(0,'Screensize')); % Maximize figure.
        
                    saveas(gca,'ERPcrej.fig')
                    saveas(gca,'ERPcrej.jpg')
                  clipboard('copy','crej.edf')
                  pop_writeeeg(eegout);
        close
             end
             if r1>1
                 clipboard('copy','2000 4500')
                 eegout=pop_importdata('setname','hits','data','datamathit.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
%         pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
        
        helpdlg('name must be hits.edf')
                clipboard('copy','hits.edf')
                pop_writeeeg(eegout);%, 'type','EDF');
        close
           end
           if r2>1
               clipboard('copy','2000 4500')
               eegout=pop_importdata('setname','misses','data','datamatmiss.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
        pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
                    pop_erpimage(eegout,1);
                    set(gca, 'Position', get(0,'Screensize')); % Maximize figure.
                    title('ERP Misses')
                    saveas(gca,'ERPmiss.fig')
                    saveas(gca,'ERPmiss.jpg')
        helpdlg(' must be misses.edf')
              clipboard('copy','misses.edf')
              pop_writeeeg(eegout);%, 'type','EDF','label',{'miss'},'T0',[1999 10 10 12 00 00.0]);
        close
          end
        %Now loading the new EDf and getting the time-freq heatmap and svaing
        %the averge power by bands in a text file and the plots in jpg's.
        
        for ii=1:3
            
            %skipping void cases
            if ii==1 & r3<2
                ii=ii+1;
            end
            if ii==2 & r1<2
                ii=ii+1;
            end
            if ii==3 & r2<2
                break;
            end
            
            
            switch ii
                case 1
                    fn='crej.edf'
                    ntrial=r3;
                case 2
                    fn='hits.edf'
                    ntrial=r1;
                case 3
                    fn='misses.edf'
                    ntrial=r2;
            end
            
            cfg = [];                                           % empty configuration
            cfg.dataset                 = fn;       % name of CTF dataset
            cfg.trialdef.triallength=6;
            cfg.trialdef.ntrials=ntrial;
            cfg = ft_definetrial(cfg);
            cfg.continuous='yes';
            chname='Chan 1';%handles.hedf.Label;
            % while (chname(end)==' ')
            %     chname=chname(1:end-1);
            % end
            % preprocess the data
            cfg.channel   =chname
            cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
            dataFIC = ft_preprocessing(cfg);
            for kk=1:length(dataFIC.trial)
                dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
            end
            cfg              = [];
            cfg.output       = 'pow';
            cfg.channel      = chname;
            cfg.method       = 'mtmconvol';
            cfg.taper        = 'hanning';
            cfg.keeptrials = 'yes';
            cfg.foi          = 2:2:80;                         % analysis 2 to 30 Hz in steps of 2 Hz
            cfg.t_ftimwin    = ones(length(cfg.foi),1).*0.5;   % length of time window = 0.5 sec
            cfg.toi          = 2:0.01:4.5;                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
            TFRhann = ft_freqanalysis(cfg, dataFIC);
            xtimes=cfg.toi-3;
            cfg = [];
            cfg.baseline     = [2 2.9];
            cfg.baselinetype ='relative';
            %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
            cfg.channel      = chname;
            cfg.zlim = [0 6];
            figure
            ft_singleplotTFR(cfg,TFRhann);
            %title('mtmconvol= multiplication in the frequency domain')
            set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1','1.5'})
            set(gca,'fontsize',14)
            title(strcat('Avg FFT ',fn(1:end-4),'_ch:',selchan))
            saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'fig');
            saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'jpg');
            %close
            auxps=fixdim(TFRhann.powspctrm);
            deltaFFT=fixdim(auxps(:,1,:));
            thetaFFT=fixdim(mean(auxps(:,2:4,:),2));
            alphaFFT=fixdim(mean(auxps(:,4:6,:),2));
            betaFFT=fixdim(mean(auxps(:,8:12,:),2));
            lowGFFT=fixdim(mean(auxps(:,15:25,:),2));
            highGFFT=fixdim(mean(auxps(:,25:40,:),2));
            meanfft=fixdim(mean(auxps,1));
            %plotting and saving the figs and matrices
            save(strcat(fn(1:end-4),'_Avg_FFT.txt'),'meanfft','-ascii')
            switch ii%Crej, hits or misses
                case 1                    
                    fn='crej.edf'
                    ntrial=r3;
                case 2
                    fn='hits.edf'
                    ntrial=r1;
                case 3
                    fn='misses.edf'
                    ntrial=r2;
            end
            %figure
            %set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
            %subplot(2,3,1)
            %             x=-1:0.01:1.5;
            %             m=fixdim(mean(deltaFFT));
            %             einf=fixdim(m-sem(deltaFFT));
            %             emax=m+sem(deltaFFT);
            %             X=[x,fliplr(x)];                %create continuous x value array for plotting
            %             Y=[einf,fliplr(emax)];              %create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                  %plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Fast Delta (2-4 Hz)')
            
            %subplot(2,3,2)
            %             m=mean(thetaFFT);
            %             einf=m-sem(thetaFFT);
            %             emax=m+sem(thetaFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                %#plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Theta (4-8 Hz)')
            
            
            %subplot(2,3,3)
            %             m=mean(alphaFFT);
            %             einf=m-sem(alphaFFT);
            %             emax=m+sem(alphaFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                %#plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Alpha (8-12 Hz)')
            
            
            %subplot(2,3,4)
            %             m=mean(betaFFT);
            %             einf=m-sem(betaFFT);
            %             emax=m+sem(betaFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                 %#plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Beta (16-24 Hz)')
            
            
            %             subplot(2,3,5)
            %             m=mean(lowGFFT);
            %             einf=m-sem(lowGFFT);
            %             emax=m+sem(lowGFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %             fill(X,Y,'c','EdgeColor','none');             %#plot filled area
            %             hold on
            %             plot(x,m(1:length(x)),'b','linewidth',2)
            %             title('Low G (30-50 Hz)')
            %
            %             subplot(2,3,6)
            %             m=mean(highGFFT);
            %             einf=m-sem(highGFFT);
            %             emax=m+sem(highGFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %             fill(X,Y,'c','EdgeColor','none');                  %#plot filled area
            %             hold on
            %             plot(x,m(1:length(x)),'b','linewidth',2)
            %             title('High G (50-80 Hz)')
            %             set(gca, 'Position', get(0,'Screensize')); % Maximize figure.
            %             fign=strcat('band_fft_',fn(1:end-4),'.jpg');
            %             saveas(gca,fign);
            %             close
            switch ii
                case 1
                    fn2=('deltaFFT_crej.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_crej.txt');%',fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_crej');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_crej');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_crej');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_crej');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.crej_avgFFT=meanfft;
                            ch1data.crej_deltaFFT=deltaFFT;
                            ch1data.crej_thetaFFT=thetaFFT;
                            ch1data.crej_alphaFFT=alphaFFT;
                            ch1data.crej_betaFFT=betaFFT;
                            ch1data.crej_lowGFFT=lowGFFT;
                            ch1data.crej_highGFFT=highGFFT;
                        case 2
                            ch2data.crej_avgFFT=meanfft;
                            ch2data.crej_deltaFFT=deltaFFT;
                            ch2data.crej_thetaFFT=thetaFFT;
                            ch2data.crej_alphaFFT=alphaFFT;
                            ch2data.crej_betaFFT=betaFFT;
                            ch2data.crej_lowGFFT=lowGFFT;
                            ch2data.crej_highGFFT=highGFFT;
                        case 3
                            ch3data.crej_avgFFT=meanfft;
                            ch3data.crej_deltaFFT=deltaFFT;
                            ch3data.crej_thetaFFT=thetaFFT;
                            ch3data.crej_alphaFFT=alphaFFT;
                            ch3data.crej_betaFFT=betaFFT;
                            ch3data.crej_lowGFFT=lowGFFT;
                            ch3data.crej_highGFFT=highGFFT;
                    end
                    
                    %                 helpdlg('txt File saved')
                case 2
                    fn2=('deltaFFT_hits.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_hits.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_hits.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_hits.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_hits.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_hits.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.hits_avgFFT=meanfft;
                            ch1data.hits_deltaFFT=deltaFFT;
                            ch1data.hits_thetaFFT=thetaFFT;
                            ch1data.hits_alphaFFT=alphaFFT;
                            ch1data.hits_betaFFT=betaFFT;
                            ch1data.hits_lowGFFT=lowGFFT;
                            ch1data.hits_highGFFT=highGFFT;
                        case 2
                            ch2data.hits_avgFFT=meanfft;
                            ch2data.hits_deltaFFT=deltaFFT;
                            ch2data.hits_thetaFFT=thetaFFT;
                            ch2data.hits_alphaFFT=alphaFFT;
                            ch2data.hits_betaFFT=betaFFT;
                            ch2data.hits_lowGFFT=lowGFFT;
                            ch2data.hits_highGFFT=highGFFT;
                        case 3
                            ch3data.hits_avgFFT=meanfft;
                            ch3data.hits_deltaFFT=deltaFFT;
                            ch3data.hits_thetaFFT=thetaFFT;
                            ch3data.hits_alphaFFT=alphaFFT;
                            ch3data.hits_betaFFT=betaFFT;
                            ch3data.hits_lowGFFT=lowGFFT;
                            ch3data.hits_highGFFT=highGFFT;
                    end
                    
                case 3
                    fn2=('deltaFFT_mises.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_mises.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_mises.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_mises.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_mises.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_mises.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.mises_avgFFT=meanfft;
                            ch1data.mises_deltaFFT=deltaFFT;
                            ch1data.mises_thetaFFT=thetaFFT;
                            ch1data.mises_alphaFFT=alphaFFT;
                            ch1data.mises_betaFFT=betaFFT;
                            ch1data.mises_lowGFFT=lowGFFT;
                            ch1data.mises_highGFFT=highGFFT;
                        case 2
                            ch2data.mises_avgFFT=meanfft;
                            ch2data.mises_deltaFFT=deltaFFT;
                            ch2data.mises_thetaFFT=thetaFFT;
                            ch2data.mises_alphaFFT=alphaFFT;
                            ch2data.mises_betaFFT=betaFFT;
                            ch2data.mises_lowGFFT=lowGFFT;
                            ch2data.mises_highGFFT=highGFFT;
                        case 3
                            ch3data.mises_avgFFT=meanfft;
                            ch3data.mises_deltaFFT=deltaFFT;
                            ch3data.mises_thetaFFT=thetaFFT;
                            ch3data.mises_alphaFFT=alphaFFT;
                            ch3data.mises_betaFFT=betaFFT;
                            ch3data.mises_lowGFFT=lowGFFT;
                            ch3data.mises_highGFFT=highGFFT;
                    end
                    
            end
            
        end
        
    end
    
    
    
    
    cd ..
    
    
end
newfn=strcat(handles.fn(1:end-4),'.mat')
save(newfn,'ch1data','ch2data','ch3data')
guidata(hObject, handles);




% --- Executes on button press in swa.
function swa_Callback(hObject, eventdata, handles)
% hObject    handle to swa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on selection change in selectedfun.
function selectedfun_Callback(hObject, eventdata, handles)
% hObject    handle to selectedfun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns selectedfun contents as cell array
%        contents{get(hObject,'Value')} returns selected item from selectedfun
contents = cellstr(get(hObject,'String'))
switch contents{get(hObject,'Value')}
    case 'Find Light onset'
        %read a signal and uses it to get timing info for averaging the selected channel
        [filename, pathname] = uigetfile('*.mat', 'Pick the mat file with the stimulus signal');
        cd (pathname)
        sigdata=load(filename);
        %         figure;
        %         plot(sigdata.tscale(2:end),diff(sigdata.tracets),'k-')
        %         hold on
        %         plot(sigdata.tscale,sigdata.tracets,'r-')
        indx=find(diff(sigdata.tracets)<-0.0001);
        indx=indx(1:end-1);%eliminating the last stimulus.
        handles.stimtimes=sigdata.tscale(1+indx);
        nch=size(get(handles.chanlist,'string'),1);
        if nch==6
            nch=4;
        end
        selchan=get(handles.chanlist,'value');
        mindif=floor(min(diff(handles.stimtimes))*handles.sr(selchan));
        datamatrix=zeros(mindif,length(indx));
        stimpos=handles.stimtimes*handles.sr(selchan)-0.3*handles.sr(selchan);%starts 300 ms before stim
        h=allchild(0);
        if length(h)==1
            figure
            c='b-';
        else
            figure(h(2));
            c='r-'
        end
        for chn=1:nch
            for i=1:length(indx);
                datamatrix(:,i)=handles.news(round(stimpos(i)):round(stimpos(i)+mindif-1),chn);
            end
            matavg(chn,:)=mean(datamatrix');
        end
        mmax=max(max(matavg));
        mmin=min(min(matavg));
        minmax=[mmin mmax];
        %minmax=1E-4*[-0.68 0.42];
        for chn=1:nch
            subplot(8,4,chn)
            plot((0:mindif-1)/handles.sr(selchan),matavg(chn,:),c)
            axis tight
            set(gca,'ylim',minmax)
            hold on
            plot([0.3 0.3],minmax,'g--')
        end
        figure
        plot((0:mindif-1)/handles.sr(selchan),mean(matavg))
        set(gca,'ylim',minmax)
        hold on
        plot([0.3 0.3],minmax,'g--')
    case '2-ch EEG freq comparison'
        maxfrec=800;
        figure
        v1=getthepower(handles.news(:,1)*(10^6)/20,handles.dur,maxfrec,1);
        
        subplot(2,1,1)
        axis tight
        set(gca,'xlim',[0 20])
        %set(gca,'ylim',[0 1.75])
        title('Subcraneal')
        subplot(2,1,2)
        axis tight
        set(gca,'ylim',[-500 500])
        figure
        v2=getthepower(handles.news(:,2)*(10^6)/20,handles.dur,maxfrec,1);
        subplot(2,1,1)
        axis tight
        set(gca,'xlim',[0 20])
        title('Subgaleal')
        subplot(2,1,2)
        axis tight
        set(gca,'ylim',[-500 500])
        
        N = length(handles.news(:,1)); %% number of points
        T = handles.dur; %% define time of interval, 3.4 seconds
        t = [0:N-1]/N; %% define time
        t = t*T; %% define time in seconds
        freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
        %freq=freq(1:length(aux));
        %making 1Hz bins
        aux=min(find(freq>1))-1;%number of req points corresponding to 1 Hz
        newv1=reshape(v1(1:(maxfrec*aux)),aux,maxfrec);
        newv2=reshape(v2(1:(maxfrec*aux)),aux,maxfrec);
        aux2=min(find(freq>maxfrec))-1;
        figure;plot(1:maxfrec,mean(newv2)./mean(newv1))
        hold on
        plot(0:maxfrec-1,ones(1,maxfrec),'g--')
        axis tight;
        minmax=get(gca,'ylim');
        set(gca,'ylim',[0 minmax(2)])
        box off
        
        box off
        set(gca,'fontsize',14)
        ylabel ('H')
        title('Subgaleal/Subcraneal')
end
guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function selectedfun_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selectedfun (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in savematf.
function savematf_Callback(hObject, eventdata, handles)
% hObject    handle to savematf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selchan=get(handles.chanlist,'value');
tscale=handles.x;
tracets=handles.news(:,selchan);
save('trace','tscale','tracets');
helpdlg('Trace saved!')



% --- Executes on button press in frectime.
function frectime_Callback(hObject, eventdata, handles)
% hObject    handle to frectime (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% find the interesting segments of data


cfg = [];                                           % empty configuration
cfg.dataset                 = handles.fn;       % name of CTF dataset
%cfg.trialdef.eventtype      = 'backpanel trigger';
%cfg.trialdef.prestim        = 3;
%cfg.trialdef.poststim       = 3;
%cfg.trialdef.eventvalue     = 3;                    % event value of FIC
cfg.trialdef.triallength=6;
cfg.trialdef.ntrials=floor(length(handles.s)/(cfg.trialdef.triallength*handles.sr));
cfg = ft_definetrial(cfg);
cfg.continuous='yes';
chname=handles.hedf.Label;
while (chname(end)==' ')
    chname=chname(1:end-1);
end
% preprocess the data
cfg.channel   =chname;        % read all MEG channels except MLP31 and MLO12
cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
%Scaling data from V to uV
dataFIC = ft_preprocessing(cfg);
for kk=1:length(dataFIC.trial)
    dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
end

cfg              = [];
cfg.output       = 'pow';
cfg.channel      = chname;
cfg.method       = 'mtmconvol';
cfg.taper        = 'hanning';
cfg.keeptrials = 'yes';
cfg.foi          = 2:2:80;                         % analysis 2 to 30 Hz in steps of 2 Hz
cfg.t_ftimwin    = ones(length(cfg.foi),1).*0.5;   % length of time window = 0.5 sec
cfg.toi          = 2:0.01:4.5;                  % time window "slides" from -0.5 to 1.5 sec in steps of 0.05 sec (50 ms)
TFRhann = ft_freqanalysis(cfg, dataFIC);
xtimes=cfg.toi-3;
cfg = [];
cfg.baseline     = [2 2.9];
cfg.baselinetype ='relative';
%cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
cfg.channel      = chname;
figure
ft_singleplotTFR(cfg,TFRhann);
%title('mtmconvol= multiplication in the frequency domain')
set(gca,'XTickLabel',{'-1000','-500','0','500','1000','1500'})
set(gca,'fontsize',14)

%plotting arbitrary bands
% figure
% semilogy(xtimes,fixdim(mean(TFRhann.powspctrm(1,1:4,:))),'r-','linewidth',2);
% hold on
% semilogy(xtimes,fixdim(mean(TFRhann.powspctrm(1,5:13,:))),'k-','linewidth',2);
% semilogy(xtimes,fixdim(mean(TFRhann.powspctrm(1,14:19,:))),'g-','linewidth',2);
% semilogy(xtimes,fixdim(mean(TFRhann.powspctrm(1,20:end,:))),'b-','linewidth',2);
% legend('2-8 Hz','10-26 Hz','28-38 Hz','40-80 Hz')
% ylabel('Power (mV^2)','fontsize',21)
% set(gca,'XTickLabel',{'-1000','-500','0','500','1000','1500'})
% set(gca,'fontsize',14)
% xlabel('Time (ms)','fontsize',21)
% newp=TFRhann.powspctrm;
% for i=1:size(TFRhann.powspctrm,2)
%     newp(1,i,:)=newp(1,i,:)./mean(mean(newp(1,i,1:100)));
% end
% figure
% plot(xtimes,fixdim(mean(newp(1,1:2,:))),'r-','linewidth',2);
% hold on
% plot(xtimes,fixdim(mean(newp(1,3:4,:))),'k-','linewidth',2);
% plot(xtimes,fixdim(mean(newp(1,5:8,:))),'g-','linewidth',2);
% plot(xtimes,fixdim(mean(newp(1,9:15,:))),'b-','linewidth',2);
% plot(xtimes,fixdim(mean(newp(1,16:end,:))),'m-','linewidth',2);
%
% legend('2-4 Hz','4-8 Hz','8-16 Hz','16-30 Hz','30-80 Hz')
% ylabel('Mean Relative Power','fontsize',21)
% set(gca,'XTickLabel',{'-1000','-500','0','500','1000','1500'})
% set(gca,'fontsize',14)
% xlabel('Time (ms)','fontsize',21)

%Getting the power in bands for every trial:
%beta: 2-4, theta:4-8, alpha: 8-12, Beta:16-24, lgama: 30-50, hgama: 50-80
auxps=fixdim(TFRhann.powspctrm);
deltaFFT=auxps(:,1,:);
thetaFFT=mean(auxps(:,2:4,:),2);
alphaFFT=mean(auxps(:,4:6,:),2);
betaFFT=mean(auxps(:,8:12,:),2);
lowGFFT=mean(auxps(:,15:25,:),2);
highGFFT=mean(auxps(:,25:40,:),2);

fn=strcat('mat',handles.fn(1:end-4),'.txt');
save(fn,'mathit','-ascii')
helpdlg('txt File saved')
%Running wavelet 4 times

% cfg              = [];
% cfg.output       = 'pow';
% cfg.channel      = 'Chan 1';
% cfg.method       = 'wavelet';
% %cfg.taper        = 'hanning';
% cfg.width      = 3;
% cfg.foi          = 2:1:80;                         % analysis 2 to 30 Hz in steps of 2 Hz
% %cfg.t_ftimwin    = ones(length(cfg.foi),1).*0.5;   % length of time window = 0.5 sec
% cfg.toi          = 2:0.01:4.5;                  % time window "slides" from -0.5 to 1.5 sec in steps of 0.05 sec (50 ms)
% TFRhann1 = ft_freqanalysis(cfg, dataFIC);
%
% cfg.width      = 4;
% TFRhann2 = ft_freqanalysis(cfg, dataFIC);
% cfg.width      = 6;
% TFRhann3 = ft_freqanalysis(cfg, dataFIC);
% cfg.width      = 9;
% TFRhann4 = ft_freqanalysis(cfg, dataFIC);
%
% cfg = [];
% cfg.baseline     = [1 2.9];
% cfg.baselinetype ='relative';
% %cfg.zlim         = [ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
% cfg.channel      = 'Chan 1';
% figure
% % subplot(1,2,1)
% % ft_singleplotTFR(cfg, TFRhann2);
% % set(gca,'Xtick',[])
% % subplot(4,1,2)
% % ft_singleplotTFR(cfg, TFRhann3);
% % title off
% % set(gca,'Xtick',[])
% % subplot(4,1,3)
% % ft_singleplotTFR(cfg, TFRhann2);
% % title off
% % set(gca,'Xtick',[])
% % subplot(1,2,2)
% % ft_singleplotTFR(cfg, TFRhann1);
% % figure
% TFRhannf=TFRhann4;
% TFRhannf.powspctrm(1,1:9,:)=TFRhann1.powspctrm(1,1:9,:);
% TFRhannf.powspctrm(1,10:14,:)=TFRhann2.powspctrm(1,10:14,:);
% TFRhannf.powspctrm(1,15:45,:)=TFRhann3.powspctrm(1,15:45,:);
% ft_singleplotTFR(cfg, TFRhannf);
% set(gca,'XTickLabel',{'-1000','-500','0','500','1000','1500'})
% set(gca,'fontsize',14)
title off



% --- Executes on button press in plotEEGandFFT. Plots EEg and FFT of first
% channel plus EMG in the 4th
function plotEEGandFFT_Callback(hObject, eventdata, handles)
% hObject    handle to plotEEGandFFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selchan=get(handles.chanlist,'value');
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
%plotting the power and the trace of the whole EEG (in uV)
winsize=floor(handles.sr(selchan)*fftwindow);
e1=handles.news(:,1)*1E6;
e2=handles.news(:,2)*1E6;
e3=handles.news(:,3)*1E6;
emg=(bandpassfilter(handles.news(:,4),handles.sr(4),[10 100]))*1E6;
figure
p=getthepowerc(e3,(length(e1)/handles.sr(selchan)),30,1,'b-');
hold on
p2=getthepowerc(e1,(length(e1)/handles.sr(selchan)),30,1,'r-');
p3=getthepowerc(e2,(length(e1)/handles.sr(selchan)),30,1,'k-');
legend('R-V1','R-FC','L-FC')

figure
subplot(4,1,1)
xscl=(0:length(e1)-1)/(handles.sr(1));
plot(xscl, e1,'k-')
box off
axis tight
set(gca,'XTick',[])
subplot(4,1,2)
xscl=(0:length(e1)-1)/(handles.sr(2));
plot(xscl, e2,'k-')
box off
axis tight
set(gca,'XTick',[])

subplot(4,1,3)
xscl=(0:length(e1)-1)/(handles.sr(3));
plot(xscl, e3,'k-')
box off
set(gca,'XTick',[])
axis tight
subplot(4,1,4)
xscl=(0:length(emg)-1)/handles.sr(4);
plot(xscl, emg,'k-')
box off
axis tight
xlabel('Time (s)','fontsize',21)
%set(gca,'XTick',[])




% --- Executes on button press in fftepochs.
function fftepochs_Callback(hObject, eventdata, handles)
% hObject    handle to fftepochs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
maxfrec=30;
selchan=get(handles.chanlist,'value');
handles.sr(selchan)=str2num(get(handles.edit14,'string'));
fftwindow=str2num(get(handles.edit2,'string'));%size in s for doing the fft
winsize=floor(handles.sr(selchan)*fftwindow);
e1=handles.news(1:winsize*floor(length(handles.news)/winsize),get(handles.chanlist,'value'));
e1=(e1-mean(e1))*1E6;
eeg1=reshape(e1,winsize,length(e1)/winsize);
thres=str2num(get(handles.tmt,'string'))*1E6;
T=fftwindow;
powerv=getthepower(eeg1(:,1),fftwindow,maxfrec,0);
%matpower=NaN*ones(length(powerv),size(eeg1,2));
k=1;
for i=1:size(eeg1,2)
    if max(abs(eeg1(:,i)))<thres
        matpower(:,k)=getthepower(eeg1(:,i),fftwindow,maxfrec,0);
        k=k+1;
    end
end
if k==0
    helpdlg('Only noise!')
else
    disp(k)
    figure
    trace=eeg1(:,1);
    N = length(trace); %% number of points
    t = [0:N-1]/N; %% define time
    t = t*T; %% define time in seconds
    p = mean(matpower');
    freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
    plot(freq,p,'k-','linewidth',1);
    set(gca,'fontsize',14)
    xlabel('Hz','fontsize',18')
    box off
    set(gca,'xlim',[0 maxfrec]); %% zoom in
    ylabel('Power (mV^2)','fontsize',18)
end
minmax=get(gca,'ylim');
x=[0.5 4 8 16];
hold on;plot([x' x'],minmax,'g--')
guidata(hObject, handles);




function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in heatmap. Plots heatmap of the whole trace
function heatmap_Callback(hObject, eventdata, handles)
% hObject    handle to heatmap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winsize=10;%size of the FFT window in s.
stepsize=1;%Duh
cfg = [];                                           % empty configuration
cfg.dataset                 = handles.fn;       % name of CTF dataset
%cfg.trialdef.eventtype      = 'backpanel trigger';
%cfg.trialdef.prestim        = 3;
%cfg.trialdef.poststim       = 3;
%cfg.trialdef.eventvalue     = 3;                    % event value of FIC
cfg.trialdef.triallength=handles.dur;
cfg.trialdef.ntrials=1;
cfg = ft_definetrial(cfg);
cfg.continuous='yes';

% preprocess the data
names=cellstr(get(handles.chanlist,'string'));
cfg.channel=names{handles.selchan};
cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
%Scaling data from V to uV
dataFIC = ft_preprocessing(cfg);

cfg              = [];
cfg.output       = 'pow';
cfg.channel=names{handles.selchan};
cfg.method       = 'mtmconvol';
cfg.taper        = 'hanning';
cfg.foi          = 0:1:12;                         % analysis 2 to 30 Hz in steps of 2 Hz
cfg.t_ftimwin    = ones(length(cfg.foi),1).*winsize;   % length of time window = 0.5 sec
cfg.toi          = 2*winsize:stepsize:handles.dur-2*winsize;                  % time window "slides" from -0.5 to 1.5 sec in steps of 0.05 sec (50 ms)
TFRhann = ft_freqanalysis(cfg, dataFIC);
xtimes=cfg.toi;
cfg = [];
%cfg.baseline     = [10 100];%All frequencies relative to the first 100 s
%cfg.baselinetype ='relative';
%cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
cfg.channel      = names{handles.selchan};
figure
ft_singleplotTFR(cfg,TFRhann);
%title('mtmconvol= multiplication in the frequency domain')
%set(gca,'XTickLabel',{'-1000','-500','0','500','1000','1500'})
set(gca,'fontsize',14)



% --- Executes on button press in loadTDT.
function loadTDT_Callback(hObject, eventdata, handles)
% hObject    handle to loadTDT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton24.
function pushbutton24_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Loads scoring and Identifies the prescnece of waves within a range and charactrize the slope
%for early and late phase and positive and negative deflections. ALso
%calculates the RMS, all divided by states.
%Steps:
%   1- Read scoring and divide trace in 10s epochs
%   2- Get the RMS of each epoch
%   3- Filter data in the range of the desired wave
%   4- Find zero corssing and peaks
%   5- Calculate the slopes
lepch=10;%10 s epochs
%Reading scoring
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the scoring data');
%handles.news=[];
cd (pathname)
fid = fopen(filename);
for i=1:10
    fgetl(fid);%Read headers
end
k=0;
%getting the parameters for the delta waves:
selchan=get(handles.chanlist,'value');
if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end

while ~feof(fid)
    k=k+1;
    scoring(k)=-1;
    C = textscan(fid,'%s',1);%skip epoch number
    st=textscan(fid,'%s',1);%read scoring
    if strcmp(char(st{1}),'W')
        scoring(k)=0;
    end
    if strcmp(char(st{1}),'WA')
        scoring(k)=0.1;
    end
    if strcmp(char(st{1}),'NR')
        scoring(k)=1;
    end
    if strcmp(char(st{1}),'NA')
        scoring(k)=1.1;
    end
    if strcmp(char(st{1}),'R')
        scoring(k)=2;
    end
    if strcmp(char(st{1}),'RA')
        scoring(k)=2.1;
    end
    l=fgetl(fid);
end
%now getting the average RMS and delta wave per state
fclose(fid)
axis(handles.axes1);
hold on
vectp=(scoring/max(scoring))/3;
vectp=vectp*max(handles.news(:,selchan));
plot((0:k-1)*lepch,vectp,'r-')
handles.news(:,selchan)=handles.news(:,selchan)-mean(handles.news(:,selchan));
news=resample(handles.news(:,selchan),1,5);
figure;plot(news)
minstd=0.5;
maxstd=2;
deltaW=[];
deltaNR=[];
deltaR=[];
indx=find(scoring==1);
disp('Calculating RMS and Delta shape for NREM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    rmsNR(i)=rms(trace);
    stdNR(i)=std(trace);%std during nrem, will be used for normalization
end
normfactor=1.5*mean(stdNR);
news=news./normfactor;
for i=1:length(indx)
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    deltaNR=[deltaNR;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
indx=find(scoring==0);
disp('Calculating RMS and Delta shape for WA')

for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    rmsW(i)=rms(trace);
    deltaW=[deltaW;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
indx=find(scoring==2)
disp('Calculating RMS and Delta shape for REM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    rmsR(i)=rms(trace);
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    deltaR=[deltaR;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
% figure
% subplot(2,1,1)
% plot(rmsW)
% hold on
% plot(rmsNR,'r-')
% plot(rmsR,'k-')
% subplot(2,1,2)
% plot(mean(deltaW))
% hold on
% plot(mean(deltaNR),'r-')
% plot(mean(deltaR),'k-')
newfn=strcat(filename(1:end-4),'.mat')
save(newfn,'rmsW','rmsNR','rmsR','deltaW','deltaNR','deltaR')
helpdlg('File saved')


function deltamatrix=getdeltashape(trace,minstd,maxstd,sr,topl)
y=diff(sign(trace))*max(trace)/2;
%plot(y,'r-')
zcrsp=find(y>1E-7);
zcrsn=find(y<-1E-7);
sampler=sr/5;
durp=diff(zcrsn)/sampler;
%plot (news)
minmax=get(gca,'ylim');
indd=find(durp(1:end-1)>0.25 & durp(1:end-1)<2);
deltamatrix=zeros(length(indd),2*round(sr/5));
s=1;
k=0;
xvec=(0:(length(trace)-1))/sampler;
if topl==1
    figure
    plot(xvec,trace,'k-')
    hold on
end
for t=1:length(indd)
    t0=zcrsn(indd(t));
    tf=zcrsn(1+indd(t));
    tm=zcrsp(1+indd(t));
    if tm>tf
        tm=zcrsp(indd(t));
    end
    
    if (max(trace(t0:tf))>minstd*s && max(trace(t0:tf))<maxstd*s && min(trace(t0:tf)>-maxstd*s) )|| (min(trace(t0:tf)<-minstd*s) && min(trace(t0:tf)>-maxstd*s) && max(trace(t0:tf))<maxstd*s)
        k=k+1;
        dto(k)=t0;
        dtm(k)=tm;
        dtf(k)=tf;
        if topl==1
            plot(xvec(t0:tf),trace(t0:tf),'r-','linewidth',2)
        end
        %centering on the zero crossing tm
        posi=round(sampler)-(tm-t0);
        if posi<1
            posi=1;
        end
        posf=posi+(tf-t0);
        if posf>round(2*sampler)%last point cannot be beyond 2 sec.
            posf=round(2*sampler);
        end
        if posf==100
            deltamatrix(k,posi:posf)=trace(t0:t0+(posf-posi));
        else
            deltamatrix(k,posi:posf)=trace(t0:tf);
        end
    end
end
deltamatrix=deltamatrix(1:k,:);
% if topl==1
%     figure
%     subplot(2,1,1)
%     plot(xvec,trace,'k-')
%     subplot(2,1,2)
%     xvd=(0:size(deltamatrix,2)-1)/(sr/5);
%     plot(xvd,mean(deltamatrix))
%     title('mean delta')
% end


% --- Executes on button press in pushbutton25.
function pushbutton25_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
%Same but for SD and RS
%The first 2160 epochs are considered SD.
lepch=10;%10 s epochs
%Reading scoring
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the scoring data');
%handles.news=[];
cd (pathname)
fid = fopen(filename);
for i=1:10
    fgetl(fid);%Read headers
end
k=0;
%getting the parameters for the delta waves:
selchan=get(handles.chanlist,'value');
if handles.sr(selchan)<200
    handles.sr(selchan)=250;
end

while ~feof(fid)
    k=k+1;
    scoring(k)=-1;
    C = textscan(fid,'%s',1);%skip epoch number
    st=textscan(fid,'%s',1);%read scoring
    if strcmp(char(st{1}),'W')
        scoring(k)=0;
    end
    if strcmp(char(st{1}),'WA')
        scoring(k)=0.1;
    end
    if strcmp(char(st{1}),'NR')
        scoring(k)=1;
    end
    if strcmp(char(st{1}),'NA')
        scoring(k)=1.1;
    end
    if strcmp(char(st{1}),'R')
        scoring(k)=2;
    end
    if strcmp(char(st{1}),'RA')
        scoring(k)=2.1;
    end
    l=fgetl(fid);
end
%now getting the average RMS and delta wave per state
fclose(fid)
axis(handles.axes1);
hold on
vectp=(scoring/max(scoring))/3;
vectp=vectp*max(handles.news(:,selchan));
plot((0:k-1)*lepch,vectp,'r-')
handles.news(:,selchan)=handles.news(:,selchan)-mean(handles.news(:,selchan));
news=resample(handles.news(:,selchan),1,5);
figure;plot(news)
minstd=0.5;
maxstd=2;
%Doing all for the SD part
deltaW=[];
deltaNR=[];
deltaR=[];
rmsW=0;
rmsNR=0;
rmsR=0;
indx=find(scoring==1);
disp('Calculating RMS and Delta shape for NREM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    stdNR(i)=std(trace);%std during nrem, will be used for normalization
end
normfactor=1.5*mean(stdNR);

indx=find(scoring(1:2160)==1);
disp('Calculating RMS and Delta shape for NREM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    rmsNR(i)=rms(trace);
end
normfactor=1.5*mean(stdNR);
news=news./normfactor;
for i=1:length(indx)
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    deltaNR=[deltaNR;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
indx=find(scoring(1:2160)==0);
disp('Calculating RMS and Delta shape for WA')

for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    rmsW(i)=rms(trace);
    deltaW=[deltaW;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
indx=find(scoring(1:2160)==2)
disp('Calculating RMS and Delta shape for REM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    rmsR(i)=rms(trace);
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    deltaR=[deltaR;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
newfn=strcat(filename(1:end-4),'SD.mat')
save(newfn,'rmsW','rmsNR','rmsR','deltaW','deltaNR','deltaR')

%Now for the RS part
deltaW=[];
deltaNR=[];
deltaR=[];
rmsW=0;
rmsNR=0;
rmsR=0;

indx=find(scoring(2161:end)==1);
if length(indx)>0
    indx=indx+2160;
end
disp('Calculating RMS and Delta shape for NREM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    rmsNR(i)=rms(trace);
end
for i=1:length(indx)
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    deltaNR=[deltaNR;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
indx=find(scoring(2161:end)==0);
if length(indx)>0
    indx=indx+2160;
end
disp('Calculating RMS and Delta shape for WA')

for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    rmsW(i)=rms(trace);
    deltaW=[deltaW;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
indx=find(scoring(2161:end)==2);
if length(indx)>0
    indx=indx+2160;
end
disp('Calculating RMS and Delta shape for REM')
for i=1:length(indx)
    trace=handles.news(max(1,round(handles.sr*(indx(i)-1)*lepch)):round(handles.sr*indx(i)*lepch),get(handles.chanlist,'value'));
    rmsR(i)=rms(trace);
    ntrace=news(max(1,round((handles.sr/5)*(indx(i)-1)*lepch)):round((handles.sr/5)*indx(i)*lepch));
    deltaR=[deltaR;getdeltashape(ntrace,minstd,maxstd,handles.sr(selchan),0)];
end
newfn=strcat(filename(1:end-4),'SR.mat')
save(newfn,'rmsW','rmsNR','rmsR','deltaW','deltaNR','deltaR')

helpdlg('Files saved')


% --- Executes on button press in dmts.
function dmts_Callback(hObject, eventdata, handles)
% hObject    handle to dmts (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cn=getComputerName();
cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     p=[2656 333 560 420];
%     set(0, 'DefaultFigurePosition', p)
% end
%reading text file
[filename, pathname] = uigetfile('*.txt', 'Pick the text file with the stim data');
handles.fn=filename;
%handles.news=[];
cd (pathname)
fid = fopen(filename);
disp('Reading text file with results...')
C = textscan(fid,'%s');%Read all fields in file as cell array
Nfields=49;%Number of fields in the TXT file used for this task
indph1=13;%position of the result of phase 1
indph2=22;
indph2given=18;

k=0;
indrph1= C{1}((Nfields+indph1+(0:Nfields:length(C{1})-Nfields-1)));
indrph2= C{1}((Nfields+indph2+(0:Nfields:length(C{1})-Nfields-1)));
%indph2g= C{1}((Nfields+indph2given+(0:Nfields:length(C{1})-Nfields-1)));
p1ok=char(indrph1)=='Y';
p2ok=char(indrph2)=='Y';
%p2g=char(indph2g)=='Y';
indp1ok=find(p1ok);% & p2g);
selchan=get(handles.chanlist,'value');
fclose(fid)
%now getting the timings of each stim presentation from the voltage (must
%be the last channel)
%timestim=zeros(size(indhit));
%dvec=diff(handles.news(:,end));
ldata=length(handles.news(:,end));
vec=handles.news(1:ldata-1,end);
vec2=handles.news(2:ldata,end);
thresvec=0.8*max(vec);
times=find(vec<=thresvec & vec2>thresvec);
timestim=times/handles.sr(end);
figure;
plot((0:ldata-1)/2000,handles.news(:,1));
minmax=get(gca,'ylim');
%building the indexes of stimtime. All points should be assigned to either
%ph1 or ph2. ph1 ok is allways followed by ph2
timepos=0;
nph2=1;
for t=1:length(p1ok)
    timepos=timepos+1;
    ph1stim(t)=timestim(timepos);
    if p1ok(t)
        timepos=timepos+1;
        ph2stim(nph2)=timestim(timepos);
        nph2=nph2+1;
    end
end
newph1=ph1stim(find(p1ok));%discarding the trials when ph1 was not OK
newph2=p2ok(find(p1ok));%Result of phase 2 for the subset when ph1 was OK
hold on
plot([timestim timestim],minmax,'g--')
plot([newph1' newph1'],minmax,'r--')
plot([ph2stim' ph2stim'],minmax,'b--')
timehit=ph2stim(find(newph2));%Time of stim when choice is correct
timemiss=ph2stim(find(newph2==0));%Time of stim when choice is error
timecrej=newph1(find(newph2));%Time of stim of Sample when choice is correct
timefalm=newph1(find(newph2==0));%Time of stim of Sample when choice is error
plot([timehit' timehit'],minmax/2,'k.-')
o1=findobj('color','k');
plot([timemiss' timemiss'],minmax/2,'c.-')
o2=findobj('color','c');
plot([timecrej' timecrej'],minmax/2,'y.-')
o3=findobj('color','y');
plot([timefalm' timefalm'],minmax/2,'m.-')
o4=findobj('color','m');
legend([o1(1) o2(1) o3(1) o4(1)],'Ch OK','Ch err','Samp. Ch OK','Samp. Ch Err')
ch1data=[];ch2data=[];ch3data=[];
lth=length(timehit);
ltm=length(timemiss);
ltc=length(timecrej);
ltf=length(timefalm);

for selchan=1:3
%for selchan=2:2
    e1=handles.news(:,selchan);
    newtimehit=[];
    newtimemiss=[];
    newtimecrej=[];
    newtimefalm=[];
    
    % e2=handles.news(:,2);
    % e3=handles.news(:,3);
    %Now making the matrices. First rebuild the timing only for the artifact free ones.
    thres=1.7E-4;
    linf=1.5;%1.5 s of artifact free data around stim time s
    k=0;
    if lth>0
        for i=1:lth
            if (max(abs(e1(floor((timehit(i)-linf)*handles.sr(selchan)):ceil(timehit(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timehit(i)-linf)*handles.sr(selchan)):ceil(timehit(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimehit(k)=timehit(i);
            end
        end
    end
    
    k=0;
    if ltm>0
        for i=1:ltm
            if (max(abs(e1(floor((timemiss(i)-linf)*handles.sr(selchan)):ceil(timemiss(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timemiss(i)-linf)*handles.sr(selchan)):ceil(timemiss(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimemiss(k)=timemiss(i);
            end
        end
    end
    
    k=0;
    if ltc>0
        for i=1:ltc
            if (max(abs(e1(floor((timecrej(i)-linf)*handles.sr(selchan)):ceil(timecrej(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timecrej(i)-linf)*handles.sr(selchan)):ceil(timecrej(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimecrej(k)=timecrej(i);
            end
        end
    end
    
    
    k=0;
    if ltf>0
        for i=1:ltf
            if (max(abs(e1(floor((timefalm(i)-linf)*handles.sr(selchan)):ceil(timefalm(i)+linf)*handles.sr(selchan)-1)))<thres && max(abs(e1(floor((timefalm(i)-linf)*handles.sr(selchan)):ceil(timefalm(i)+linf)*handles.sr(selchan)-1)))>2E-7)
                k=k+1;
                newtimefalm(k)=timefalm(i);
            end
        end
    end
    
    chlstrings={'Choice Correct','Choice Error','Sample Ch.Correct.','Sample Ch. Error'};
    
    %Now making the matrices twice longer to avoid artifacts caused by the
    %bandpass filter
    mathit=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimehit)));
    matmiss=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimemiss)));
    matcrej=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimecrej)));
    matfalm=zeros(ceil(4*linf*handles.sr(selchan)),length((newtimefalm)));
    s=ceil(4*linf*handles.sr(selchan));
    % figure
    % plot([0 1],[1 1],'g:')
    % hold on
    % plot([0 1],[2 2],'r:')
    % plot([0 1],[3 3],'b:')
    % legend('C. rej.','Hit','Miss')
    %     figure
    %     plot(handles.x,e1,'k')
    %     hold on
    %     o1=0;o2=0;o3=0;o4=0;
    %     if length(timecrej)>0
    %         o1=vline(timecrej./60,'g--');
    %         set(o1,'linewidth',1.5)
    %     end
    %     if length(timehit)>0
    %         o2=vline(timehit./60,'r--');
    %         set(o2,'linewidth',1.5)
    %     end
    %     if length(timefalm)>0
    %         o3=vline(timefalm./60,'m--');
    %         set(o3,'linewidth',1.5)
    %     end
    %     if length(timemiss)>0
    %         o4=vline(timemiss./60,'b--');
    %         set(o4,'linewidth',1.5)
    %     end
    %     plot(handles.x,e1,'k')
    %
    %
    %
    %     %legend('C. Rej.','Hit','Miss','F. Alarm')
    %     axis tight
    switch selchan;%get(handles.chanlist,'value')
        case 1
            cd eeg
        case 2
            cd eeg-1
        case 3
            cd eeg-2
    end
    %     title(get(handles.filename,'string'),'fontsize',16)
    %     xlabel('Min.')
    %     box off
    r1=length(newtimehit)
    if r1>1
        for i=1:r1
            mathit(:,i)=e1(floor((newtimehit(i)-(2*linf))*handles.sr(selchan)):floor((newtimehit(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        mathit=0;
    end
    
    r2=length(newtimemiss)
    if r2>1
        for i=1:r2
            matmiss(:,i)=e1(floor((newtimemiss(i)-(2*linf))*handles.sr(selchan)):floor((newtimemiss(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        matmiss=0;
    end
    
    r3=length(newtimecrej)
    if r3>1
        for i=1:r3
            matcrej(:,i)=e1(floor((newtimecrej(i)-(2*linf))*handles.sr(selchan)):floor((newtimecrej(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        matcrej=0;
    end
    
    r4=length(newtimefalm)
    if r4>1
        for i=1:r4
            matfalm(:,i)=e1(floor((newtimefalm(i)-(2*linf))*handles.sr(selchan)):floor((newtimefalm(i)-(2*linf))*handles.sr(selchan))+s-1);
        end
    else
        matfalm=0;
    end
    
    %storing the matrices in the comon structure
    switch selchan
        case 1
            ch1data.mathit=mathit;
            ch1data.matmiss=matmiss;
            ch1data.matcrej=matcrej;
            ch1data.matfalm=matfalm;
        case 2
            ch2data.mathit=mathit;
            ch2data.matmiss=matmiss;
            ch2data.matcrej=matcrej;
            ch2data.matfalm=matfalm;
        case 3
            ch3data.mathit=mathit;
            ch3data.matmiss=matmiss;
            ch3data.matcrej=matcrej;
            ch3data.matfalm=matfalm;
    end
    
    
    %     figure
    %     subplot(2,2,1)
    %     plot(mathit)
    %     subplot(2,2,2)
    %     plot(matmiss)
    %     subplot(2,2,3)
    %     plot(matcrej)
    %     subplot(2,2,4)
    %     plot(matfalm)
    %Implementing ananlysis using fieldtrip functions for mathit:
    %First making mathit in the CTF format with one channel (mathit).
    %     data.hdr.Fs=handles.sr(selchan);
    %     data.hdr.nChans=1;
    %     data.hdr.nSamples=length(mathit);
    %     data.hdr.nSamplesPre=floor(length(mathit)/2);
    %     data.hdr.nTrials=size(mathit,2);
    %     data.hdr.label={'Mathit'};
    mat2sav=reshape(mathit,1,size(mathit,1)*size(mathit,2));
    save('datamathit.mat','mat2sav')
    mat2sav=reshape(matmiss,1,size(matmiss,1)*size(matmiss,2));
    save('datamatmiss.mat','mat2sav')
    mat2sav=reshape(matcrej,1,size(matcrej,1)*size(matcrej,2));
    save('datamatcrej.mat','mat2sav')
    mat2sav=reshape(matfalm,1,size(matfalm,1)*size(matfalm,2));
    save('datamatfalm.mat','mat2sav')

    %     data.label={'Mathit'};
    %     data.fsample=handles.sr(selchan);
    %     ca={mat2cell(mathit,[length(mathit)],ones(size(mathit,2),1))};
    %     vect=-3:1/2000:3;
    %     vect=vect(1:length(vect)-1);
    %     for i=1:size(mathit,2)
    %         ca{1}(i)=mat2cell(cell2mat(ca{1}(i))')
    %         data.time{i}=vect;
    %     end
    %     data.trial=ca;
    
    %     data.hdr.nChans=1;
    %     data.hdr.nSamples=length(mathit);
    %     data.hdr.nSamplesPre=floor(length(mathit)/2);
    %     data.hdr.nTrials=size(mathit,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% COmenting the plotting:
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %     sx=0:ceil(4*linf*handles.sr(selchan))-1;
    %     sx=sx*4*linf/(ceil(4*linf*handles.sr(selchan))-1);
    %     sx=sx-2*linf;
    %     fa=figure
    %     set(fa, 'Position', get(0,'Screensize')); % Maximize figure.
    %     hold on
    %     plegend={};
    %     if r1>1
    %         plot(sx,mean(mathit'),'k-')
    %         plegend{1}='Hit';
    %         fname='meanhit.txt';
    %         aux=mean(mathit');
    %         save(fname,'aux','-ascii')
    %     end
    %     hold on
    %     if r2>1
    %         plot(sx,mean(matmiss'),'r-')
    %         plegend{length(plegend)+1}='Miss';
    %         fname='meanmiss.txt';
    %         aux=mean(matmiss');
    %         save(fname,'aux','-ascii')
    
    
    %     end
    %     if r3>1
    %         plot(sx,mean(matcrej'),'b-')
    %         plegend{length(plegend)+1}='Crect. Rej.';
    %         fname='meancrej.txt';
    %         aux=mean(matcrej');
    %         save(fname,'aux','-ascii')
    %
    %     end
    %     if r4>1
    %         plot(sx,mean(matfalm'),'g-')
    %         plegend{length(plegend)+1}='F. Alarm';
    %         fname='meanfalm.txt';
    %         aux=mean(matfalm');
    %         save(fname,'aux','-ascii')
    %
    %     end
    %     set(gca,'fontsize',12)
    %     minmax=get(gca,'ylim');
    %     plot([0 0],minmax,'c--')
    %     title('Average','fontsize',16)
    %     legend(plegend)
    %     set(gca,'xlim',[-0.1 1.5])
    %     saveas(fa,'average.jpg')
    %Now getting the RMS value in the power bands.
    
    tit=[{'RMS Alpha_ (8-12 Hz)'},{'RMS Beta__ (16-24 Hz)'},{'RMS LowG__ (30-50)'},{'RMS HighG (50-80)'}];
    initial=[8 16 30 50];
    final=[12 24 50 80];
    %close
    for q=1:length(initial)
        %wsize=1/initial(q);
        wsize=0.1;
        ny1=[];ny2=[];ny3=[];ny4=[];rmsm1=[];rmsm2=[];rmsm3=[];rmsm4=[];
        ff=figure %this is the fig for the respective frequency band
        set(ff, 'Position', get(0,'Screensize')); % Maximize figure.
        if r1>1
            %ny1=bandpassfilter(mathit,handles.sr(selchan),[initial(q) final(q)]);
            for ii=1:size(mathit,2)
                ny1(:,ii)=bandpassfilter(mathit(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            
            ny1=ny1(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny1,2)
                %binning each row:
                aux1=ny1(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm1=reshape(aux1,floor(wsize*handles.sr(selchan)),floor(length(ny1)/(wsize*handles.sr(selchan))));
                rmsm1(w,:)=rms(nm1);
            end
            mm1=mean(rmsm1);
            
            x0=(2*linf*(0:length(mm1)-1)/(length(mm1)-1))-(linf);
            % plot(nt,mm,'r.-')
            % hold on
            % minmax=get(gca,'ylim');
            % plot([0 0],minmax,'r--')
            subplot(2,2,1)
            %     x0=[0:wsize/(2*linf):2*linf];
            %     x0=x0-linf;
            errorbar(x0,mean(rmsm1),sem(rmsm1),'k-');
            hold on
            %plot(x0,rmsm1,'g-')
            plot(x0,mean(rmsm1),'ko-','linewidth',2)
            [xd,yd]=size(rmsm1);
%                      for ii=1:xd
%                          plot(x0,rmsm1(ii,:),'color',0.7*[ii/yd ii/yd ii/yd])
%                      end
                        set(gca,'fontsize',14)
                        xlabel('s','fontsize',16)
                        ylabel('V','fontsize',16)
                        title(char(tit(q)),'fontsize',18)
                        legend(strcat(chlstrings{1},' N=',num2str(r1)))
                        minmax=get(gca,'ylim');
                        plot([0 0]',minmax,'g--')
                        set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
                        %now saving data in ascii
                         tname=char(tit(q));
                         fname=strcat(tname(1:10),chlstrings{1},'.txt');
                         
                        axis tight
                        saveas(ff,fname(5:9),'fig')
                        saveas(ff,fname(5:9),'jpg')
            m1t=rmsm1;
            save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.hit_rmsalpha=m1t';
                        case 2
                            ch2data.hit_rmsalpha=m1t';
                        case 3
                            ch3data.hit_rmsalpha=m1t';
                    end
                                 
                case 2
                    switch selchan
                        case 1
                            ch1data.hit_rmsbeta=m1t';
                        case 2
                            ch2data.hit_rmsbeta=m1t';
                        case 3
                            ch3data.hit_rmsbeta=m1t';
                    end
                    
                case 3
                    switch selchan
                        case 1
                            ch1data.hit_rmsLowG=m1t';
                        case 2
                            ch2data.hit_rmsLowG=m1t';
                        case 3
                            ch3data.hit_rmsLowG=m1t';
                    end
                    
                case 4
                    switch selchan
                        case 1
                            ch1data.hit_rmshighG=m1t';
                        case 2
                            ch2data.hit_rmshighG=m1t';
                        case 3
                            ch3data.hit_rmshighG=m1t';
                    end
                    
            end
            
            
        else
            mm1=0;
        end
        
        if r2>1
            for ii=1:size(matmiss,2)
                ny2(:,ii)=bandpassfilter(matmiss(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            ny2=ny2(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny2,2)
                %binning each row:
                aux=ny2(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(ny2)/(wsize*handles.sr(selchan))));
                rmsm2(w,:)=rms(nm);
            end
            mm2=mean(rmsm2);
            
                        x0=(2*linf*(0:length(mm2)-1)/(length(mm2)-1))-(linf);
                        subplot(2,2,2)
                        errorbar(x0,mean(rmsm2),sem(rmsm2),'k-');
                        hold on
                        %plot(x0,rmsm2,'g-')
                        plot(x0,mean(rmsm2),'ko-','linewidth',2)
                        set(gca,'fontsize',14)
                        xlabel('s','fontsize',16)
                        ylabel('V','fontsize',16)
                        title(char(tit(q)),'fontsize',18)
                        legend(strcat(chlstrings{2},' N=',num2str(r2)))
                        minmax=get(gca,'ylim');
                        plot([0 0]',minmax,'g--')
            
                        %now saving data in ascii
                        tname=char(tit(q));
                        fname=strcat(tname(1:10),chlstrings{2},'.txt')
                        m1t=rmsm2;
                        axis tight
                        saveas(ff,fname(5:9),'fig')
                        saveas(ff,fname(5:9),'jpg')
                        save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.mises_rmsalpha=m1t';
                        case 2
                            ch2data.mises_rmsalpha=m1t';
                        case 3
                            ch3data.mises_rmsalpha=m1t';
                    end
                    %             save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.mises_rmsbeta=m1t';
                        case 2
                            ch2data.mises_rmsbeta=m1t';
                        case 3
                            ch3data.mises_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.mises_rmsLowG=m1t';
                        case 2
                            ch2data.mises_rmsLowG=m1t';
                        case 3
                            ch3data.mises_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.mises_rmshighG=m1t';
                        case 2
                            ch2data.mises_rmshighG=m1t';
                        case 3
                            ch3data.mises_rmshighG=m1t';
                    end
            end
            
        else
            mm2=0;
        end
        
        
        if r3>1
            for ii=1:size(matcrej,2)
                ny3(:,ii)=bandpassfilter(matcrej(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            ny3=ny3(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny3,2)
                %binning each row:
                aux=ny3(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(ny3)/(wsize*handles.sr(selchan))));
                rmsm3(w,:)=rms(nm);
            end
            mm3=mean(rmsm3);
            
                        x0=(2*linf*(0:length(mm3)-1)/(length(mm3)-1))-(linf);
                        subplot(2,2,3)
                        errorbar(x0,mean(rmsm3),sem(rmsm3),'k-');
                        hold on
                        %plot(x0,rmsm3,'g-')
                        plot(x0,mean(rmsm3),'ko-','linewidth',2)
                        set(gca,'fontsize',14)
                        xlabel('s','fontsize',16)
                        ylabel('V','fontsize',16)
                        title(char(tit(q)),'fontsize',18)
                        legend(strcat(chlstrings{3},' N=',num2str(r3)))
                        minmax=get(gca,'ylim');
                        plot([0 0]',minmax,'g--')
            
                        %now saving data in ascii
                        tname=char(tit(q));
                        fname=strcat(tname(1:10),'sampleOK','.txt');
                        axis tight
                        saveas(ff,fname(5:9),'fig')
                        saveas(ff,fname(5:9),'jpg')
            m1t=rmsm3;
            %
                        save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.crej_rmsalpha=m1t';
                        case 2
                            ch2data.crej_rmsalpha=m1t';
                        case 3
                            ch3data.crej_rmsalpha=m1t';
                    end
                                save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.crej_rmsbeta=m1t';
                        case 2
                            ch2data.crej_rmsbeta=m1t';
                        case 3
                            ch3data.crej_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.crej_rmsLowG=m1t';
                        case 2
                            ch2data.crej_rmsLowG=m1t';
                        case 3
                            ch3data.crej_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.crej_rmshighG=m1t';
                        case 2
                            ch2data.crej_rmshighG=m1t';
                        case 3
                            ch3data.crej_rmshighG=m1t';
                    end
            end
        else
            mm3=0;
        end
        
        if r4>1
            for ii=1:size(matfalm,2)
                ny4(:,ii)=bandpassfilter(matfalm(:,ii),handles.sr(selchan),[initial(q) final(q)]);
            end
            
            %ny4=bandpassfilter(matfalm,handles.sr(selchan),[initial(q) final(q)]);
            ny4=ny4(linf*handles.sr(selchan):3*linf*handles.sr(selchan)-1,:);
            for w=1:size(ny4,2)
                %binning each row:
                aux=ny4(1:handles.sr(selchan)*wsize*floor(2*linf/wsize),w);
                nm=reshape(aux,floor(wsize*handles.sr(selchan)),floor(length(ny4)/(wsize*handles.sr(selchan))));
                rmsm4(w,:)=rms(nm);
            end
            mm4=mean(rmsm4);
            
                        x0=(2*linf*(0:length(mm4)-1)/(length(mm4)-1))-(linf);
                        subplot(2,2,4)
                        errorbar(x0,mean(rmsm4),sem(rmsm4),'k-');
                        hold on
                        %plot(x0,rmsm4,'g-')
                        plot(x0,mean(rmsm4),'ko-','linewidth',2)
                        set(gca,'fontsize',14)
                        xlabel('s','fontsize',16)
                        ylabel('V','fontsize',16)
                        title(char(tit(q)),'fontsize',18)
                        legend(strcat(chlstrings{4},' N=',num2str(r4)))
                        minmax=get(gca,'ylim');
                        plot([0 0]',minmax,'g--')
            
                        %now saving data in ascii
                        tname=char(tit(q));
                        fname=strcat(tname(1:10),'sampleERR','.txt');
                        axis tight
                        saveas(ff,fname(5:9),'fig')
                        saveas(ff,fname(5:9),'jpg')
            m1t=rmsm4;
                        save(fname,'m1t','-ascii')
            switch q
                case 1
                    switch selchan
                        case 1
                            ch1data.falm_rmsalpha=m1t';
                        case 2
                            ch2data.falm_rmsalpha=m1t';
                        case 3
                            ch3data.falm_rmsalpha=m1t';
                    end
                    %             save(fname,'m1t','-ascii')
                case 2
                    switch selchan
                        case 1
                            ch1data.falm_rmsbeta=m1t';
                        case 2
                            ch2data.falm_rmsbeta=m1t';
                        case 3
                            ch3data.falm_rmsbeta=m1t';
                    end
                case 3
                    switch selchan
                        case 1
                            ch1data.falm_rmsLowG=m1t';
                        case 2
                            ch2data.falm_rmsLowG=m1t';
                        case 3
                            ch3data.falm_rmsLowG=m1t';
                    end
                case 4
                    switch selchan
                        case 1
                            ch1data.falm_rmshighG=m1t';
                        case 2
                            ch2data.falm_rmshighG=m1t';
                        case 3
                            ch3data.falm_rmshighG=m1t';
                    end
            end
        else
            mm4=0;
        end
        %     figure
        %     subplot(2,2,1)
        %     plot(mean(ny1'));
        %         subplot(2,2,2)
        %     plot(mean(ny2'));
        %
        %         subplot(2,2,3)
        %     plot(mean(ny3'));
        %
        %         subplot(2,2,4)
        %     plot(mean(ny4'));
        %
        %Nowthe FFTs
        
        
        close(ff)
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%
    %% NOW THE REAL DEAL %%
    %%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%
    kqk=1;
    if kqk==1
      %  Read mat file, convert it to EDf, plot ERP , save EDF and calculate power of each band per trial and average time-freq. heatmap
              if r3>1
                    clipboard('copy','2000 4500')
                  eegout=pop_importdata('setname','crej','data','datamatcrej.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
         %pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
                     pop_erpimage(eegout,1);
                    f=gca;
                    title('ERP Sample Ch. Correct')
                    set(f, 'Position', get(0,'Screensize')); % Maximize figure.
        
                    saveas(gca,'ERPsampleOK','fig')
                    saveas(gca,'ERPsampleOK','jpg')
                  clipboard('copy','crej.edf')
                  pop_writeeeg(eegout);
        %close
             end
             if r1>1
                 clipboard('copy','2000 4500')
                 eegout=pop_importdata('setname','hits','data','datamathit.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
         pop_erpimage(eegout,1);
         title('ERP OK')
                    saveas(gca,'ERPchoiceOK','fig')
                    saveas(gca,'ERPchoiceOK','jpg')
                 %pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
        
        %helpdlg('name must be hits.edf')
                clipboard('copy','hits.edf')
                pop_writeeeg(eegout);%, 'type','EDF');
        %close
             end
         if r4>1
                 clipboard('copy','2000 4500')
                 eegout=pop_importdata('setname','falm','data','datamatfalm.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
         pop_erpimage(eegout,1);
                 %pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
        set(gca, 'Position', get(0,'Screensize')); % Maximize figure.
                    title('ERP Sample Ch Err.')
                    saveas(gca,'ERPsampErr','fig')
                    saveas(gca,'ERPsampErr','jpg')
        %helpdlg('name must be falm.edf')
                clipboard('copy','falm.edf')
                pop_writeeeg(eegout);%, 'type','EDF');
        %close
           end

             
           if r2>1
               clipboard('copy','2000 4500')
               eegout=pop_importdata('setname','misses','data','datamatmiss.mat','dataformat','matlab','subject','braulio','nbchan',1,'pnts',12000,'srate',2000);
        %pop_erpimage(eegout,1);
               %pop_erpimage(eegout,1,1, [], 'ERP',5, 0, [], [2,4.5]);
                    pop_erpimage(eegout,1);
                    set(gca, 'Position', get(0,'Screensize')); % Maximize figure.
                    title('ERP Error')
                    saveas(gca,'ERPerror','fig')
                    saveas(gca,'ERPerror','jpg')
        %helpdlg(' must be misses.edf')
              clipboard('copy','misses.edf')
              pop_writeeeg(eegout);%, 'type','EDF','label',{'miss'},'T0',[1999 10 10 12 00 00.0]);
        %close
          end
        %Now loading the new EDf and getting the time-freq heatmap and svaing
        %the averge power by bands in a text file and the plots in jpg's.
        
        for ii=1:4
            
            %skipping void cases
            if ii==1 & r3<2
                ii=ii+1;
            end
            if ii==2 & r1<2
                ii=ii+1;
            end
            if ii==3 & r2<2
                ii=ii+1;
            end
            if ii==4 & r4<2
                
                break;
            end
            
            
            switch ii
                case 1
                    fn='crej.edf'
                    ntrial=r3;
                case 2
                    fn='hits.edf'
                    ntrial=r1;
                case 3
                    fn='misses.edf'
                    ntrial=r2;
                case 4
                    fn='falm.edf'
                    ntrial=r4;
            end
            
            cfg = [];                                           % empty configuration
            cfg.dataset                 = fn;       % name of CTF dataset
            cfg.trialdef.triallength=6;
            cfg.trialdef.ntrials=ntrial;
            cfg = ft_definetrial(cfg);
            cfg.continuous='yes';
            %chname='Chan 1';%handles.hedf.Label;
            chname=handles.hedf.Label(selchan,:);
            while (chname(end)==' ')
                chname=chname(1:end-1);
            end
            % preprocess the data
            cfg.channel   =chname
            cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
            dataFIC = ft_preprocessing(cfg);
            for kk=1:length(dataFIC.trial)
                dataFIC.trial{kk}=dataFIC.trial{kk}*1E6;
            end
            cfg              = [];
            cfg.output       = 'pow';
            cfg.channel      = chname;
            cfg.method       = 'mtmconvol';
            cfg.taper        = 'hanning';
            cfg.keeptrials = 'yes';
            cfg.foi          = 2:2:80;                         % analysis 2 to 30 Hz in steps of 2 Hz
            cfg.t_ftimwin    = ones(length(cfg.foi),1).*0.5;   % length of time window = 0.5 sec
            cfg.toi          = 2:0.01:4.5;                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
            TFRhann = ft_freqanalysis(cfg, dataFIC);
            xtimes=cfg.toi-3;
            cfg = [];
            cfg.baseline     = [2 2.9];
            cfg.baselinetype ='relative';
            %cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
            cfg.channel      = chname;
            cfg.zlim = [0 6];
            figure
            ft_singleplotTFR(cfg,TFRhann);
            %title('mtmconvol= multiplication in the frequency domain')
            set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1','1.5'})
            set(gca,'fontsize',14)
            title(strcat('Avg FFT ',fn(1:end-4),'_ch:',selchan))
            saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'fig');
            saveas(gca,strcat(fn(1:end-4),'_Avg_FFT'),'jpg');
            %close
            auxps=fixdim(TFRhann.powspctrm);
            deltaFFT=fixdim(auxps(:,1,:));
            thetaFFT=fixdim(mean(auxps(:,2:4,:),2));
            alphaFFT=fixdim(mean(auxps(:,4:6,:),2));
            betaFFT=fixdim(mean(auxps(:,8:12,:),2));
            lowGFFT=fixdim(mean(auxps(:,15:25,:),2));
            highGFFT=fixdim(mean(auxps(:,25:40,:),2));
            meanfft=fixdim(mean(auxps,1));
            %plotting and saving the figs and matrices
            save(strcat(fn(1:end-4),'_Avg_FFT.txt'),'meanfft','-ascii')
            switch ii%Crej, hits or misses
                case 1                    
                    fn='crej.edf'
                    ntrial=r3;
                case 2
                    fn='hits.edf'
                    ntrial=r1;
                case 3
                    fn='misses.edf'
                    ntrial=r2;
                case 4
                    fn='falms.edf'
                    ntrial=r4;
            end
            %figure
            %set(gcf, 'Position', get(0,'Screensize')); % Maximize figure.
            %subplot(2,3,1)
            %             x=-1:0.01:1.5;
            %             m=fixdim(mean(deltaFFT));
            %             einf=fixdim(m-sem(deltaFFT));
            %             emax=m+sem(deltaFFT);
            %             X=[x,fliplr(x)];                %create continuous x value array for plotting
            %             Y=[einf,fliplr(emax)];              %create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                  %plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Fast Delta (2-4 Hz)')
            
            %subplot(2,3,2)
            %             m=mean(thetaFFT);
            %             einf=m-sem(thetaFFT);
            %             emax=m+sem(thetaFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                %#plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Theta (4-8 Hz)')
            
            
            %subplot(2,3,3)
            %             m=mean(alphaFFT);
            %             einf=m-sem(alphaFFT);
            %             emax=m+sem(alphaFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                %#plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Alpha (8-12 Hz)')
            
            
            %subplot(2,3,4)
            %             m=mean(betaFFT);
            %             einf=m-sem(betaFFT);
            %             emax=m+sem(betaFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %fill(X,Y,'c','EdgeColor','none');                 %#plot filled area
            %hold on
            %plot(x,m(1:length(x)),'b','linewidth',2)
            %title('Beta (16-24 Hz)')
            
            
            %             subplot(2,3,5)
            %             m=mean(lowGFFT);
            %             einf=m-sem(lowGFFT);
            %             emax=m+sem(lowGFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %             fill(X,Y,'c','EdgeColor','none');             %#plot filled area
            %             hold on
            %             plot(x,m(1:length(x)),'b','linewidth',2)
            %             title('Low G (30-50 Hz)')
            %
            %             subplot(2,3,6)
            %             m=mean(highGFFT);
            %             einf=m-sem(highGFFT);
            %             emax=m+sem(highGFFT);
            %             Y=[einf,fliplr(emax)];              %#create y values for out and then back
            %             fill(X,Y,'c','EdgeColor','none');                  %#plot filled area
            %             hold on
            %             plot(x,m(1:length(x)),'b','linewidth',2)
            %             title('High G (50-80 Hz)')
            %             set(gca, 'Position', get(0,'Screensize')); % Maximize figure.
            %             fign=strcat('band_fft_',fn(1:end-4),'.jpg');
            %             saveas(gca,fign);
            %             close
            switch ii
                case 1
                    fn2=('deltaFFT_sampleOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_sampleOK.txt');%',fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_sampleOK');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_sampleOK');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_sampleOK');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_sampleOK');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.crej_avgFFT=meanfft;
                            ch1data.crej_deltaFFT=deltaFFT;
                            ch1data.crej_thetaFFT=thetaFFT;
                            ch1data.crej_alphaFFT=alphaFFT;
                            ch1data.crej_betaFFT=betaFFT;
                            ch1data.crej_lowGFFT=lowGFFT;
                            ch1data.crej_highGFFT=highGFFT;
                        case 2
                            ch2data.crej_avgFFT=meanfft;
                            ch2data.crej_deltaFFT=deltaFFT;
                            ch2data.crej_thetaFFT=thetaFFT;
                            ch2data.crej_alphaFFT=alphaFFT;
                            ch2data.crej_betaFFT=betaFFT;
                            ch2data.crej_lowGFFT=lowGFFT;
                            ch2data.crej_highGFFT=highGFFT;
                        case 3
                            ch3data.crej_avgFFT=meanfft;
                            ch3data.crej_deltaFFT=deltaFFT;
                            ch3data.crej_thetaFFT=thetaFFT;
                            ch3data.crej_alphaFFT=alphaFFT;
                            ch3data.crej_betaFFT=betaFFT;
                            ch3data.crej_lowGFFT=lowGFFT;
                            ch3data.crej_highGFFT=highGFFT;
                    end
                    
                    %                 helpdlg('txt File saved')
                case 2
                    fn2=('deltaFFT_choiceOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_choiceOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_choiceOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_choiceOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_choiceOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_choiceOK.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.hits_avgFFT=meanfft;
                            ch1data.hits_deltaFFT=deltaFFT;
                            ch1data.hits_thetaFFT=thetaFFT;
                            ch1data.hits_alphaFFT=alphaFFT;
                            ch1data.hits_betaFFT=betaFFT;
                            ch1data.hits_lowGFFT=lowGFFT;
                            ch1data.hits_highGFFT=highGFFT;
                        case 2
                            ch2data.hits_avgFFT=meanfft;
                            ch2data.hits_deltaFFT=deltaFFT;
                            ch2data.hits_thetaFFT=thetaFFT;
                            ch2data.hits_alphaFFT=alphaFFT;
                            ch2data.hits_betaFFT=betaFFT;
                            ch2data.hits_lowGFFT=lowGFFT;
                            ch2data.hits_highGFFT=highGFFT;
                        case 3
                            ch3data.hits_avgFFT=meanfft;
                            ch3data.hits_deltaFFT=deltaFFT;
                            ch3data.hits_thetaFFT=thetaFFT;
                            ch3data.hits_alphaFFT=alphaFFT;
                            ch3data.hits_betaFFT=betaFFT;
                            ch3data.hits_lowGFFT=lowGFFT;
                            ch3data.hits_highGFFT=highGFFT;
                    end
                 case 4
                    fn2=('deltaFFT_sampleERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_sampleERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_sampleERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_sampleERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_sampleERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_sampleERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.falm_avgFFT=meanfft;
                            ch1data.falm_deltaFFT=deltaFFT;
                            ch1data.falm_thetaFFT=thetaFFT;
                            ch1data.falm_alphaFFT=alphaFFT;
                            ch1data.falm_betaFFT=betaFFT;
                            ch1data.falm_lowGFFT=lowGFFT;
                            ch1data.falm_highGFFT=highGFFT;
                        case 2
                            ch2data.falm_avgFFT=meanfft;
                            ch2data.falm_deltaFFT=deltaFFT;
                            ch2data.falm_thetaFFT=thetaFFT;
                            ch2data.falm_alphaFFT=alphaFFT;
                            ch2data.falm_betaFFT=betaFFT;
                            ch2data.falm_lowGFFT=lowGFFT;
                            ch2data.falm_highGFFT=highGFFT;
                        case 3
                            ch3data.falm_avgFFT=meanfft;
                            ch3data.falm_deltaFFT=deltaFFT;
                            ch3data.falm_thetaFFT=thetaFFT;
                            ch3data.falm_alphaFFT=alphaFFT;
                            ch3data.falm_betaFFT=betaFFT;
                            ch3data.falm_lowGFFT=lowGFFT;
                            ch3data.falm_highGFFT=highGFFT;
                    end    
                case 3
                    fn2=('deltaFFT_choiceERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'deltaFFT','-ascii')
                    fn2=('thetaFFT_choiceERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'thetaFFT','-ascii')
                    fn2=('alphaFFT_choiceERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'alphaFFT','-ascii')
                    fn2=('betaFFT_choiceERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'betaFFT','-ascii')
                    fn2=('lowGFFT_choiceERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'lowGFFT','-ascii')
                    fn2=('highGFFT_choiceERR.txt');%,fn(1:end-4),'.txt');
                    save(fn2,'highGFFT','-ascii')
                    switch selchan
                        case 1
                            ch1data.mises_avgFFT=meanfft;
                            ch1data.mises_deltaFFT=deltaFFT;
                            ch1data.mises_thetaFFT=thetaFFT;
                            ch1data.mises_alphaFFT=alphaFFT;
                            ch1data.mises_betaFFT=betaFFT;
                            ch1data.mises_lowGFFT=lowGFFT;
                            ch1data.mises_highGFFT=highGFFT;
                        case 2
                            ch2data.mises_avgFFT=meanfft;
                            ch2data.mises_deltaFFT=deltaFFT;
                            ch2data.mises_thetaFFT=thetaFFT;
                            ch2data.mises_alphaFFT=alphaFFT;
                            ch2data.mises_betaFFT=betaFFT;
                            ch2data.mises_lowGFFT=lowGFFT;
                            ch2data.mises_highGFFT=highGFFT;
                        case 3
                            ch3data.mises_avgFFT=meanfft;
                            ch3data.mises_deltaFFT=deltaFFT;
                            ch3data.mises_thetaFFT=thetaFFT;
                            ch3data.mises_alphaFFT=alphaFFT;
                            ch3data.mises_betaFFT=betaFFT;
                            ch3data.mises_lowGFFT=lowGFFT;
                            ch3data.mises_highGFFT=highGFFT;
                    end
                    
            end
            
        end
        
    end
    
    
    
    
    cd ..
    
    
end
newfn=strcat(handles.fn(1:end-4),'.mat')
save(newfn,'ch1data','ch2data','ch3data')

%Saving trials
choice1OK=ch1data.mathit;
choice2OK=ch2data.mathit;
choice3OK=ch3data.mathit;

choice1ERR=ch1data.matmiss;
choice2ERR=ch2data.matmiss;
choice3ERR=ch3data.matmiss;

sample1OK=ch1data.matcrej;
sample2OK=ch2data.matcrej;
sample3OK=ch3data.matcrej;

sample1ERR=ch1data.matfalm;
sample2ERR=ch2data.matfalm;
sample3ERR=ch3data.matfalm;


save ('choice1OK.txt','choice1OK','-ascii')
save ('choice2OK.txt','choice2OK','-ascii')
save ('choice3OK.txt','choice3OK','-ascii')

save ('sample1OK.txt','sample1OK','-ascii')
save ('sample2OK.txt','sample2OK','-ascii')
save ('sample3OK.txt','sample3OK','-ascii')

save ('sample1ERR.txt','sample1ERR','-ascii')
save ('sample2ERR.txt','sample2ERR','-ascii')
save ('sample3ERR.txt','sample3ERR','-ascii')

save ('choice1ERR.txt','choice1ERR','-ascii')
save ('choice2ERR.txt','choice2ERR','-ascii')
save ('choice3ERR.txt','choice3ERR','-ascii')



guidata(hObject, handles);



% --- Executes on button press in get_onset.
function get_onset_Callback(hObject, eventdata, handles)
% hObject    handle to get_onset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lvect=length(handles.news);
aux=zeros(lvect,1);
aux(1:lvect-1)=handles.news(2:lvect,handles.selchan);
aux(lvect)=aux(lvect-1);
thres=(max(aux)+min(aux))/2;
handles.postim=find(handles.news(:,handles.selchan)<thres & aux>thres);
figure;plot(handles.postim,'kd')
set(handles.onset,'value',1)
timest=handles.postim/handles.sr(handles.selchan);
save('sttimes.mat','timest')
helpdlg('stim time saved')
guidata(hObject, handles);


% --- Executes on button press in erp.
function erp_Callback(hObject, eventdata, handles)
% hObject    handle to erp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Getting the ERP based on the read stimulus. 
if get(handles.onset,'value')
    %cannot use reshape since the ISI is not constant 
    %Findingmin ISI:
    minisi=min(diff(handles.postim))-1;
    newmat=zeros(length(handles.postim),minisi);
    disp(handles.selchan)
    for i=1:length(handles.postim)
        newmat(i,:)=handles.news(handles.postim(i):handles.postim(i)+minisi-1,handles.selchan);
    end
    figure
    plot(mean(newmat))
else
    helpdlg('load the stim first!')
end

% --- Executes on button press in onset.
function onset_Callback(hObject, eventdata, handles)
% hObject    handle to onset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of onset


% --- Executes on button press in array.
function array_Callback(hObject, eventdata, handles)
% hObject    handle to array (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


selchan=get(handles.chanlist,'value');

tl=length(handles.news)/handles.sr(selchan);%total length in s
pl=length(handles.news(:,1));
xvec=tl*(0:pl-1)/(pl-1);
figure
for i=1:size(handles.news,2)
    if i==1
        plot(xvec,handles.news(:,i)')
        axis tight
        minmax=get(gca,'ylim');
        hold on
    else
        plot(xvec,(i-1)*sum(abs(minmax))+handles.news(:,i)')
        axis tight
    end
end
title('Raw')
xlabel('S')
%set(gca,'xlim',[15.1 15.3])
figure
for i=1:size(handles.news,2)
    if i==1
        plot(xvec,handles.news(:,i)'-mean(handles.news'))
        axis tight
        minmax=get(gca,'ylim');
        hold on
    else
        plot(xvec,(i-1)*sum(abs(minmax))+handles.news(:,i)'-median(handles.news'))
        axis tight
    end
end
title('Fixed?')
xlabel('S')
guidata(hObject, handles);


% --- Executes on button press in timeFrec.
function timeFrec_Callback(hObject, eventdata, handles)
% hObject    handle to timeFrec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
strtT=60*str2num(get(handles.edit5,'string'));
endT=60*str2num(get(handles.edit6,'string'));
fn=handles.fn;
ntrial=1;
cfg = [];                                           % empty configuration
cfg.dataset                 = fn;       % name of CTF dataset
cfg.trialdef.triallength=handles.dur;
cfg.trialdef.ntrials=ntrial;
cfg = ft_definetrial(cfg);
cfg.continuous='yes';
chname=handles.hedf.Label;
% while (chname(end)==' ')
%     chname=chname(1:end-1);
% end
% preprocess the data
cfg.channel   =chname
cfg.demean    = 'no';%'yes';                              % do baseline correction with the complete trial
dataFIC = ft_preprocessing(cfg);
for kk=1:length(dataFIC.trial)
    dataFIC.trial{kk}=dataFIC.trial{kk};
end
cfg              = [];
cfg.output       = 'pow';
cfg.channel      = {chname};
cfg.method       = 'mtmconvol';%
cfg.taper        = 'hanning';
cfg.keeptrials = 'yes';
cfg.foi          = 1:1:100;                         % analysis 2 to 30 Hz in steps of 2 Hz
cfg.t_ftimwin    = ones(length(cfg.foi),1).*1;%0.5;   % length of time window = 0.5 sec
cfg.toi          = strtT:0.002:endT;                  % time window "slides" from -1 to 1.5 sec in steps of 10 ms
TFRhann = ft_freqanalysis(cfg, dataFIC);
xtimes=cfg.toi-3;
cfg = [];
cfg.baseline     = [strtT 10+strtT];
cfg.baselinetype ='relative';%'absolute';
%TFRhann.powspctrm=log(TFRhann.powspctrm);
%TFRhann.powspctrm=TFRhann.powspctrm-min(min(TFRhann.powspctrm))
%cfg.zlim         =[ min(min(TFRhann.powspctrm))  max(max(TFRhann.powspctrm))];
cfg.channel      = chname;
cfg.zlim = [0 70];
figure

ft_singleplotTFR(cfg,TFRhann);
%title('mtmconvol= multiplication in the frequency domain')
%set(gca,'XTickLabel',{'-1','-0.5','0','0.5','1','1.5'})
set(gca,'fontsize',14)
selchan=1;
title(strcat('Avg FFT ',fn(1:end-4),'_ch:',selchan))


% --- Executes on button press in mmn.
function mmn_Callback(hObject, eventdata, handles)
% hObject    handle to mmn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Mismatch negativity for auditory stim%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%finding the timings from ch 3
selchan=4;
cheeg1=2;
cheeg2=3;
aux1=handles.news(2:end,selchan);
aux2=handles.news(1:end-1,selchan);
stmtime=find(aux2<3 & aux1>3);
[v,p]=max(stmtime);
if v>length(aux1)-handles.sr(1)
    stmtime=stmtime(1:end-1);%If there is less than 1 s of blank at the end, remove the last stim.
end

stmtimeoff=find(aux2>3 & aux1<3);
 figure;
 x=(0:length(handles.news(:,selchan))-1)/handles.sr(1);
 plot(x,handles.news(:,selchan),'.-');

inds=find(aux2(stmtime+15)<5);
indd=find(aux2(stmtime+15)>5);

inddev=stmtime(indd);
indstd=stmtime(inds);
%plotting the jitter in the detection of the stim
% for i=1:length(inddev)
%     matd(i,:)=aux2(inddev(i)-30:inddev(i)+30);
% end
% for i=1:length(indstd)
%     mats(i,:)=aux2(indstd(i)-30:indstd(i)+30);
% end
% figure;subplot(1,2,1)
% plot(matd')
% subplot(1,2,2)
% plot(mats')
% title('Detected voltage')
prestim=0.2;
lprestim=ceil(handles.sr(1)*prestim);
poststim=0.6;
lpoststim=ceil(handles.sr(1)*poststim);
% erpstd1=zeros(lprestim+lpoststim,length(indstd));
% erpdev1=zeros(lprestim+lpoststim,length(inddev));
% erpdev2=erpdev1;
% erpstd2=erpstd1;
figure;plot(x(1:length(aux2)),aux2);hold on;plot([inddev inddev]'/handles.sr(1),[0 6],'r-')
plot([indstd indstd]'/handles.sr(1),[0 6],'g--')
k1=1;
k2=1;
thresholdn=1E-4;
for i=1:length(indstd);
    stp=indstd(i)-lprestim;
    if max(abs(handles.news(stp:stp+lprestim+lpoststim-1,cheeg1)))<thresholdn%3*std(handles.news(stp:stp+lprestim+lpoststim-1,1))
        erpstd1(:,k1)=lowpassfilter(handles.news(stp:stp+lprestim+lpoststim-1,cheeg1),handles.sr(1),50);
        k1=k1+1;
    end
    if max(abs(handles.news(stp:stp+lprestim+lpoststim-1,cheeg2)))<thresholdn%3*std(handles.news(stp:stp+lprestim+lpoststim-1,2))
        erpstd2(:,k2)=lowpassfilter(handles.news(stp:stp+lprestim+lpoststim-1,cheeg2),handles.sr(1),50);
        k2=k2+1;
    end
end
merpstd1=1E6*mean(erpstd1');
merpstd2=1E6*mean(erpstd2');
k1=1;
k2=1;
length(inddev)
for i=1:length(inddev);
    stp=inddev(i)-lprestim;
    %adding the trace if it has no artifacts
     if max(abs(handles.news(stp:stp+lprestim+lpoststim-1,cheeg1)))<thresholdn%3*std(handles.news(stp:stp+lprestim+lpoststim-1,1))
        erpdev1(:,k1)=lowpassfilter(handles.news(stp:stp+lprestim+lpoststim-1,cheeg1),handles.sr(1),50);
        k1=k1+1;
     end
     if max(abs(handles.news(stp:stp+lprestim+lpoststim-1,cheeg2)))<thresholdn%3*std(handles.news(stp:stp+lprestim+lpoststim-1,2))
        erpdev2(:,k2)=lowpassfilter(handles.news(stp:stp+lprestim+lpoststim-1,cheeg2),handles.sr(1),50);
        k2=k2+1;
     end
end
k1
k2

merpdev1=1E6*mean(erpdev1');
merpdev2=1E6*mean(erpdev2');
x=0:lprestim+lpoststim-1;
x=x/length(x);
x=x*(prestim+poststim)-prestim;
figure
subplot(2,1,1)
% plot(x,1E6*erpdev1);
% hold on
% plot(x,ones(1,length(erpdev1))*2*max(std(1E6*erpdev1)),'.');
% plot(x,ones(1,length(erpdev1))*-2*max(std(1E6*erpdev1)),'.');

einf=merpdev1-sem(1E6*erpdev1');
emax=merpdev1+sem(1E6*erpdev1');
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[einf,fliplr(emax)];              %create y values for out and then back
fill(X,Y,[1,0.6,0.6],'EdgeColor','none');                  %plot filled area
hold on
einf=merpstd1-sem(1E6*erpstd1');
emax=merpstd1+sem(1E6*erpstd1');
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[einf,fliplr(emax)];              %create y values for out and then back
fill(X,Y,[0.8,0.8,0.8],'EdgeColor','none');                  %plot filled area
plot(x,merpdev1,'r-','linewidth',1.5)
plot(x,merpstd1,'k-','linewidth',1.5)
title('Frontal CTX')
legend(strcat('Deviant N=',num2str(size(erpdev1,2))),strcat('Standard N=',num2str(size(erpstd1,2))))
box off
ylabel('uV','fontsize',16)
set(gca,'fontsize',13)
subplot(2,1,2)
plot(x,merpdev2,'r-','linewidth',1.5)
hold on
plot(x,merpstd2,'k-','linewidth',1.5)
title('Parietal CTX')
box off
ylabel('uV','fontsize',16)
set(gca,'fontsize',13)
xlabel('s','fontsize',16)







% --- Executes on button press in newerp.
function newerp_Callback(hObject, eventdata, handles)
% hObject    handle to newerp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
prompt={'Channel with data:','Channel with stim:','number of stimuli:','prestim time (s)','poststim time(s)'};
name='Input for ERP';
numlines=1;
defaultanswer={'1','3','1','0.5','0.7'};
answer=inputdlg(prompt,name,numlines,defaultanswer);
chdata=str2num(char(answer{1}));
chstim=str2num(char(answer{2}));
nstim=str2num(char(answer{3}));
prestim=floor(handles.sr(1)*str2num(char(answer{4})));%prestim in points
poststim=floor(handles.sr(1)*str2num(char(answer{5})));%poststim in points
data=handles.s(:,chdata);
stimdata=handles.s(:,chstim);
resol=10000;
%finding values of stim according to histogram. Dividing the range of
%values in resol segments.
[p,v]=hist(stimdata,resol);
%choosing the values that have frecuency >0
indp=find(p>0);
newv1=v(indp);
nostimval=median(stimdata);
%getting rid of the baseline value
pz=find(min(abs(newv1-nostimval)));
if pz==1
    finalv=newv1(2:end);
else
    if pz==length(newv1)
        finalv=newv1(1:end-1);
    else
        finalv=[newv1(1:pz-1) newv1(pz+1:end)];
    end
end
finalv=sort(finalv);
md=min(diff(finalv))/2;
%finding stim points
shiftstim=stimdata(2:end);

figure
xaxis=0:prestim+poststim;
xaxis=xaxis/handles.sr(1);
xaxis=xaxis-(prestim/handles.sr(1));

%short ERP plot for single amplitud stim
maxv=max(stimdata);
minv=min(stimdata);
posistim=find(shiftstim>((maxv-minv)/2) & stimdata(1:end-1)<((maxv-minv)/2));
erpmat=zeros(length(posistim),poststim+prestim+1);
progressbar(0)
for i=2:length(posistim-1)
    erpmat(i-1,:)=data(posistim(i)-prestim:posistim(i)+poststim);
  progressbar(i/length(posistim-1));
end
progressbar(1)
plot(xaxis,mean(erpmat))
title(['ch ' char(answer{1}) '; n=' num2str(size(erpmat,1))])
box off
axis tight

%up to here
if nstim>100
for i=1:nstim
    posistim=find(shiftstim>(finalv(i)-md) & shiftstim<(finalv(i)+md) & stimdata(1:end-1)<(finalv(i)-md));
    if length(posistim)<1
        disp('no stim found....')
        break
    end
    %making the matrix:
    for k=1:length(posistim)
        epochsd{i}(:,k)=data(posistim(k)-prestim:posistim(k)+poststim);
        epochsst{i}(:,k)=stimdata(posistim(k)-prestim:posistim(k)+poststim);
    end
   
    subplot(nstim,2,(2*i)-1)
    plot(xaxis,mean(epochsd{i}'))
    axis tight
    subplot(nstim,2,(2*i))
    plot(xaxis,mean(epochsst{i}'))
    set(gca,'ylim',[0 0.13])
end
end







