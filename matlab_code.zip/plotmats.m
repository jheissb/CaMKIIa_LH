function varargout = plotmats(varargin)
% PLOTMATS M-file for plotmats.fig
%      PLOTMATS, by itself, creates a new PLOTMATS or raises the existing
%      singleton*.
%
%      H = PLOTMATS returns the handle to a new PLOTMATS or the handle to
%      the existing singleton*.
%
%      PLOTMATS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PLOTMATS.M with the given input arguments.
%
%      PLOTMATS('Property','Value',...) creates a new PLOTMATS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before plotmats_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to plotmats_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help plotmats

% Last Modified by GUIDE v2.5 09-Feb-2015 11:50:11
%to do:
%high gamma (50-80) adn average FFT for vehicle and PCP for single animals and average for either
%ch1 or 2 and 3
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @plotmats_OpeningFcn, ...
    'gui_OutputFcn',  @plotmats_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before plotmats is made visible.
function plotmats_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to plotmats (see VARARGIN)

% Choose default command line output for plotmats
handles.output = hObject;
% cn=getComputerName();
% cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     pth='C:\Users\E26903\Documents\My Dropbox\Jaime';
% end
% if strcmp('laptopjh',cn)
%     pth='D:\jhexp\2013\vivo';
% end
pth=pwd;
put_flist(pth,hObject, handles);
% Update handles structure
handles.drugread=0;
handles.vehread=0;
guidata(hObject, handles);

% UIWAIT makes plotmats wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = plotmats_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.dnames = cellstr(get(hObject,'String'));% returns listbox1 contents as cell array
handles.chosen=get(hObject,'Value');% returns selected item from listbox1
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function put_flist(path,hObject,handles)
dir_path = (path);
cd(dir_path);
dir_struct = dir ('*.*'); %dir_path
if (get(handles.checkbox1,'value') & ~get(handles.checkbox2,'value'))
    dir_struct = dir ('*.txt'); %dir_path
end
if (get(handles.checkbox2,'value') & ~get(handles.checkbox1,'value'))
    dir_struct = dir ('*.mat'); %dir_path
end

[sorted_names,sorted_index] = sortrows({dir_struct.name}');
handles.file_name = sorted_names;
handles.sorted_index = [sorted_index];
%set(handles.flist,'String',handles.file_name,'Value',1);%chooses the first
set(handles.listbox1,'String',handles.file_name);%chooses something
guidata(hObject, handles);



% --- Executes on button press in pushbutton1.PLots the
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%plots the average FFT Heatmap
avgfftch1_hits=0;
avgfftch1_miss=0;
avgfftch1_crej=0;
avgfftch2_hits=0;
avgfftch2_miss=0;
avgfftch2_crej=0;
avgfftch3_hits=0;
avgfftch3_miss=0;
avgfftch3_crej=0;
nhch1=0;nmch1=0;ncrch1=0;
nhch2=0;nmch2=0;ncrch2=0;
nhch3=0;nmch3=0;ncrch3=0;

for i=1:length(handles.chosen)
    load(char(handles.dnames{handles.chosen(i)}))
    %CH1:
    if isfield(ch1data,'hits_avgFFT')
        if length(ch1data.hits_avgFFT)>1
            if nhch1==0
                avgfftch1_hits+normat(90,ch1data.hits_avgFFT);
            else
                avgfftch1_hits=avgfftch1_hits+normat(90,ch1data.hits_avgFFT);
            end
            
            nhch1=nhch1+1;
        end
    end
    if isfield(ch1data,'mises_avgFFT')
        
        if length(ch1data.mises_avgFFT)>1
            avgfftch1_miss=avgfftch1_miss+normat(90,ch1data.mises_avgFFT);
            nmch1=nmch1+1;
        end
    end
    if isfield(ch1data,'crej_avgFFT')
        
        if length(ch1data.crej_avgFFT)>1
            avgfftch1_crej=avgfftch1_crej+normat(90,ch1data.crej_avgFFT);
            ncrch1=ncrch1+1;
        end
    end
    
    %CH2:
    if isfield(ch2data,'hits_avgFFT')
        if length(ch2data.hits_avgFFT)>1
            avgfftch2_hits=avgfftch2_hits+normat(90,ch2data.hits_avgFFT);
            nhch2=nhch2+1;
        end
    end
    
    if isfield(ch2data,'mises_avgFFT')
        if length(ch2data.mises_avgFFT)>1
            avgfftch2_miss=avgfftch2_miss+normat(90,ch2data.mises_avgFFT);
            nmch2=nmch2+1;
        end
    end
    if isfield(ch2data,'crej_avgFFT')
        if length(ch2data.crej_avgFFT)>1
            avgfftch2_crej=avgfftch2_crej+normat(90,ch2data.crej_avgFFT);
            ncrch2=ncrch2+1;
        end
    end
    
    %CH3:
    if isfield(ch3data,'hits_avgFFT')
        
        if length(ch3data.hits_avgFFT)>1
            avgfftch3_hits=avgfftch1_hits+normat(90,ch1data.hits_avgFFT);
            nhch1=nhch1+1;
        end
    end
    if isfield(ch3data,'mises_avgFFT')
        if length(ch3data.mises_avgFFT)>1
            avgfftch3_miss=avgfftch3_miss+normat(90,ch3data.mises_avgFFT);
            nmch3=nmch3+1;
        end
    end
    if isfield(ch3data,'crej_avgFFT')
        if length(ch3data.crej_avgFFT)>1
            avgfftch3_crej=avgfftch3_crej+normat(90,ch3data.crej_avgFFT);
            ncrch3=ncrch3+1;
        end
    end
    
end

%Normalizing
%Ch1:
avgfftch1_hits=avgfftch1_hits/nhch1;
valminhitch1=min(min(avgfftch1_hits));%baseline value ~0.1;
avgfftch1_hits=avgfftch1_hits-valminhitch1;
valmaxhitch1=max(max(avgfftch1_hits));
avgfftch1_hits=avgfftch1_hits/valmaxhitch1;%normalazing between 0 and 1

avgfftch1_miss=avgfftch1_miss/nmch1;
valblmissch1=0.2-min(min(avgfftch1_miss));%baseline value ~1;
avgfftch1_miss=avgfftch1_miss-min(min(avgfftch1_miss));
valblmissch1=valblmissch1/max(max(avgfftch1_miss));
avgfftch1_miss=avgfftch1_miss/max(max(avgfftch1_miss));%normalazing between 0 and 1

avgfftch1_crej=avgfftch1_crej/ncrch1;
valblcrejch1=0.2-min(min(avgfftch1_crej));%baseline value ~1;
avgfftch1_crej=avgfftch1_crej-min(min(avgfftch1_crej));
valblcrejch1=valblcrejch1/max(max(avgfftch1_crej));
avgfftch1_crej=avgfftch1_crej/max(max(avgfftch1_crej));%normalazing between 0 and 1

%Ch2:
avgfftch2_hits=avgfftch2_hits/nhch2;
valblhitch2=0.2-min(min(avgfftch2_hits));%baseline value ~0.1;
avgfftch2_hits=avgfftch2_hits-min(min(avgfftch2_hits));
valblhitch2=valblhitch2/max(max(avgfftch2_hits));
avgfftch2_hits=avgfftch2_hits/max(max(avgfftch2_hits));%normalazing between 0 and 1

avgfftch2_miss=avgfftch2_miss/nmch2;
valblmissch2=0.2-min(min(avgfftch2_miss));%baseline value ~1;
avgfftch2_miss=avgfftch2_miss-min(min(avgfftch2_miss));
valblmissch2=valblmissch2/max(max(avgfftch2_miss));
avgfftch2_miss=avgfftch2_miss/max(max(avgfftch2_miss));%normalazing between 0 and 1

avgfftch2_crej=avgfftch2_crej/ncrch2;
valblcrejch2=0.2-min(min(avgfftch2_crej));%baseline value ~1;
avgfftch2_crej=avgfftch2_crej-min(min(avgfftch2_crej));
valblcrejch2=valblcrejch2/max(max(avgfftch2_crej));
avgfftch2_crej=avgfftch2_crej/max(max(avgfftch2_crej));%normalazing between 0 and 1

%Ch3:
avgfftch3_hits=avgfftch3_hits/nhch3;
valblhitch3=0.2-min(min(avgfftch3_hits));%baseline value ~0.1;
avgfftch3_hits=avgfftch3_hits-min(min(avgfftch3_hits));
valblhitch3=valblhitch3/max(max(avgfftch3_hits));
avgfftch3_hits=avgfftch3_hits/max(max(avgfftch3_hits));%normalazing between 0 and 1

avgfftch3_miss=avgfftch3_miss/nmch3;
valblmissch3=0.2-min(min(avgfftch3_miss));%baseline value ~1;
avgfftch3_miss=avgfftch3_miss-min(min(avgfftch3_miss));
valblmissch3=valblmissch3/max(max(avgfftch3_miss));
avgfftch3_miss=avgfftch3_miss/max(max(avgfftch3_miss));%normalazing between 0 and 1

avgfftch3_crej=avgfftch3_crej/ncrch3;
valblcrejch3=0.2-min(min(avgfftch3_crej));%baseline value ~1;
avgfftch3_crej=avgfftch3_crej-min(min(avgfftch3_crej));
valblcrejch3=valblcrejch3/max(max(avgfftch3_crej));
avgfftch3_crej=avgfftch3_crej/max(max(avgfftch3_crej));%normalazing between 0 and 1

%Now plotting

figure

disp('Set the size of the fig')
pause

%CH1:
subplot(3,15,[1:4])
image(avgfftch1_hits*75)
axis xy
colormap('jet')
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str(xlabl/100))
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch1 hits')
%plotting colorbar
subplot(3,30,10)
m0=75*min(min(avgfftch1_hits));
mf=75*max(max(avgfftch1_hits));

cbar=m0:(mf-m0)/63:mf;
subplot(3,30,5)
image(cbar)
colormap('jet')
axis xy
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str([m0/75 mf/75]))


subplot(3,15,[16:27])
image(avgfftch1_miss*75)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str(xlabl/100))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch1 miss')
P=30:42;
subplot(3,15,P)
image(avgfftch1_crej*75)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str(xlabl/100))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch1 crej')

%CH2:
subplot(3,3,4)
image(avgfftch2_hits*75)
axis xy
colormap('jet')
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str(xlabl/100))
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch2 hits')

subplot(3,3,5)
image(avgfftch2_miss*75)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str(xlabl/100))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch2 miss')

subplot(3,3,6)
image(avgfftch2_crej*75)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str(xlabl/100))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch2 crej')

%ch3:
subplot(3,3,7)
image(avgfftch3_hits*75)
axis xy
colormap('jet')
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str(xlabl/100))
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch3 hits')

subplot(3,3,8)
image(avgfftch3_miss*75)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str(xlabl/100))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch3 miss')

subplot(3,3,9)
image(avgfftch3_crej*75)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str(xlabl/100))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S')
ylabel('Hz')
title('Avgfftch3 crej')




% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in selectfolder.
function selectfolder_Callback(hObject, eventdata, handles)
% hObject    handle to selectfolder (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% cn=getComputerName();
% cn=cn(1:end-1);
% if strcmp('cas11329',cn)
%     pth='C:\Users\E26903\Documents\My Dropbox\Jaime';
% end
% if strcmp('laptopjh',cn)
%     pth='D:\jhexp\2013\vivo';
% end
%
set(handles.listbox1,'value',1)
pth=pwd;
path_of = uigetdir(pth,'Pick a folder');
cd(path_of);
put_flist(path_of,hObject, handles);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close all


% --- Executes on button press in rms_ko.
function rms_ko_Callback(hObject, eventdata, handles)
% hObject    handle to rms_ko (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.NRdeltako=[];
handles.Rdeltako=[];
handles.Wdeltako=[];
handles.NRrmsko=[];
handles.Rrmsko=[];
handles.Wrmsko=[];
handles.NRdltako=[];
handles.Rdltako=[];
handles.Wdltako=[];

for i=1:length(handles.chosen)
    data=load(char(handles.dnames{i}));
    handles.NRrmsko(i)=mean(data.rmsNR);
    handles.Rrmsko(i)=mean(data.rmsR);
    handles.Wrmsko(i)=mean(data.rmsW);
    handles.Wrmsko(i)=mean(data.rmsW);
    handles.NRdltako(i,:)=mean(data.deltaNR);
    handles.Rdltako(i,:)=mean(data.deltaR);
    handles.Wdltako(i,:)=mean(data.deltaW);
    
    handles.ratiormsko(i)=handles.Wrmsko(i)/handles.NRrmsko(i);
    handles.NRdeltako=[handles.NRdeltako;data.deltaNR];
    handles.Rdeltako=[handles.Rdeltako;data.deltaR];
    handles.Wdeltako=[handles.Wdeltako;data.deltaW];
    handles.wavpepochNRko(i)=length(data.deltaNR)/length(data.rmsNR);
    handles.wavpepochRko(i)=length(data.deltaR)/length(data.rmsR);
    handles.wavpepochWko(i)=length(data.deltaW)/length(data.rmsW);
    
end
helpdlg('KO selected')
guidata(hObject, handles);



% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
display('RMS vals WT:')
handles.Wrmswt
handles.NRrmswt
handles.Rrmswt
handles.ratiormswt

display('RMS vals KO:')
handles.Wrmsko
handles.NRrmsko
handles.Rrmsko
disp('ratio ko:')
handles.ratiormsko
disp('ratio WT:')
handles.ratiormswt

figure
disp('numwaves:')
disp('W wt')
handles.wavpepochWwt
disp('R wt')

handles.wavpepochRwt
disp('NR wt')

handles.wavpepochNRwt
disp('W ko')

handles.wavpepochWko
disp('R ko')

handles.wavpepochRko
disp('NR ko')

handles.wavpepochNRko

subplot(1,2,1)
nf=0.0001;%max(handles.Wrmswt);
dwt=[mean(handles.Wrmswt/nf) mean(handles.NRrmswt/nf) mean(handles.Rrmswt/nf) mean(handles.ratiormswt)];
ewt=[sem(handles.Wrmswt/nf) sem(handles.NRrmswt/nf) sem(handles.Rrmswt/nf) sem(handles.ratiormswt)];
dko=[mean(handles.Wrmsko/nf) mean(handles.NRrmsko/nf) mean(handles.Rrmsko/nf) mean(handles.ratiormsko)];
eko=[sem(handles.Wrmsko/nf) sem(handles.NRrmsko/nf) sem(handles.Rrmsko/nf) sem(handles.ratiormsko)];

ebar=([ewt(1) eko(1); ewt(2) eko(2); ewt(3) eko(3); ewt(4) eko(4)]);
tobar=([dwt(1) dko(1);dwt(2) dko(2);dwt(3) dko(3);dwt(4) dko(4) ]);


h = bar(tobar);
%set(h,'BarWidth',1); % The bars will now touch each other

set(gca,'YGrid','on')
set(gca,'GridLineStyle','-')
set(gca,'XTicklabel','W|NR|R|W/NR')
set(get(gca,'YLabel'),'String','Mean RMS')

lh = legend('WT','KO');
%set(lh,'Location','BestOutside','Orientation','horizontal')

hold on;

numgroups = size(tobar, 1);
numbars = size(tobar, 2);

groupwidth = min(0.8, numbars/(numbars+1.5));

for i = 1:numbars
    % Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
    x = (1:numgroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*numbars); % Aligning error bar with individual bar
    errorbar(x, tobar(:,i), ebar(:,i), 'k', 'linestyle', 'none');
end
h = bar(tobar);

colormap([0 0 0;1 0 0]);

subplot(1,2,2)
dwt=[mean(handles.wavpepochWwt) mean(handles.wavpepochNRwt) mean(handles.wavpepochRwt)];
ewt=[sem(handles.wavpepochWwt) sem(handles.wavpepochNRwt) sem(handles.wavpepochRwt)];
dko=[mean(handles.wavpepochWko) mean(handles.wavpepochNRko) mean(handles.wavpepochRko)];
eko=[sem(handles.wavpepochWko) sem(handles.wavpepochNRko) sem(handles.wavpepochRko)];

ebar=([ewt(1) eko(1); ewt(2) eko(2); ewt(3) eko(3)]);
tobar=([dwt(1) dko(1);dwt(2) dko(2);dwt(3) dko(3)]);


h = bar(tobar);
%set(h,'BarWidth',1); % The bars will now touch each other

set(gca,'YGrid','on')
set(gca,'GridLineStyle','-')
set(gca,'XTicklabel','W|NR|R')
set(get(gca,'YLabel'),'String','Waves/epoch')

lh = legend('WT','KO');
%set(lh,'Location','BestOutside','Orientation','horizontal')

hold on;

numgroups = size(tobar, 1);
numbars = size(tobar, 2);

groupwidth = min(0.8, numbars/(numbars+1.5));

for i = 1:numbars
    % Based on barweb.m by Bolu Ajiboye from MATLAB File Exchange
    x = (1:numgroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*numbars); % Aligning error bar with individual bar
    errorbar(x, tobar(:,i), ebar(:,i), 'k', 'linestyle', 'none');
end
h = bar(tobar);

colormap([0 0 0;1 0 0])
figure

mdwt=mean(handles.NRdltawt);
mdko=mean(handles.NRdltako);
sdwt=sem(handles.NRdltawt);
sdko=sem(handles.NRdltako);
einfwt=mdwt-sdwt;
emaxwt=mdwt+sdwt;
einfko=mdko-sdko;
emaxko=mdko+sdko;

subplot(1,4,1)

x=2*(0:length(mdwt)-1)/(length(mdwt)-1);
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[einfwt,fliplr(emaxwt)];              %create y values for out and then back
fill(X,Y,[0.5 0.5 0.5],'EdgeColor','none');                  %plot filled area
hold on
Y=[einfko,fliplr(emaxko)];              %create y values for out and then back
fill(X,Y,[1 0.5 0.5],'EdgeColor','none');                  %plot filled area

plot(x,mdwt,'k-','linewidth',2)
plot(x,mdko,'r-','linewidth',2)
xlabel('s')
ylabel('uV')
title('Mean delta for NR')
set(gca,'xlim',[0.5 1.5])
set(gca,'ylim',[-1 1]*0.8)

subplot(1,4,2)
mdwt=mean(handles.Rdltawt);
mdko=mean(handles.Rdltako);
sdwt=sem(handles.Rdltawt);
sdko=sem(handles.Rdltako);
einfwt=mdwt-sdwt;
emaxwt=mdwt+sdwt;
einfko=mdko-sdko;
emaxko=mdko+sdko;

Y=[einfwt,fliplr(emaxwt)];              %create y values for out and then back
fill(X,Y,[0.5 0.5 0.5],'EdgeColor','none');                  %plot filled area
hold on
Y=[einfko,fliplr(emaxko)];              %create y values for out and then back
fill(X,Y,[1 0.5 0.5],'EdgeColor','none');                  %plot filled area

plot(x,mdwt,'k-','linewidth',2)
plot(x,mdko,'r-','linewidth',2)
xlabel('s')
ylabel('uV')
title('Mean delta for R')
set(gca,'xlim',[0.5 1.5])
set(gca,'ylim',[-1 1]*0.8)

subplot(1,4,3)
mdwt=mean(handles.Wdltawt);
mdko=mean(handles.Wdltako);
sdwt=sem(handles.Wdltawt);
sdko=sem(handles.Wdltako);
einfwt=mdwt-sdwt;
emaxwt=mdwt+sdwt;
einfko=mdko-sdko;
emaxko=mdko+sdko;

Y=[einfwt,fliplr(emaxwt)];              %create y values for out and then back
fill(X,Y,[0.5 0.5 0.5],'EdgeColor','none');                  %plot filled area
hold on
Y=[einfko,fliplr(emaxko)];              %create y values for out and then back
fill(X,Y,[1 0.5 0.5],'EdgeColor','none');                  %plot filled area

plot(x,mdwt,'k-','linewidth',2)
plot(x,mdko,'r-','linewidth',2)
xlabel('s')
ylabel('uV')
title('Mean delta for W')
set(gca,'xlim',[0.5 1.5])
set(gca,'ylim',[-1 1]*0.8)

subplot(1,4,4)

plot(x,mdwt,'k--','linewidth',1)
hold on
plot(x,mdko,'r--','linewidth',1)
mdwt=mean(handles.NRdltawt);
mdko=mean(handles.NRdltako);
plot(x,mdwt,'k-','linewidth',1)
plot(x,mdko,'r-','linewidth',1)
mdwt=mean(handles.Rdltawt);
mdko=mean(handles.Rdltako);
plot(x,mdwt,'k.-','linewidth',1)
plot(x,mdko,'r.-','linewidth',1)

xlabel('s')
ylabel('uV')
title('Mean delta')
legend('W wt','W ko','NR wt','NR ko','R wt','R ko')
set(gca,'xlim',[0.5 1.5])
set(gca,'ylim',[-1 1]*0.8)







% --- Executes on button press in rms_delta_wt.
function rms_delta_wt_Callback(hObject, eventdata, handles)
% hObject    handle to rms_delta_wt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.NRrmswt=[];
handles.Rrmswt=[];
handles.Wrmswt=[];
handles.NRdltawt=[];
handles.Rdltawt=[];
handles.Wdltawt=[];
handles.NRdeltawt=[];
handles.Rdeltawt=[];
handles.Wdeltawt=[];

for i=1:length(handles.chosen)
    data=load(char(handles.dnames{i}));
    handles.NRrmswt(i)=mean(data.rmsNR);
    handles.Rrmswt(i)=mean(data.rmsR);
    handles.Wrmswt(i)=mean(data.rmsW);
    handles.NRdltawt(i,:)=mean(data.deltaNR);
    handles.Rdltawt(i,:)=mean(data.deltaR);
    handles.Wdltawt(i,:)=mean(data.deltaW);
    handles.ratiormswt(i)=handles.Wrmswt(i)/handles.NRrmswt(i);
    handles.NRdeltawt=[handles.NRdeltawt;data.deltaNR];
    handles.Rdeltawt=[handles.Rdeltawt;data.deltaR];
    handles.Wdeltawt=[handles.Wdeltawt;data.deltaW];
    handles.wavpepochNRwt(i)=length(data.deltaNR)/length(data.rmsNR);
    handles.wavpepochRwt(i)=length(data.deltaR)/length(data.rmsR);
    handles.wavpepochWwt(i)=length(data.deltaW)/length(data.rmsW);
end
helpdlg('WT selected')
guidata(hObject, handles);


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
put_flist(pwd,hObject,handles)

% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
put_flist(pwd,hObject,handles)
% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in heatmapselchan.
function heatmapselchan_Callback(hObject, eventdata, handles)
% hObject    handle to heatmapselchan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Reads only one channel per file and makes the average FFT and bands
% For Acute PCP study use the following channels for both vehicle and PCP treatments for Frontal Cortex plots:
%
% 45-40: Ch.2 (Right FC)
% 86-40: Ch.1 (Left FC) -
% 86-54: Both channels faulty signal
% 86-50: Ch.1 (Left FC)
% 86-35: Both channels faulty signal
% 86-42: Ch.1 (Left FC)
% 86-146: Ch.2 (Right FC)
% 86-1068: Ch.2 (Right FC)
%
% Same applies for Acute Ketamine study use the following channels for both vehicle and Ketamine treatments for Frontal Cortex plots:
%
% 45-40: Ch.2 (Right FC)
% 86-40: Ch.1 (Left FC)
% 86-54: Both channels faulty signal
% 86-50: Ch.1 (Left FC)
% 86-35: Both channels faulty signal
% 86-42: Ch.1 (Left FC)
% 86-146: Ch.2 (Right FC)
% 86-1068: Ch.2 (Right FC)

avgfft_hits=0;
avgfft_miss=0;
avgfft_crej=0;
% delta_hits=0;
% theta_hits=0;
% beta_hits=0;
% alpha_hits=0;
% lowG_hits=0;
% highG_hits=0;

nh=0;nm=0;ncr=0;
for i=1:length(handles.chosen)
    selchan(i)=input(strcat('select channel for ',char(handles.dnames{handles.chosen(i)}),': '));
    load(char(handles.dnames{handles.chosen(i)}));
    if selchan(i)==1
        chdata=ch1data;
    elseif selchan(i)==2
        chdata=ch2data;
    else
        chdata=ch3data
    end
    %CH1:
    if isfield(chdata,'hits_avgFFT')
        if length(chdata.hits_avgFFT)>1
            delta_hits(:,i)=mean(chdata.hits_deltaFFT,1);
            theta_hits(:,i)=mean(chdata.hits_thetaFFT,1);
            beta_hits(:,i)=mean(chdata.hits_betaFFT,1);
            alpha_hits(:,i)=mean(chdata.hits_alphaFFT,1);
            lowG_hits(:,i)=mean(chdata.hits_lowGFFT,1);
            highG_hits(:,i)=mean(chdata.hits_highGFFT,1);
            meanerp_hits(:,i)=mean(chdata.mathit');
            if nh==0
                avgfft_hits=normat(90,chdata.hits_avgFFT);%-0.8;
            else
                avgfft_hits=avgfft_hits+normat(90,chdata.hits_avgFFT);%-0.8;
            end
            nh=nh+1;
        end
    end
    if isfield(chdata,'mises_avgFFT')
        if length(chdata.mises_avgFFT)>1
            delta_miss(:,i)=mean(chdata.mises_deltaFFT,1);
            theta_miss(:,i)=mean(chdata.mises_thetaFFT,1);
            beta_miss(:,i)=mean(chdata.mises_betaFFT,1);
            alpha_miss(:,i)=mean(chdata.mises_alphaFFT,1);
            lowG_miss(:,i)=mean(chdata.mises_lowGFFT,1);
            highG_miss(:,i)=mean(chdata.mises_highGFFT,1);
            meanerp_miss(:,i)=mean(chdata.matmiss');
            if nm==0
                avgfft_miss=normat(90,chdata.mises_avgFFT);%-0.8;
            else
                avgfft_miss=avgfft_miss+normat(90,chdata.mises_avgFFT);%-0.8;
            end
            nm=nm+1;
        end
    end
    
    if isfield(chdata,'crej_avgFFT')
        if length(chdata.crej_avgFFT)>1
            delta_crej(:,i)=mean(chdata.crej_deltaFFT,1);
            theta_crej(:,i)=mean(chdata.crej_thetaFFT,1);
            beta_crej(:,i)=mean(chdata.crej_betaFFT,1);
            alpha_crej(:,i)=mean(chdata.crej_alphaFFT,1);
            lowG_crej(:,i)=mean(chdata.crej_lowGFFT,1);
            highG_crej(:,i)=mean(chdata.crej_highGFFT,1);
            meanerp_crej(:,i)=mean(chdata.matcrej');
            if ncr==0
                avgfft_crej=normat(90,chdata.crej_avgFFT);%-0.8;
            else
                avgfft_crej=avgfft_crej+normat(90,chdata.crej_avgFFT);%-0.8;
            end
            ncr=ncr+1;
        end
    end
end

%saving txt files:
maxminffthits=[min(min(avgfft_hits)) max(max(avgfft_hits))];
maxminfftmiss=[min(min(avgfft_miss)) max(max(avgfft_miss))];
maxminfftcrej=[min(min(avgfft_crej)) max(max(avgfft_crej))];
txta='';
for i=1:length(handles.chosen)
    txta=strcat(txta,num2str(selchan(i)));
end
auxhits=avgfft_hits;%+0.8*nh;
save(strcat('avgfft_hits',txta,'.txt'),'auxhits','-ascii');
auxmiss=avgfft_miss;%+0.8*nm;
save(strcat('avgfft_miss',txta,'.txt')','auxmiss','-ascii');
auxcrej=avgfft_crej;%+0.8*ncr;
save(strcat('avgfft_crej',txta,'.txt'),'auxcrej','-ascii');
save(strcat('meanERP_crej',txta,'.txt'),'meanerp_crej','-ascii');
save(strcat('meanERP_hits',txta,'.txt'),'meanerp_hits','-ascii');
save(strcat('meanERP_miss',txta,'.txt'),'meanerp_miss','-ascii');

%plotting ERP
if get(handles.veh,'value')%Color  for vehicle
    colfill=[0.6 0.6 1];
    coltr='b';
else
    colfill=[1 0.6 0.6];
    coltr='r';
end
figure
if length(meanerp_crej(:))>0
    meanerp_crej=meanerp_crej*1E6;
    m=mean(meanerp_crej');
    minerr=m-sem(meanerp_crej');
    maxerr=m+sem(meanerp_crej');
end
x=(0:length(meanerp_crej)-1)/2000;
x=x-3;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Mean ERP C. rej','fontsize',21)
box off
set(gca,'fontsize',14)
set(gca,'xlim',[-1 1.5])
xlabel('S','fontsize',21)
ylbl=str2num(get(gca,'yticklabel'));
set(gca,'Yticklabel',num2str(ylbl));
ylabel('Mean ERP(uV)','fontsize',18)


figure
if length(meanerp_miss(:))>0
    meanerp_miss=meanerp_miss*1E6;
    m=mean(meanerp_miss');
    minerr=m-sem(meanerp_miss');
    maxerr=m+sem(meanerp_miss');
end
x=(0:length(meanerp_miss)-1)/2000;
x=x-3;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Mean ERP Miss','fontsize',21)
box off
set(gca,'fontsize',14)
set(gca,'xlim',[-1 1.5])
xlabel('S','fontsize',18)
ylbl=str2num(get(gca,'yticklabel'));
set(gca,'Yticklabel',num2str(ylbl));
ylabel('Mean ERP(uV)','fontsize',18)


figure
if length(meanerp_hits(:))>0
    meanerp_hits=meanerp_hits*1E6;
    m=mean(meanerp_hits');
    minerr=m-sem(meanerp_hits');
    maxerr=m+sem(meanerp_hits');
end
x=(0:length(meanerp_hits)-1)/2000;
x=(x-3)*1000;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Mean ERP Hits','fontsize',21)
box off
set(gca,'fontsize',14)
set(gca,'xlim',[-1000 1500])
xlabel('ms','fontsize',21)
ylbl=str2num(get(gca,'yticklabel'));
set(gca,'Yticklabel',num2str(ylbl));
ylabel('Mean ERP(uV)','fontsize',18)
%Normalizing
%Ch1:
avgfft_hits=avgfft_hits/nh;
%valblhit=0.2-min(min(avgfft_hits));%baseline value ~0.1;
%avgfft_hits=avgfft_hits-min(min(avgfft_hits));
%valblhit=valblhit/max(max(avgfft_hits));
%avgfft_hits=avgfft_hits/max(max(avgfft_hits));%normalazing between 0 and 1

avgfft_miss=avgfft_miss/nm;
%valblmiss=0.2-min(min(avgfft_miss));%baseline value ~1;
%avgfft_miss=avgfft_miss-min(min(avgfft_miss));
%valblmiss=valblmiss/max(max(avgfft_miss));
%avgfft_miss=avgfft_miss/max(max(avgfft_miss));%normalazing between 0 and 1

avgfft_crej=avgfft_crej/ncr;
%valblcrej=0.2-min(min(avgfft_crej));%baseline value ~1;
%avgfft_crej=avgfft_crej-min(min(avgfft_crej));
%valblcrej=valblcrej/max(max(avgfft_crej));
%avgfft_crej=avgfft_crej/max(max(avgfft_crej));%normalazing between 0 and 1


%Now plotting

figure

% disp('Set the size of the fig')
% pause
factor=64/str2double(get(handles.edit1,'string'));%factor to multiply the heatmat so the value set for fixed scale=64
%CH1:
%subplot(1,3,1)
image(avgfft_hits*factor)
axis xy
colormap('jet')
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str((xlabl*10)-1000))
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('ms','fontsize',21)
ylabel('Hz','fontsize',21)
title('Avgfft hits')
set(gca,'fontsize',14)
c=colorbar;
ylablcb=str2num(get(c,'Yticklabel'));
if get(handles.fixedscale,'value')
    set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*str2double(get(handles.edit1,'string')))));
else
    set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*(maxminffthits(2)-maxminffthits(1))+maxminffthits(1))));
end
set(gca,'fontsize',14)
figure
%subplot(1,3,2)
image(avgfft_miss*factor)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str((xlabl/100)-1))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('ms','fontsize',21)
ylabel('Hz','fontsize',21)
title('Avgfft miss')
set(gca,'fontsize',14)
c=colorbar;
ylablcb=str2num(get(c,'Yticklabel'));
if get(handles.fixedscale,'value')
    set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*str2double(get(handles.edit1,'string')))));
else
    set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*(maxminffthits(2)-maxminffthits(1))+maxminffthits(1))));
end
set(gca,'fontsize',14)
figure
%subplot(1,3,3)
image(avgfft_crej*factor)
axis xy
colormap('jet')
set(gca,'Xticklabel',num2str((xlabl/100)-1))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S','fontsize',21)
ylabel('Hz','fontsize',21)
title('Avgfft crej')
set(gca,'fontsize',14)
c=colorbar;
ylablcb=str2num(get(c,'Yticklabel'));
if get(handles.fixedscale,'value')
    set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*str2double(get(handles.edit1,'string')))));
else
    set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*(maxminffthits(2)-maxminffthits(1))+maxminffthits(1))));
end
set(gca,'fontsize',14)

%Nomralizing bands with the average of the first 900 ms:
delta_crej=normat(90,delta_crej');
theta_crej=normat(90,theta_crej');
alpha_crej=normat(90,alpha_crej');
beta_crej=normat(90,beta_crej');
lowG_crej=normat(90,lowG_crej');
highG_crej=normat(90,highG_crej');
delta_hits=normat(90,delta_hits');
theta_hits=normat(90,theta_hits');
alpha_hits=normat(90,alpha_hits');
beta_hits=normat(90,beta_hits');
lowG_hits=normat(90,lowG_hits');
highG_hits=normat(90,highG_hits');
delta_miss=normat(90,delta_miss');
theta_miss=normat(90,theta_miss');
alpha_miss=normat(90,alpha_miss');
beta_miss=normat(90,beta_miss');
lowG_miss=normat(90,lowG_miss');
highG_miss=normat(90,highG_miss');

%saving txt files for the bands
save('delta_crej.txt','delta_crej','-ascii');
save('theta_crej.txt','theta_crej','-ascii');
save('alpha_crej.txt','alpha_crej','-ascii');
save('beta_crej.txt','beta_crej','-ascii');
save('lowG_crej.txt','lowG_crej','-ascii');
save('highG_crej.txt','highG_crej','-ascii');

save('delta_hits.txt','delta_hits','-ascii');
save('theta_hits.txt','theta_hits','-ascii');
save('alpha_hits.txt','alpha_hits','-ascii');
save('beta_hits.txt','beta_hits','-ascii');
save('lowG_hits.txt','lowG_hits','-ascii');
save('highG_hits.txt','highG_hits','-ascii');

save('delta_miss.txt','delta_miss','-ascii');
save('theta_miss.txt','theta_miss','-ascii');
save('alpha_miss.txt','alpha_miss','-ascii');
save('beta_miss.txt','beta_miss','-ascii');
save('lowG_miss.txt','lowG_miss','-ascii');
save('highG_miss.txt','highG_miss','-ascii');



%Plotting the bands now:
if get(handles.veh,'value')%Color  for vehicle
    colfill=[0.6 0.6 1];
    coltr='b';
else
    colfill=[1 0.6 0.6];
    coltr='r';
end
figure
subplot(2,3,1)
if size(delta_crej,1)==1
    m=delta_crej;
    minerr=m;
    maxerr=m;
else
    m=mean(delta_crej);
    minerr=m-sem(delta_crej);
    maxerr=m+sem(delta_crej);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('C. Rej.:Fast Delta (2-4 Hz)')
box off
set(gca,'fontsize',14)
ylabel('Relative Power','fontsize',18)
subplot(2,3,2)
if size(theta_crej,1)==1
    m=theta_crej;
    minerr=m;
    maxerr=m;
else
    m=mean(theta_crej);
    minerr=m-sem(theta_crej);
    maxerr=m+sem(theta_crej);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('C. Rej.:Theta (4-8 Hz)')
box off
set(gca,'fontsize',14)

subplot(2,3,3)
if size(alpha_crej,1)==1
    m=alpha_crej;
    minerr=m;
    maxerr=m;
else
    m=mean(alpha_crej);
    minerr=m-sem(alpha_crej);
    maxerr=m+sem(alpha_crej);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('C. Rej.:Alpha (8-12 Hz)')
box off
set(gca,'fontsize',14)

subplot(2,3,4)
if size(beta_crej,1)==1
    m=beta_crej;
    minerr=m;
    maxerr=m;
else
    
    m=mean(beta_crej);
    minerr=m-sem(beta_crej);
    maxerr=m+sem(beta_crej);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('C. Rej.:Beta (16-24 Hz)')
box off
set(gca,'fontsize',14)
xlabel('s','fontsize',18)
ylabel('Relative Power','fontsize',18)

subplot(2,3,5)
if size(lowG_crej,1)==1
    m=lowG_crej;
    minerr=m;
    maxerr=m;
else
    
    m=mean(lowG_crej);
    minerr=m-sem(lowG_crej);
    maxerr=m+sem(lowG_crej);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('C. Rej.:LowG (30-50 Hz)')
box off
box off
set(gca,'fontsize',14)
xlabel('s','fontsize',18)

subplot(2,3,6)
if size(highG_crej,1)==1
    m=highG_crej;
    minerr=m;
    maxerr=m;
else
    
    m=mean(highG_crej);
    minerr=m-sem(highG_crej);
    maxerr=m+sem(highG_crej);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('C. Rej.:HighG (50-80 Hz)')
box off
set(gca,'fontsize',14)
xlabel('s','fontsize',18)

figure
subplot(2,3,1)
if size(delta_miss,1)==1
    m=delta_miss;
    minerr=m;
    maxerr=m;
else
    m=mean(delta_miss);
    minerr=m-sem(delta_miss);
    maxerr=m+sem(delta_miss);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Miss: Fast Delta (2-4 Hz)')
box off
subplot(2,3,2)
if size(theta_miss,1)==1
    m=theta_miss;
    minerr=m;
    maxerr=m;
else
    m=mean(theta_miss);
    minerr=m-sem(theta_miss);
    maxerr=m+sem(theta_miss);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Miss: Theta (4-8 Hz)')
box off
subplot(2,3,3)
if size(alpha_miss,1)==1
    m=alpha_miss;
    minerr=m;
    maxerr=m;
else
    
    m=mean(alpha_miss);
    minerr=m-sem(alpha_miss);
    maxerr=m+sem(alpha_miss);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Miss:Alpha (8-12 Hz)')
box off
subplot(2,3,4)
if size(beta_miss,1)==1
    m=beta_miss;
    minerr=m;
    maxerr=m;
else
    m=mean(beta_miss);
    minerr=m-sem(beta_miss);
    maxerr=m+sem(beta_miss);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Miss: Beta (8-12 Hz)')
box off
subplot(2,3,5)
if size(lowG_miss,1)==1
    m=lowG_miss;
    minerr=m;
    maxerr=m;
else
    m=mean(lowG_miss);
    minerr=m-sem(lowG_miss);
    maxerr=m+sem(lowG_miss);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Miss: LowG (30-50 Hz)')
box off
subplot(2,3,6)
if size(highG_miss,1)==1
    m=highG_miss;
    minerr=m;
    maxerr=m;
else
    m=mean(highG_miss);
    minerr=m-sem(highG_miss);
    maxerr=m+sem(highG_miss);
end
x=-1:0.01:1.5;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
plot(x,m(1:length(x)),coltr,'linewidth',2)
title('Miss: HighG (50-80 Hz)')
box off

figure
coltr1=[1 0 0];
colfill=[1 0.7 0.7];
%subplot(2,3,1)
if size(delta_hits,1)==1
    m=delta_hits;
    minerr=m;
    maxerr=m;
else
    m=mean(delta_hits);
    minerr=m-sem(delta_hits);
    maxerr=m+sem(delta_hits);
end
x=-1000:10:1500;
X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
p1=plot(x,m(1:length(x)),'color',coltr1,'linewidth',2);
%title('Fast Delta (2-4 Hz)')
box off
set(gca,'fontsize',14)
ylabel('Relative Power','fontsize',18)
hold on
%subplot(2,3,2)
coltr2=[0 1 0];
colfill=[0.7 1 0.7];

if size(theta_hits,1)==1
    m=theta_hits;
    minerr=m;
    maxerr=m;
else
    m=mean(theta_hits);
    minerr=m-sem(theta_hits);
    maxerr=m+sem(theta_hits);
end
% x=-1:0.01:1.5;
% X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
p2=plot(x,m(1:length(x)),'color',coltr2,'linewidth',2)
%title('Theta (4-8 Hz)')
%box off
%set(gca,'fontsize',14)

%subplot(2,3,3)
coltr3=[0 0 1];
colfill=[0.7 0.7 1];

if size(alpha_hits,1)==1
    m=alpha_hits;
    minerr=m;
    maxerr=m;
else
    m=mean(alpha_hits);
    minerr=m-sem(alpha_hits);
    maxerr=m+sem(alpha_hits);
end
% x=-1:0.01:1.5;
% X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
p3=plot(x,m(1:length(x)),'color',coltr3,'linewidth',2)
%title('Hits: Alpha (8-12 Hz)')
%box off
%set(gca,'fontsize',14)

%subplot(2,3,4)
coltr4=[0 0 0];
colfill=[0.7 0.7 0.7];

if size(beta_hits,1)==1
    m=beta_hits;
    minerr=m;
    maxerr=m;
else
    m=mean(beta_hits);
    minerr=m-sem(beta_hits);
    maxerr=m+sem(beta_hits);
end
% x=-1:0.01:1.5;
% X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
p4=plot(x,m(1:length(x)),'color',coltr4,'linewidth',2)
%title('Hits: Beta (8-12 Hz)')
%box off
%set(gca,'fontsize',14)
%xlabel('s','fontsize',18)
%ylabel('Relative Power','fontsize',18)


%subplot(2,3,5)
coltr5=[0 1 1];
colfill=[0.7 1 1];

if size(lowG_hits,1)==1
    m=lowG_hits;
    minerr=m;
    maxerr=m;
else
    m=mean(lowG_hits);
    minerr=m-sem(lowG_hits);
    maxerr=m+sem(lowG_hits);
end
% x=-1:0.01:1.5;
% X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
p5=plot(x,m(1:length(x)),'color',coltr5,'linewidth',2)
% title('Hits: LowG (30-50 Hz)')
% box off
% set(gca,'fontsize',14)
% xlabel('s','fontsize',18)

%subplot(2,3,6)
coltr6=[1 0 1];
colfill=[1 0.7 1];
if size(highG_hits,1)==1
    m=highG_hits;
    minerr=m;
    maxerr=m;
else
    m=mean(highG_hits);
    minerr=m-sem(highG_hits);
    maxerr=m+sem(highG_hits);
end
% x=-1:0.01:1.5;
% X=[x,fliplr(x)];                %create continuous x value array for plotting
Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
fill(X,Y,colfill,'EdgeColor','none');                  %plot filled area
hold on
p6=plot(x,m(1:length(x)),'color',coltr6,'linewidth',2)
%title('Hits: HighG (50-80 Hz)')
%box off
%set(gca,'fontsize',14)
xlabel('ms','fontsize',18)
% h1 = findobj('Color',coltr1);
% h2 = findobj('Color',coltr2);
% h3 = findobj('Color',coltr3);
% h4 = findobj('Color',coltr4);
% h5 = findobj('Color',coltr5);
% h6 = findobj('Color',coltr6);
%legend([h1(1) h2(1) h3(1) h4(1) h5(1) h6(1)],{'D(2-4 Hz)','T(4-8 Hz)','A(8-12 Hz)','B(12-30Hz)','lG(30-50Hz)','hG(5-80Hz)'});

legend([p1 p2 p3 p4 p5 p6],{'D(2-4 Hz)','T(4-8 Hz)','A(8-12 Hz)','B(12-30Hz)','lG(30-50Hz)','hG(5-80Hz)'});




% --- Executes on button press in veh.
function veh_Callback(hObject, eventdata, handles)
% hObject    handle to veh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of veh


% --- Executes on button press in fixedscale.
function fixedscale_Callback(hObject, eventdata, handles)
% hObject    handle to fixedscale (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fixedscale



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in arrowhead13.
function arrowhead13_Callback(hObject, eventdata, handles)
% hObject    handle to arrowhead13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Reads the mat files and plot the following:
%mean bout duration of WA, NREM and REM every 30 min for stim and baseline
%mean percentage of time for WA, NREM and REM
%Mean SWA during NREM
%Mean FFT during NREM and REM for baseline and stim for differnet periods
%in time
%plots the FFT during NREM in a 6x4 plot for both stim and baseline
disp('Reading files...')
if ~isfield(handles,'nbaseln')
    handles.nbaseln=0;
end
if ~isfield(handles,'nstim')
    handles.nstim=0;
end
%save(fndata,'zt0','sc','pwa','pnr','pr','startsec','endsec','matpowerWA','matpowerNR','matpowerREM','freq')
if get(handles.veh,'value')
    %reading baseline
    kpwa=0;kpnr=0;kpr=0;
    for i=1:length(handles.chosen)
        data=load(char(handles.dnames{handles.chosen(i)}));
        handles.pwabl(i)=data.pwa;
        handles.pnrbl(i)=data.pnr;
        handles.prbl(i)=data.pr;
        handles.matpWAbl(i,:)=mean(data.matpowerWA);
        handles.freq4wabl=data.freq;
        handles.matNRbl(i,:)=mean(data.matpowerNR);
        handles.freq4wabl=data.freq;
        handles.matpREMbl(i,:)=mean(data.matpowerREM);
        handles.freq4wabl=data.freq;
    end
    disp('Baseline read')
    handles.nbasel=length(handles.chosen);%One baseline per subject so this is thenumber of animals
else
    %reading stim
    kpwa=0;kpnr=0;kpr=0;
    for i=1:length(handles.chosen)
        data=load(char(handles.dnames{handles.chosen(i)}));
        handles.pwast(i)=data.pwa;
        handles.pnrst(i)=data.pnr;
        handles.prst(i)=data.pr;
        handles.boutwast(i)=data.mboutwa;
        handles.boutnrst(i)=data.mboutnr;
        handles.boutrst(i)=data.mboutr;
        handles.matpWAst(i,:)=mean(data.matpowerWA);
        handles.freq4wast=data.freq;
        handles.matNRst(i,:)=mean(data.matpowerNR);
        handles.freq4wast=data.freq;
        handles.matpREMst(i,:)=mean(data.matpowerREM);
        handles.freq4wast=data.freq;
    end
    disp('Stim read')
    handles.nstim=length(handles.chosen);%This is all the periods * Num of subjects
end
guidata(hObject, handles);



% --- Executes on button press in plot_avgs.
function plot_avgs_Callback(hObject, eventdata, handles)
% hObject    handle to plot_avgs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
nsubj=handles.nbasel;
nperiods=handles.nstim/nsubj;
figure
%plotting the mean power for NREM
for j=1:nperiods
    subplot(1,nperiods,j)
    plot(handles.freq4wast,mean(handles.matNRst((j:nperiods:handles.nstim),:)),'k-','linewidth',2)
    hold on
    plot(handles.freq4wast,mean(handles.matNRbl),'g-','linewidth',0.5)
    %set(gca,'ylim',[0 0.15])
end

%normat=handles.matNRst([1:14,16:18,21:24],:)./handles.matNRbl([1:14,16:18,21:24],:);

normatNR=handles.matNRst;
normatWA=handles.matpWAst;
for nex=0:nsubj-1
    for q=1:nperiods
        normatNR(q+(nperiods*nex),:)=normatNR(q+(nperiods*nex),:)./handles.matNRbl(nex+1,:);
        normatWA(q+(nperiods*nex),:)=normatWA(q+(nperiods*nex),:)./handles.matpWAbl(nex+1,:);
    end
end


% for nex=0:size(handles.matNRbl,1)-1
%     for q=1:7
%         normatWA(q+(7*nex),:)=normatWA(q+(7*nex),:)./handles.matpWAbl(nex+1,:);
%     end
% end

% normatREM=handles.matpREMst;
% for nex=0:3
%     for q=1:7
%         normatREM(q+(7*nex),:)=normatREM(q+(7*nex),:)./handles.matpREMbl(nex+1,:);
%     end
% end
%

%plotting the mean power for NREM
% subplot(1,7,1)
% plot(handles.freq4wast,mean(normat([1 8 15],:)),'k-','linewidth',1)
% set(gca,'ylim',[0 3])
ndats=handles.nstim;
%ploting single panels
for j=1:nperiods
    figure
    m=mean(normatNR((j:nperiods:ndats),:));
    einf=m-abs(sem(normatNR((j:nperiods:ndats),:)));
    emax=m+abs(sem(normatNR((j:nperiods:ndats),:)));
    X=[handles.freq4wast,fliplr(handles.freq4wast)];
    Y=[einf,fliplr(emax)];
    fill(X,Y,[0.4 0.4 0.4],'EdgeColor','none');                  %plot filled area
    hold on
    plot(handles.freq4wast,m,'k-','linewidth',1)
    set(gca,'ylim',[0.5 2.5])
    xlabel('Hz','fontsize',16)
    set(gca,'fontsize',14)
    box off
    title(strcat('ZT ',num2str(7+(j-1))),'fontsize',21)
end
figure

for j=1:nperiods-1
    subplot(2,nperiods-1,j)
    m=mean(normatNR((j:nperiods:ndats),:));
    einf=m-abs(sem(normatNR((j:nperiods:ndats),:)));
    emax=m+abs(sem(normatNR((j:nperiods:ndats),:)));
    X=[handles.freq4wast,fliplr(handles.freq4wast)];
    Y=[einf,fliplr(emax)];
    fill(X,Y,[0.4 0.4 0.4],'EdgeColor','none');                  %plot filled area
    hold on
    plot(handles.freq4wast,m,'k-','linewidth',1)
    set(gca,'ylim',[0.5 2.5])
    xlabel('Hz','fontsize',16)
    set(gca,'fontsize',14)
    box off
    title(strcat('ZT ',num2str(7+(j-1))),'fontsize',21)
end


%geting the low delta and high delta average vals
[v,firstpld]=min(abs(handles.freq4wast-0.5));%the position of frequency
[v,lastpld]=min(abs(handles.freq4wast-2.5));%the position of frequency
[v,lastphd]=min(abs(handles.freq4wast-4.5));%the position of frequency
ldnormat=mean(normatNR(:,firstpld:lastpld),2);
hdnormat=mean(normatNR(:,lastpld:lastphd),2);
% allvalsld=normatNR(:,firstpld:lastpld);
% allvalshd=normatNR(:,lastpld:lastphd);

for j=1:nperiods
    avgld(j)=mean(ldnormat(j:nperiods:ndats));
    avghd(j)=mean(hdnormat(j:nperiods:ndats));
    semld(j)=sem(ldnormat(j:nperiods:ndats));
    semhd(j)=sem(hdnormat(j:nperiods:ndats));
    allvalsld(j,:)=ldnormat(j:nperiods:ndats);
    allvalshd(j,:)=hdnormat(j:nperiods:ndats);
    
end

%plotting the mean normalized power for WA
for j=1:nperiods-1
    subplot(2,nperiods-1,j+nperiods-1)
    m=mean(normatWA((j:nperiods:ndats),:));
    einf=m-abs(sem(normatWA((j:nperiods:ndats),:)));
    emax=m+abs(sem(normatWA((j:nperiods:ndats),:)));
    X=[handles.freq4wast,fliplr(handles.freq4wast)];
    Y=[einf,fliplr(emax)];
    fill(X,Y,[0.4 0.4 0.4],'EdgeColor','none');                  %plot filled area
    hold on
    plot(handles.freq4wast,m,'k-','linewidth',1)
    set(gca,'ylim',[0.5 2.5])
    xlabel('Hz','fontsize',16)
    set(gca,'fontsize',14)
    box off
end
%Plotting single panels for WA
% for j=1:nperiods
%     figure
%     m=mean(normatWA((j:nperiods:ndats),:));
%     einf=m-abs(sem(normatWA((j:nperiods:ndats),:)));
%     emax=m+abs(sem(normatWA((j:nperiods:ndats),:)));
%     X=[handles.freq4wast,fliplr(handles.freq4wast)];
%     Y=[einf,fliplr(emax)];
%     fill(X,Y,[0.4 0.4 0.4],'EdgeColor','none');                  %plot filled area
%     hold on
%     plot(handles.freq4wast,m,'k-','linewidth',1)
%     set(gca,'ylim',[0.5 2.5])
%     xlabel('Hz','fontsize',16)
%     set(gca,'fontsize',14)
%     box off
% end

%plotting the mean % of time and bout duration
figure
for q=1:nperiods
    mpwa(q)=mean(handles.pwast(q:nperiods:ndats));%this was already muiltiplied when saving
    pwavals(q,:)=handles.pwast(q:nperiods:ndats);
    epwa(q)=sem(handles.pwast(q:nperiods:ndats));
    mpnr(q)=mean(100*handles.pnrst(q:nperiods:ndats));
    pnrvals(q,:)=100*handles.pnrst(q:nperiods:ndats);
    epnr(q)=sem(100*handles.pnrst(q:nperiods:ndats));
    mprem(q)=mean(100*handles.prst(q:nperiods:ndats));
    eprem(q)=sem(100*handles.prst(q:nperiods:ndats));
    premvals(q,:)=100*handles.prst(q:nperiods:ndats);
    
    mbdwa(q)=mean(handles.boutwast(q:nperiods:ndats));
    ebdwa(q)=sem(handles.boutwast(q:nperiods:ndats)');
    bdwavals(q,:)=handles.boutwast(q:nperiods:ndats);
    mbdnr(q)=mean(handles.boutnrst(q:nperiods:ndats));
    ebdnr(q)=sem( handles.boutnrst(q:nperiods:ndats)');
    bdnrvals(q,:)=handles.boutnrst(q:nperiods:ndats);
    mbdrem(q)=mean(handles.boutrst(q:nperiods:ndats));
    ebdrem(q)=sem(handles.boutrst(q:nperiods:ndats)');
    bdremvals(q,:)=handles.boutrst(q:nperiods:ndats);
end
ztstart=7;%ZT for the first data bloxk
ztend=10;%ZT for the last data block (for 1 h  block)
subplot(3,1,1)
xzt=ztstart+(0:((ztend-ztstart+1)/length(mpwa)):((ztend-ztstart+1)-((ztend-ztstart+1)/length(mpwa))));
ztend2=xzt(end);
errorbar((xzt),mpwa,epwa,'k.')
hold on
%plot(xzt,pwavals,'.-','color',[0.7 0.7 0.7])
plot((xzt),mpwa,'ok-','linewidth',1,'MarkerFaceColor',[1 1 1])
axis tight;%set(gca,'ylim',[0 85])
box off
set(gca,'fontsize',14)
ylabel('% T in WA','fontsize',21)
set(gca,'xlim',[ztstart ztend2])

subplot(3,1,2)
errorbar(xzt,mpnr,epnr,'k.')
hold on
%plot(xzt,pnrvals,'.-','color',[0.7 0.7 0.7])
plot(xzt,mpnr,'ok-','linewidth',1,'MarkerFaceColor',[1 1 1])
set(gca,'ylim',[0 85])
box off
set(gca,'fontsize',14)
ylabel('% T in NREM','fontsize',21)
set(gca,'xlim',[ztstart ztend])
subplot(3,1,3)
errorbar(xzt,mprem,eprem,'k.')
hold on
%plot(xzt,premvals,'.-','color',[0.7 0.7 0.7])
plot(xzt,mprem,'ok-','linewidth',1,'MarkerFaceColor',[1 1 1])
set(gca,'ylim',[0 85])
box off
set(gca,'fontsize',14)
ylabel('% T in REM','fontsize',21)
xlabel('ZT Time (hours)','fontsize',21)
set(gca,'xlim',[ztstart ztend2])

%Plotting mean bout duration
figure
subplot(3,1,1)
errorbar(xzt,mbdwa,ebdwa,'k.')
hold on
%plot(xzt,bdwavals,'.-','color',[0.7 0.7 0.7])
plot(xzt,mbdwa,'ok-','linewidth',1,'MarkerFaceColor',[1 1 1])
%set(gca,'ylim',[0 100])
box off
set(gca,'fontsize',14)
ylabel('B.Dur. WA (s)','fontsize',21)
set(gca,'xlim',[ztstart ztend2])
set(gca,'ylim',[0 500])
subplot(3,1,2)
errorbar(xzt,mbdnr,ebdnr,'k.')
hold on
%plot(xzt,bdnrvals,'.-','color',[0.7 0.7 0.7])
plot(xzt,mbdnr,'ok-','linewidth',1,'MarkerFaceColor',[1 1 1])
%set(gca,'ylim',[0 100])
box off
set(gca,'fontsize',14)
ylabel('B.Dur.NREM (s)','fontsize',21)
set(gca,'xlim',[ztstart ztend2])
set(gca,'ylim',[0 500])
subplot(3,1,3)
errorbar(xzt,mbdrem,ebdrem,'k.')
hold on
%plot(xzt,bdremvals,'.-','color',[0.7 0.7 0.7])
plot(xzt,mbdrem,'ok-','linewidth',1,'MarkerFaceColor',[1 1 1])
%set(gca,'ylim',[0 100])
box off
set(gca,'fontsize',14)
ylabel('B.Dur. REM (s)','fontsize',21)
xlabel('ZT Time (hours)','fontsize',21)
set(gca,'xlim',[ztstart ztend2])
set(gca,'ylim',[0 500])



figure
%Ploting SWA
x=xzt;
plot(x,avgld,'ob-','MarkerFaceColor',[0 0 1])
hold on
plot(x,avghd,'or-','MarkerFaceColor',[1 0 0])
errorbar(x,avgld,semld,'k.')
hold on
errorbar(x,avghd,semhd,'k.')
box off
ylabel('Relative SWA','fontsize',21)
xlabel('ZT Time (hours)','fontsize',21)
set(gca,'xlim',[ztstart ztend2])
set(gca,'fontsize',14)
legend('Low Delta (0.5-2.5 Hz)','High Delta (2.5-4.5 Hz)')
plot(x,avgld,'ob-','MarkerFaceColor',[0 0 1])
hold on
plot(x,avghd,'or-','MarkerFaceColor',[1 0 0])
save('summary_vals.mat','pwavals','pnrvals','premvals','bdwavals','bdnrvals','bdremvals','allvalsld','allvalshd')



% --- Executes on button press in normalized_power.
function normalized_power_Callback(hObject, eventdata, handles)
% hObject    handle to normalized_power (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Reads the FFT data of the selected channels for drug and vehicle.
%Normalizes each frequency by the vehicle and saves the natrix
%reading each experiment.
%First the drug
for i=1:2
    fname=char(handles.dnames{handles.chosen(i)});
    selchan=input(strcat('select channel for ',fname,': '));
    load(char(handles.dnames{handles.chosen(i)}));
    if fname(i)=='D'
        if selchan==1
            chdatad=ch1data;
        elseif selchan==2
            chdatad=ch2data;
        else
            chdatad=ch3data;
        end
        dhits=[];dcr=[];
        if isfield(chdatad,'hits_avgFFT')
            dhits=(chdatad.hits_avgFFT(:,1:100));
        end
        if isfield(chdatad,'crej_avgFFT')
            dcr=(chdatad.crej_avgFFT(:,1:100));
        end
    else
        if selchan==1
            chdatav=ch1data;
        elseif selchan==2
            chdatav=ch2data;
        else
            chdatav=ch3data;
        end
        vhits=[];vcr=[];
        if isfield(chdatav,'hits_avgFFT')
            vhits=(chdatav.hits_avgFFT(:,1:100));
        end
        if isfield(chdatav,'crej_avgFFT')
            vcr=(chdatav.crej_avgFFT(:,1:100));
        end
    end
end
normathits=dhits./vhits;
normatcr=dcr./vcr;
save(strcat('N',num2str(selchan),fname(2:end)),'normathits','normatcr','dhits','dcr','vhits','vcr')
helpdlg('Saved')


% --- Executes on button press in normheatmap.
function normheatmap_Callback(hObject, eventdata, handles)
% hObject    handle to normheatmap (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
avghits=[];avgcr=[];
n=length(handles.chosen);
for i=1:n
    data=load(char(handles.dnames{handles.chosen(i)}));
    %normalizing by mean in time
    for k=1:size(data.dhits,1)
        dnorm(k,:)=data.dhits(k,:)/mean(data.vhits(k,1:100));
        vnorm(k,:)=data.vhits(k,:)/mean(data.vhits(k,1:100));
    end
    if i==1
        avghits=data.dhits;
        avgcr=data.normatcr;
        vhits=data.vhits;
        avgdnorm=dnorm;
        avgvnorm=vnorm;
    else
        avghits=avghits+data.normathits;
        avgcr=avgcr+data.normatcr;
        avgdnorm=avgdnorm+dnorm;
        avgvnorm=avgvnorm+vnorm;
    end
end
avghits=avghits/n;
avgcr=avgcr/n;
avgdnorm=avgdnorm/n;
avgvnorm=avgvnorm/n;
figure
% disp('Set the size of the fig')
% pause
factor=64/str2double(get(handles.edit1,'string'));%factor to multiply the heatmat so the value set for fixed scale=64
%CH1:
% subplot(1,2,1)
%image(ones(size(avghits))*factor)
image(avgdnorm*factor)
axis xy
colormap('jet')
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str((xlabl/100)))
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S','fontsize',21)
ylabel('Hz','fontsize',21)
title('Avgfft prestim hits')
set(gca,'fontsize',14)
c=colorbar;
ylablcb=str2num(get(c,'Yticklabel'));
% if get(handles.fixedscale,'value')
set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*str2double(get(handles.edit1,'string')))));
% else
%     set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*(maxminffthits(2)-maxminffthits(1))+maxminffthits(1))));
% end
set(gca,'fontsize',14)
box off
figure
% disp('Set the size of the fig')
% pause
factor=64/str2double(get(handles.edit1,'string'));%factor to multiply the heatmat so the value set for fixed scale=64
%CH1:
% subplot(1,2,1)
%image(ones(size(avghits))*factor)
image(avgvnorm*factor)
axis xy
colormap('jet')
xlabl=str2num(get(gca,'Xticklabel'));
set(gca,'Xticklabel',num2str((xlabl/100)))
ylabl=str2num(get(gca,'Yticklabel'))
set(gca,'Yticklabel',num2str(2*ylabl))
xlabel('S','fontsize',21)
ylabel('Hz','fontsize',21)
title('Avgfft prestim hits')
set(gca,'fontsize',14)
c=colorbar;
ylablcb=str2num(get(c,'Yticklabel'));
% if get(handles.fixedscale,'value')
set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*str2double(get(handles.edit1,'string')))));
% else
%     set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*(maxminffthits(2)-maxminffthits(1))+maxminffthits(1))));
% end
set(gca,'fontsize',14)
box off

% subplot(1,2,2)
% image(avgcr*factor)
% axis xy
% colormap('jet')
% xlabl=str2num(get(gca,'Xticklabel'));
% set(gca,'Xticklabel',num2str((xlabl/100)))
% ylabl=str2num(get(gca,'Yticklabel'))
% set(gca,'Yticklabel',num2str(2*ylabl))
% xlabel('S','fontsize',21)
% ylabel('Hz','fontsize',21)
% title('Avgfft prestim crej')
% set(gca,'fontsize',14)
% c=colorbar;
% ylablcb=str2num(get(c,'Yticklabel'));
% % if get(handles.fixedscale,'value') `
%     set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*str2double(get(handles.edit1,'string')))));
% % else
% %     set(c,'Yticklabel',num2str(0.1*round(10*(ylablcb./64)*(maxminffthits(2)-maxminffthits(1))+maxminffthits(1))));
% % end
% set(gca,'fontsize',14)



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
switch get(hObject,'Value')
    case 2
        %Population Analysis for optogentic stimulation
        %to plot: mean power bands, mean median latency to wake for vehicle and
        %drug (ALM) and probability of SWS to W transition for all data
        %Number of animals awaken after (4*n) sec/all cases from all
        %animals.n=1:25
        if get(handles.veh,'value')
            %reading vehicle
            handles.deltaFFTv=[];
            handles.thetaFFTv=[];
            handles.alphaFFTv=[];
            handles.betaFFTv=[];
            handles.lowGFFTv=[];
            handles.highGFFTv=[];
            handles.meanfftv=[];
            handles.favcasesbv=zeros(1,120);%This has the index of cases that animal woke up after 1,2 ,3...120 sec.
            handles.favcasesyv=zeros(1,120);%This has the index of cases that animal woke up after 1,2 ,3...120 sec.
            handles.totcasesbv=0;
            handles.totcasesyv=0;
            for i=1:length(handles.chosen)
                data=load(char(handles.dnames{handles.chosen(i)}));
                auxps0=fixdim(data.TFRhannEEGmatNR.powspctrm);
                notindnan=find(~isnan(auxps0(1,1,:)));
                auxps=auxps0(:,:,notindnan);
                handles.deltaFFTv(i,:)=mean(fixdim(mean(auxps(:,1:2,:),2)),1);
                handles.thetaFFTv(i,:)=mean(fixdim(mean(auxps(:,3:4,:),2)),1);
                handles.alphaFFTv(i,:)=mean(fixdim(mean(auxps(:,5:6,:),2)),1);
                handles.betaFFTv(i,:)=mean(fixdim(mean(auxps(:,7:15,:),2)),1);
                handles.lowGFFTv(i,:)=mean(fixdim(mean(auxps(:,15:30,:),2)),1);
                handles.highGFFTv(i,:)=mean(fixdim(mean(auxps(:,30:40,:),2)),1);
                handles.meanfftv(i,:)=mean(fixdim(mean(auxps,1)),1);
                handles.medianlatbv(i)=mean(data.indwa);
                handles.medianlatyv(i)=mean(data.indway);
                for casf=1:length(data.indwa)
                    handles.favcasesbv(min(120,data.el*data.indwa(casf)))=handles.favcasesbv(min(120,data.el*data.indwa(casf)))+1;
                end
                for casf=1:length(data.indway)
                    handles.favcasesyv(min(120,data.el*data.indway(casf)))=handles.favcasesyv(min(120,data.el*data.indway(casf)))+1;
                end
                handles.totcasesbv=handles.totcasesbv+length(data.indwa);
                handles.totcasesyv=handles.totcasesyv+length(data.indway);
            end
            handles.vehread=1;
            handles.nv=length(handles.chosen)
        else
            handles.deltaFFTd=[];
            handles.thetaFFTd=[];
            handles.alphaFFTd=[];
            handles.betaFFTd=[];
            handles.lowGFFTd=[];
            handles.highGFFTd=[];
            handles.meanfftd=[];
            handles.favcasesbd=zeros(1,120);%This has the index of cases that animal woke up after 1,2 ,3...120 sec.
            handles.favcasesyd=zeros(1,120);%This has the index of cases that animal woke up after 1,2 ,3...120 sec.
            handles.totcasesbd=0;
            handles.totcasesyd=0;
            for i=1:length(handles.chosen)
                data=load(char(handles.dnames{handles.chosen(i)}));
                auxps0=fixdim(data.TFRhannEEGmatNR.powspctrm);
                notindnan=find(~isnan(auxps0(1,1,:)));
                auxps=auxps0(:,:,notindnan);
                handles.deltaFFTd(i,:)=mean(fixdim(mean(auxps(:,1:2,:),2)),1);
                handles.thetaFFTd(i,:)=mean(fixdim(mean(auxps(:,3:4,:),2)),1);
                handles.alphaFFTd(i,:)=mean(fixdim(mean(auxps(:,5:6,:),2)),1);
                handles.betaFFTd(i,:)=mean(fixdim(mean(auxps(:,7:15,:),2)),1);
                handles.lowGFFTd(i,:)=mean(fixdim(mean(auxps(:,15:30,:),2)),1);
                handles.highGFFTd(i,:)=mean(fixdim(mean(auxps(:,30:40,:),2)),1);
                handles.meanfftd(i,:)=mean(fixdim(mean(auxps,1)),1);
                handles.medianlatbd(i)=mean(data.indwa);
                handles.medianlatyd(i)=mean(data.indway);
                for casf=1:length(data.indwa)
                    handles.favcasesbd(min(120,data.el*data.indwa(casf)))=handles.favcasesbd(min(120,data.el*data.indwa(casf)))+1;
                end
                for casf=1:length(data.indway)
                    handles.favcasesyd(min(120,data.el*data.indway(casf)))=handles.favcasesyd(min(120,data.el*data.indway(casf)))+1;
                end
                handles.totcasesbd=handles.totcasesbd+length(data.indwa);
                handles.totcasesyd=handles.totcasesyd+length(data.indway);
            end
            handles.drugread=1;
            handles.nd=length(handles.chosen)
        end
        guidata(hObject, handles);
        if handles.drugread & handles.vehread
            %plotting bands
            figure
            subplot(3,2,1)
            %Plotting the bands now:
            colfillv=[0.6 0.6 1];
            coltrv='b';
            colfilld=[1 0.6 0.6];
            coltrd='r';
            m1=mean(handles.deltaFFTd);
            minerr=m1-sem(handles.deltaFFTd);
            maxerr=m1+sem(handles.deltaFFTd);
            x=-data.Taround+1:data.stepfft:data.Taround-1;
            x=x(2:end);
            X=[x,fliplr(x)];                %create continuous x value array for plotting
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfilld,'EdgeColor','none');                  %plot filled area
            hold on
            m2=mean(handles.deltaFFTv);
            minerr=m2-sem(handles.deltaFFTv);
            maxerr=m2+sem(handles.deltaFFTv);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfillv,'EdgeColor','none');                  %plot filled area
            hold on
            plot(x,m1(1:length(x)),coltrd,'linewidth',2)
            plot(x,m2(1:length(x)),coltrv,'linewidth',2)
            title('Delta (0.5-4 Hz)','fontsize',21)
            box off
            set(gca,'fontsize',14)
            ylabel('Power (uV^2)','fontsize',18)
            
            subplot(3,2,2)
            %Plotting the bands now:
            colfillv=[0.6 0.6 1];
            coltrv='b';
            colfilld=[1 0.6 0.6];
            coltrd='r';
            m1=mean(handles.thetaFFTd);
            minerr=m1-sem(handles.thetaFFTd);
            maxerr=m1+sem(handles.thetaFFTd);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfilld,'EdgeColor','none');                  %plot filled area
            hold on
            m2=mean(handles.thetaFFTv);
            minerr=m2-sem(handles.thetaFFTv);
            maxerr=m2+sem(handles.thetaFFTv);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfillv,'EdgeColor','none');                  %plot filled area
            hold on
            plot(x,m1(1:length(x)),coltrd,'linewidth',2)
            plot(x,m2(1:length(x)),coltrv,'linewidth',2)
            title('Theta (4-8 Hz)','fontsize',21)
            box off
            set(gca,'fontsize',14)
            %ylabel('Power (uV^2)','fontsize',18)
            
            subplot(3,2,3)
            %Plotting the bands now:
            colfillv=[0.6 0.6 1];
            coltrv='b';
            colfilld=[1 0.6 0.6];
            coltrd='r';
            m1=mean(handles.alphaFFTd);
            minerr=m1-sem(handles.alphaFFTd);
            maxerr=m1+sem(handles.alphaFFTd);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfilld,'EdgeColor','none');                  %plot filled area
            hold on
            m2=mean(handles.alphaFFTv);
            minerr=m2-sem(handles.alphaFFTv);
            maxerr=m2+sem(handles.alphaFFTv);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfillv,'EdgeColor','none');                  %plot filled area
            hold on
            plot(x,m1(1:length(x)),coltrd,'linewidth',2)
            plot(x,m2(1:length(x)),coltrv,'linewidth',2)
            title('Alpha (8-12 Hz)','fontsize',21)
            box off
            set(gca,'fontsize',14)
            ylabel('Power (uV^2)','fontsize',18)
            
            subplot(3,2,4)
            %Plotting the bands now:
            colfillv=[0.6 0.6 1];
            coltrv='b';
            colfilld=[1 0.6 0.6];
            coltrd='r';
            m1=mean(handles.betaFFTd);
            minerr=m1-sem(handles.betaFFTd);
            maxerr=m1+sem(handles.betaFFTd);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfilld,'EdgeColor','none');                  %plot filled area
            hold on
            m2=mean(handles.betaFFTv);
            minerr=m2-sem(handles.betaFFTv);
            maxerr=m2+sem(handles.betaFFTv);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfillv,'EdgeColor','none');                  %plot filled area
            hold on
            plot(x,m1(1:length(x)),coltrd,'linewidth',2)
            plot(x,m2(1:length(x)),coltrv,'linewidth',2)
            title('Beta (12-30 Hz)','fontsize',21)
            box off
            set(gca,'fontsize',14)
            %ylabel('Power (uV^2)','fontsize',18)
            
            subplot(3,2,5)
            %Plotting the bands now:
            colfillv=[0.6 0.6 1];
            coltrv='b';
            colfilld=[1 0.6 0.6];
            coltrd='r';
            m1=mean(handles.lowGFFTd);
            minerr=m1-sem(handles.lowGFFTd);
            maxerr=m1+sem(handles.lowGFFTd);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfilld,'EdgeColor','none');                  %plot filled area
            hold on
            m2=mean(handles.lowGFFTv);
            minerr=m2-sem(handles.lowGFFTv);
            maxerr=m2+sem(handles.lowGFFTv);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfillv,'EdgeColor','none');                  %plot filled area
            hold on
            plot(x,m1(1:length(x)),coltrd,'linewidth',2)
            plot(x,m2(1:length(x)),coltrv,'linewidth',2)
            title('Low G(30-60 Hz)','fontsize',21)
            box off
            set(gca,'fontsize',14)
            ylabel('Power (uV^2)','fontsize',18)
            xlabel('s','fontsize',18)
            
            subplot(3,2,6)
            %Plotting the bands now:
            colfillv=[0.6 0.6 1];
            coltrv='b';
            colfilld=[1 0.6 0.6];
            coltrd='r';
            m1=mean(handles.highGFFTd);
            minerr=m1-sem(handles.highGFFTd);
            maxerr=m1+sem(handles.highGFFTd);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfilld,'EdgeColor','none');                  %plot filled area
            hold on
            m2=mean(handles.highGFFTv);
            minerr=m2-sem(handles.highGFFTv);
            maxerr=m2+sem(handles.highGFFTv);
            Y=[minerr,fliplr(maxerr)];              %create y values for out and then back
            fill(X,Y,colfillv,'EdgeColor','none');                  %plot filled area
            hold on
            plot(x,m1(1:length(x)),coltrd,'linewidth',2)
            plot(x,m2(1:length(x)),coltrv,'linewidth',2)
            title('High G(50-80 Hz)','fontsize',21)
            box off
            set(gca,'fontsize',14)
            %ylabel('Power (uV^2)','fontsize',18)
            xlabel('s','fontsize',18)
            %Plotting the mean latency to wake
            
            figure
            y=[mean(handles.medianlatbv) mean(handles.medianlatyv) mean(handles.medianlatbd) mean(handles.medianlatyd)];
            e=[sem(handles.medianlatbv) sem(handles.medianlatyv) sem(handles.medianlatbd) sem(handles.medianlatyd)];
            errorbar(y,e,'k.')
            hold on
            bar(y)
            set(gca,'XTick',[1 2 3 4])
            set(gca,'XTickLabel',{'Stim Veh','Ctrl Veh','Stim Alm','Ctrl Alm'})
            box off
            set(gca,'fontsize',16)
            ylabel('No of 4s Epochs to Wake','fontsize',18)
            %plotting cumulative probability to wake
            figure
            subplot(1,2,2)
            for i=1:120
                cpyd(i)=sum(handles.favcasesyd(1:i))/handles.totcasesyd;
                cpyv(i)=sum(handles.favcasesyv(1:i))/handles.totcasesyv;
                cpbd(i)=sum(handles.favcasesbd(1:i))/handles.totcasesbd;
                cpbv(i)=sum(handles.favcasesbv(1:i))/handles.totcasesbv;
            end
            plot(cpyd,'y-','linewidth',2)
            hold on
            plot(cpbd,'b-','linewidth',2)
            set(gca,'fontsize',16)
            hold on
            
            ylabel('Cumulative prob. of Wake','fontsize',18)
            xlabel('Time after stimulation (s)','fontsize',18)
            title ('ALM','fontsize',21)
            legend ('Ctrl','Stim')
            box off
            axis tight
            subplot(1,2,1)
            plot(cpyv,'y-','linewidth',2)
            hold on
            plot(cpbv,'b-','linewidth',2)
            set(gca,'fontsize',16)
            hold on
            ylabel('Cumulative prob. of Wake','fontsize',18)
            xlabel('Time after stimulation (s)','fontsize',18)
            title ('Veh','fontsize',21)
            legend ('Ctrl','Stim')
            axis tight
            box off
        else
            if ~handles.drugread
                helpdlg('Load Drug data')
            end
            if ~handles.vehread
                helpdlg('Load vehicle data')
            end
        end
        
    case 3 %analysis of imaged vs non imaged vs sham. Also plots the population figures
        %1- load % time, Bout dur, power for each state for each animal imaged (Mic on & mic off)
        %2- load % time, Bout dur, +and power for each state for each sham animal
        %3- plot mean and SEM for each value for each group and generate
        %txt table with all values
        cd ('D:\pop\old\imag')
        pth=pwd;
        path_img = uigetdir(pth,'Select directory with Imaging data');
        path_sham = uigetdir(pth,'Select directory with Sham data');
        cd(path_img);
        %reading imaginf data:
        dir_img=dir ('*.mat');
        disp('Reading img folder...')
        for np=1:3
            all_evratewa{np}=[];%ev rate from all cells for each epoch during WA
            wa_evratewa{np}=[];%ev rate from wa cells for each epoch during WA
            Qwa_evratewa{np}=[];
            Awa_evratewa{np}=[];
            nr_evratewa{np}=[];
            r_evratewa{np}=[];
            inv_evratewa{np}=[];
            
            wa_evratewamix{np}=[];%ev rate from wa cells for each epoch during WA
            Qwa_evratewamix{np}=[];
            Awa_evratewamix{np}=[];
            nr_evratewamix{np}=[];
            r_evratewamix{np}=[];
            
            all_evrateQwa{np}=[];%ev rate from all cells for each epoch during WA
            wa_evrateQwa{np}=[];%ev rate from wa cells for each epoch during WA
            Qwa_evrateQwa{np}=[];
            Awa_evrateQwa{np}=[];
            nr_evrateQwa{np}=[];
            r_evrateQwa{np}=[];
            inv_evrateQwa{np}=[];
            wa_evrateQwamix{np}=[];
            Qwa_evrateQwamix{np}=[];
            Awa_evrateQwamix{np}=[];%ev rate from wa cells for each epoch during WA
            nr_evrateQwamix{np}=[];
            r_evrateQwamix{np}=[];
            
            all_evrateAwa{np}=[];%ev rate from all cells for each epoch during WA
            wa_evrateAwa{np}=[];%ev rate from wa cells for each epoch during WA
            Qwa_evrateAwa{np}=[];
            Awa_evrateAwa{np}=[];
            nr_evrateAwa{np}=[];
            r_evrateAwa{np}=[];
            inv_evrateAwa{np}=[];
            wa_evrateAwamix{np}=[];
            Qwa_evrateAwamix{np}=[];
            Awa_evrateAwamix{np}=[];%ev rate from wa cells for each epoch during WA
            nr_evrateAwamix{np}=[];
            r_evrateAwamix{np}=[];
            
            all_evratenrem{np}=[];
            wa_evratenrem{np}=[];
            Qwa_evratenrem{np}=[];
            Awa_evratenrem{np}=[];
            nr_evratenrem{np}=[];
            r_evratenrem{np}=[];
            inv_evratenrem{np}=[];
            wa_evratenremmix{np}=[];
            Qwa_evratenremmix{np}=[];
            Awa_evratenremmix{np}=[];
            nr_evratenremmix{np}=[];
            r_evratenremmix{np}=[];
            
            all_evraterem{np}=[];
            wa_evraterem{np}=[];
            Qwa_evraterem{np}=[];
            Awa_evraterem{np}=[];
            nr_evraterem{np}=[];
            r_evraterem{np}=[];
            inv_evraterem{np}=[];
            wa_evrateremmix{np}=[];
            Qwa_evrateremmix{np}=[];
            Awa_evrateremmix{np}=[];
            nr_evrateremmix{np}=[];
            r_evrateremmix{np}=[];
            
            wa_rem_evratewamix{np}=[];
            wa_nrem_evratewamix{np}=[];
            nr_wa_evratewamix{np}=[];
            nr_rem_evratewamix{np}=[];
            r_nr_evratewamix{np}=[];
            r_wa_evratewamix{np}=[];
            wa_rem_evrateremmix{np}=[];
            wa_nrem_evrateremmix{np}=[];
            nr_wa_evrateremmix{np}=[];
            nr_rem_evrateremmix{np}=[];
            r_nr_evrateremmix{np}=[];
            r_wa_evrateremmix{np}=[];
            wa_rem_evrateQwamix{np}=[];
            wa_nrem_evrateQwamix{np}=[];
            nr_wa_evrateQwamix{np}=[];
            nr_rem_evrateQwamix{np}=[];
            r_nr_evrateQwamix{np}=[];
            r_wa_evrateQwamix{np}=[];
            wa_rem_evrateAwamix{np}=[];
            wa_nrem_evrateAwamix{np}=[];
            nr_wa_evrateAwamix{np}=[];
            nr_rem_evrateAwamix{np}=[];
            r_nr_evrateAwamix{np}=[];
            r_wa_evrateAwamix{np}=[];
            wa_rem_evratenremmix{np}=[];
            wa_nrem_evratenremmix{np}=[];
            nr_wa_evratenremmix{np}=[];
            nr_rem_evratenremmix{np}=[];
            r_nr_evratenremmix{np}=[];
            r_wa_evratenremmix{np}=[];
            
            
        end
        
        
        
        wa23=[];
        nr23=[];
        r23=[];
        wa23nor=[];
        nr23nor=[];
        r23nor=[];
        allwahg=[];
        allmaxev=[];
        alltracewa=[];
        if exist('popdata.mat')>0
            delete('popdata.mat')
            dir_img=dir ('*.mat');
        end
        for i=1:length(dir_img)
            scoreep{i}=[];
            imgdata=load(dir_img(i).name);
            ncells(i)=size(imgdata.pref,2);
            
            %index for cell type for each animal/period. Number of cells
            %for each type changes between periods
            nmovs=size(imgdata.viddata,2);
            currmv=0;
            
            for np=1:3
                indleast=round(10*(imgdata.leastpref(np,:)-round(imgdata.leastpref(np,:))));
                indpwa{np,i}=find(imgdata.pref(np,:)==2);
                indpnr{np,i}=find(imgdata.pref(np,:)==3);
                indpr{np,i}=find(imgdata.pref(np,:)==1);
                
                indpwaremmx{np,i}=find(round(imgdata.leastpref(np,:))==2 & indleast==3);%pref is wa and least pref is NREM thus 2nd pref is REM
                indpwanremmx{np,i}=find(round(imgdata.leastpref(np,:))==2 & indleast==1);
                indpnrwamx{np,i}=find(round(imgdata.leastpref(np,:))==3 & indleast==1);
                indpnrremmx{np,i}=find(round(imgdata.leastpref(np,:))==3 & indleast==2);
                indprnremmx{np,i}=find(round(imgdata.leastpref(np,:))==1 & indleast==2);
                indprwamx{np,i}=find(round(imgdata.leastpref(np,:))==1 & indleast==3);
                indpmixed{np,i}=find(imgdata.leastpref(np,:)>0);
                indpinv{np,i}=find(imgdata.leastpref(np,:)==0 & imgdata.pref(np,:)==0);
                if length(indpinv{np,i})==0
                    indpinv{np,i}=find(imgdata.pref(np,:)~=0);
                end
                
                %                 ina=find(isnan(imgdata.matevwa{np}));
                %                 imgdata.matevwa{np}(ina)=0;
                %                 ina=find(isnan(imgdata.matevnrem{np}));
                %                 imgdata.matevnrem{np}(ina)=0;
                %                 ina=find(isnan(imgdata.matevrem{np}));
                %                 imgdata.matevrem{np}(ina)=0;
                %getting mean event rate for each state for all and state specific cells
                
                %Idenifying Qwa and Awa epochs and cells
                indQwa{np,i}=find(imgdata.matlmawa{np}==min(imgdata.matlmawa{np}));
                indAwa{np,i}=find(imgdata.matlmawa{np}>min(imgdata.matlmawa{np}));%epochs within wake that are either Qwa or Awa
                evrateQwa=mean(imgdata.matevwa{np}(indQwa{np,i},indpwa{np,i}),1);
                evrateAwa=mean(imgdata.matevwa{np}(indAwa{np,i},indpwa{np,i}),1);
                Qwacells{np,i}=indpwa{np,i}(find(evrateQwa>evrateAwa));%Qwa cells within the indpwa{np,i} subset
                Awacells{np,i}=indpwa{np,i}(find(evrateQwa<=evrateAwa));
                
                %Idenifying Qwamix and Awamix epochs and cells
                indQwa{np,i}=find(imgdata.matlmawa{np}==min(imgdata.matlmawa{np}));
                indAwa{np,i}=find(imgdata.matlmawa{np}>min(imgdata.matlmawa{np}));%epochs within wake that are either Qwa or Awa
                evrateQwa=mean(imgdata.matevwa{np}(indQwa{np,i},indpwa{np,i}),1);
                evrateAwa=mean(imgdata.matevwa{np}(indAwa{np,i},indpwa{np,i}),1);
                Qwacells{np,i}=indpwa{np,i}(find(evrateQwa>evrateAwa));%Qwa cells within the indpwa{np,i} subset
                Awacells{np,i}=indpwa{np,i}(find(evrateQwa<=evrateAwa));
                
                if length(imgdata.matevwa{np})>0
                    %Wa (all) epochs for cell groups
                    
                    all_evratewa{np}=[all_evratewa{np} mean(imgdata.matevwa{np},1)];%all cells WA epochs
                    wa_evratewa{np}=[wa_evratewa{np} mean(imgdata.matevwa{np}(:,indpwa{np,i}),1)];% WA cells, wa epochs
                    
                    Qwa_evratewa{np}=[Qwa_evratewa{np} mean(imgdata.matevwa{np}(:,Qwacells{np,i}),1)];%Qwa cells, WA epochs
                    
                    Awa_evratewa{np}=[Awa_evratewa{np} mean(imgdata.matevwa{np}(:,Awacells{np,i}),1)];
                    
                    nr_evratewa{np}=[nr_evratewa{np} mean(imgdata.matevwa{np}(:,indpnr{np,i}),1)];
                    r_evratewa{np}=[r_evratewa{np} mean(imgdata.matevwa{np}(:,indpr{np,i}),1)];
                    inv_evratewa{np}=[inv_evratewa{np} mean(imgdata.matevwa{np}(:,indpinv{np,i}),1)];
                    i
                    np
                    disp(strcat('number of cells for indpwa{np,i}',num2str(length(indpwa{np,i}))))
                    disp(strcat('number of cells for Qwacells{np,i}',num2str(length(Qwacells{np,i}))))
                    disp(strcat('number of cells for Awacells{np,i}',num2str(length(Awacells{np,i}))))
                    disp(strcat('number of cells for indpnr{np,i}',num2str(length(indpnr{np,i}))))
                    disp(strcat('number of cells for indpr{np,i}',num2str(length(indpr{np,i}))))
                    disp(strcat('number of cells for indpinv{np,i}',num2str(length(indpinv{np,i}))))
                    %mixed:
                    wa_rem_evratewamix{np}=[wa_rem_evratewamix{np} mean(imgdata.matevwa{np}(:,indpwaremmx{np,i}),1)];
                    wa_nrem_evratewamix{np}=[wa_nrem_evratewamix{np} mean(imgdata.matevwa{np}(:,indpwanremmx{np,i}),1)];
                    nr_wa_evratewamix{np}=[nr_wa_evratewamix{np} mean(imgdata.matevwa{np}(:,indpnrwamx{np,i}),1)];
                    nr_rem_evratewamix{np}=[nr_rem_evratewamix{np} mean(imgdata.matevwa{np}(:,indpnrremmx{np,i}),1)];
                    r_nr_evratewamix{np}=[r_nr_evratewamix{np} mean(imgdata.matevwa{np}(:,indprnremmx{np,i}),1)];
                    r_wa_evratewamix{np}=[r_wa_evratewamix{np} mean(imgdata.matevwa{np}(:,indprwamx{np,i}),1)];
                    
                    %identifying Qwa and Awa cells
                end
                
                %adding the two sub states Awa and Qwa:
                if length(indQwa{np,i})>0
                    %Qwa epochs for cell groups
                    
                    all_evrateQwa{np}=[all_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},:),1)];%all cells Qwa epochs
                    wa_evrateQwa{np}=[wa_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpwa{np,i}),1)];%Wa cells, Qwa epochs
                    Qwa_evrateQwa{np}=[Qwa_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},Qwacells{np,i}),1)];%Qwa cells, Qwa epochs
                    Awa_evrateQwa{np}=[Awa_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},Awacells{np,i}),1)];%Awa cells, Qwa epochs
                    
                    nr_evrateQwa{np}=[nr_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpnr{np,i}),1)];
                    r_evrateQwa{np}=[r_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpr{np,i}),1)];
                    inv_evrateQwa{np}=[inv_evrateQwa{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpinv{np,i}),1)];
                    
                    %mixed:
                    wa_rem_evrateQwamix{np}=[wa_rem_evrateQwamix{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpwaremmx{np,i}),1)];
                    wa_nrem_evrateQwamix{np}=[wa_nrem_evrateQwamix{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpwanremmx{np,i}),1)];
                    nr_wa_evrateQwamix{np}=[nr_wa_evrateQwamix{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpnrwamx{np,i}),1)];
                    nr_rem_evrateQwamix{np}=[nr_rem_evrateQwamix{np} mean(imgdata.matevwa{np}(indQwa{np,i},indpnrremmx{np,i}),1)];
                    r_nr_evrateQwamix{np}=[r_nr_evrateQwamix{np} mean(imgdata.matevwa{np}(indQwa{np,i},indprnremmx{np,i}),1)];
                    r_wa_evrateQwamix{np}=[r_wa_evrateQwamix{np} mean(imgdata.matevwa{np}(indQwa{np,i},indprwamx{np,i}),1)];
                    
                    
                    
                    %identifying Qwa and Awa cells
                end
                if length(indAwa{np,i})>0
                    
                    %Qwa epochs for cell groups
                    all_evrateAwa{np}=[all_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},:),1)];%all cells Awa epochs
                    wa_evrateAwa{np}=[wa_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpwa{np,i}),1)];%Wa cells, Awa epochs
                    Qwa_evrateAwa{np}=[Qwa_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},Qwacells{np,i}),1)];%Qwa cells, Awa epochs
                    Awa_evrateAwa{np}=[Awa_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},Awacells{np,i}),1)];%Awa cells, Awa epochs
                    
                    nr_evrateAwa{np}=[nr_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpnr{np,i}),1)];
                    r_evrateAwa{np}=[r_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpr{np,i}),1)];
                    inv_evrateAwa{np}=[inv_evrateAwa{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpinv{np,i}),1)];
                    
                    %mixed:
                    wa_rem_evrateAwamix{np}=[wa_rem_evrateAwamix{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpwaremmx{np,i}),1)];
                    wa_nrem_evrateAwamix{np}=[wa_nrem_evrateAwamix{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpwanremmx{np,i}),1)];
                    nr_wa_evrateAwamix{np}=[nr_wa_evrateAwamix{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpnrwamx{np,i}),1)];
                    nr_rem_evrateAwamix{np}=[nr_rem_evrateAwamix{np} mean(imgdata.matevwa{np}(indAwa{np,i},indpnrremmx{np,i}),1)];
                    r_nr_evrateAwamix{np}=[r_nr_evrateAwamix{np} mean(imgdata.matevwa{np}(indAwa{np,i},indprnremmx{np,i}),1)];
                    r_wa_evrateAwamix{np}=[r_wa_evrateAwamix{np} mean(imgdata.matevwa{np}(indAwa{np,i},indprwamx{np,i}),1)];
                    
                    
                end
                
                
                if length(imgdata.matevnrem{np})>0
                    all_evratenrem{np}=[all_evratenrem{np} mean(imgdata.matevnrem{np},1)];
                    wa_evratenrem{np}=[wa_evratenrem{np} mean(imgdata.matevnrem{np}(:,indpwa{np,i}),1)];
                    Qwa_evratenrem{np}=[Qwa_evratenrem{np} mean(imgdata.matevnrem{np}(:,Qwacells{np,i}),1)];%Qwa cells, nrem epochs
                    Awa_evratenrem{np}=[Awa_evratenrem{np} mean(imgdata.matevnrem{np}(:,Awacells{np,i}),1)];%Awa cells, nrem epochs
                    
                    nr_evratenrem{np}=[nr_evratenrem{np} mean(imgdata.matevnrem{np}(:,indpnr{np,i}),1)];
                    r_evratenrem{np}=[r_evratenrem{np} mean(imgdata.matevnrem{np}(:,indpr{np,i}),1)];
                    inv_evratenrem{np}=[inv_evratenrem{np} mean(imgdata.matevnrem{np}(:,indpinv{np,i}),1)];
                    
                    wa_rem_evratenremmix{np}=[wa_rem_evratenremmix{np} mean(imgdata.matevwa{np}(:,indpwaremmx{np,i}),1)];
                    wa_nrem_evratenremmix{np}=[wa_nrem_evratenremmix{np} mean(imgdata.matevwa{np}(:,indpwanremmx{np,i}),1)];
                    nr_wa_evratenremmix{np}=[nr_wa_evratenremmix{np} mean(imgdata.matevwa{np}(:,indpnrwamx{np,i}),1)];
                    nr_rem_evratenremmix{np}=[nr_rem_evratenremmix{np} mean(imgdata.matevwa{np}(:,indpnrremmx{np,i}),1)];
                    r_nr_evratenremmix{np}=[r_nr_evratenremmix{np} mean(imgdata.matevwa{np}(:,indprnremmx{np,i}),1)];
                    r_wa_evratenremmix{np}=[r_wa_evratenremmix{np} mean(imgdata.matevwa{np}(:,indprwamx{np,i}),1)];
                    
                    
                end
                
                if length(imgdata.matevrem{np})>0
                    all_evraterem{np}=[all_evraterem{np} mean(imgdata.matevrem{np},1)];
                    wa_evraterem{np}=[wa_evraterem{np} mean(imgdata.matevrem{np}(:,indpwa{np,i}),1)];
                    Qwa_evraterem{np}=[Qwa_evraterem{np} mean(imgdata.matevrem{np}(:,Qwacells{np,i}),1)];%Qwa cells, rem epochs
                    Awa_evraterem{np}=[Awa_evraterem{np} mean(imgdata.matevrem{np}(:,Awacells{np,i}),1)];%Awa cells, rem epochs
                    
                    nr_evraterem{np}=[nr_evraterem{np} mean(imgdata.matevrem{np}(:,indpnr{np,i}),1)];
                    r_evraterem{np}=[r_evraterem{np} mean(imgdata.matevrem{np}(:,indpr{np,i}),1)];
                    inv_evraterem{np}=[inv_evraterem{np} mean(imgdata.matevrem{np}(:,indpinv{np,i}),1)];
                    
                    wa_rem_evrateremmix{np}=[wa_rem_evrateremmix{np} mean(imgdata.matevrem{np}(:,indpwaremmx{np,i}),1)];
                    wa_nrem_evrateremmix{np}=[wa_nrem_evrateremmix{np} mean(imgdata.matevrem{np}(:,indpwanremmx{np,i}),1)];
                    nr_wa_evrateremmix{np}=[nr_wa_evrateremmix{np} mean(imgdata.matevrem{np}(:,indpnrwamx{np,i}),1)];
                    nr_rem_evrateremmix{np}=[nr_rem_evrateremmix{np} mean(imgdata.matevrem{np}(:,indpnrremmx{np,i}),1)];
                    r_nr_evrateremmix{np}=[r_nr_evrateremmix{np} mean(imgdata.matevrem{np}(:,indprnremmx{np,i}),1)];
                    r_wa_evrateremmix{np}=[r_wa_evrateremmix{np} mean(imgdata.matevrem{np}(:,indprwamx{np,i}),1)];
                    
                end
                
                %now getting the correlation per epoch and in 0.5 s steps
                %between the four cell pops and the 4 bands for each epoch for each cell.
                %Also get the max event rate and the mean trace
                %replacing nans by 0s
                
                wacorr{np,i}=[];
                nrcorr{np,i}=[];
                rcorr{np,i}=[];
                invcorr{np,i}=[];
                scoreep2{np,i}=[];
                
                wacorr05{np,i}=[];%this will have the f rate of each epoch for wa cells in 0.5 s bins
                nrcorr05{np,i}=[];%this will have the f rate of each epoch for nr cells in 0.5 s bins
                rcorr05{np,i}=[];%this will have the f rate of each epoch for r cells in 0.5 s bins
                invcorr05{np,i}=[];%this will have the f rate of each epoch for inv cells in 0.5 s bins
                maxcorr{np,i}=[];%this will have the max f rate of each epoch from all cells
                maxcorr05{np,i}=[];%this will have the max f rate of each epoch for inv cells in 0.5 s bins
                meantrace{np,i}=[];%Mean trace from all cells in 0.5 bins
                %indexp{np,i}=[];
                
                deltacorr{np,i}=[];
                deltacorr05{np,i}=[];
                thetacorr{np,i}=[];
                thetacorr05{np,i}=[];
                lgcorr{np,i}=[];
                lgcorr05{np,i}=[];
                hgcorr{np,i}=[];
                hgcorr05{np,i}=[];
                lmatrace{np,i}=[];
            end
            %only for period 2: (Otherwize it's impossible to combine the
            %cells together, since different periods have different pools
            %of cells
            %identifying movies from period 2:
            movp2{i}=[];
            nmovsp2=0;
            for j=1:nmovs
                if imgdata.viddata(j).period==2
                    nmovsp2=nmovsp2+1;
                    movp2{i}(nmovsp2)=j;
                end
            end
            for currmv=movp2{i}
                np=imgdata.viddata(currmv).period;%this should be always 2.
                %building vectors with event rate for each cell
                wacorr{np,i}=[wacorr{np,i}; imgdata.viddata(currmv).meanevrate(:,indpwa{np,i})];%this will have the f rate of each epoch for wa cells from all periods
                nrcorr{np,i}=[nrcorr{np,i}; imgdata.viddata(currmv).meanevrate(:,indpnr{np,i})];%this will have the f rate of each epoch for nr cells
                rcorr{np,i}=[rcorr{np,i}; imgdata.viddata(currmv).meanevrate(:,indpr{np,i})];%this will have the f rate of each epoch for r cells
                invcorr{np,i}=[invcorr{np,i}; imgdata.viddata(currmv).meanevrate(:,indpinv{np,i})];%this will have the f rate of each epoch for inv cells
                scoreep2{np,i}=[scoreep2{np,i} imgdata.viddata(currmv).score];
                deltacorr{np,i}=[deltacorr{np,i} imgdata.viddata(currmv).delta];
                thetacorr{np,i}=[thetacorr{np,i} imgdata.viddata(currmv).theta];
                lgcorr{np,i}=[lgcorr{np,i} imgdata.viddata(currmv).Lgama];
                hgcorr{np,i}=[hgcorr{np,i} imgdata.viddata(currmv).Hgama];
                
                wacorr05{np,i}=[wacorr05{np,i};  imgdata.viddata(currmv).events05(:,indpwa{np,i})];%this will have the f rate of each epoch for wa cells in 0.5 s bins
                nrcorr05{np,i}=[nrcorr05{np,i}; imgdata.viddata(currmv).events05(:,indpnr{np,i})];%this will have the f rate of each epoch for nr cells in 0.5 s bins
                rcorr05{np,i}=[rcorr05{np,i}; imgdata.viddata(currmv).events05(:,indpr{np,i})];%this will have the f rate of each epoch for r cells in 0.5 s bins
                invcorr05{np,i}=[invcorr05{np,i}; imgdata.viddata(currmv).events05(:,indpinv{np,i})];%this will have the f rate of each epoch for inv cells in 0.5 s bins
                meantrace{np,i}=[meantrace{np,i} mean(imgdata.viddata(currmv).trace05,2)'];
                %To do: add LMA here
                lenlma=length(imgdata.viddata(currmv).lma);
                flma=find(imgdata.viddata(currmv).xaxisLMA>=imgdata.viddata(currmv).fixedtime(1));
                lstlma=find(imgdata.viddata(currmv).xaxisLMA<=imgdata.viddata(currmv).fixedtime(end));
                flma=max(1,flma(1)-1);
                lstlma=1+lstlma(end);
                auxlma=simpres(imgdata.viddata(currmv).lma(flma:lstlma),2)';
                auxlma=auxlma(1:length(imgdata.viddata(currmv).Hgama05(:)));%This could introduce a 1 place shift since it doesn't check if it should be cropped to the left or right.
                lmatrace{np,i}=[lmatrace{np,i} auxlma];%Cropping the LMA to match the 4 s epochs and doubling hte points so it will be at 2 Hz
                
                %building vectors with power bands for epoch and 0.5
                %bins
                deltacorr05{np,i}=[deltacorr05{np,i} imgdata.viddata(currmv).delta05(:)'];
                thetacorr05{np,i}=[thetacorr05{np,i} imgdata.viddata(currmv).theta05(:)'];
                lgcorr05{np,i}=[lgcorr05{np,i} imgdata.viddata(currmv).Lgama05(:)'];
                hgcorr05{np,i}=[hgcorr05{np,i} imgdata.viddata(currmv).Hgama05(:)'];
            end
            %Finding cells with same pref for periods 2 and 3 for each
            %animal
            aux=sort([indpnr{2,i} indpnr{3,i}]);
            indxrep=find(diff(aux)==0);
            indpnrp2and3{i}=aux(indxrep);
            
            aux=sort([indpr{2,i} indpr{3,i}]);
            indxrep=find(diff(aux)==0);
            indprp2and3{i}=aux(indxrep);
            
            aux=sort([indpwa{2,i} indpwa{3,i}]);
            indxrep=find(diff(aux)==0);
            indpwap2and3{i}=aux(indxrep);
            
            aux=sort([Awacells{2,i} Awacells{3,i}]);
            indxrep=find(diff(aux)==0);
            indpAwap2and3{i}=aux(indxrep);
            
            aux=sort([Qwacells{2,i} Qwacells{3,i}]);
            indxrep=find(diff(aux)==0);
            indpQwap2and3{i}=aux(indxrep);
            
            aux=sort([indpinv{2,i} indpinv{3,i}]);
            indxrep=find(diff(aux)==0);
            indpinvp2and3{i}=aux(indxrep);
            
            aux=sort([indpmixed{2,i} indpmixed{3,i}]);
            indxrep=find(diff(aux)==0);
            indpmixp2and3{i}=aux(indxrep);
            
            %Getting the f rate of the identified cells vs the others for
            %period 2. Need to get the position of the identified cells in
            %the wa_evratewa{2} and similar arrays.
            p0w=0;p0nr=0;p0r=0;
            
            if i>1
                for k=1:i-1
                    p0w=p0w+length(indpwa{2,k});
                    p0nr=p0nr+length(indpnr{2,k});
                    p0r=p0r+length(indpr{2,k});
                end
            end
            %           wa23nor{i}=wa_evratewa{2}(p0w+1:p0w+length(indpwa{2,i}));
            indchcwa{i}=1:length(indpwa{2,i});
            indchcnr{i}=1:length(indpnr{2,i});
            indchcr{i}=1:length(indpr{2,i});
            %if length(indpwap2and3{i})>0
            for indx=1:length(indpwap2and3{i})%finding firing rate during wa for subset of wa active cells
                pos=find(indpwap2and3{i}(indx)==indpwa{2,i});
                wa23=[wa23 wa_evratewa{2}(p0w+pos)];%Taking the element out of the mean event rate vector
                pos2=find(indpwap2and3{i}(indx)==indpwa{2,i}(indchcwa{i}));%needs a new index since the vector shrinks in every iteration
                indchcwa{i}=takeout(indchcwa{i},pos2);%take the element at pos out of the vector
            end
            %else
            wa23nor=[wa23nor wa_evratewa{2}(p0w+indchcwa{i})];
            
            for indx=1:length(indpnrp2and3{i})%finding firing rate during wa for subset of wa active cells
                pos=find(indpnrp2and3{i}(indx)==indpnr{2,i});
                nr23=[nr23 nr_evratenrem{2}(p0nr+pos)];
                pos2=find(indpnrp2and3{i}(indx)==indpnr{2,i}(indchcnr{i}));
                indchcnr{i}=takeout(indchcnr{i},pos2);
            end
            nr23nor=[nr23nor nr_evratenrem{2}(p0nr+indchcnr{i})];
            
            for indx=1:length(indprp2and3{i})%finding firing rate during wa for subset of wa active cells
                pos=find(indprp2and3{i}(indx)==indpr{2,i});
                r23=[r23 r_evraterem{2}(p0r+pos)];
                pos2=find(indprp2and3{i}(indx)==indpr{2,i}(indchcr{i}));
                indchcr{i}=takeout(indchcr{i},pos2);
            end
            r23nor=[r23nor r_evraterem{2}(p0r+indchcr{i})];
            indwai=find(scoreep{i}<0.5);%wake with artifacts for file i
            indnri=find(scoreep{i}>0.5 & scoreep{i}<1.5 );
            indri=find(scoreep{i}>1.5);
            nepsi=length(scoreep{i});
            %barpercstate=100*[[length(indwa)/neps ;length(indnr)/neps; length(indr)/neps] [length(indwai)/nepsi; length(indnri)/nepsi;length(indri)/nepsi]];
            imgdata.barpercstate=100*[[length(indwai)/nepsi ;length(indnri)/nepsi; length(indri)/nepsi] [length(indwai)/nepsi; length(indnri)/nepsi;length(indri)/nepsi]];
            perc_state_noimg(i,:)=imgdata.barpercstate(:,1);%WA, NR,R
            perc_state_img(i,:)=imgdata.barpercstate(:,2);%WA, NR,R
            bout_dur_noimg(i,:)=[mean(imgdata.boutdurwa) mean(imgdata.boutdurnr) mean(imgdata.boutdurr)];%check data consistency
            bout_dur_img(i,:)=[mean(imgdata.boutdurimgpwa) mean(imgdata.boutdurimgpnr) mean(imgdata.boutdurimgpr)];
            xfrecimg=imgdata.xfreq;
            fft_noimg_wa(i,:)=imgdata.fftwa;
            fft_noimg_nr(i,:)=imgdata.fftnr;
            fft_noimg_r(i,:)=imgdata.fftr;
            fft_img_wa(i,:)=imgdata.fftimgwa;
            fft_img_nr(i,:)=imgdata.fftimgnr;
            fft_img_r(i,:)=imgdata.fftimgr;
            %Getting overal event rate/period
            
            %To do:
            %1- Get mean Frate for all periods, for Wa, NREM, REM and inv cells.
            %2- Get percentage of cells that are in each class for each
            %period and pie plot for ZT 5-6
            %3- Get percentage of cells that preserve selectivity form
            %ZT5 to ZT11
            %4-Mean corr index per epoch
        end
        
        %Sumarizing the percentage of cells that remain stable for
        %AW,QW,INV and mix
        totAW=0;
        totQW=0;
        totmix=0;
        totinv=0;
        totAWst=0;
        totQWst=0;
        totmixst=0;
        totinvst=0;
        for i=1:length(dir_img)
            totAW=totAW+length(Awacells{2,i});
            totQW=totQW+length(Qwacells{2,i});
            totmix=totmix+length(indpmixed{2,i});
            totinv=totinv+length(indpinv{2,i});
            totAWst=totAWst+length(indpAwap2and3{i});
            totQWst=totQWst+length(indpQwap2and3{i});
            totmixst=totmixst+length(indpmixp2and3{i});
            totinvst=totinvst+length(indpinvp2and3{i});
        end
        disp('AW:')
        disp(100*totAWst/totAW)
        disp('QW:')
        disp(100*totQWst/totQW)
        disp('Mix:')
        disp(100*totmixst/totmix)
        disp('INV:')
        disp(100*totinvst/totinv)
        %end
        
        %bar plots: mean f rate per state for each ZT period, mean f rate per cell pref.
        
        figure%Comparison between ZTs
        subplot(4,4,[1 2])
        btpwa=[mean(all_evratewa{1}) mean(all_evratewa{2}) mean(all_evratewa{3})];
        etpwa=[sem(all_evratewa{1}) sem(all_evratewa{2}) sem(all_evratewa{3})];
        
        btpQwa=[mean(all_evrateQwa{1}) mean(all_evrateQwa{2}) mean(all_evrateQwa{3})];
        etpQwa=[sem(all_evrateQwa{1}) sem(all_evrateQwa{2}) sem(all_evrateQwa{3})];
        
        btpAwa=[mean(all_evrateAwa{1}) mean(all_evrateAwa{2}) mean(all_evrateAwa{3})];
        etpAwa=[sem(all_evrateAwa{1}) sem(all_evrateAwa{2}) sem(all_evrateAwa{3})];
        
        btpnr=[mean(all_evratenrem{1}) mean(all_evratenrem{2}) mean(all_evratenrem{3})];
        etpnr=[sem(all_evratenrem{1}) sem(all_evratenrem{2}) sem(all_evratenrem{3})];
        btpr=[mean(all_evraterem{1}) mean(all_evraterem{2}) mean(all_evraterem{3})];
        etpr=[sem(all_evraterem{1}) sem(all_evraterem{2}) sem(all_evraterem{3})];
        matdat=[btpAwa' btpQwa'  btpnr' btpr'];
        mate=[etpAwa' etpQwa'  etpnr' etpr'];
        barwitherr(mate,matdat);
        gbrmap=[[0 1 0];[0 0.5 0];[0 0 1];[1 0 0]];
        colormap(gbrmap);
        box off
        totncells=length(all_evratewa{3});
        title(strcat('Mean Ev. rate for all cells (N=',num2str(totncells),')'),'fontsize',21)
        set(gca,'XTickLabel',{'ZT0-1','ZT5-6','ZT11-12'},'fontsize',14)
        ylabel('Ev/s','fontsize',18)
        set(gca,'ylim',[0 0.75])
        legend('AW','QW','NREM','REM','Orientation','horizontal')
        legend boxoff
        subplot(4,4,[5 6])
        %         btpwa=[mean([wa_evratewa{1} wa_evratewa{2} wa_evratewa{3}]) mean([nr_evratewa{1} nr_evratewa{2} nr_evratewa{3}]) mean([r_evratewa{1} r_evratewa{2} r_evratewa{3}]) mean([inv_evratewa{1} inv_evratewa{2} inv_evratewa{3}])];
        %         etpwa=[sem([wa_evratewa{1} wa_evratewa{2} wa_evratewa{3}]) sem([nr_evratewa{1} nr_evratewa{2} nr_evratewa{3}]) sem([r_evratewa{1} r_evratewa{2} r_evratewa{3}]) sem([inv_evratewa{1} inv_evratewa{2} inv_evratewa{3}])];
        %         btpnr=[mean([wa_evratenrem{1} wa_evratenrem{2} wa_evratenrem{3}]) mean([nr_evratenrem{1} nr_evratenrem{2} nr_evratenrem{3}]) mean([r_evratenrem{1} r_evratenrem{2} r_evratenrem{3}]) mean([inv_evratenrem{1} inv_evratenrem{2} inv_evratenrem{3}])];
        %         etpnr=[sem([wa_evratenrem{1} wa_evratenrem{2} wa_evratenrem{3}]) sem([nr_evratenrem{1} nr_evratenrem{2} nr_evratenrem{3}]) sem([r_evratenrem{1} r_evratenrem{2} r_evratenrem{3}]) sem([inv_evratenrem{1} inv_evratenrem{2} inv_evratenrem{3}])];
        %         btpr=[mean([wa_evraterem{1} wa_evraterem{2} wa_evraterem{3}]) mean([nr_evraterem{1} nr_evraterem{2} nr_evraterem{3}]) mean([r_evraterem{1} r_evraterem{2} r_evraterem{3}]) mean([inv_evraterem{1} inv_evraterem{2} inv_evraterem{3}])];
        %         etpr=[sem([wa_evraterem{1} wa_evraterem{2} wa_evraterem{3}]) sem([nr_evraterem{1} nr_evraterem{2} nr_evraterem{3}]) sem([r_evraterem{1} r_evraterem{2} r_evraterem{3}]) sem([inv_evraterem{1} inv_evraterem{2} inv_evraterem{3}])];
        
        btpwa=[mean(wa_evratewa{2}) mean(nr_evratewa{2}) mean(r_evratewa{2}) mean(inv_evratewa{2})];
        etpwa=[sem(wa_evratewa{2}) sem(nr_evratewa{2}) sem(r_evratewa{2}) sem(inv_evratewa{2})];
        
        btpQwa=[mean(Awa_evrateQwa{2}) mean(Qwa_evrateQwa{2}) mean(nr_evrateQwa{2}) mean(r_evrateQwa{2}) mean(inv_evrateQwa{2})];
        etpQwa=[sem(Awa_evrateQwa{2}) sem(Qwa_evrateQwa{2})  sem(nr_evrateQwa{2}) sem(r_evrateQwa{2}) sem(inv_evrateQwa{2})];
        
        btpAwa=[mean(Awa_evrateAwa{2}) mean(Qwa_evrateAwa{2}) mean(nr_evrateAwa{2}) mean(r_evrateAwa{2}) mean(inv_evrateAwa{2})];
        etpAwa=[sem(Awa_evrateAwa{2}) sem(Qwa_evrateAwa{2}) sem(nr_evrateAwa{2}) sem(r_evrateAwa{2}) sem(inv_evrateAwa{2})];
        
        btpnr=[mean(Awa_evratenrem{2}) mean(Qwa_evratenrem{2}) mean(nr_evratenrem{2}) mean(r_evratenrem{2}) mean(inv_evratenrem{2})];
        etpnr=[sem(Awa_evratenrem{2}) sem(Qwa_evratenrem{2})  sem(nr_evratenrem{2}) sem(r_evratenrem{2}) sem(inv_evratenrem{2})];
        
        btpr=[mean(Awa_evraterem{2}) mean(Qwa_evraterem{2}) mean(nr_evraterem{2}) mean(r_evraterem{2}) mean(inv_evraterem{2})];
        etpr=[sem(Awa_evraterem{2}) sem(Qwa_evraterem{2}) sem(nr_evraterem{2}) sem(r_evraterem{2}) sem(inv_evraterem{2})];
        
        matdat=[ btpAwa' btpQwa' btpnr' btpr'];
        mate=[etpAwa' etpQwa' etpnr' etpr'];
        barwitherr(mate,matdat);
        gbrmap=[[0 1 0];[0.4 1 0.4];[0.5 0.5 0.5];[0 0 1];[1 1 1];[1 0 0]];
        colormap(gbrmap);
        box off
        title('St. dep. cells','fontsize',21)
        set(gca,'XTickLabel',{'AW.Pr.','QW.Pr.','NREM Pr.','REM Pr.','INV'},'fontsize',14)
        set(gca,'ylim',[0 0.75])
        ylabel('Ev/s','fontsize',18)
        subplot(4,6,13)
        %         pie([length(wa_evratewa{2}) length(inv_evratenrem{2}) length(nr_evratewa{2}) totncells-length(wa_evratewa{2})-length(nr_evratewa{2})-length(r_evratenrem{2})-length(inv_evratenrem{2}) length(r_evratenrem{2})],...
        %             {'W','INV','NREM','Other','REM'})
        pie([length(Awa_evrateAwa{2}) length(Qwa_evrateQwa{2})  length(nr_evratewa{2}) length(r_evratenrem{2}) length(inv_evratenrem{2}) totncells-length(wa_evratewa{2})-length(nr_evratewa{2})-length(r_evratenrem{2})-length(inv_evratenrem{2}) ],...
            {'AW','QW','NREM','REM','INV','Mixed'})
        disp([ length(Awa_evrateAwa{2}) length(Qwa_evrateQwa{2}) length(nr_evratewa{2}) length(r_evratenrem{2}) length(inv_evratenrem{2}) totncells-length(wa_evratewa{2})-length(nr_evratewa{2})-length(r_evratenrem{2})-length(inv_evratenrem{2}) ])
        disp(strcat('AW','QW','NREM','REM','INV','Mixed'))
        subplot(4,6,15)
        %         pie([length(wa_evratewa{2}) length(inv_evratenrem{2}) length(nr_evratewa{2}) totncells-length(wa_evratewa{2})-length(nr_evratewa{2})-length(r_evratenrem{2})-length(inv_evratenrem{2}) length(r_evratenrem{2})],...
        %             {'W','INV','NREM','Other','REM'})
        pie([ length(Awa_evrateAwa{3}) length(Qwa_evrateQwa{3}) length(nr_evratewa{3}) length(r_evratenrem{3}) length(inv_evratenrem{3}) totncells-length(wa_evratewa{3})-length(nr_evratewa{3})-length(r_evratenrem{3})-length(inv_evratenrem{3}) ],...
            {'AW3','QW3','NREM3','REM3','INV3','Mixed3'})
        disp([length(Awa_evrateAwa{3}) length(Qwa_evrateQwa{3})  length(nr_evratewa{3}) length(r_evratenrem{3}) length(inv_evratenrem{3}) totncells-length(wa_evratewa{3})-length(nr_evratewa{3})-length(r_evratenrem{3})-length(inv_evratenrem{3}) ])
        aw3=length(Awa_evrateAwa{3});
        qw3= length(Qwa_evrateQwa{3});
        nrem3= length(nr_evratewa{3});
        rem3=length(r_evratenrem{3});
        inv3=length(inv_evratenrem{3});
        mixed3=totncells-length(wa_evratewa{3})-length(nr_evratewa{3})-length(r_evratenrem{3})-length(inv_evratenrem{3});
        disp('aw3:')
        disp(100*aw3/totncells)
        disp('qw3:')
        disp(100*qw3/totncells)
        disp('nrem3:')
        disp(100*nrem3/totncells)
        disp('rem3:')
        disp(100*rem3/totncells)
        disp('inv3:')
        disp(100*inv3/totncells)
        disp('mixed3:')
        disp(100*mixed3/totncells)
        
        
        
        disp(strcat('AW','QW','NREM','REM','INV','Mixed'))
        subplot(4,6,14)
        %plotting f rate for mixed
        vtop=([length(wa_rem_evratewamix{2})  length(wa_nrem_evratewamix{2}) length(nr_wa_evratewamix{2}) length(nr_rem_evratewamix{2}) length(r_nr_evratewamix{2}) length(r_wa_evratewamix{2})]);
        vtop(find(vtop==0))=1;
        disp(vtop)
        pie(vtop,{'W-REM','W-NREM','NREM-W','NREM-REM','REM-NREM','REM-W'})
        disp('W-REM W-NREM NREM-W NREM-REM REM-NREM REM-W')
        title('Pref. for Mixed')
        
        %now pie for cells who's pref remain constant in 2 ZTs
        subplot(4,4,13)
        pie([length(wa23)  length(nr23) length(r23)],{'W','NREM','REM'})
        title('Same pref')
        
        btp=([[mean(wa23) mean(wa23nor)];[mean(nr23) mean(nr23nor)];[mean(r23) mean(r23nor)]]);
        etp=([[sem(wa23) sem(wa23nor)];[sem(nr23) sem(nr23nor)];[sem(r23) sem(r23nor)]]);
        subplot(4,4,14)
        barwitherr(etp,btp);
        set(gca,'XTickLabel',{'W','NREM','REM'},'fontsize',14)
        set(gca,'ylim',[0 0.75])
        legend('= Pref','# Pref','Orientation','horizontal')
        box off
        ylabel('Ev./s','fontsize',18)
        legend boxoff
        %Now the frecs:
        epoch
        kwa=0;knr=0;kr=0;ki=0;kwa05=0;
        np=2;%Getting the correlations only for period 2 for all animals and all cells
        for anim=1:length(dir_img)
            ncellswa=size(wacorr{np,anim},2);
            ncellsnr=size(nrcorr{np,anim},2);
            ncellsr=size(rcorr{np,anim},2);
            ncellinv=size(invcorr{np,anim},2);
            
            for nc=1:ncellswa
                kwa=kwa+1;
                [corwadl(kwa),pvalwadl(kwa)]=getcor(wacorr{np,anim}(:,nc),deltacorr{np,anim});
                [corwath(kwa),pvalwath(kwa)]=getcor(wacorr{np,anim}(:,nc),thetacorr{np,anim});
                [corwalg(kwa),pvalwalg(kwa)]=getcor(wacorr{np,anim}(:,nc),lgcorr{np,anim});
                [corwahg(kwa),pvalwahg(kwa)]=getcor(wacorr{np,anim}(:,nc),hgcorr{np,anim});
            end
            for nc=1:ncellsnr
                knr=knr+1;
                [cornrdl(knr),pvalnrdl(knr)]=getcor(nrcorr{np,anim}(:,nc),deltacorr{np,anim});
                [cornrth(knr),pvalnrth(knr)]=getcor(nrcorr{np,anim}(:,nc),thetacorr{np,anim});
                [cornrlg(knr),pvalnrlg(knr)]=getcor(nrcorr{np,anim}(:,nc),lgcorr{np,anim});
                [cornrhg(knr),pvalnrhg(knr)]=getcor(nrcorr{np,anim}(:,nc),hgcorr{np,anim});
            end
            for nc=1:ncellsr
                kr=kr+1;
                [corrdl(kr),pvalrdl(kr)]=getcor(rcorr{np,anim}(:,nc),deltacorr{np,anim});
                [corrth(kr),pvalrth(kr)]=getcor(rcorr{np,anim}(:,nc),thetacorr{np,anim});
                [corrlg(kr),pvalrlg(kr)]=getcor(rcorr{np,anim}(:,nc),lgcorr{np,anim});
                [corrhg(kr),pvalrhg(kr)]=getcor(rcorr{np,anim}(:,nc),hgcorr{np,anim});
            end
            for nc=1:ncellinv
                ki=ki+1;
                [coridl(ki),pvalidl(ki)]=getcor(invcorr{np,anim}(:,nc),deltacorr{np,anim});
                [corith(ki),pvalith(ki)]=getcor(invcorr{np,anim}(:,nc),thetacorr{np,anim});
                [corilg(ki),pvalilg(ki)]=getcor(invcorr{np,anim}(:,nc),lgcorr{np,anim});
                [corihg(ki),pvalihg(ki)]=getcor(invcorr{np,anim}(:,nc),hgcorr{np,anim});
            end
            indwa05{anim}=find(scoreep2{np,anim}==0);%epochs classified as wa
            dim1=size(scoreep2{np,anim},2);
            dim2=size(wacorr05{np,anim},1);
            ncellsw=size(wacorr05{np,anim},2);
            newm=reshape(wacorr05{np,anim},dim1,round(dim2/dim1),ncellsw);
            
            %make vectors with ev rate for all cells, max ev rate and mean
            %trace for wa cells during wa to check if there is still corr
            %with Hgamma
            waev{anim}=reshape(newm(indwa05{anim},:,:),length(indwa05{anim})*size(newm,2),ncellsw);%event rate for all WA cells during WA
            newm=reshape(hgcorr05{np,anim},dim1,round(dim2/dim1));
            wahg{anim}=reshape(newm(indwa05{anim},:),length(indwa05{anim})*size(newm,2),1);%high gamma for wa epochs
            maxev{anim}=max(waev{anim}');
            meanev{anim}=mean(waev{anim},2);
            newm=reshape(meantrace{np,anim},dim1,round(dim2/dim1));
            tracewa{anim}=reshape(newm(indwa05{anim},:),length(indwa05{anim})*size(newm,2),1);%ca traces for wa epochs in 0.5 s bins
            newm=reshape(lmatrace{np,anim},dim1,round(dim2/dim1));
            walma{anim}=reshape(newm(indwa05{anim},:),length(indwa05{anim})*size(newm,2),1);%high gamma for wa epochs
            
            
            %substracting the means:
            allwahg=[allwahg (wahg{anim}-mean(wahg{anim}))'];
            allmaxev=[allmaxev maxev{anim}-mean(maxev{anim})];
            alltracewa=[alltracewa (tracewa{anim}-mean(tracewa{anim}))'];
            
            %this is to copare the corrcoef with the shift in one place to
            %the left or right
            [correltr{anim},pvalctr{anim}]=getcor(tracewa{anim},wahg{anim});
            [correltrshl{anim},pvalctrshl{anim}]=getcor(tracewa{anim}(2:end),wahg{anim}(1:end-1));
            [correltrshr{anim},pvalctrshr{anim}]=getcor(tracewa{anim}(1:end-1),wahg{anim}(2:end));
            
            %Now getting the coef for every cell, for every animal
            for nc=1:ncellswa
                kwa05=kwa05+1;
                ind=find(waev{anim}(:,nc)>0);
                [corwahg05(kwa),pvalwahg05(kwa)]=getcor(waev{anim}(ind,nc),wahg{anim}(ind));
            end
            %There is no correlation since the events are almost binary and
            %variable while the gama is continous
        end
        
        %bar plot of the average corrcoef for each cell
        subplot(4,4,3)
        btp=[mean(corwadl) mean(corwath) mean(corwalg) mean(corwahg)];
        etp=[sem(corwadl) sem(corwath) sem(corwalg) sem(corwahg)];
        barwitherr(etp,btp);
        set(gca,'XTickLabel',{''},'fontsize',14)
        title(strcat('W N=',num2str(length(corwadl))),'fontsize',18)
        minmax=get(gca,'ylim');
        box off
        
        subplot(4,4,7)
        btp=[mean(cornrdl) mean(cornrth) mean(cornrlg) mean(cornrhg)];
        etp=[sem(cornrdl) sem(cornrth) sem(cornrlg) sem(cornrhg)];
        barwitherr(etp,btp);
        set(gca,'XTickLabel',{''},'fontsize',14)
        title(strcat('NREM N=',num2str(length(cornrdl))),'fontsize',18)
        box off
        set(gca,'ylim',minmax)
        
        subplot(4,4,11)
        btp=[mean(corrdl) mean(corrth) mean(corrlg) mean(corrhg)];
        etp=[sem(corrdl) sem(corrth) sem(corrlg) sem(corrhg)];
        barwitherr(etp,btp);
        set(gca,'XTickLabel',{''},'fontsize',14)
        title(strcat('REM N=',num2str(length(corrdl))),'fontsize',18)
        box off
        set(gca,'ylim',minmax)
        
        subplot(4,4,15)
        btp=[mean(coridl) mean(corith) mean(corilg) mean(corihg)];
        etp=[sem(coridl) sem(corith) sem(corilg) sem(corihg)];
        barwitherr(etp,btp);
        set(gca,'XTickLabel',{'d','q/d','Lg','Hg'},'fontsize',14)
        title(strcat('INV N=',num2str(length(coridl))),'fontsize',18)
        box off
        set(gca,'ylim',minmax)
        
        %bar plot of the  % of cells that have p-val<0.05
        subplot(4,4,4)
        btp=100*[length(find(pvalwadl<0.05))/length(pvalwadl) length(find(pvalwath<0.05))/length(pvalwadl) length(find(pvalwalg<0.05))/length(pvalwadl) length(find(pvalwahg<0.05))/length(pvalwadl)];
        bar(btp)
        set(gca,'XTickLabel',{''},'fontsize',14)
        title('% W','fontsize',18)
        box off
        set(gca,'ylim',[0 100])
        
        subplot(4,4,8)
        btp=100*[length(find(pvalnrdl<0.05))/length(pvalnrdl) length(find(pvalnrth<0.05))/length(pvalnrdl) length(find(pvalnrlg<0.05))/length(pvalnrdl) length(find(pvalnrhg<0.05))/length(pvalnrdl)];
        bar(btp)
        set(gca,'XTickLabel',{''},'fontsize',14)
        title('% NREM','fontsize',18)
        box off
        set(gca,'ylim',[0 100])
        
        subplot(4,4,12)
        btp=100*[length(find(pvalrdl<0.05))/length(pvalrdl) length(find(pvalrth<0.05))/length(pvalrdl) length(find(pvalrlg<0.05))/length(pvalrdl) length(find(pvalrhg<0.05))/length(pvalrdl)];
        bar(btp)
        set(gca,'XTickLabel',{''},'fontsize',14)
        title('% REM','fontsize',18)
        box off
        set(gca,'ylim',[0 100])
        
        subplot(4,4,16)
        btp=100*[length(find(pvalidl<0.05))/length(pvalidl) length(find(pvalith<0.05))/length(pvalidl) length(find(pvalilg<0.05))/length(pvalidl) length(find(pvalihg<0.05))/length(pvalidl)];
        bar(btp)
        set(gca,'XTickLabel',{''},'fontsize',14)
        title('% INV','fontsize',18)
        box off
        set(gca,'ylim',[0 100])
        set(gca,'XTickLabel',{'d','q/d','Lg','Hg'},'fontsize',14)
        
        %Now correltaion between Hgamma and W cells during W
        %         waev{anim}=;%event rate for all cells
        %         wahg{anim}=%high gamma for wa epochs
        %         maxev{anim}
        %         tracewa{anim}
        
        %to do: plot ev rate of cell with highes corrcoef for 4s epochs
        %plot max ev. rate
        %plot mean trace
        %finding max:
        pastcells=0;
        i=1;
        [v,p]=max(corwadl);%we want to find the cells in position p of the global index
        while(pastcells+size(waev{i},2))<p
            pastcells=pastcells+size(waev{i},2);
            i=i+1;
        end
        locat=p-pastcells;
        
        figure;
        subplot(6,1,1)
        %single cell
        xsc=0.5*(0:size(waev{i},1)-1);
        plot(xsc,waev{i}(:,locat),'k')
        box off
        title('Single Cell Events','fontsize',18)
        subplot(6,1,2)
        %mean evr for all cells
        plot(xsc,meanev{i},'k')
        box off
        title('Mean Ev. rate','fontsize',18)
        
        subplot(6,1,3)
        %max evr for all cells
        plot(xsc,maxev{i},'k')
        box off
        title('Max Ev. rate','fontsize',18)
        
        subplot(6,1,4)
        %mean ca traces
        plot(xsc,tracewa{i},'k')
        box off
        title('Mean Ca Trace','fontsize',18)
        
        subplot(6,1,5)
        %gamma
        plot(xsc,wahg{i},'k')
        box off
        title('High Gamma','fontsize',18)
        
        subplot(6,1,6)
        %gamma
        plot(xsc,walma{i},'k')
        box off
        title('LMA','fontsize',18)
        
        
        
        figure
        plot(alltracewa,allwahg,'o')
        figure;
        [v,p]=corrcoef(alltracewa,allwahg);
        plot(corwahg05)
        title('Correlation for all cells')
        
        
        
        %%%%%%%
        %saving variables for the population
        all_evratewap1=all_evratewa{1};all_evratewap2=all_evratewa{2};all_evratewap3=all_evratewa{3};
        all_evrateQwap1=all_evrateQwa{1};all_evrateQwap2=all_evrateQwa{2};all_evrateQwap3=all_evrateQwa{3};
        all_evrateAwap1=all_evrateAwa{1};all_evrateAwap2=all_evrateAwa{2};all_evrateAwap3=all_evrateAwa{3};
        all_evratenremp1=all_evratenrem{1};all_evratenremp2=all_evratenrem{2};all_evratenremp3=all_evratenrem{3};
        all_evrateremp1=all_evraterem{1};all_evrateremp2=all_evraterem{2};all_evrateremp3=all_evraterem{3};
        
        Qwa_evrateQwap1=Qwa_evrateQwa{1};Awa_evrateQwap1=Awa_evrateQwa{1};nr_evrateQwap1=nr_evrateQwa{1};r_evrateQwap1=r_evrateQwa{1};inv_evrateQwap1=inv_evrateQwa{1};
        Qwa_evrateAwap1=Qwa_evrateAwa{1};Awa_evrateAwap1=Awa_evrateAwa{1};,nr_evrateAwap1=nr_evrateAwa{1}; r_evrateAwap1=r_evrateAwa{1};inv_evrateAwap1=inv_evrateAwa{1};
        Qwa_evratenremp1=Qwa_evratenrem{1}; Awa_evratenremp1=Awa_evratenrem{1};nr_evratenremp1=nr_evratenrem{1};r_evratenremp1=r_evratenrem{1}; inv_evratenremp1=inv_evratenrem{1};
        Qwa_evrateremp1=Qwa_evraterem{1};Awa_evrateremp1=Awa_evraterem{1}; nr_evrateremp1=nr_evraterem{1};r_evrateremp1=r_evraterem{1};inv_evrateremp1=inv_evraterem{1};
        
        Qwa_evrateQwap2=Qwa_evrateQwa{2};Awa_evrateQwap2=Awa_evrateQwa{2};nr_evrateQwap2=nr_evrateQwa{2};r_evrateQwap2=r_evrateQwa{2};inv_evrateQwap2=inv_evrateQwa{2};
        Qwa_evrateAwap2=Qwa_evrateAwa{2};Awa_evrateAwap2=Awa_evrateAwa{2};,nr_evrateAwap2=nr_evrateAwa{2}; r_evrateAwap2=r_evrateAwa{2};inv_evrateAwap2=inv_evrateAwa{2};
        Qwa_evratenremp2=Qwa_evratenrem{2}; Awa_evratenremp2=Awa_evratenrem{2};nr_evratenremp2=nr_evratenrem{2};r_evratenremp2=r_evratenrem{2}; inv_evratenremp2=inv_evratenrem{2};
        Qwa_evrateremp2=Qwa_evraterem{2};Awa_evrateremp2=Awa_evraterem{2}; nr_evrateremp2=nr_evraterem{2};r_evrateremp2=r_evraterem{2};inv_evrateremp2=inv_evraterem{2};
        
        Qwa_evrateQwap3=Qwa_evrateQwa{3};Awa_evrateQwap3=Awa_evrateQwa{3};nr_evrateQwap3=nr_evrateQwa{3};r_evrateQwap3=r_evrateQwa{3};inv_evrateQwap3=inv_evrateQwa{3};
        Qwa_evrateAwap3=Qwa_evrateAwa{3};Awa_evrateAwap3=Awa_evrateAwa{3};,nr_evrateAwap3=nr_evrateAwa{3}; r_evrateAwap3=r_evrateAwa{3};inv_evrateAwap3=inv_evrateAwa{3};
        Qwa_evratenremp3=Qwa_evratenrem{3}; Awa_evratenremp3=Awa_evratenrem{3};nr_evratenremp3=nr_evratenrem{3};r_evratenremp3=r_evratenrem{3}; inv_evratenremp3=inv_evratenrem{3};
        Qwa_evrateremp3=Qwa_evraterem{3};Awa_evrateremp3=Awa_evraterem{3}; nr_evrateremp3=nr_evraterem{3};r_evrateremp3=r_evraterem{3};inv_evrateremp3=inv_evraterem{3};
        
        lmix= totncells - length(wa_evratewa{2}) - length(nr_evratewa{2}) - length(r_evratenrem{2}) - length(inv_evratenrem{2});
        lwa=length(wa_evratewa{2});
        lnr=length(nr_evratewa{2});
        lr=length(r_evratenrem{2});
        linv=length(inv_evratenrem{2});
        
        lwamix=length(wa_evratewamix{2})  ;
        lnrmix=length(nr_evratewamix{2}) ;
        lrmix=length(r_evratenremmix{2});
        %now pie for cells who's pref remain constant in 2 ZTs
        %pie([length(wa23)  length(nr23) length(r23)],{'W','NREM','REM'})
        
        save('popdata.mat','all_evratewap1','all_evratewap2','all_evratewap3','all_evrateQwap1','all_evrateQwap2','all_evrateQwap3','all_evrateAwap1','all_evrateAwap2','all_evrateAwap3','all_evratenremp1','all_evratenremp2','all_evratenremp3',...
            'all_evrateremp1','all_evrateremp2','all_evrateremp3','Qwa_evrateQwap2','Awa_evrateQwap2','nr_evrateQwap2','r_evrateQwap2','inv_evrateQwap2',...
            'Qwa_evrateAwap2','Awa_evrateAwap2','nr_evrateAwap2','r_evrateAwap2','inv_evrateAwap2','Qwa_evratenremp2','Awa_evratenremp2','nr_evratenremp2','r_evratenremp2','inv_evratenremp2',...
            'Qwa_evrateremp2','Awa_evrateremp2', 'nr_evrateremp2','r_evrateremp2','inv_evrateremp2','lmix','lwa','lnr','lr','linv','lwamix','lnrmix','lrmix','wa23','nr23','r23','wa23nor','nr23nor','r23nor',...
            'Qwa_evrateAwap3','Awa_evrateAwap3','nr_evrateAwap3','r_evrateAwap3','inv_evrateAwap3','Qwa_evratenremp3','Awa_evratenremp3','nr_evratenremp3','r_evratenremp3','inv_evratenremp3',...
            'Qwa_evrateremp3','Awa_evrateremp3', 'nr_evrateremp3','r_evrateremp3','inv_evrateremp3','Qwa_evrateAwap1','Awa_evrateAwap1','nr_evrateAwap1','r_evrateAwap1','inv_evrateAwap1','Qwa_evratenremp1','Awa_evratenremp1','nr_evratenremp1','r_evratenremp1','inv_evratenremp1',...
            'Qwa_evrateremp1','Awa_evrateremp1', 'nr_evrateremp1','r_evrateremp1','inv_evrateremp1');
        
        
        %reading sham data:
        disp('Reading sham folder...')
        cd(path_sham);
        dir_sham=dir ('*.mat');
        for i=1:length(dir_sham)
            shamdata=load(dir_sham(i).name);
            perc_state_sham(i,:)=[shamdata.pwa shamdata.pnr shamdata.pr];%WA, NR,R. 100 is to fix a bug in the code while saving (fixed)
            bout_dur_sham(i,:)=[shamdata.mboutwa shamdata.mboutnr shamdata.mboutr];
            xfrecsham=shamdata.freq;
            fft_sham_wa(i,:)=mean(shamdata.matpowerWA);
            fft_sham_nr(i,:)=mean(shamdata.matpowerNR);
            fft_sham_r(i,:)=mean(shamdata.matpowerREM);
        end
        
        
        %This is the code used to plot a single case.
        figure
        subplot (2,6,1:3)
        %percentages
        meanperc=[mean(perc_state_noimg,1)' mean(perc_state_img,1)' mean(perc_state_sham,1)'];%matrix
        sempercnoim=[sem(perc_state_noimg(:,1)) sem(perc_state_noimg(:,2)) sem(perc_state_noimg(:,3))];%vector cause SEM only takes vectors
        sempercim=[sem(perc_state_img(:,1)) sem(perc_state_img(:,2)) sem(perc_state_img(:,3))];
        sempercsham=[sem(perc_state_sham(:,1)) sem(perc_state_sham(:,2)) sem(perc_state_sham(:,3))];
        er=[sempercnoim' sempercim' sempercsham'];
        barwitherr(er,meanperc);
        set(gca,'fontsize',14)
        %set(gca,'XTick',[1.5 4.5 7.5])
        set(gca,'xticklabel',{'WA','NR','REM'})
        title('% Time','fontsize',18)
        box off
        set(gca,'TickLength',[0 0])
        legend({'No Img','Img','Sham'})
        colormap('hot')
        %bout duration
        subplot (2,6,[4:6])
        meanbdur=[mean(bout_dur_noimg,1)' mean(bout_dur_img,1)' mean(bout_dur_sham,1)'];%matrix
        sembdurnoim=[sem(bout_dur_noimg(:,1)) sem(bout_dur_noimg(:,2)) sem(bout_dur_noimg(:,3))];%vector cause SEM only takes vectors
        sembdurim=[sem(bout_dur_img(:,1)) sem(bout_dur_img(:,2)) sem(bout_dur_img(:,3))];
        sembdursham=[sem(bout_dur_sham(:,1)) sem(bout_dur_sham(:,2)) sem(bout_dur_sham(:,3))];
        er=[sembdurnoim' sembdurim' sembdursham'];
        barwitherr(er,meanbdur);
        set(gca,'fontsize',14)
        set(gca,'xticklabel',{'WA','NR','REM'})
        title('Mean Bout Duration (s)','fontsize',21)
        box off
        set(gca,'TickLength',[0 0])
        legend({'No Img','Img','Sham'})
        
        %ffts
        
        [v,ind20]=min(abs(xfrecimg-20));%position of 20 Hz freq
        meanfftwa_noimg=mean(fft_noimg_wa(:,1:ind20),1);
        semfftwa_noimg=sem(fft_noimg_wa(:,1:ind20));
        meanfftwa_img=mean(fft_img_wa(:,1:ind20),1);
        semfftwa_img=sem(fft_img_wa(:,1:ind20));
        meanfftwa_sham=mean(fft_sham_wa(:,1:ind20),1);
        semfftwa_sham=sem(fft_sham_wa(:,1:ind20));
        
        meanfftnr_noimg=mean(fft_noimg_nr(:,1:ind20),1);
        semfftnr_noimg=sem(fft_noimg_nr(:,1:ind20));
        meanfftnr_img=mean(fft_img_nr(:,1:ind20),1);
        semfftnr_img=sem(fft_img_nr(:,1:ind20));
        meanfftnr_sham=mean(fft_sham_nr(:,1:ind20),1);
        semfftnr_sham=sem(fft_sham_nr(:,1:ind20));
        
        meanfftr_noimg=mean(fft_noimg_r(:,1:ind20),1);
        semfftr_noimg=sem(fft_noimg_r(:,1:ind20));
        meanfftr_img=mean(fft_img_r(:,1:ind20),1);
        semfftr_img=sem(fft_img_r(:,1:ind20));
        meanfftr_sham=mean(fft_sham_r(:,1:ind20),1);
        semfftr_sham=sem(fft_sham_r(:,1:ind20));
        
        x=xfrecimg(1:ind20);
        for npl=1:3
            subplot(2,6,[2*(3+npl)-1 2*(3+npl)])
            X=[x,fliplr(x)];                %create continuous x value array for plotting
            switch npl
                case 1
                    prom1=meanfftwa_noimg;
                    prom2=meanfftwa_img;
                    prom3=meanfftwa_sham;
                    einf1=prom1-semfftwa_noimg;
                    einf2=prom2-semfftwa_img;
                    einf3=prom3-semfftwa_sham;
                    emax1=prom1+semfftwa_noimg;
                    emax2=prom2+semfftwa_img;
                    emax3=prom3+semfftwa_sham;
                    colshade=[0.85 1 0.85];
                    cline='g';
                    tit='WA'
                case 2
                    prom1=meanfftnr_noimg;
                    prom2=meanfftnr_img;
                    prom3=meanfftnr_sham;
                    einf1=prom1-semfftnr_noimg;
                    einf2=prom2-semfftnr_img;
                    einf3=prom3-semfftnr_sham;
                    emax1=prom1+semfftnr_noimg;
                    emax2=prom2+semfftnr_img;
                    emax3=prom3+semfftnr_sham;
                    colshade=[0.85 0.85 1];
                    cline='b';
                    tit='NREM'
                case 3
                    prom1=meanfftr_noimg;
                    prom2=meanfftr_img;
                    prom3=meanfftr_sham;
                    einf1=prom1-semfftr_noimg;
                    einf2=prom2-semfftr_img;
                    einf3=prom3-semfftr_sham;
                    emax1=prom1+semfftr_noimg;
                    emax2=prom2+semfftr_img;
                    emax3=prom3+semfftr_sham;
                    colshade=[1 0.85 0.85];
                    cline='r';
                    tit='REM'
            end
            Y=[einf1,fliplr(emax1)];              %create y values for out and then back
            fill(X,Y,colshade,'EdgeColor','none');                  %plot filled area
            hold on
            Y=[einf2,fliplr(emax2)];
            fill(X,Y,colshade,'EdgeColor','none');
            Y=[einf3,fliplr(emax3)];              %create y values for out and then back
            fill(X,Y,colshade,'EdgeColor','none');
            p1=plot(x,prom1,strcat(cline,'--'),'linewidth',2)
            p2=plot(x,prom2,strcat(cline,'o-'),'linewidth',2)
            p3=plot(x,prom3,strcat(cline,'.-'),'linewidth',2)
            legend([p1,p2,p3],'No Img','Img','Sham')
            xlabel('Hz','fontsize',21)
            box off
            ylabel('Power (\muV^2)','fontsize',21)
            title(tit)
        end
        
    case 4
        cd ('D:\pop\slper_all')
        pth=pwd;
        path_arch = uigetdir(pth,'Select directory with Imaging data');
        cd(path_arch);
        
        %reading imaginf data:
        dir_img=dir ('*.mat');
        S = [dir_img(:).datenum].'; % you may want to eliminate . and .. first.
        [S,S] = sort(S);
        dir_img = {dir_img(S).name}
        disp('Reading sleep arch folder...')
        for i=1:length(dir_img)
            exsarch=load(dir_img{i});
            disp(dir_img{i})
            %reading bout duration of every period, evey state
            boutnr(i)=exsarch.mboutnr;
            boutr(i)=exsarch.mboutr;
            boutwa(i)=exsarch.mboutwa;
            %reading percentage in state of every period, evey state
            prcnr(i)=exsarch.pnr;
            prcr(i)=exsarch.pr;
            prcwa(i)=exsarch.pwa;
        end
        %         indeximg=[1 3 5; 6 8 10; 11 13 15; 16 18 20];
        %         indexnoimg=[2 4;7 9;12 14;17 19];
        indeximg=[3; 8; 13 ;18];
        indexnoimg=[2 4;7 9;12 14;17 19];
        n=size(indeximg,1);
        for i=1:n
            matboutnrim(i)=mean(boutnr(indeximg(i,:)));
            matboutnrnoim(i)=mean(boutnr(indexnoimg(i,:)));
            matboutrim(i)=mean(boutr(indeximg(i,:)));
            matboutrnoim(i)=mean(boutr(indexnoimg(i,:)));
            matboutwaim(i)=mean(boutwa(indeximg(i,:)));
            matboutwanoim(i)=mean(boutwa(indexnoimg(i,:)));
            
            matpnrim(i)=mean(prcnr(indeximg(i,:)));
            matpnrnoim(i)=mean(prcnr(indexnoimg(i,:)));
            matprim(i)=mean(prcr(indeximg(i,:)));
            matprnoim(i)=mean(prcr(indexnoimg(i,:)));
            matpwaim(i)=mean(prcwa(indeximg(i,:)));
            matpwanoim(i)=mean(prcwa(indexnoimg(i,:)));
        end
        
        
        save('sleeparchimg.mat','matboutnrim','matboutrim','matboutwaim','matpnrim','matprim','matpwaim')
        save('sleeparchnoimg.mat','matboutnrnoim','matboutrnoim','matboutwanoim','matpnrnoim','matprnoim','matpwanoim')
        disp('Data saved')
        
    case 5
        sr=508.6227;
        winlen=round(4*sr);
        %Quantifies DREADD EEG/EMG
        cd ('D:\tmp\TetO_DREADD\matfiles')
        dir_dread=dir ('*.mat');
        S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
        [S,S] = sort(S);
        dir_dread = {dir_dread(S).name} ;
        disp('Reading DREADD data...')
        mseidlist={'mse1G1','mse2G1','mse3G1','mse2G2','mse3G2','mse4G2'};
        msedruglist={'VEH','ALM'};
        mseactlist={'Sal','Cno'}  ;
        figure
        for i=1:length(dir_dread)
            meet=load(dir_dread{i});
            %getting the start and end point to analyze
            startfile=str2num(meet.finf.starttime(1:2))+str2num(meet.finf.starttime(4:5))/60;
            skip=(meet.timedose-1)-startfile;%skip the first part of the data until 1 h before dosing (time in h)
            pointdose=round((meet.timecno-startfile)*3600*sr);
            t0=round(skip*3600*sr);
            datarangepred=t0:t0+round(3600*sr)-1;
            datarangepreact=t0+round(3600*sr)-1+round(10*60*sr):pointdose;
            datarangepostact=pointdose+round(10*60*sr):round(2*3600*sr)+pointdose+round(10*60*sr);%2 after CNO
            fnam=dir_dread{i};
            mseid=fnam(1:6);
            drug=fnam(8:10);
            activator=fnam(12:14);
            newind=reshape(datarangepostact(1:winlen*floor(length(datarangepostact)/winlen)),winlen,floor(length(datarangepostact)/winlen));
            
            
            [truefalse, idval] = ismember(mseid, mseidlist);
            [truefalse, index1] = ismember(drug,msedruglist);
            [truefalse, index2] = ismember(activator,mseactlist);
            condition=(1+(index1-1)*2)+index2-1;%[veh-sal,veh-cno,alm-sal,alm-cno]=[1 2 3 4]
            titlec={'VEH-SAL','VEH-CNO','ALM-SAL','ALM-CNO'};
            indsp=(idval-1)*4+condition;
            %plotting all EEGs postact
            subplot(6,4,indsp)
            for i=1:floor(length(datarangepostact)/winlen);%making 4s epochs for delta power
                delta(i)=getpband(meet.eegdata(2,newind(:,i)),4,0.5,4);
            end
            v=sort(delta);
            normval=v(round(0.8*length(delta)));
            delta=delta/normval;
            xv=((1:length(delta))-1)*4/60;
            plot(xv,delta,'k-')
            set(gca,'ylim',[0 2])
            if indsp<5
                title(titlec{condition})
            end
            if indsp>20
                xlabel('Min')
            end
            if condition==1
                ylabel('Delta Power')
            end
            sumdelta(idval,condition)=sum(delta);
        end
        figure
        bar(mean(sumdelta));
        
    case 6
        nveh=0;
        nalm=0;
        col='bgrk';
        for i=1:length(handles.chosen)
            char(handles.dnames{handles.chosen(i)})
            load(char(handles.dnames{handles.chosen(i)}))
            if length(findstr('veh',char(handles.dnames{handles.chosen(i)})))>0
                nveh=nveh+1;
                pwveh(nveh)=pwa;
                powveh(nveh,:)=mean(matpowerWA);
            else
                nalm=nalm+1;
                pwalm(nalm)=pwa;
                powalm(nalm,:)=mean(matpowerWA);
            end
        end
        figure
        for i=1:4
            plot(1,pwveh(i),strcat('d',col(i)),'markersize',9)
            hold on
            plot(2,pwalm(i),strcat('d',col(i)),'markersize',9)
            plot([1 2],[pwveh(i) pwalm(i)],strcat(col(i),'-'))
        end
        set(gca,'xlim',[0.5 2.5])
        plot(1,mean(pwveh),'k*')
        %plot(2*ones(1,4),pwalm,'d')
        plot(2,mean(pwalm),'k*')
        set(gca,'xtick',[0 1 2 3])
        set(gca,'xticklabel',{'','Veh','Alm',''})
        set(gca,'fontsize',16)
        ylabel('% WA','fontsize',16)
        box off
        set(gca,'ylim',[0 100])
        %now plotting bars
        figure
        err=[sem(pwveh) sem(pwalm)];
        errorbar([mean(pwveh) mean(pwalm)],err,'k.');
        hold on
        bar([mean(pwveh) mean(pwalm)])
        ylabel('% WA','fontsize',16)
        set(gca,'xtick',[0 1 2 3])
        set(gca,'xticklabel',{'','Veh','Alm',''})
        box off
        set(gca,'fontsize',16)
        save('pwveh.mat','pwveh')
        save('pwalm.mat','pwalm')
    case 7
        %read mat files for a double drug study
        cd ('D:\tetODREADD\mat_files')
        pth=pwd;
        path_arch = uigetdir(pth,'Select directory with four subfolders with mat files');
        cd(path_arch);
        dirnames={'alm_cno','alm_sal','veh_cno','veh_sal'};
        for i=1:length(dirnames)
            %reading  data:
            cd (char(dirnames{i}))
            dir_img=dir ('*.mat');
            S = [dir_img(:).datenum].'; % you may want to eliminate . and .. first.
            [S,S] = sort(S);
            dir_img = {dir_img(S).name};
            for nmatf=1:length(dir_img)
                aux=load(dir_img{nmatf});
                dimpt=size(aux.pt);
                dimpwa=size(aux.pwa);
                dimpnr=size(aux.pnr);
                dimpr=size(aux.pr);
                cond{i}.pt(nmatf,:,:)=aux.pt;
                if max(dimpwa)>81%subsampling power from 10 s epochs
                    cond{i}.pnr(nmatf,:,:)=aux.pnr(:,round(1:2.4815:201));
                    cond{i}.pr(nmatf,:,:)=aux.pr(:,round(1:2.4815:201));
                    cond{i}.pwa(nmatf,:,:)=aux.pwa(:,round(1:2.4815:201));
                else
                    cond{i}.pnr(nmatf,:,:)=aux.pnr;
                    cond{i}.pr(nmatf,:,:)=aux.pr;
                    cond{i}.pwa(nmatf,:,:)=aux.pwa;
                end
                %normalizing power to pre dose NREM
                nf=max(cond{i}.pnr(nmatf,1,:));
                for k=1:7
                    cond{i}.pr(nmatf,k,:)=cond{i}.pr(nmatf,k,:)/nf;
                    cond{i}.pwa(nmatf,k,:)=cond{i}.pwa(nmatf,k,:)/nf;
                    cond{i}.pnr(nmatf,k,:)=cond{i}.pnr(nmatf,k,:)/nf;
                end
                matprwa(i,nmatf,:)=cond{i}.pt(nmatf,:,1);
                pwa(i,nmatf,:,:)=cond{i}.pwa(nmatf,:,:);
                disp(dir_img{nmatf})
                disp(cond{i}.pt(nmatf,:,1))
            end
            
            %building a matrix with percentage of W for all animals, all
            %conditions
            % meantp=fixdim(mean(matprwa,2));
            
            %             barwitherr(semtp,meantp)
            %             hold on
            %             %bar(meantp)
            %             set(gca,'xlim',[0.65 7.35])
            %             nm=[0 1 0;0 0 1;1 0 0];
            %             set(gca,'xticklabel',{'ZT3','ZT4','ZT5','ZT6','ZT7','ZT8','ZT9'})
            %             colormap(nm)
            %             ylabel('% Time','fontsize',19)
            %
            %             box off
            %             set(gca, 'Ticklength', [0 0])
            %             set(gca,'fontsize',16)
            %             legend('W','NREM','REM')
            %             legend('boxoff')
            %             title(char(dirnames{i}),'fontsize',21)
            %             pnr=fixdim(mean(cond{i}.pnr));
            %             pr=fixdim(mean(cond{i}.pr));
            %             pwa=fixdim(mean(cond{i}.pwa));
            %             maxp=max([max(max(pnr)),max(max(pwa))]);
            %
            f=(0:80)/4;
            %             for i=1:7
            %                 subplot(3,7,[7+i 14+i])
            %                 %plot([8 8],[0 maxp],'--','color',[0.8 0.8 0.8])
            %                 hold on
            %                 plot(f,pwa(i,:),'g-','linewidth',2)
            %                 plot(f,pnr(i,:),'b-','linewidth',2)
            %                 %plot(f,pr(i,:),'r-','linewidth',2)
            %                 set(gca,'ylim',[0 maxp])
            %                 set(gca,'xlim',[0 20])
            %                 if i==1
            %                     ylabel('Norm. Power Spectrum','fontsize',19)
            %                 end
            %                 xlabel('Hz','fontsize',19)
            %                 set(gca,'fontsize',16)
            %                 box off
            %                 set(gca,'XMinorTick','on')
            %             end
            cd(path_arch);
        end
        
        %plotting only %W for all conditions
        %building a matrix with percentage of W for all animals, all
        %conditions
        meantp=fixdim(mean(matprwa,2));
        for condi=1:length(dirnames)
            for j=1:7
                semtp(j,condi,:)=sem(fixdim(matprwa(condi,:,j)));
            end
            
        end
        
        %ploting two exmples and then the average.
        figure
        barwitherr(semtp,meantp');
        hold on
        %bar(meantp)
        %set(gca,'xlim',[0.65 7.35])
        %nm=[0 1 0;0 0 1;1 0 0];
        set(gca,'xticklabel',{'ZT3','ZT4','ZT5','ZT6','ZT7','ZT8','ZT9'})
        ylabel('% W','fontsize',21)
        set(gca,'fontsize',18)
        box off
        set(gca, 'Ticklength', [0 0])
        legend({'Alm-Cno','Alm-Sal','Veh-Cno','Veh-Sal'});
        legend('boxoff')
        nm=[0 1 0;0 0 1;0 0 0;1 1 1];
        colormap(nm)
        
        v2p=[3 8];
        %v2p=[2 4];
        for q=1:2
            n2plot=v2p(q);
            figure
            
            bar(fixdim(matprwa(:,n2plot,:))')
            hold on
            %bar(meantp)
            %set(gca,'xlim',[0.65 7.35])
            %nm=[0 1 0;0 0 1;1 0 0];
            set(gca,'xticklabel',{'ZT3','ZT4','ZT5','ZT6','ZT7','ZT8','ZT9'})
            ylabel('% W','fontsize',21)
            set(gca,'fontsize',18)
            box off
            set(gca, 'Ticklength', [0 0])
            legend({'Alm-Cno','Alm-Sal','Veh-Cno','Veh-Sal'});
            legend('boxoff')
            nm=[0 1 0;0 0 1;0 0 0;1 1 1];
            colormap(nm)
            title(char(dir_img{v2p(q)}))
            
            figure%now ploting the power during Wa
            colorm=jet;
            for sp=1:4
                subplot(2,2,sp)
                pwa(i,nmatf,:,:)
                plot(f,fixdim(pwa(sp,v2p(q),:,:)),'linewidth',1.5)
                %                 plot(f,pnr(i,:),'b-','linewidth',2)
                %                 %plot(f,pr(i,:),'r-','linewidth',2)
                %                 set(gca,'ylim',[0 maxp])
                %                 set(gca,'xlim',[0 20])
                %                 if i==1
                ylabel('Norm. Power Spectrum','fontsize',19)
                %                 end
                xlabel('Hz','fontsize',19)
                set(gca,'fontsize',18)
                box off
                set(gca,'XMinorTick','on')
                if sp==2
                    legend({'ZT3','ZT4','ZT5','ZT6','ZT7','ZT8','ZT9'})
                end
                set(gca,'ylim',[0 0.5])
                title(char(dirnames{sp}))
            end
        end
        %                     figure;
        %             subplot(3,7,1:7)
        %             meantp=fixdim(mean(cond{i}.pt));
        %             semtp=fixdim(sem(cond{i}.pt));
        %             barwitherr(semtp,meantp)
        %             hold on
        %             %bar(meantp)
        %             set(gca,'xlim',[0.65 7.35])
        %
        %             set(gca,'xticklabel',{'ZT3','ZT4','ZT5','ZT6','ZT7','ZT8','ZT9'})
        %             colormap(nm)
        %             ylabel('% Time','fontsize',19)
        %
        %             box off
        %             set(gca, 'Ticklength', [0 0])
        %
        %             legend('W','NREM','REM')
        %
        %             title(char(dirnames{i}),'fontsize',21)
    case 8
        %New TetO-Dreadd plots from mat files
        %1- plot distribution of %W for 3d hour after veh-CNO. Establish effect
        %and no-effect groups
        %2- plot mean %W for 4 conditions for each group
        %3- Find mean FFT for each group for the channel with high teta and low
        %tetha.
        %         sr=508.6227;
        %         winlen=round(4*sr);
        %Quantifies DREADD EEG/EMG
        pth='F:\data2016\hcrt_dreadd\matfiles';
        path_of = uigetdir(pth,'Pick a folder with the mat files');
        cd(path_of);
        %plotting dist of ve-cno and establishing groups
        cd('veh_sal')
        dir_dread=dir ('*.mat')
        S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
        [S,S] = sort(S);
        dir_dread = {dir_dread(S).name} ;
        for i=1:length(dir_dread)
            meet=load(dir_dread{i});
            ptwa3(i)=meet.pt(5,1);
        end
        
        figure;
        subplot(2,1,1)
        hist(ptwa3)
        set(gca,'xlim',[0 100])
        set(gca,'ylim',[0 8])
        set(gca,'fontsize',14)
        title('Distribution for Veh-Sal')
        xlabel('% W')
        ylabel('N')
        cd(path_of);
        dirname={'Veh_CNO','Veh_Sal','Alm_CNO','Alm_Sal'};
        condname={'Veh-CNO','Veh-Sal','Alm-CNO','Alm-Sal'};
        xl={'ZT3-4','ZT4-5(V/A)','ZT5-6 (S/C)','ZT6-7','ZT7-8','ZT8-9','ZT9-10'};
        %plotting dist of ve-cno and establishing groups
        cd('Veh_CNO')
        dir_dread=dir ('*.mat');
        S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
        [S,S] = sort(S);
        dir_dread = {dir_dread(S).name} ;
        for i=1:length(dir_dread)
            meet=load(dir_dread{i});
            ptwa3(i)=meet.pt(5,1);
        end
        subplot(2,1,2)
        hist(ptwa3)
        set(gca,'xlim',[0 100])
        set(gca,'ylim',[0 8])
        set(gca,'fontsize',14)
        title('Distribution for Veh-CNO')
        xlabel('% W')
        ylabel('N')
        cd('..')
        indnoef=find(ptwa3<50);
        indef=find(ptwa3>50);
        %Now loading data for all conditions
        for cnd=1:4
            cd(char(dirname{cnd}))
            dir_dread=dir ('*.mat');
            S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
            [S,S] = sort(S);
            dir_dread = {dir_dread(S).name} ;
            for i=1:length(dir_dread)
                load(dir_dread{i});
                if length(f)==201
                    indf=round(1:2.4815:201);
                else
                    indf=1:81;
                    fok=f;
                end
                cond(cnd).bd(i,:,:)=bd;
                cond(cnd).pt(i,:,:)=pt;
                %selecting the channel with more energy during REM
                if max(max(pr1'))>max(max(pr2'))
                    cond(cnd).pwa(i,:,:)=pwa1(:,indf);
                    cond(cnd).pnr(i,:,:)=pnr1(:,indf);;
                    cond(cnd).pr(i,:,:)=pr1(:,indf);;
                else
                    cond(cnd).pwa(i,:,:)=pwa2(:,indf);;
                    cond(cnd).pnr(i,:,:)=pnr2(:,indf);;
                    cond(cnd).pr(i,:,:)=pr2(:,indf);;
                end
            end
            
            cd('..')
        end
        %PLOTTING:
        col=(['k','g','b','r'])
        figure
        % %W for effect and no effect, 4 condition/plot
        subplot(2,1,1)
        for q=1:4
            %plotting effect
            vtp=mean(cond(q).pt(indef,:,1));
            err=sem(cond(q).pt(indef,:,1));
            errorbar(vtp,err,'k.');
            hold on
            o(q)=plot(vtp,strcat(col(q),'.-'),'linewidth',2);
        end
        legend(o,condname)
        set(gca,'xlim',[1 7])
        set(gca,'xticklabel',{'ZT3-4','ZT4-5(V/A)','ZT5-6 (S/C)','ZT6-7','ZT7-8','ZT8-9','ZT9-10'})
        ylabel('% W','fontsize',16)
        title(strcat('Strong Effect (N=',num2str(length(indef)),')'),'fontsize',20)
        box off
        set(gca,'fontsize',14)
        set(gca,'ylim',[0 100])
        subplot(2,1,2)
        for q=1:4
            %plotting effect
            vtp=mean(cond(q).pt(indnoef,:,1));
            err=sem(cond(q).pt(indnoef,:,1));
            errorbar(vtp,err,'k.');
            hold on
            o(q)=plot(vtp,strcat(col(q),'.-'),'linewidth',2);
        end
        title(strcat('Weak Effect (N=',num2str(length(indnoef)),')'),'fontsize',20)
        legend(o,condname)
        set(gca,'xlim',[1 7])
        set(gca,'xticklabel',xl)
        ylabel('% W','fontsize',16)
        box off
        set(gca,'ylim',[0 100])
        set(gca,'fontsize',14)
        %Now the power
        %plotting meanpower under every condition for every state, for every hour
        figure
        for i=1:7
            
            for q=1:4
                subplot(3,7,i)
                %plotting power for each condition for effect
                o(q)=plot(fok,fixdim(mean(cond(q).pwa(indef,i,:))),strcat(col(q),'-'),'linewidth',2);
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 700])
                hold on
                if i==1
                    ylabel('Power during W (uV^2)','fontsize',16)
                end
                title(char(xl{i}))
                subplot(3,7,7+i)
                plot(fok,fixdim(mean(cond(q).pnr(indef,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 700])
                hold on
                if i==1
                    ylabel('Power for NREM (uV^2)','fontsize',16)
                end
                subplot(3,7,14+i)
                plot(fok,fixdim(mean(cond(q).pr(indef,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 700])
                xlabel('Hz')
                hold on
                if i==1
                    ylabel('Power for REM (uV^2)','fontsize',16)
                end
            end
            legend(o,condname)
        end
        figure
        for i=1:7
            
            for q=1:4
                subplot(3,7,i)
                %plotting power for each condition for effect
                o(q)=plot(fok,fixdim(mean(cond(q).pwa(indnoef,i,:))),strcat(col(q),'-'),'linewidth',2);
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 600])
                hold on
                if i==1
                    ylabel('Power during W','fontsize',16)
                end
                subplot(3,7,7+i)
                plot(fok,fixdim(mean(cond(q).pnr(indnoef,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 1200])
                hold on
                if i==1
                    ylabel('Power for NREM','fontsize',16)
                end
                subplot(3,7,14+i)
                plot(fok,fixdim(mean(cond(q).pr(indnoef,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 1000])
                xlabel(char(xl{i}))
                hold on
                if i==1
                    ylabel('Power for REM','fontsize',16)
                end
            end
            legend(o,condname)
        end
        
        
        
    case 10
        
        %New TetO-Dreadd plots from mat files
        %1- plot distribution of %W for 3d hour after veh-CNO. Establish effect
        %and no-effect groups
        %2- plot mean %W for 4 conditions for each group
        %3- Find mean FFT for each group for the channel with high teta and low
        %tetha.
        sr=813.8042;
        %Quantifies DREADD EEG/EMG
        pth='F:\data2017\gad_creR26_DREADD\alm_effect\';
        path_of = uigetdir(pth,'Pick a folder with the mat files');
        cd(path_of);
        dirname={'veh','alm'};
        condname={'Veh','Alm'};
        
        %Now loading data for all conditions
        for cnd=1:2
            cd(char(dirname{cnd}))
            dir_dread=dir ('*.mat');
            S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
            [S,S] = sort(S);
            dir_dread = {dir_dread(S).name} ;
            for i=1:length(dir_dread)
                load(dir_dread{i});
                if length(f)==201
                    indf=round(1:2.4815:201);
                else
                    indf=1:81;
                    fok=f;
                end
                
                cond(cnd).bd(i,:,:)=bd;
                cond(cnd).pt(i,:,:)=pt;
                %selecting the channel with more energy during REM
                if max(max(pr1'))>max(max(pr2'))
                    cond(cnd).pwa(i,:,:)=pwa1;
                    cond(cnd).pnr(i,:,:)=pnr1;
                    cond(cnd).pr(i,:,:)=pr1;
                else
                    cond(cnd).pwa(i,:,:)=pwa2;
                    cond(cnd).pnr(i,:,:)=pnr2;
                    cond(cnd).pr(i,:,:)=pr2;
                end
            end
            
            cd('..')
        end
        %PLOTTING:
        col=(['k','r','b','g'])
        figure
        % %W
        mesg={'% W','% NREM','% REM'};
        mesg2={'BD W (s)','BD NREM (s)','BD REM (s)'};
        
        for npltpt=1:3
            subplot(2,3,npltpt)
            for q=1:2
                %plotting %W
                for zth=1:12
                    vtp(zth)=mean(cond(q).pt(find(~isnan(cond(q).pt(:,zth,npltpt))),zth,npltpt));
                    err(zth)=sem(cond(q).pt(find(~isnan(cond(q).pt(:,zth,npltpt))),zth,npltpt));
                    [h,pvalpt(zth,npltpt)]=ttest2(cond(1).pt(find(~isnan(cond(1).pt(:,zth,npltpt))),zth,npltpt),cond(2).pt(find(~isnan(cond(2).pt(:,zth,npltpt))),zth,npltpt));
                end
                errorbar(vtp,err,'k.','linewidth',1);
                hold on
                o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2);
            end
            set(gca,'fontsize',14)
            %set(gca,'ylim',[0 100])
            set(gca,'Xtick',[0.5:1:11.5])
            xl2=char(num2str((12:23)'));
            set(gca,'Xticklabel',xl2)
            xlabel('ZT','fontsize',18)
            set(gca,'xlim',[0.5 12])
            if npltpt==3
                legend(o,condname)
            end
            xl={'ZT12-13','ZT13-14','ZT14-15','ZT15-16','ZT16-17','ZT17-18','ZT18-19','ZT19-20','ZT20-21','ZT21-22','ZT22-23','ZT23-24'};
            ylabel(char(mesg{npltpt}),'fontsize',18)
            %title(strcat('Sleep Arch (N=',num2str(size(pwa1,1)),')'),'fontsize',20)
            box off
            set(gca,'ylim',[0 100])
            minmax=get(gca,'ylim');
            pvsig=nan(size(pvalpt(:,npltpt)));
            pvsig(find(pvalpt(:,npltpt)<0.05))=1;
            plot(1:12,pvsig*minmax(2),'k*')
            
            
            subplot(2,3,3+npltpt)
            for q=1:2
                %plotting BDW
                for zth=1:12
                    vtp(zth)=mean(cond(q).bd(find(~isnan(cond(q).bd(:,zth,npltpt))),zth,npltpt));
                    err(zth)=sem(cond(q).bd(find(~isnan(cond(q).bd(:,zth,npltpt))),zth,npltpt));
                    [h,pvalbd(zth,npltpt)]=ttest2(cond(1).bd(find(~isnan(cond(1).bd(:,zth,npltpt))),zth,npltpt),cond(2).bd(find(~isnan(cond(2).bd(:,zth,npltpt))),zth,npltpt));
                end
                errorbar(vtp,err,'k.','linewidth',1);
                hold on
                o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2);
            end
            %legend(o,condname)
            
            ylabel(char(mesg2{npltpt}),'fontsize',18)
            % title(strcat('Sleep Arch (N=',num2str(size(pwa1,2)),')'),'fontsize',20)
            box off
            set(gca,'fontsize',14)
            axis tight;%set(gca,'ylim',[0 100])
            minmax=get(gca,'ylim');
            pvsig=nan(size(pvalbd(:,npltpt)));
            pvsig(find(pvalbd(:,npltpt)<0.05))=1;
            plot(1:12,pvsig*minmax(2),'k*')
            set(gca,'Xtick',[0.5:1:11.5])
            xl2=char(num2str((12:23)'));
            set(gca,'Xticklabel',xl2)
            xlabel('ZT','fontsize',18)
            set(gca,'xlim',[0.5 12])
        end
        
        %Now the power
        %plotting meanpower under every condition for every state, for every hour
        xl={'ZT12-13','ZT13-14','ZT14-15','ZT15-16','ZT16-17','ZT17-18','ZT18-19','ZT19-20','ZT20-21','ZT21-22','ZT22-23','ZT23-24'};
        figure
        for i=1:12
            
            for q=1:2
                subplot(3,12,i)
                %plotting power for each condition for effect
                o(q)=plot(fok,fixdim(mean(cond(q).pwa(:,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 600])
                hold on
                if i==1
                    ylabel('Power for W','fontsize',16)
                end
                subplot(3,12,12+i)
                plot(fok,fixdim(mean(cond(q).pnr(:,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 1200])
                hold on
                if i==1
                    ylabel('Power for NREM','fontsize',16)
                end
                subplot(3,12,24+i)
                plot(fok,fixdim(mean(cond(q).pr(:,i,:))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 1000])
                xlabel(char(xl{i}))
                hold on
                if i==1
                    ylabel('Power for REM','fontsize',16)
                end
            end
            legend(o,condname)
        end
        
        
        
        
        
    case 11
        %the good one
        clearvars
        close all
        %generic sleep arch pop for different conditions (BD, %time and mean
        %power for each state per hour)
        epochl=4;%asuming 4s epochs
        %defining parameters for histogram of percentage time wake
        nbins=7;
        fhwbd=input('Hour # to start collecting WBD ?');
        pth='F:\data2017\';
        path_of = uigetdir(pth,'Pick a folder with the different conditions');
        cd(path_of);
        dir_conds=dir;
        %             S = [dir_conds(:).datenum].'; % you may want to eliminate . and .. first.
        %             [S,S] = sort(S);
        dir_conds = {dir_conds(3:end).name};
        nconds=length(dir_conds);
        for i=1:nconds
            allbdw{i}=[];
            spfcond{i}=[];
        end
        
        for cnd=1:nconds
            %aux=cellstr(dir_conds{2+i})
            %allspeeds{cnd}=[];
            aux=dir_conds{cnd};
            nameconds{cnd}=aux;
            %cellstr(aux);
            %Now loading data for all conditions
            
            cd(nameconds{cnd})
            dir_dread=dir ('*.mat');
            S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
            [S,S] = sort(S);
        dir_dread = {dir_dread(S).name} ;
        [y,indx]=natsort(dir_dread);
        dir_dread=dir_dread(indx)
            
           
            figure
            allbd{cnd}=[];%initiallize array with all BDs
            cond(cnd).perc=zeros(nbins+1,length(dir_dread));%percentage of total W time for each bin for each condition for each animal
            for i=1:length(dir_dread)
                clear('zt0time');
                load(dir_dread{i});
                h0=time2h(strattime);
                if ~exist('zt0time')
                    if h0>19.5
                        zt0time='08:00:00';
                    else
                        zt0time='07:00:00';
                    end
                    ZTfirsth='12'
                    ZTdosing='12'
                end
                    
                    feptime=[num2str(str2num(zt0time(1:2))+str2num(ZTfirsth)) zt0time(3:end)];
                
                    
                
                firstepoch=round(3600*(time2h(feptime)-time2h(strattime))/epochl);%First epoch used for analysis. The recording strarted before, so it needs to be skipped.
                scrok=scr(max(1,firstepoch):end);%skipping the epochs not included in analysis
                epochs2skip=firstepoch+round(3600*fhwbd/epochl);
                nh2an=size(bd,1)-fhwbd+1;
                disp(['analyzing ',num2str(nh2an),' hours'])
                %nh2an=5;
                if exist('bdata')%analysis for behaviour from video
                    t0behav=3600*(time2h(char(bdata.t0))-h0);%first second of behav.
                    %finding the next point where an epoch begins
                    if t0behav<0
                        fepb=1;
                        discardb=-t0behav;
                    else
                        fepb=ceil(t0behav/epochl);
                        discardb=fepb*epochl-t0behav;%seconds to dicard at the begining of the behav matrix to match the begining of an epoch
                    end
                    
                    
                    %lastsecb=bdata.mat(end,1)+t0behav;
                    [v,posdiscard]=min(find(bdata.mat(:,1)>discardb));
                    
                    indw=find(scr==0);
                    nepsb=floor((bdata.mat(end,1)-discardb)/epochl);
                    bdata.mat(:,1)=bdata.mat(:,1)+t0behav;
                    matpos=bdata.mat(posdiscard:end,:);
                    
                    %filtering positions to get the speed every 10 samples
                    pm=[medfilt1(matpos(:,3),10),medfilt1(matpos(:,4),10)];
                    ff=ones(10,1)/10;
                    pm=[conv(pm(:,1),ff,'same'),conv(pm(:,2),ff,'same')];
                    %timep=[matpos(1,1);matpos(10:10:end,1)];
                    timep=matpos(:,1);
                    %posevr10=[pm(1,:);pm(10:10:end,:)];
                    %distance0=sqrt(posevr10(:,1).^2+posevr10(:,2).^2);
                    distance0=sqrt(pm(:,1).^2+pm(:,2).^2);
                    distance0=abs(distance0-distance0(1,1));
                    speed=abs(diff(distance0))./diff(timep);
                    speed=[speed(1); speed];
                    %assuming semi continous recording of the behavior
                    %making epochs for behavior:
                    %                     peakpow9conc=[peakpow9{1} peakpow9{2} peakpow9{3}];%first 3 h of peakpow during W
                    %                     %allpeakpow9conc=[peakpow9{1} peakpow9{2} peakpow9{3} peakpow9{4} peakpow9{5} peakpow9{6} peakpow9{7} peakpow9{8} peakpow9{9} peakpow9{11} peakpow9{12}]
                    %                     if fepb>1
                    %                         powskip=length(find(scr(1:fepb)==0));%epochs of W before the video started and after the begining of the first period
                    %                     else
                    %                         powskip=0;
                    %                     end
                    %                     peakpow9conc=peakpow9conc(1+powskip:end);
                    %                     indpp9=find(scr(fepb:fepb+nepsb-1)==0);%W epochs during the behavior
                    %                     peakpow9conc=peakpow9conc(1:length(indpp9));
                    tepb=nan(1,nepsb);
                    xtep=0:epochl:epochl*nepsb;
                    xtep=xtep(1:nepsb);
                    figure
                    for nep=1:nepsb
                        %
                        x0=min(find((timep)>=((nep-1)*epochl)));%First value within the epoch
                        v1=timep(x0);
                        xf=max(find((timep)<=((nep)*epochl)));%last value within the epoch
                        if length(xf)==0
                            [v,xf]=min(timep);
                        end
                        v2=timep(xf);
                        if v2-v1<1
                            %disp(['No nearby time point for',num2str(nep),' assigning nan'])
                            speedepb_mean(nep)=nan;%speedepb_mean(nep-1);
                            speedepb_max(nep)=nan;%speedepb_max(nep-1);
                            speedepb_min(nep)=nan;
                        else
                            speedepb_mean(nep)=mean(speed(x0:xf));
                            speedepb_max(nep)=max(speed(x0:xf));
                            speedepb_min(nep)=min(speed(x0:xf));
                            tepb(nep)=v1;
                        end
                    end
                    indw=find(scr(1:nepsb)==0);%W without artifact
                    indwwa=find(scr(1:nepsb)<1);%just W
                    spw=speedepb_mean(indw);
                    spw1=speedepb_max(indwwa);
                    spw2=speedepb_mean(indwwa);
                    spw3=speedepb_min(indwwa);
                    p9w=p9(indw);
                    spwok=spw(find(~isnan(spw)));
                    spwok1=spw1(find(~isnan(spw1)));
                    spwok2=spw2(find(~isnan(spw1)));
                    spwok3=spw3(find(~isnan(spw1)));
                    p9wok=p9w(find(~isnan(spw)));
                    plot(spwok,p9wok,'ko')
                    minmax=get(gca,'xlim');
                    minmay=get(gca,'ylim');
                    set(gca,'fontsize',14)
                    xlabel('Speed (cm/s)','fontsize',20)
                    ylabel('H t (mV^2)','fontsize',20)
                    box off
                    % mini=min(minmax(2),minmay(2));
                    % plot([0 min],[0 min],'g--')
                    [v,p]=corrcoef([p9wok,spwok']);
                    title(['Corr:',num2str(v(2,1)),' P-val:',num2str(p(2,1)),' mse#',num2str(i),' ',nameconds{cnd}])
                    cond(cnd).corr(i)=v(2,1);%correlation betwen p9 and speed
                    cond(cnd).pvalcorr(i)=-log10(p(2,1));%p value
                    cond(cnd).meanspd(i)=mean(spwok);
                    cond(cnd).meanspdmax(i)=mean(spwok1);
                    cond(cnd).meanspdmean(i)=mean(spwok2);
                    cond(cnd).meanspdmin(i)=mean(spwok3);
                    %allspeeds{cnd}=[allspeeds{cnd} spwok2];
                    cond(cnd).meanp9(i)=mean(p9wok);
                    spfcond{cnd}=[spfcond{cnd} spwok2];
                    %                     auxi=speedepb_mean(indpp9);
                    %                     indnan=~isnan(auxi);
                    
                    %plot(auxi(indnan),peakpow9conc(indnan),'o')
                    figure
                    plot(p9wok*2000,'r-')
                    hold on
                    plot(spwok,'k-')
                    legend({'Ht','Speed'})
                    %                      plot(speedepb_mean,'r-')
                    %                      hold on
                    %                      plot(scr(fepb:fepb+nepsb-1))
                    %                      plot(200*p9(fepb:fepb+nepsb-1),'k')
                    %                     subplot(3,1,1);
                    %                     plot(scr(1:2000))
                    %                     title('score')
                    %                     subplot(3,1,2)
                    %                     plot(zeros(1,2000))
                    %                     hold on
                    %                     plot(indpp9,speedepb_mean(indpp9),'.-')
                    %                     title('speed of W epochs')
                    %                     subplot(3,1,3)
                    %                     plot(zeros(1,2000))
                    %                     hold on
                    %                     plot(indpp9,peakpow9conc,'.-')
                    %                     title('Pow9')
                    
                    %hold on
                    %mm=max(max(speedepb_max(indpp9)),
                    
                    %                     subplot(3,1,3)
                    %                     plot
                     [n,x]=hist(spwok2,10000);
                nbins=9;%log2(ceil(max(x)));
                total=sum(n.*x);%total # epochs
%                 indbin0=find(x<=1);
%                 if length(indbin0)>0
%                     cond(cnd).spperc(1,i)=100*sum(n(indbin0).*x(indbin0))/total;
%                 end
                nbin=0;
                for k=0:2:14
                    nbin=nbin+1;
                    %indbin=find(x>(2^(k-1)) & x<=(2^k));
                    if k==14
                        indbin=find(x>k);
                    else
                        indbin=find(x>k & x<=k+2);
                    end
                    
                    if length(indbin)>0
                        cond(cnd).spperc(nbin,i)=100*sum(n(indbin).*x(indbin))/total;
                    else
                        cond(cnd).spperc(nbin,i)=0;
                    end
                end
            
            
                    
                end
                
                
                bdwa=getboutok(scr(epochs2skip:min(length(scr),epochs2skip+round(nh2an*3600/epochl))),0);%looking for W bouts  for nh2an hours
                %bdwa=getboutok(scr(epochs2skip:end));
                bdwa=bdwa(find(bdwa>3))*epochl/60;%in minutes
                allbdw{cnd}=[allbdw{cnd} bdwa];
                indf=1:81;
                fok=f;
                fdelta0=1+max(find(fok<0.5));
                fdeltaf=min(find(fok>4));
                ftet0=1+max(find(fok<8));
                ftetf=min(find(fok>10));%change back to 10
                
                [n,x]=hist(bdwa,10000);
                total=sum(n.*x);%total time in wake
                indbin0=find(x<=1);
                if length(indbin0)>0
                    cond(cnd).perc(1,i)=100*sum(n(indbin0).*x(indbin0))/total;
                end
                for k=1:nbins
                    indbin=find(x>(2^(k-1)) & x<=(2^k));
                    if length(indbin)>0
                        cond(cnd).perc(k+1,i)=100*sum(n(indbin).*x(indbin))/total;
                    end
                end
                ind0=find(bd==0);
                bd(ind0)=NaN;
                cond(cnd).bd(i,:,:)=bd*epochl/60;%in minutes;
                cond(cnd).pt(i,:,:)=pt;
                %selecting the channel with more energy during REM
                if exist('sel') %if the parameter sel was saved, use htat channel. OTherwise choose the max power during REM
                    if sel==1
                        cond(cnd).pwa(i,:,:)=pwa1*0.0025;
                        cond(cnd).pnr(i,:,:)=pnr1*0.0025;
                        cond(cnd).pr(i,:,:)=pr1*0.0025;
                    else
                        cond(cnd).pwa(i,:,:)=pwa2*0.0025;
                        cond(cnd).pnr(i,:,:)=pnr2*0.0025;
                        cond(cnd).pr(i,:,:)=pr2*0.0025;
                    end
                    
                else
                    if max(max(pr1'))>max(max(pr2'))
                        cond(cnd).pwa(i,:,:)=pwa1*0.0025;
                        cond(cnd).pnr(i,:,:)=pnr1*0.0025;
                        cond(cnd).pr(i,:,:)=pr1*0.0025;
                    else
                        cond(cnd).pwa(i,:,:)=pwa2*0.0025;
                        cond(cnd).pnr(i,:,:)=pnr2*0.0025;
                        cond(cnd).pr(i,:,:)=pr2*0.0025;
                    end
                end
                %replacing 0's by NaNs
                indnan=find(cond(cnd).pwa==0);
                cond(cnd).pwa(indnan)=nan;
                
                indnan=find(cond(cnd).pnr==0);
                cond(cnd).pnr(indnan)=nan;
                
                indnan=find(cond(cnd).pr==0);
                cond(cnd).pr(indnan)=nan;
                
                %storing high teta and SWA
                cond(cnd).nrd(i,:)=nanmean(cond(cnd).pnr(i,:,fdelta0:fdeltaf),3);%delta power during NREM
                cond(cnd).htw(i,:)=nanmean(cond(cnd).pwa(i,:,ftet0:ftetf),3);%High teta during wake
                
                %                 plot (max(max(pr1')),max(max(pr2')),'o')
                %                 xlabel('max PR1');
                %                 ylabel('max PR2')
                %                 plot([0 max(max(max(pr1')),max(max(pr2')))],[0 max(max(max(pr1')),max(max(pr2')))],'g--')
                %                 hold on
                
               
            
            
            end
            title(['cond:' num2str(cnd)])
            cd('..')
            

        end
        
        %hist WBD W
        
        
        %figure;
        q=0;
        disp('Wbout durs')
        for np=1:nconds
            length(allbdw{np})
            subplot(1,nconds,np)
            %hist(allbdw{np},100)
            %title(nameconds{np})
            for k=1:nconds
                if k~=np
                    q=q+1;
                    if nconds>2
                        f=nconds;
                    else
                        f=1;
                    end
                    [h,p(q)]=kstest2(allbdw{np},allbdw{k});
                    p(q)=p(q)*f;
                    if (p(q))<0.05
                        disp([nameconds{np} '<>' nameconds{k} ' ' num2str(p(q))])
                    end
                    
                end
            end
        end
       
        %PLOTTING:
        
        %ploting histogram speeds
       
  if nconds>2
            col=(['b','g','m','k','c','r','y']);
            mark=(['^','v','>','<','.','*']);
        else
            col=(['r','k']);
            mark=(['^','v']);
        end       
        
        
        
        %plotting p val and corrcoef
       
        if exist('bdata')
            q=0; 
            p=[];
            for np=1:nconds
            length(spfcond{np} )
            disp('Speed dist')
            for k=1:nconds
                if k~=np
                    q=q+1;
                    if nconds>2
                        f=nconds;
                    else
                        f=1;
                    end
                    [h,p(q)]=kstest2(spfcond{np},spfcond{k});
                    if (p(q)*f)<0.05
                        disp([nameconds{np} '<>' nameconds{k} num2str(p(q))])
                    end
                    
                end
            end
        end
          disp(p)
          
            figure
%         subplot(1,2,1)
%         hist(allspeeds{1},20)
%         title(char(nameconds{1}))
%         subplot(1,2,2)
%         hist(allspeeds{2},20)
%         title(char(nameconds{2}))
        for q=1:nconds
            for zth=1:nbin
                vtp(zth)=mean(cond(q).spperc(zth,:))';
                err(zth)=sem(cond(q).spperc(zth,:)');
                                if q==1
                                    [h,newpvalbd(zth)]=ttest2(cond(1).spperc(zth,:)',cond(2).spperc(zth,:)');
                                end
            end
            errorbar(0:2:14,vtp,err,'k.','linewidth',1);
            hold on
            o(q)=plot(0:2:14,vtp,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
        end
        box off
        set(gca,'xlim',[-0.5 16])
        xt=get(gca,'xticklabel')
        set(gca,'xlim',[-1 15])
        set(gca,'xtick',-1:2:15)
        set(gca,'xticklabel',xt)
        set(gca,'fontsize',14)
        xlabel('speed (cm/s)','fontsize',21)
        ylabel('% of Time','fontsize',21)
        set(gca,'ylim',[0 75])
        
            figure
            for q=1:nconds
                meancorr(q)=mean(cond(q).corr);%correlation betwen p9 and speed
                [h,pvcorr]=ttest2(cond(1).corr,cond(2).corr);
                meanpval(q)=mean(cond(q).pvalcorr);%p value
                [h,pvpv]=ttest2(cond(1).pvalcorr,cond(2).pvalcorr);
                meanspd(q)=mean(cond(q).meanspd);
                [h,pvspd]=ttest2(cond(1).meanspd,cond(2).meanspd);
                meanp9(q)=mean(cond(q).meanp9);
                [h,pvp9]=ttest2(cond(1).meanp9,cond(2).meanp9);
                semcorr(q)=sem(cond(q).corr);%correlation betwen p9 and speed
                sempval(q)=sem(cond(q).pvalcorr);%p value
                semspd(q)=sem(cond(q).meanspd);
                semp9(q)=sem(cond(q).meanp9);
                
                %speed vals for all W epochs including art
                meanspdmax(q)=mean(cond(q).meanspdmax);
                semspdmax(q)=sem(cond(q).meanspdmax);
                [h,pvspdmax]=ttest2(cond(1).meanspdmax,cond(2).meanspdmax);
                
                meanspdmean(q)=mean(cond(q).meanspdmean);
                semspdmean(q)=sem(cond(q).meanspdmean);
                [h,pvspdmean]=ttest2(cond(1).meanspdmean,cond(2).meanspdmean);
                
                meanspdmin(q)=mean(cond(q).meanspdmin);
                semspdmin(q)=sem(cond(q).meanspdmin);
                [h,pvspdmin]=ttest2(cond(1).meanspdmin,cond(2).meanspdmin);
            end
            %plotting speeds
                        subplot(1,3,1)
                        errorbar(meanspdmax,semspdmax,'k.');
                        hold on
                        bar(meanspdmax)
                        title(['Speed max. P-val:',num2str(pvspdmax)])
                        set(gca,'xtick',[1 2])
                        set(gca,'xticklabel',{'CNO','SAL'})
                        set(gca,'fontsize',14)
                        box off
            
            %subplot(1,3,2)
            errorbar(meanspdmean,semspdmean,'k.');
            hold on
            bar(meanspdmean)
            title('Speed mean:') %num2str(mean(. P-val:',num2str(pvspdmean)])
            set(gca,'xtick',[1 2])
            set(gca,'xticklabel',{'CNO','SAL'})
            set(gca,'fontsize',14)
            box off
%             
                        subplot(1,3,3)
                        errorbar(meanspdmin,semspdmin,'k.');
                        hold on
                        bar(meanspdmin)
                        title(['Speed min. P-val:',num2str(pvspdmin)])
                        set(gca,'xtick',[1 2])
                        set(gca,'xticklabel',{'CNO','SAL'})
                        set(gca,'fontsize',14)
                        box off
            
            figure
            subplot(2,4,3)
            errorbar(fliplr(meancorr),fliplr(semcorr),'k.');
            set(gca,'fontsize',18)
            hold on
            bar(fliplr(meancorr))
            set(gca,'xtick',[1 2])
            set(gca,'xticklabel',{'SAL','CNO'},'fontsize',20)
            minmax=get(gca,'ylim');
            if pvcorr<0.05
                plot([1.5 1.5],[minmax(2) minmax(2)],'k*')
            end
            ylabel('Mean Corr. Coef.','fontsize',20)
            box off
            axis tight
            
            subplot(2,4,4)
            errorbar(fliplr(meanpval),fliplr(sempval),'k.');
            set(gca,'fontsize',18)
            hold on
            bar(fliplr(meanpval))
            set(gca,'xtick',[1 2])
            set(gca,'xticklabel',{'SAL','CNO'})
            axis tight
            minmax=get(gca,'ylim');
            if pvpv<0.05
                plot([1.5 1.5],[minmax(2) minmax(2)],'k*')
            end
            ylabel('- logP','fontsize',20)
            box off
                        
            subplot(2,4,1)
            errorbar(fliplr(meanspdmean),fliplr(semspdmean),'k.');
            hold on
            bar(fliplr(meanspdmean))
            %title(['Speed mean. P-val:',num2str(pvspdmean)])
            set(gca,'xtick',[1 2])
            set(gca,'xticklabel',{'SAL','CNO'},'fontsize',20)
            set(gca,'fontsize',18)
            box off
            axis tight
            minmax=get(gca,'ylim');
            if pvspdmean<0.05
                plot([1.5 1.5],[minmax(2) minmax(2)],'k*')
            end             
%             errorbar(meanspd,semspd,'k.');
%             hold on
%             bar(meanspd)
%             set(gca,'xtick',[1 2])
%             set(gca,'xticklabel',{'CNO','SAL'})
%             minmax=get(gca,'ylim')
%             if pvspd<0.05
%                 plot([1.5 minmax(2)],'k*')
%             end
            ylabel('Speed (cm/s)','fontsize',20)
            subplot(2,4,2)
            errorbar(fliplr(meanp9),fliplr(semp9),'k.');
            set(gca,'fontsize',14)
            hold on
            bar(fliplr(meanp9))
            set(gca,'xtick',[1 2])
            set(gca,'xticklabel',{'SAL','CNO'},'fontsize',20)
            minmax=get(gca,'ylim');
            if pvp9<0.05
                plot([1.5 1.5],[minmax(2) minmax(2)],'k*')
            end
            ylabel('Ht (mV^2)','fontsize',20)
            box off

            subplot(2,4,5)
            %
            plot(cond(1).corr,cond(2).corr,'ko')
            hold on
            plot([0 max([cond(2).corr cond(1).corr])],[0 max([cond(2).corr cond(1).corr])],'g--')
            
            xlabel(['Corr. Coef. ' nameconds{1}],'fontsize',20)
            ylabel(['Corr. Coef. ' nameconds{2}],'fontsize',20)
            box off
            axis tight
            
            subplot(2,4,6)
            plot(cond(1).pvalcorr,cond(2).pvalcorr,'ko')
            hold on
            plot([0 max([cond(2).pvalcorr cond(1).pvalcorr])],[0 max([cond(2).pvalcorr cond(1).pvalcorr])],'g--')
            xlabel(['P-val C.C. ' nameconds{1}],'fontsize',20)
            ylabel(['P-val C.C. ' nameconds{2}],'fontsize',20)
            box off
            axis tight
            
            subplot(2,4,7)
            cond(1).meanspdmean
            plot(cond(1).meanspdmean,cond(2).meanspdmean,'ko')
            hold on
            plot([0 max([cond(2).meanspdmean cond(1).meanspdmean])],[0 max([cond(2).meanspdmean cond(1).meanspdmean])],'g--')
            xlabel(['Speed ' nameconds{1} '(cm/s)'],'fontsize',20)
            ylabel(['Speed ' nameconds{2} '(cm/s)'],'fontsize',20)
            box off
            axis tight
            %             errorbar(meanspd,semspd,'k.');
            %             hold on
            %             bar(meanspd)
            %             set(gca,'xtick',[1 2])
            %             set(gca,'xticklabel',{'CNO','SAL'})
            %             minmax=get(gca,'ylim')
            %             if pvspd<0.05
            %                 plot([1.5 minmax(2)],'k*')
            %             end
            %             ylabel('Speed (cm/s)','fontsize',20)
            
            subplot(2,4,8)
            plot(cond(1).meanp9,cond(2).meanp9,'ko')
            hold on
            plot([0 max([cond(2).meanp9 cond(1).meanp9])],[0 max([cond(2).meanp9 cond(1).meanp9])],'g--')
            xlabel(['H t (mV^2)' nameconds{1}],'fontsize',20)
            ylabel(['H t (mV^2)' nameconds{2}],'fontsize',20)
            box off
            axis tight
            
            
            %             errorbar(meanp9,semp9,'k.');
            %             hold on
            %             bar(meanp9)
            %             set(gca,'xtick',[1 2])
            %             set(gca,'xticklabel',{'CNO','SAL'})
            %             minmax=get(gca,'ylim')
            %             if pvp9<0.05
            %                 plot([1.5 minmax(2)],'k*')
            %             end
            %             ylabel('Ht (mV^2)','fontsize',20)
        end
        
        
        
        np=size(cond(cnd).bd,2);
        firstZT=input('ZT of first time point?')
        if firstZT<12
            np=min(np,12-firstZT);%We don't want to extend the analysis past ZT12
        else
            np=size(cond(cnd).bd,2);%12;%check this
        end
        
        figure
        % %W
        mesg={'W','NREM','REM'};
        mesg2={'BD W (min)','BD NREM (min)','BD REM (min)'};
        if nconds==2
            selc=2;
        else
            selc=3;
        end
        for npltpt=1:3
            subplot(2,3,npltpt)
            bigmat=[];
            for q=1:nconds
                vtp=[];
                err=[];
                %plotting %W
                for zth=1:np
                    %                 if q==3 & zth==3
                    %                     disp(cond(q).pt(find(~isnan(cond(q).pt(:,zth,npltpt))),zth,npltpt))
                    %                 end
                    %                     vtp(zth)=mean(cond(q).pt(find(~isnan(cond(q).pt(:,zth,npltpt))),zth,npltpt));
                    %                     err(zth)=sem(cond(q).pt(find(~isnan(cond(q).pt(:,zth,npltpt))),zth,npltpt));
                    vtp(zth)=nanmean(cond(q).pt(:,zth,npltpt));
                    err(zth)=sem(cond(q).pt(:,zth,npltpt));
                    cumtime(zth,:)=0.6*sum(cond(q).pt(:,1:zth,npltpt),2);
                    
                    
                    
                      [h,pvalpt(zth,npltpt)]=ttest2(cond(1).pt(find(~isnan(cond(1).pt(:,zth,npltpt))),zth,npltpt),cond(selc).pt(find(~isnan(cond(selc).pt(:,zth,npltpt))),zth,npltpt));
                end
                pvalpt=pvalpt*np;
                Totaltime(q,:)=sum(cond(q).pt(:,fhwbd:fhwbd+3,npltpt).*ones(size(cond(q).pt(:,fhwbd:fhwbd+3,npltpt)))*0.6,2);
                
                errorbar(vtp,err,'k.','linewidth',1);
                %
                hold on
                if nconds==2 & q==1
                    plot(cond(1).pt(:,:,1)','.--','linewidth',0.5)
                end
                o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
                bigmat(q,:,:)=cond(q).pt(:,1:np,npltpt);
                bigmatct(q,:,:)=cumtime;
            end
            fhand=gca;
            if npltpt==1
                if nconds>2
                    almeffect=Totaltime(3,:)-Totaltime(1,:);
                    disp(mean(almeffect))
                    figure
                    
                    for q=[1 3]
                        bigmatct(q,:,:)= bigmatct(q,:,:)-bigmatct(nconds,:,:);
                        vtpct=mean(bigmatct(q,:,:),3);
                        errct=sem(fixdim(bigmatct(q,:,:))');
                        errorbar(vtpct,errct,'k.','linewidth',1);
                        hold on
                        o(q)=plot(vtpct,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
                        if nconds==2 & q==1
                             plot(cond(q).bd(find(~isnan(cond(q).bd(:,zth,npltpt))),zth,npltpt))
                        end
                    end
                    %ttest between conds 1 and 3 for diff cum time
                    for zth=1:np
                        [h,p]= ttest(fixdim(bigmatct(1,zth,:)),fixdim(bigmatct(3,zth,:)));
                        pv_cum(zth)=p;
                    end
                    indsig=find(pv_cum<0.05);
                    xl2=char(num2str((firstZT:firstZT+np)'));
                    marker_sig='*';
                    set(gca,'fontsize',14)
                    axis tight
                    set(gca,'Xtick',[0.5:2:12.5])
                    set(gca,'Xticklabel',xl2)
                    xlabel('ZT','fontsize',18)
                    
                    box off
                    minmax=get(gca,'ylim');
                    set(gca,'ylim',[0 minmax(2)])
                    ylabel('D Cumulative W time (min)','fontsize',18)
                    top=nan(1,np);
                    top(indsig)=minmax(2)*1.03;
                    p=plot(1:np,top,'k*');
                    box off
                    axis tight
                    set(gca,'xlim',[0.5 np+0.5])
                    figure
%                     %now just the bar plot
%                     ztok=fhwbd+5;%min(9,np);Only 5 h after dosing
%                     d1=fixdim(bigmatct(1,ztok,:))
%                     alm_cno=fixdim(bigmatct(1,ztok,:))-sum(fixdim(bigmatct(1,1:fhwbd-1,:)),2);
%                     veh_cno=fixdim(bigmatct(3,ztok,:))-sum(fixdim(bigmatct(3,1:fhwbd-1,:)),2);
%                     vtp=[mean(alm_cno) mean(veh_cno)];
%                     err=[sem(alm_cno) sem(veh_cno)];
%                     difalmveh=alm_cno-veh_cno;
%                     errorbar(vtp,err,'k.','linewidth',1);
%                     hold on
%                     bar(vtp)
%                     set(gca,'xlim',[0.5 2.5])
%                     set(gca,'xtick',[1 2])
%                     minmax=get(gca,'ylim');
%                     if pv_cum(ztok)<0.05
%                         plot(1.5,minmax(2),'k*')
%                     end
%                     set(gca,'xticklabel',{'ALM-CNO','VEH-CNO'})
%                     set(gca,'ylim',[0 minmax(2)]);
%                     set(gca,'fontsize',14)
%                     box off
%                     ylabel('D Total W time (min)','fontsize',18)
%                     title(num2str(pv_cum(ztok)));
%                     %saving vals for anova
%                     alm_cno=fixdim(bigmatct(1,ztok,:))-sum(fixdim(bigmatct(1,1:fhwbd-1,:)),2);
%                     veh_cno=fixdim(bigmatct(3,ztok,:))-sum(fixdim(bigmatct(3,1:fhwbd-1,:)),2);
%                     save('difcumtime.mat','alm_cno','veh_cno','almeffect')
                end
            end
            axes(fhand)
            %             figure
            %             vtp=mean(cumtime,3);
            %             errtt=sem(cumtime,3');
            %             errorbar(vtp,errtt,'k.')
            % %             vtp=mean(Totaltime');
            % %             errtt=sem(Totaltime');
            % %             errorbar(vtp,errtt,'k.')
            %             hold on
            %             bar(vtp)
            %             axes(f)
            
            
            %2-way rep meas anova for %time
            [pvals,pval_con]=repmeasanova(bigmat); %zeros should not be NaN for % of time
            bigmat2=reshape(bigmat,size(bigmat,1)*size(bigmat,2),size(bigmat,3));
%             if firstZT==3
%                 pval_con=[];
%                 [nada,pval_con]=repmeasanova(bigmat(:,2:6,:));
%             end
            
            indp=find(pval_con<0.05);
            xl2=char(num2str((firstZT:firstZT+np)'));
            xl2eo=char(num2str((firstZT:2:firstZT+np)'));
            marker_sig='*+odxs';
            set(gca,'fontsize',14)
            %set(gca,'ylim',[0 100])
            %set(gca,'Xtick',[0.5:1:11.5])
            set(gca,'Xtick',[0.5:2:12.5])
            set(gca,'Xticklabel',xl2eo)
            xlabel('ZT','fontsize',18)
            %axis tight
            set(gca,'xlim',[0.5 np+0.5])
            if npltpt==3
                legend(o,nameconds)
                title('REM')
                save([path_of 'PTrem.txt'],'bigmat2','-ascii')
                
            end
            %xl={'ZT12-13','ZT13-14','ZT14-15','ZT15-16','ZT16-17','ZT17-18','ZT18-19','ZT19-20','ZT20-21','ZT21-22','ZT22-23','ZT23-24'};
            if npltpt==1
            %ylabel(char(mesg{npltpt}),'fontsize',18)
                ylabel('Hourly Percentage','fontsize',18)
                title('W')
                save([path_of 'PTwa.txt'],'bigmat2','-ascii')
            end
            if npltpt==2
                title('NREM')
                save([path_of 'PTNrem.txt'],'bigmat2','-ascii')
            end
                
            %title(strcat('Sleep Arch (N=',num2str(size(pwa1,1)),')'),'fontsize',20)
            box off
            axis tight
            %set(gca,'ylim',[0 106])
            minmax=get(gca,'ylim');
            
            %if npltpt==1 
                limy=minmax;
            set(gca,'ylim',[0 limy(2)])
            %end
            obpls=[];
            nn=0;
            for n2plt=1:length(pval_con);
                top=nan(1,np);
                %top=zeros(1,np);
                %if isin(n2plt,indp)
                nn=nn+1;
                newindp=find(pvals(:,n2plt)<(0.05/size(pvals,1)));
                top(newindp)=limy(2)+(limy(2)/100)*3*(n2plt);
                if length(newindp)>0 %isin(n2plt,newindp)
                    p=plot(1:np,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                
                top=limy(2)+(limy(2)/100)*3*(n2plt);
                if isin(n2plt,indp)
                    p=plot(np+0.5,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                obpls(nn)=p;
                %end
            end
            arrsig=[];
            ff=0;
            %If there are N conditions, there are (N-1)*N/2 couples to compare
            names_leg=[];
            if npltpt==2
                for It=1:length(nameconds)-1
                    for sec=It+1:length(nameconds)
                        ff=ff+1;
                        names_leg{ff}=[char(nameconds{It}) '<>' char(nameconds{sec})];
                        %                         plot(1,ff-1,['k' marker_sig(ff)])
                        %                         plot([2 2.2],[ff-1 ff-1],'o-','markerfacecolor',col(It),'markeredgecolor',col(It))
                        %                         plot([3 3.2],[ff-1 ff-1],'o-','linewidth',2,'markerfacecolor',col(sec),'markeredgecolor',col(sec))
                    end
                end
                %legend(obpls,names_leg{1:nn})
                legend(obpls,names_leg)
            end
            axis tight
            set(gca,'xlim',[0.5 np+0.5])
            %set(gca,'ylim',[0 minmax(2)])
            
            %set(gca,'ylim',[0 limy(2)+(limy(2)/100)*4*length(pval_con)])
            if nconds==2    
                minmax=get(gca,'ylim');
                pvsig=nan(size(pvalpt(:,npltpt)));
                pvsig(find(pvalpt(:,npltpt)<0.05))=1;
                plot(1:np,pvsig*minmax(2)*1.03,'k*')
                set(gca,'ylim',[0 1.03*minmax(2)])
            end
            %
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            subplot(2,3,3+npltpt)
            for q=1:nconds
                vtp=[];
                err=[];
                %plotting BDW
                for zth=1:np
                    vtp(zth)=mean(cond(q).bd(find(~isnan(cond(q).bd(:,zth,npltpt))),zth,npltpt));
                    err(zth)=sem(cond(q).bd(find(~isnan(cond(q).bd(:,zth,npltpt))),zth,npltpt));
                    [h,pvalbd(zth,npltpt)]=ttest2(cond(1).bd(find(~isnan(cond(1).bd(:,zth,npltpt))),zth,npltpt),cond(selc).bd(find(~isnan(cond(selc).bd(:,zth,npltpt))),zth,npltpt));
                end
                errorbar(vtp,err,'k.','linewidth',1);
                hold on
                o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
                
                    
                bigmat(q,:,:)=cond(q).bd(:,1:np,npltpt);
            end
            %legend(o,condname)
            if npltpt==1
                %ylabel(char(mesg2{npltpt}),'fontsize',18)
                ylabel('Hourly Bout Duration (min)','fontsize',18)
            end
            % title(strcat('Sleep Arch (N=',num2str(size(pwa1,2)),')'),'fontsize',20)
            box off
            set(gca,'fontsize',14)
            axis tight;%set(gca,'ylim',[0 100])
            minmax=get(gca,'ylim');
            %2-way rep meas anova
            [pvals,pval_con]=repmeasanova(bigmat);
            bigmat2=reshape(bigmat,size(bigmat,1)*size(bigmat,2),size(bigmat,3));
            switch npltpt
                case 1
                    save([path_of 'BDwa.txt'],'bigmat2','-ascii')
                case 2
                    save([path_of 'BDNrem.txt'],'bigmat2','-ascii')
                case 3
                    save([path_of 'BDrem.txt'],'bigmat2','-ascii')
            end
            indp=find(pval_con<0.05);
             limy=minmax;
            obpls=[];
            nn=0;
            for n2plt=1:length(pval_con);
                top=nan(1,np);
                %top=zeros(1,np);
                %if isin(n2plt,indp)
                nn=nn+1;
                newindp=find(pvals(:,n2plt)<(0.05/size(pvals,1)));
                top(newindp)=limy(2)+(limy(2)/100)*3*(n2plt);
                if length(newindp)>0 
                    p=plot(1:np,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                
                top=limy(2)+(limy(2)/100)*3*(n2plt);
                if isin(n2plt,indp)
                    p=plot(np+0.5,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                obpls(nn)=p;
                %end
            end
            %set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*4*length(pval_con)])
            
            set(gca,'ylim',[0 minmax(2)])
            if nconds==2   
                minmax=get(gca,'ylim');
                pvsig=nan(size(pvalpt(:,npltpt)));
                pvsig(find(pvalbd(:,npltpt)<(0.05/np)))=1;
                plot(1:np,pvsig*minmax(2)*1.03,'k*')
                set(gca,'ylim',[0 1.03*minmax(2)])
            end
            %xl2=char(num2str((12:23)'));
                    set(gca,'Xtick',[0.5:2:12.5])
                    set(gca,'Xticklabel',xl2eo)
                    xlabel('ZT','fontsize',18)
            axis tight
            minmax=get(gca,'ylim');
            set(gca,'xlim',[0.5 np+0.5])
            set(gca,'ylim',[0 minmax(2)])
        end
        %         if size(cond,2)>2
        %             figure;plot(cond(3).pt(:,5,1),'o-')
        %             set(gca,'ylim',[0 101])
        %         end
        
        
        %plotting HT and SWA and wake power
        newpvalbd=ones(np,1);%initialize p vals in 1
        figure
        subplot(2,6,11:12)
        for q=1:nconds
            vtp=[];
            err=[];
            %plotting SWA
            for zth=1:np
                vtp(zth)=mean(cond(q).nrd(find(cond(q).nrd(:,zth)>0),zth));
                err(zth)=sem(cond(q).nrd(find(cond(q).nrd(:,zth)>0),zth));
               if length(find(cond(1).nrd(:,zth)>0))*length(find(cond(2).nrd(:,zth)>0))>0
                                     [h,newpvalbd(zth)]=ttest2(cond(1).nrd(find(cond(1).nrd(:,zth)>0),zth),cond(selc).nrd(find(cond(selc).nrd(:,zth)>0),zth));
                 end
            end
            errorbar(vtp,err,'k.','linewidth',1);
            hold on
            o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
            %making zero NaN as those are not real zeros but absent data.
            aux=cond(q).nrd(:,1:np);
            indz=find(aux==0);
            aux(indz)=nan;
            bigmat(q,:,:)=aux;
        end
        %legend(o,coendndname)
        ylabel('NRD','fontsize',18)
        % title(strcat('Sleep Arch (N=',num2str(size(pwa1,2)),')'),'fontsize',20)
        box off
        set(gca,'fontsize',14)
        axis tight;%set(gca,'ylim',[0 100])
        minmax=get(gca,'ylim');
         limy=minmax;
        %2-way rep meas anova
        [pvals,pval_con]=repmeasanova(bigmat);
        bigmat2=reshape(bigmat,size(bigmat,1)*size(bigmat,2),size(bigmat,3));
        indp=find(pval_con<0.05);
        save([path_of 'SWA.txt'],'bigmat2','-ascii')
        obpls=[];
        nn=0;
        for n2plt=1:length(pval_con);
                top=nan(1,np);
                %top=zeros(1,np);
                %if isin(n2plt,indp)
                nn=nn+1;
                newindp=find(pvals(:,n2plt)<(0.05/size(pvals,1)));
                top(newindp)=limy(2)+(limy(2)/100)*3*(n2plt);
                if length(newindp)>0 
                    p=plot(1:np,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                
                top=limy(2)+(limy(2)/100)*3*(n2plt);
                if isin(n2plt,indp)
                    p=plot(np+0.5,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                obpls(nn)=p;
                %end
            end
        
        if nconds==2
                minmax=get(gca,'ylim');
                pvsig=nan(size(newpvalbd));
                pvsig(find(newpvalbd<(0.05/np)))=1;
                plot(1:np,pvsig*minmax(2)*1.03,'k*')
        end
        set(gca,'Xtick',[0.5:2:np+0.5])
        %xl2=char(num2str((firstZT:firstZT+np)'));
        set(gca,'Xticklabel',xl2eo)
        xlabel('ZT','fontsize',18)
        axis tight
        ylim=get(gca,'ylim');
        set(gca,'xlim',[0.5 np+0.5])
        %set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*4*length(pval_con)])
        set(gca,'ylim',[0 ylim(2)])
        
        subplot(2,6,9:10)
        for q=1:nconds
            vtp=[];
            err=[];
            %plotting HT
            for zth=1:np
                
                vtp(zth)=mean(cond(q).htw(:,zth));
                err(zth)=sem(cond(q).htw(:,zth));
                [h,newpvalbd(zth)]=ttest2(cond(1).htw(:,zth),cond(selc).htw(:,zth));
            end
            errorbar(vtp,err,'k.','linewidth',1);
            hold on
            o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
            %making zero NaN as those are not real zeros but absent data.
            aux=cond(q).htw(:,1:np);
            indz=find(aux==0);
            aux(indz)=nan;
            bigmat(q,:,:)=aux;
        end
        %legend(o,coendndname)
        ylabel('HT W','fontsize',18)
        % title(strcat('Sleep Arch (N=',num2str(size(pwa1,2)),')'),'fontsize',20)
        box off
        set(gca,'fontsize',14)
        axis tight;%set(gca,'ylim',[0 100])
        minmax=get(gca,'ylim');
         limy=minmax;
        
        %2-way rep meas anova
        [pvals,pval_con]=repmeasanova(bigmat);
        bigmat2=reshape(bigmat,size(bigmat,1)*size(bigmat,2),size(bigmat,3));
        save([path_of 'HT.txt'],'bigmat2','-ascii')
        indp=find(pval_con<0.05)
        
        obpls=[];
        nn=0;
        for n2plt=1:length(pval_con);
                top=nan(1,np);
                %top=zeros(1,np);
                %if isin(n2plt,indp)
                nn=nn+1;
                newindp=find(pvals(:,n2plt)<(0.05/size(pvals,1)));
                top(newindp)=limy(2)+(limy(2)/100)*3*(n2plt);
                if length(newindp)>0 
                    p=plot(1:np,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                
                top=limy(2)+(limy(2)/100)*3*(n2plt);
                if isin(n2plt,indp)
                    p=plot(np+0.5,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                obpls(nn)=p;
                %end
            end
        
        
        if nconds==2
                pvsig=nan(size(newpvalbd));
                pvsig(find(newpvalbd<(0.05/np)))=1;
                plot(1:np,pvsig*1.03*minmax(2),'k*')
        end
        set(gca,'Xtick',[0.5:2:np+0.5])
        xl2=char(num2str((firstZT:firstZT+np)'));%this was commented
        set(gca,'Xticklabel',xl2eo)
        xlabel('ZT','fontsize',18)%
        axis tight
        ylim=get(gca,'ylim');
        set(gca,'xlim',[0.5 np+0.5])
        set(gca,'ylim',[0 ylim(2)])
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        newpvalbd=[];
        vtp=[];
        err=[];
        %plotting histogram of WBD
        subplot(2,6,7:8)
        %first, finding the range
        
        %now making bins in 2^(0:nbins)
        xhist=[0 2.^[0:nbins]];
        newpvalbd=[];
        bigmat=[];
        for q=1:nconds
            for zth=1:nbins+1
                
                vtp(zth)=mean(cond(q).perc(zth,:)');
                err(zth)=sem(cond(q).perc(zth,:)');
                                if q==1
                                    [h,newpvalbd(zth)]=ttest2(cond(1).perc(zth,:)',cond(selc).perc(zth,:)');
                                end
            end
            errorbar(vtp,err,'k.','linewidth',1);
            hold on
            o(q)=plot(vtp,strcat(col(q),mark(q),'-'),'linewidth',2,'markerfacecolor','w','markersize',9);
            bigmat(q,:,:)=cond(q).perc(1:nbins+1,:)';
        end
        hold on
        box off
        set(gca,'fontsize',14)
        axis tight;
        minmax=get(gca,'ylim');
         limy=minmax;
        %2-way rep meas anova
        [pvals,pval_con]=repmeasanova(bigmat);
        bigmat2=reshape(bigmat,size(bigmat,1)*size(bigmat,2),size(bigmat,3));
        indp=find(pval_con<0.05);
        save([path_of 'WBDhist.txt'],'bigmat2','-ascii')
        %1-way anova for every time bin
        %         for binnum=1:size(bigmat,3)
        %             [pv,tbl,stats]= anova1(bigmat(:,:,binnum)',nameconds,'off');
        %             tmc=multcompare(stats,'Display','off');
        %             pvals(binnum,:)=tmc(:,end);
        %          end
        %             obpls=[];
        %             nn=0;
        %             for n2plt=1:size(pvals,2);
        %                 top=nan(1,size(bigmat,3));
        %                     nn=nn+1;
        %                     newindp=find(pvals(:,n2plt)<0.05);
        %                     top(newindp)=minmax(2)+(minmax(2)/100)*4*n2plt;
        %                     p=plot(1:size(bigmat,3),top,['k' marker_sig(n2plt)]);
        %                     obpls(nn)=p;
        %                 %end
        %             end
        %
        
        for n2plt=1:length(pval_con);
                top=nan(1,nbins+1);
                %top=zeros(1,np);
                %if isin(n2plt,indp)
                nn=nn+1;
                newindp=find(pvals(:,n2plt)<(0.05/size(pvals,1)));
                top(newindp)=limy(2)+(limy(2)/100)*3*(n2plt);
                if length(newindp)>0 
                    p=plot(1:nbins+1,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                
                top=limy(2)+(limy(2)/100)*3*(n2plt);
                if isin(n2plt,indp)
                    p=plot(np+0.5,top,['k' marker_sig(n2plt)]);
                else
                    p=plot(0,0,['k' marker_sig(n2plt)]);
                end
                obpls(nn)=p;
                %end
            end
        if nconds==2
                pvsig=nan(size(newpvalbd));
                pvsig(find(newpvalbd<(0.05/(nbins+1))))=1;
                plot(1:nbins+1,pvsig*minmax(2)*1.05,'k*')
        end
        disp('Pvals %wbd')
        disp(newpvalbd*(nbins+1))
        xl=get(gca,'xlim');
        
        %set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*4*length(pval_con)])
        %set(gca,'ylim',[0 minmax(2)*1.05])
        axis tight
        ylim=get(gca,'ylim');
        set(gca,'xlim',[0.5 xl(2)+0.5])
        set(gca,'xtick',[0.5:1:xl(2)+0.5])
        set(gca,'xticklabel',num2str(xhist'))
        xlabel('WBD (min)','fontsize',18)
        ylabel('% W time','fontsize',18)
        set(gca,'ylim',[0 ylim(2)])
        
        
        %Now the power
        %plotting meanpower under every condition for every state, for every hour
        %xl={'ZT12-13','ZT13-14','ZT14-15','ZT15-16','ZT16-17','ZT17-18','ZT18-19','ZT19-20','ZT20-21','ZT21-22','ZT22-23','ZT23-24'};
        %limits for range of frecs
        
        %finishing previous plot:
         set(gca,'fontsize',16)
        maxnp=5;
        npp=min(np,maxnp);
        %f2=subsam2(fok,4);
        maxftp=200;%15;%maf frec for plootting
        %indnpf=min(find(f2>maxftp))-1;%Number of times the anova will be ran.
        %indnpf=min(find(fok>=maxftp))-1
        nfrecpointsin1hz=min(find(fok>1))-1;
        p60=min(find(fok>60))-1;
        p120=min(find(fok>120))-1;
        p180=min(find(fok>180))-1;
        
        %filtering 60HZ artifact:
        newf=subsam(fok,nfrecpointsin1hz,1);
        p60lr=min(find(newf>60))-1;
        p120lr=min(find(newf>120))-1;
        p180lr=min(find(newf>180))-1;
        [v,p]=min(abs(newf-maxftp));
        indnpf=p;
        %pth='F:\data2017\HCRT_DREADD\gad_creR26_DREADD\bline24h';
        PathName = uigetdir(pth,'Pick a folder with blines');
        %reading blines
        cd(PathName);
        dir_bl=dir ('*.mat');
        S = [dir_bl(:).datenum].'; % you may want to eliminate . and .. first.
        [S,S] = sort(S);
        dir_bl = {dir_bl(S).name} ;
        [y,indx]=natsort(dir_bl);
        dir_bl=dir_bl(indx);
        for i=1:npp
            if firstZT==3
                ni=i+1;
            else
                ni=i;
            end
            %plotting fillings of SEM
            for q=1:nconds
                %making relative frec in 2 Hz bins:
              
                %figure
                for q1=1:size(cond(q).pwa,1) %subject
                    %cond(q).pwa(q1,ni,:)=notchfilterfd(cond(q).pwa(q1,ni,:),fok);
%                     cond(q).pwa(q1,ni,p60-1:p60+1)=nan;
%                     cond(q).pwa(q1,ni,p120-1:p120+1)=nan;
%                     cond(q).pwa(q1,ni,p180-1:p180+1)=nan;
%                     cond(4).pwa(q1,ni,:)=notchfilterfd(cond(4).pwa(q1,ni,:),fok);
                      %getting sleep arch of bline:
                       %normalizing by the corresponding hour. %assuming
                     %bline starts at ZT12
                     flagcond=0;%this is zero for camKii only
                     blinep=load(char(dir_bl{q1}));
                     ZT=ni%+firstZT-1;
                     hbline=ZT;
                     
                     if flagcond
                         if nconds>2
                             hbline=ZT+12;
                         else
                             hbline=ZT-11;
                         end
                     end
                     disp(blinep.sel)
                     if hbline>24
                         hbline=hbline-24;
                     end
                     if blinep.sel==2
                         normtr=blinep.pwa2(hbline,:)*0.0025;
                         blin3h=mean(blinep.pwa2(hbline:min(hbline+2,size(blinep.pwa2,1)),:))*0.0025;
                     else
                         blin3h=mean(blinep.pwa1(hbline:min(hbline+2,size(blinep.pwa1,1)),:))*0.0025;
                         normtr=blinep.pwa1(hbline,:)*0.0025;
                     end
                      %%%%%%%%%%
                      %Adding 3h trace 2 plot
                      %%%%%%%%%%
                      
                      if i==2
                          aux=fixdim(mean(cond(q).pwa(q1,ni:ni+3,:),2));
                          aux=notchfilterfd(aux,fok,4);
                          blin3h=notchfilterfd(blin3h,fok,4);
                          blin3h=notchfilterfd153(blin3h,fok,4);
                          trace(q,q1,:)=aux./blin3h;
                          if q1==5
                              a=3;
                              %trace(q,q1,:)=ones(size(trace(q,q1,:)));
                          end
                      end
                      
                      
%                     
                     disp([char(dir_dread{q1}) ' -- ' char(dir_bl{q1})]);
                    
                     
                      hrpwa=fixdim(cond(q).pwa(q1,ni,:))./normtr;%cond(4).pwa(q1,ni,:));  
                      lowrespwan(q).normpwa(q1,ni,:)=subsam(hrpwa,nfrecpointsin1hz,1);
                      lowrespwan(q).normpwa(q1,ni,p60lr-1:p60lr+2)=nan;
                      lowrespwan(q).normpwa(q1,ni,p120lr-1:p120lr+2)=nan;
                      lowrespwan(q).normpwa(q1,ni,p180lr-3:p180lr+5)=nan;
%ind=find(~isnan(fixdim(cond(q).pwa(q1,ni,:))));
%                     lowrespwan(q).normpwa(q1,ni,:)=nan(size(subsam(fixdim(cond(q).pwa(q1,ni,:)),nfrecpointsin1hz,0.5)));
%                     div=nan(size(fixdim(cond(4).pwa(q1,ni,:))));
%                     normp=div;
%                     normp(ind)=fixdim(cond(q).pwa(q1,ni,ind)./cond(4).pwa(q1,ni,ind));
%                     
%                     %
%                     lowrespwan(q1,ni,:)=subsam(normp,nfrecpointsin1hz,0.5);
                    %subsam(fixdim(cond(q).pwa(q1,ni,:)./cond(4).pwa(q1,ni,:)),nfrecpointsin1hz,0.5);
                    
                    plot(newf,fixdim(lowrespwan(q).normpwa(q1,ni,:)))
                    title([num2str(q1) num2str(ni)])
                     a=1;
                end
                
                f=gca;
                %figure
                
                %lowrespowerwa(q,i,:)=subsam(cond(q).pwa(:,ni,:)
                subplot(2,npp,i)
                %plot(newf,mean(fixdim(lowrespwan(:,ni,:)),1));
                meantp=mean(fixdim(lowrespwan(q).normpwa(:,ni,:)));
                errtp=sem(fixdim(lowrespwan(q).normpwa(:,ni,:)));
%                 meantp=fixdim(nanmean(cond(q).pwa(:,ni,:)));
%                 errtp=fixdim(sem(cond(q).pwa(:,ni,:)));
                einf=meantp-errtp;
                emax=meantp+errtp;
                x=fok;%f2;%%2*(0:length(mdwt)-1)/(length(mdwt)-1);
                X=[x,fliplr(x)];                %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                staux=col(q);
                %fill(X,Y,palec(staux),'EdgeColor','none');                  %plot filled area
                hold on
                box off
%                 for ii=1:size(cond(q).pwa,1)%subsampling the power for each animal and each ZT time 
%                     aux=subsam2(fixdim(cond(q).pwa(ii,i+1,:)),4)';
%                     bigmatw(q,:,ii)=aux(1:indnpf);
%                 end
                %bigmatw(q,:,:)=fixdim(cond(q).pwa(:,i+1,1:indnpf))';
                
                %bigmatw(q,:,:)=fixdim(cond(q).pwa(:,ni,1:indnpf))';
                bigmatw(q,:,:)=fixdim(lowrespwan(q).normpwa(:,ni,1:indnpf))';
            end
             %now plotting means so they will be on top of the fills
            
            for q=1:nconds
                %plotting power for each condition for effect
                subplot(2,npp,i)          
                %ftp=fixdim(nanmean(cond(q).pwa(:,ni,:)));
                ftp=mean(fixdim(lowrespwan(q).normpwa(:,ni,:)));
                o(q)=plot(newf(1:indnpf),ftp(1:indnpf),strcat(col(q),'-'),'linewidth',2);
                %o(q)=plot(fok(1:indnpf),ftp(1:indnpf),strcat(col(q),'-'),'linewidth',2);
                %o(q)=plot(fok(1:indnpf),fixdim(nanmean(cond(q).pwa(:,i,1:indnpf))),strcat(col(q),'-'),'linewidth',2);
                set(gca,'xlim',[0 maxftp])
                %set(gca,'ylim',[0 0.65])
                hold on
                minmax=get(gca,'ylim');
                
                if i==1
                    ylabel('Power during W (uV^2)','fontsize',16)
                end
                
                %plotting sig pvals. Doing ANOVA for every time epoint
                vecsig=makevecsig1w(bigmatw);%gives a vectors of NAN and 1's where 1 means pval<0.05 for 1W anova in each point
                for n2plt=1:size(vecsig,1)-1;%the forst row of vecsig is just the overall pval for 1-w anova
                    plot(fok(1:indnpf),vecsig(n2plt+1,:)*minmax(2)+(minmax(2)/100)*3*n2plt,['k' marker_sig(n2plt)]);
                    %plot(f2(1:indnpf),vecsig(n2plt+1,:)*minmax(2)+(minmax(2)/100)*3*n2plt,['k' marker_sig(n2plt)]);
                end
                set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*3*(size(vecsig,1)-1)])
                %plot(fok,vecsig*minmax(2),'m.')
                set(gca,'fontsize',16)
            end
            xlabel({'Hz';['ZT' xl2(ni,:) '-' xl2(ni+1,:)]})
        end
      
        
        figure
        set(gca,'fontsize',16)
        maxnp=7;
        npp=min(np,maxnp);
        for i=1:npp
            
            %plotting fillings of SEM
            for q=1:nconds
                subplot(3,npp,i)
                
                meantp=fixdim(nanmean(cond(q).pwa(:,i,:)));
                errtp=fixdim(sem(cond(q).pwa(:,i,:)));
                einf=meantp-errtp;
                emax=meantp+errtp;
                x=fok;%2*(0:length(mdwt)-1)/(length(mdwt)-1);
                X=[x,fliplr(x)];                %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                staux=col(q);
                fill(X,Y,palec(staux),'EdgeColor','none');                  %plot filled area
                hold on
                box off
                subplot(3,npp,npp+i)
                meantp=fixdim(nanmean(cond(q).pnr(:,i,:)));
                errtp=fixdim(sem(cond(q).pnr(:,i,:)));
                einf=meantp-errtp;
                emax=meantp+errtp;
                x=fok;%2*(0:length(mdwt)-1)/(length(mdwt)-1);
                X=[x,fliplr(x)];                %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                fill(X,Y,palec(col(q)),'EdgeColor','none');                  %plot filled area
                hold on
                box off
                subplot(3,npp,2*npp+i)
                meantp=fixdim(nanmean(cond(q).pr(:,i,:)));
                errtp=fixdim(sem(cond(q).pr(:,i,:)));
                einf=meantp-errtp;
                emax=meantp+errtp;
                x=fok;%2*(0:length(mdwt)-1)/(length(mdwt)-1);
                X=[x,fliplr(x)];                %create continuous x value array for plotting
                Y=[einf,fliplr(emax)];              %create y values for out and then back
                fill(X,Y,palec(col(q)),'EdgeColor','none');                  %plot filled area
                hold on
                box off
                bigmatw(q,:,:)=fixdim(cond(q).pwa(:,i,1:indnpf))';
                bigmatnr(q,:,:)=fixdim(cond(q).pnr(:,i,1:indnpf))';
                bigmatr(q,:,:)=fixdim(cond(q).pr(:,i,1:indnpf))';
            end
            
            %now plotting means
            
            for q=1:nconds
                %plotting power for each condition for effect
                subplot(3,npp,i)
                o(q)=plot(fok(1:indnpf),fixdim(nanmean(cond(q).pwa(:,i,1:indnpf))),strcat(col(q),'-'),'linewidth',2);
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 0.65])
                hold on
                minmax=get(gca,'ylim');
                
                if i==1
                    ylabel('Power during W (uV^2)','fontsize',16)
                end
                xlabel('Hz')
                %plotting sig pvals. Doing ANOVA for every time epoint
                vecsig=makevecsig1w(bigmatw);%gives a vectors of NAN and 1's where 1 means pval<0.05 for 1W anova in each point
                for n2plt=1:size(vecsig,1)-1;%the forst row of vecsig is just the overall pval for 1-w anova
                    plot(fok(1:indnpf),vecsig(n2plt+1,:)*minmax(2)+(minmax(2)/100)*3*n2plt,['k' marker_sig(n2plt)]);
                end
                set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*3*(size(vecsig,1)-1)])
                %plot(fok,vecsig*minmax(2),'m.')
                set(gca,'fontsize',14)
                
                subplot(3,npp,npp+i)
                plot(fok(1:indnpf),fixdim(nanmean(cond(q).pnr(:,i,1:indnpf))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 0.65])
                minmax=get(gca,'ylim');
                hold on
                if i==1
                    ylabel('Power for NREM (uV^2)','fontsize',16)
                end
                xlabel('Hz')
                
                vecsig=makevecsig1w(bigmatnr);%gives a matrix of NAN and 1's where 1 means pval<0.05 for 1W anova in each point
                for n2plt=1:size(vecsig,1)-1;%the forst row of vecsig is just the overall pval for 1-w anova
                    plot(fok(1:indnpf),vecsig(n2plt+1,:)*minmax(2)+(minmax(2)/100)*3*n2plt,['k' marker_sig(n2plt)]);
                end
                set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*3*(size(vecsig,1)-1)])
                
                
                %plot(fok,vecsig*minmax(2),'m.')
                
                set(gca,'fontsize',14)
                
                subplot(3,npp,2*npp+i)
                plot(fok(1:indnpf),fixdim(nanmean(cond(q).pr(:,i,1:indnpf))),strcat(col(q),'-'),'linewidth',2)
                set(gca,'xlim',[0 15])
                set(gca,'ylim',[0 1])
                xlabel(['ZT' num2str(firstZT+i-1) '-' num2str(firstZT+i)])
                minmax=get(gca,'ylim');
                vecsig=makevecsig1w(bigmatr);%gives a vectors of NAN and 1's where 1 means pval<0.05 for 1W anova in each point
                for n2plt=1:size(vecsig,1)-1;%the forst row of vecsig is just the overall pval for 1-w anova
                    plot(fok(1:indnpf),vecsig(n2plt+1,:)*minmax(2)+(minmax(2)/100)*3*n2plt,['k' marker_sig(n2plt)]);
                end
                set(gca,'ylim',[0 minmax(2)+(minmax(2)/100)*3*(size(vecsig,1)-1)])
                
                %plot(fok,vecsig*minmax(2),'m.')
                %xl2(i)))
                hold on
                if i==1
                    ylabel('Power for REM (uV^2)','fontsize',16)
                    legend(o,nameconds)
                end
                set(gca,'fontsize',14)
            end
            %storing the delta (0.5-4) and high teta (8-9) power            
        end
        %plotting frec plot and bars
          figure
          subplot(1,2,1)
          for q=1:nconds
              %I got a filling...
              meantp=fixdim(mean(trace(q,:,:),2));
%               meantp(p60)=(meantp(p60-1)+meantp(p60+1))/2;
%               meantp(p180)=(meantp(p180-1)+meantp(p180+1))/2;
              errtp=sem(fixdim(trace(q,:,:)));
%               errtp(p60)=(errtp(p60-1)+errtp(p60+1))/2;
%               errtp(p180)=(errtp(p180-1)+errtp(p180+1))/2;
              einf=meantp-errtp;
              emax=meantp+errtp;
              x=fok;%2*(0:length(mdwt)-1)/(length(mdwt)-1);
              X=[x,fliplr(x)];                %create continuous x value array for plotting
              Y=[einf,fliplr(emax)];              %create y values for out and then back
              staux=col(q);
              fill(X,Y,palec(staux),'EdgeColor','none');                  %plot filled area
              hold on
              box off
          end
          for q=1:nconds
              %now means...
              meantp=fixdim(mean(trace(q,:,:),2));
              o(q)=plot(fok,meantp,strcat(col(q),'-'),'linewidth',2);
                set(gca,'xlim',[0 200])
                %set(gca,'ylim',[0 0.65])
                hold on
                minmax=get(gca,'ylim');
                if i==1
                    ylabel('Normalize Power','fontsize',21)
                end
                xlabel('Frequency (Hz)','fontsize',21)
          end
          %now bar plots
          %ranges are: '0.5-4','4-8','8-10','15-50','60-80','90-120','130-160','170-200'
          l=[0.5 4 8 15 60 90];
          h=[4 8 10 50 80 200];
          for i=1:length(l)
              [v,fp]=min(abs(fok-l(i)));
              [v,lp]=min(abs(fok-h(i)));%getting the start and end frecs
              
              for q=1:nconds
                meanp(q,i)=mean(fixdim(mean(trace(q,:,fp:lp),3)));
                semp(q,i)=sem(fixdim(mean(trace(q,:,fp:lp),3)));
                bigmatband(q,:,i)=fixdim(mean(trace(q,:,fp:lp),3));%condition, subject, band
              end
          end
           set(gca,'fontsize',14)
           ylabel('Normalized W Power','fontsize',21)
           set(gca,'ylim',[0.5 3.7])
           subplot(1,2,2)
           h=barwitherr(semp',meanp')
           
           ylabel('Normalized W Power','fontsize',21)
           %set(h(1),'FaceColor','b');
           set(gca,'xticklabel',{'0.5-4','4-8','8-10','15-50','60-80','90-200'})
           set(gca,'fontsize',14)
           %making colormap(blue,green,magenta,black)
           if nconds>2
           newmap=[[0 0 1];[0 1 0];[1 0 1];[0 0 0]];
           colormap(newmap)
           else
                newmap=[[1 0 0];[0 0 0]];
                colormap(newmap)
           end
           xlabel('Spectral band (Hz)','fontsize',21)  
           box off
           legend(nameconds)
           legend boxoff
           set(gca,'ylim',[0 3.1])
           bigmatb=reshape(bigmatband,size(bigmatband,1)*size(bigmatband,2),size(bigmatband,3));
           save ('c:\tmp\stats\bigmatband.txt','bigmatb','-ascii')
           
    case 12
        %compare sleep arch. Plots Power, and bar plot of BD and %Time for
        %NR with ttest.
        clear
        pth='F:\data2018\nNOS_opto\pilot for grant\dosing\stimeffct';
        path_of = uigetdir(pth,'Pick a folder with the two groups');
        cd(path_of);
        dir_conds=dir;
        %             S = [dir_conds(:).datenum].'; % you may want to eliminate . and .. first.
        %             [S,S] = sort(S);
        dir_conds = {dir_conds(3:end).name};
        nconds=length(dir_conds);
        for i=1:nconds
            allbdw{i}=[];
            spfcond{i}=[];
        end
        m=0;
        for cnd=1:nconds
            %aux=cellstr(dir_conds{2+i})
            %allspeeds{cnd}=[];
            aux=dir_conds{cnd};
            nameconds{cnd}=aux;
            %cellstr(aux);
            %Now loading data for all conditions
            
            cd(nameconds{cnd})
            dir_dread=dir ('*.mat');
            S = [dir_dread(:).datenum].'; % you may want to eliminate . and .. first.
            [S,S] = sort(S);
        dir_dread = {dir_dread(S).name} ;
        [y,indx]=natsort(dir_dread);
        dir_dread=dir_dread(indx)
            %allbd{cnd}=[];%initiallize array with all BDs
            %cond(cnd).perc=zeros(length(dir_dread));%percentage of total W time for each bin for each condition for each animal
            for i=1:length(dir_dread)
                load(dir_dread{i});
                cond(cnd).perst(i,:)=[pwa pnr pr];
                cond(cnd).bdur(i,:)=[mboutwa mboutnr mboutr]*4;%old version saved time in epochs
                cond(cnd).wapow(i,:)=mean(matpowerWA);
                cond(cnd).nrpow(i,:)=mean(matpowerNR);
                cond(cnd).rpow(i,:)=mean(matpowerREM);
                cond(cnd).f=freq;
                aux=getboutok(sc(max(1,round(startsec/4)):floor(endsec/4)),1);
                boutsnr=aux(find(aux>2));
                auxr=getboutok(sc(max(1,round(startsec/4)):floor(endsec/4)),2);
                boutsr=auxr(find(auxr>2));
                auxw=getboutok(sc(max(1,round(startsec/4)):floor(endsec/4)),0);
                boutsw=auxw(find(auxw>2));
                disp('b length:')
                cond(cnd).nbtNR(i)=length(boutsnr);
                disp(length(boutsnr))
                cond(cnd).nbtWA(i)=length(boutsw);
                disp(length(boutsw))
                cond(cnd).nbtR(i)=length(boutsr);
                
               
                
            end
            cd(path_of);
        end
        
        %NREM:
        figure;
        %Summary plot comparing the 1)PSD, 2)power in the relevant band(delta
        %for NR, Gama and HT for W and tetha for REM. 3) % 4) BD, 5)NB. 3 x
        %5 grid, with the first double.
        subplot(3,6,1:2)
        %subplot(1,2,1)
        
        X=[freq,fliplr(freq)];                %create continuous x value array for plotting
                      %plot filled area
        hold on
        
        Y=[mean(cond(2).nrpow)-sem(cond(2).nrpow),fliplr(mean(cond(2).nrpow)+sem(cond(2).nrpow))];              %create y values for out and then back
        fill(X,Y,[0.85 0.85 1],'EdgeColor','none'); 
        Y=[mean(cond(1).nrpow)-sem(cond(1).nrpow),fliplr(mean(cond(1).nrpow)+sem(cond(1).nrpow))];              %create y values for out and then back
        fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');    
        plot(freq,mean(cond(1).nrpow),'k','linewidth',1.5);
        plot(freq,mean(cond(2).nrpow),'b','linewidth',1.5);
        legend(flip(nameconds),'fontsize',18,'edgecolor','w')
        xlabel('Hz','fontsize',21)
        box off
        ylabel('Power (\muV^2)','fontsize',21)
        axis tight
        set(gca,'xlim',[0 10])
        set(gca,'fontsize',18)
        subplot(3,6,3)
         %subplot(1,2,2)
        %add low and high delta pbands
        [v,pos05]=min(abs(freq-0.5));
        [v,pos25]=min(abs(freq-2.5));
        [v,pos4]=min(abs(freq-4));
        allLDpre=mean(cond(1).nrpow(:,pos05:pos25)'); 
        allLDstim=mean(cond(2).nrpow(:,pos05:pos25)');
        allHDpre=mean(cond(1).nrpow(:,pos25:pos4)'); 
        allHDstim=mean(cond(2).nrpow(:,pos25:pos4)');
        allDpre=mean(cond(1).nrpow(:,pos05:pos4)'); 
        allDstim=mean(cond(2).nrpow(:,pos05:pos4)'); 
        hid=[mean(allHDpre) mean(allHDstim)];
        lowd=[mean(allLDpre) mean(allLDstim)];
        dp=[mean(allDpre) mean(allDstim)];
        errd=[sem(allDpre) sem(allDstim)];
        errlowd=[sem(allLDpre) sem(allDstim)];
        errhid=[sem(allHDpre) sem(allHDstim)];
        errorbar(dp,errd,'k.')
        hold on
        b=bar(dp)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('\delta Power (\muV^2)','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest([allDpre,allDstim])
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
       
        
        %comentted below
%         errorbar([lowd hid],[errlowd errhid],'k.')
%         hold on
%         bar([lowd hid])
%         ylabel('Mean Power (\muV^2)','fontsize',21)
%         set(gca,'XTick',[1 2 3 4])
%         set(gca,'XTicklabel',{'LD Off','LD ON','HD Off','HD On'})
%         box off
%         set(gca,'fontsize',18)
        
%         %pt
        subplot(subplot(3,6,4))
        meanpnr=[mean(cond(1).perst(:,2)) mean(cond(2).perst(:,2))];
        sempnr=[sem(cond(1).perst(:,2)) sem(cond(2).perst(:,2))];
        errorbar(meanpnr,sempnr,'k.')
        hold on
        b=bar(meanpnr)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('% NREM','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).perst(:,2),cond(2).perst(:,2))
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        %BD
        subplot(subplot(3,6,5))
        meanbnr=[mean(cond(1).bdur(:,2)) mean(cond(2).bdur(:,2))];
        sembnr=[mean(cond(1).bdur(:,2)) mean(cond(2).bdur(:,2))];
        errorbar(meanbnr,sembnr,'k.')
        hold on
        b=bar(meanbnr)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('BD NREM','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).bdur(:,2),cond(2).bdur(:,2))
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',18)
        end
        subplot(3,6,6)
        %N bouts
        errnb=[sem(cond(1).nbtNR) sem(cond(2).nbtNR)];
        meannb=[mean(cond(1).nbtNR) mean(cond(2).nbtNR)];
        errorbar(meannb,errnb,'k.')
        hold on
        b=bar(meannb)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('N bouts NR','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).nbtNR,cond(2).nbtNR)
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',18)
        end
        %[p,table,stats]=anova2([[allLDpre allHDpre]' [allLDstim allHDstim]'],3);
        disp(p)
        
        save([path_of 'powervalsnrem.mat'],'allLDpre','allLDstim','allHDpre','allHDstim')
        %WAKE
  
        subplot(3,6,7:8)
        %subplot(1,2,1)
        
        X=[freq,fliplr(freq)];                %create continuous x value array for plotting
                      %plot filled area
        hold on
        
        Y=[mean(cond(2).wapow)-sem(cond(2).wapow),fliplr(mean(cond(2).wapow)+sem(cond(2).wapow))];              %create y values for out and then back
        fill(X,Y,[0.85 0.85 1],'EdgeColor','none'); 
        Y=[mean(cond(1).wapow)-sem(cond(1).wapow),fliplr(mean(cond(1).wapow)+sem(cond(1).wapow))];              %create y values for out and then back
        fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');    
        plot(freq,mean(cond(1).wapow),'k','linewidth',1.5);
        plot(freq,mean(cond(2).wapow),'b','linewidth',1.5);
        legend(flip(nameconds),'fontsize',18,'edgecolor','w')
        
        xlabel('Hz','fontsize',21)
        box off
        ylabel('Power (\muV^2)','fontsize',21)
        axis tight
        %set(gca,'xlim',[0 50])
        set(gca,'fontsize',18)
        subplot(3,6,9)
        %subplot(1,2,2)
        %add low and high delta pbands
        [v,pos05]=min(abs(freq-0.5));
        [v,pos25]=min(abs(freq-2.5));
        [v,pos4]=min(abs(freq-4));
        [v,pos7]=min(abs(freq-7))
        [v,pos9]=min(abs(freq-9))
        [v,pos11]=min(abs(freq-11))
        allLDpre=mean(cond(1).wapow(:,pos05:pos25)'); 
        allLDstim=mean(cond(2).wapow(:,pos05:pos25)');
        allHDpre=mean(cond(1).wapow(:,pos25:pos4)'); 
        allHDstim=mean(cond(2).wapow(:,pos25:pos4)');
        allDpre=mean(cond(1).wapow(:,pos05:pos4)'); 
        allDstim=mean(cond(2).wapow(:,pos05:pos4)'); 
        allLThpre=mean(cond(1).wapow(:,pos7:pos9)'); 
        allLThpost=mean(cond(2).wapow(:,pos7:pos9)');
        allLHthpre=mean(cond(1).wapow(:,pos9:pos11)'); 
        allLHthpost=mean(cond(2).wapow(:,pos9:pos11)');
        
%         hid=[mean(allHDpre) mean(allHDstim)];
%         lowd=[mean(allLDpre) mean(allLDstim)];
%         dp=[mean(allDpre) mean(allDstim)];
%         errd=[sem(allDpre) sem(allDstim)];
%         errlowd=[sem(allLDpre) sem(allDstim)];
%         errhid=[sem(allHDpre) sem(allHDstim)];
%         errorbar(dp,errd,'k.')
        
        
        dp=[mean(allLHthpre) mean(allLHthpost)];
        errd=[sem(allLHthpre) sem(allLHthpost)];
        errorbar(dp,errd,'k.')
        hold on
        b=bar(dp)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('H\theta Power (\muV^2)','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(allLHthpre,allLHthpost)
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        
        %comentted below
%         errorbar([lowd hid],[errlowd errhid],'k.')
%         hold on
%         bar([lowd hid])
%         ylabel('Mean Power (\muV^2)','fontsize',21)
%         set(gca,'XTick',[1 2 3 4])
%         set(gca,'XTicklabel',{'LD Off','LD ON','HD Off','HD On'})
%         box off
%         set(gca,'fontsize',18)
        
%         %pt
        subplot(subplot(3,6,10))
        meanpw=[mean(cond(1).perst(:,1)) mean(cond(2).perst(:,1))];
        sempw=[sem(cond(1).perst(:,1)) sem(cond(2).perst(:,1))];
        errorbar(meanpw,sempw,'k.')
        hold on
        b=bar(meanpw)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('% WAKE','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).perst(:,1),cond(2).perst(:,1))
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        %BD
        subplot(subplot(3,6,11))
        meanbw=[mean(cond(1).bdur(:,1)) mean(cond(2).bdur(:,1))];
        sembw=[mean(cond(1).bdur(:,1)) mean(cond(2).bdur(:,1))];
        errorbar(meanbw,sembw,'k.')
        hold on
        b=bar(meanbw)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('BD WA','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        [h,p]=ttest2(allDpre,allDstim)
        minmax=get(gca,'ylim')
        if p<0.05
            text(1.5,max(minmax),'*','FontSize',21)
        end
        subplot(3,6,12)
        %N bouts
        errnb=[sem(cond(1).nbtWA) sem(cond(2).nbtWA)];
        meannb=[mean(cond(1).nbtWA) mean(cond(2).nbtWA)];
        errorbar(meannb,errnb,'k.')
        hold on
        b=bar(meannb)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('N bouts WA','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        [h,p]=ttest2(cond(1).nbtWA,cond(2).nbtWA)
        minmax=get(gca,'ylim')
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        %[p,table,stats]=anova2([[allLDpre allHDpre]' [allLDstim allHDstim]'],3);
        save([path_of 'powervalswake.mat'],'allLDpre','allLDstim','allHDpre','allHDstim')
        
        %REM:
        
        subplot(3,6,13:14)
        %subplot(1,2,1)
        
        X=[freq,fliplr(freq)];                %create continuous x value array for plotting
                      %plot filled area
        hold on
        
        Y=[mean(cond(2).rpow)-sem(cond(2).rpow),fliplr(mean(cond(2).rpow)+sem(cond(2).rpow))];              %create y values for out and then back
        fill(X,Y,[0.85 0.85 1],'EdgeColor','none'); 
        Y=[mean(cond(1).rpow)-sem(cond(1).rpow),fliplr(mean(cond(1).rpow)+sem(cond(1).rpow))];              %create y values for out and then back
        fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');    
        plot(freq,mean(cond(1).rpow),'k','linewidth',1.5);
        plot(freq,mean(cond(2).rpow),'b','linewidth',1.5);
        legend(flip(nameconds),'fontsize',18,'edgecolor','w')
        
        xlabel('Hz','fontsize',21)
        box off
        ylabel('Power (\muV^2)','fontsize',21)
        axis tight
        set(gca,'xlim',[0 10])
        set(gca,'fontsize',18)
        subplot(3,6,15)
        %subplot(1,2,2)
        %add low and high delta pbands
        [v,pos05]=min(abs(freq-0.5));
        [v,pos25]=min(abs(freq-2.5));
        [v,pos4]=min(abs(freq-4));
        allLDpre=mean(cond(1).rpow(:,pos05:pos25)'); 
        allLDstim=mean(cond(2).rpow(:,pos05:pos25)');
        allHDpre=mean(cond(1).rpow(:,pos25:pos4)'); 
        allHDstim=mean(cond(2).rpow(:,pos25:pos4)');
        allDpre=mean(cond(1).rpow(:,pos05:pos4)'); 
        allDstim=mean(cond(2).rpow(:,pos05:pos4)'); 
        
%         hid=[mean(allHDpre) mean(allHDstim)];
%         lowd=[mean(allLDpre) mean(allLDstim)];
%         dp=[mean(allDpre) mean(allDstim)];
%         errd=[sem(allDpre) sem(allDstim)];
%         errlowd=[sem(allLDpre) sem(allDstim)];
%         errhid=[sem(allHDpre) sem(allHDstim)];
        dp=[mean(allLThpre) mean(allLThpost)];
        errd=[sem(allLThpre) sem(allLThpost)];
        errorbar(dp,errd,'k.')
        hold on
        b=bar(dp)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('q Power (\muV^2)','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(allLThpre,allLThpost)
        if p<0.05
            text(1.5,max(minmax),'*','FontSize',21)
        end
        %comentted below
%         errorbar([lowd hid],[errlowd errhid],'k.')
%         hold on
%         bar([lowd hid])
%         ylabel('Mean Power (\muV^2)','fontsize',21)
%         set(gca,'XTick',[1 2 3 4])
%         set(gca,'XTicklabel',{'LD Off','LD ON','HD Off','HD On'})
%         box off
%         set(gca,'fontsize',18)
        
%         %pt
        subplot(subplot(3,6,16))
        meanpr=[mean(cond(1).perst(:,3)) mean(cond(2).perst(:,3))];
        sempr=[sem(cond(1).perst(:,3)) sem(cond(2).perst(:,3))];
        errorbar(meanpr,sempr,'k.')
        hold on
        b=bar(meanpr)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('% REM','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).perst(:,3),cond(2).perst(:,3))
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        %BD
        subplot(subplot(3,6,17))
        meanbr=[mean(cond(1).bdur(:,3)) mean(cond(2).bdur(:,3))];
        sembr=[mean(cond(1).bdur(:,3)) mean(cond(2).bdur(:,3))];
        errorbar(meanbr,sembr,'k.')
        hold on
        b=bar(meanbr)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('BD REM','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).bdur(:,3),cond(2).bdur(:,3))
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        subplot(3,6,18)
        %N bouts
        errnb=[sem(cond(1).nbtR) sem(cond(2).nbtR)];
        meannb=[mean(cond(1).nbtR) mean(cond(2).nbtR)];
        errorbar(meannb,errnb,'k.')
        hold on
        b=bar(meannb)
        b.FaceColor = 'flat';
        b.CData(1,:) = [0.1 0.1 0.1];
        b.CData(2,:) = [0.1 0.1 1];
        ylabel('N bouts REM','fontsize',21)
        set(gca,'XTick',[1 2])
        set(gca,'XTicklabel',nameconds)
        box off
        set(gca,'fontsize',18)
        minmax=get(gca,'ylim')
        [h,p]=ttest2(cond(1).nbtR,cond(2).nbtR)
        if p<0.05
            text(1.4,max(minmax),'*','FontSize',21)
        end
        %[h,p]=ttest2([allDpre,allDstim])
%         [p,table,stats]=anova2([[allLDpre allHDpre]' [allLDstim allHDstim]'],3);
        
        save([path_of 'powervalsrem.mat'],'allLDpre','allLDstim','allHDpre','allHDstim')
       
   
end


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
