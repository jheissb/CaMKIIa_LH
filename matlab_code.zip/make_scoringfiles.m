function make_scoringfiles(path);
%%Adds a .mat file with scoring info for every edf and architecture mat
%%file in the folder.
cd (path)
dir_mats=dir ('*.mat');
dir_edf = dir('*.edf');
%Steps:
%1- Get fname from edf file
%2- Open respective mat file
%3- Save scoring mat file with fields: statp, endp, sc, vali, scalefft,
%zt0, rangefft, epocl,t0

for nfile =1:length(dir_edf)
    fn = dir_edf(nfile)(1:end-4)
    fn=strcat(fn,'.mat')
    disp(fn)