%generates pie charts of the population size for mixed, single ref. state
%and invariant of artifcially generated even rates uniformly distributed
ncells=2000;
frates=(rand(4,ncells)+0.5)./1.5;%2000 cells, frates for AW, QW, NREM, REM
indaw=find(frates(1,:)> 1.3*frates(2,:) & frates(1,:)> 1.3*frates(3,:) & frates(1,:)> 1.3*frates(4,:));
indqw=find(frates(2,:)> 1.3*frates(1,:) & frates(2,:)> 1.3*frates(3,:) & frates(2,:)> 1.3*frates(4,:));
indnrem=find(frates(3,:)> 1.3*frates(2,:) & frates(3,:)> 1.3*frates(1,:) & frates(3,:)> 1.3*frates(4,:));
indrem=find(frates(4,:)> 1.3*frates(2,:) & frates(4,:)> 1.3*frates(3,:) & frates(4,:)> 1.3*frates(1,:));

indinv=find(frates(1,:)< 1.3*frates(2,:) & frates(1,:)< 1.3*frates(3,:) & frates(1,:)< 1.3*frates(4,:)...
    & frates(2,:)< 1.3*frates(1,:) & frates(2,:)< 1.3*frates(3,:) & frates(2,:)< 1.3*frates(4,:) ...
    & frates(3,:)< 1.3*frates(1,:) & frates(3,:)< 1.3*frates(2,:) & frates(3,:)< 1.3*frates(4,:) ...
    & frates(4,:)< 1.3*frates(1,:) & frates(4,:)< 1.3*frates(3,:) & frates(4,:)< 1.3*frates(2,:));
nsingpref=length(indaw)+length(indqw)+length(indnrem)+length(indrem);

figure
pie([length(indaw) length(indqw) length(indnrem) length(indrem) ncells-length(indinv)-nsingpref length(indinv)],{'AW','QW','NREM','REM','Mixed','Inv'});
