function varargout = iscorev4(varargin)
%Graphic interface to score and analyze EEG data in EDF format
%By Jaime Heiss, March 2013
% ISCOREV4 MATLAB code for iscorev4.fig
%      ISCOREV4, by itself, creates a new ISCOREV4 or raises the existing
%      singleton
%
%      H = ISCOREV4 returns the handle to a new ISCOREV4 or the handle to
%      the existing singleton*.
%
%      ISCOREV4('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ISCOREV4.M with the given input arguments.
%
%      ISCOREV4('Property','Value',...) creates a new ISCOREV4 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before iscorev4_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to iscorev3_OpeninngFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help iscorev4

% Last Modified by GUIDE v2.5 29-Nov-2018 17:03:53

% rescore initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @iscorev4_OpeningFcn, ...
    'gui_OutputFcn',  @iscorev4_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before iscorev4 is made visible.
function iscorev4_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to iscorev4 (see VARARGIN)

% Choose default command line output for iscorev4
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes iscorev4 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = iscorev4_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes when figure1 is resized.
function figure1_ResizeFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in load_edf.
function load_edf_Callback(hObject, eventdata, handles)
% hObject    handle to load_edf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Load EDF file and generates the parameters for sleep scoring in 2s epochs:
%Max-median EMG, Autocor EMG, RMS EEG, autocEEG, delta, gama,
%teta/(teta+delta)
handles.thresEMG_W=0;
handles.thresEMGdiff_W=1.5;%fixed by hand
handles.thresDLT_WA=0;
handles.thresDLT_NR=0;
handles.thresACEMG_SLP=0;
handles.thresACEEG_R=0;
handles.thresRIND_R=0;
handles.thresG_W=0;
handles.autoscoring=0;
handles.threspar=zeros(1,4);
h=findall(0,'type','figure')
if length(h)>1
    close (h(2:end));
end
axes(handles.axes2)
cla

% box off
% axis off
axes(handles.axes3)
cla
box off
axis off
set(handles.raw_signals,'value',1)
cla
cn=getComputerName();
cn=cn(1:end-1);
if isfield(handles,'EDF')
    handles.EDF=sdfclose(handles.EDF);
end

if isfield(handles,'nump')
    handles=rmfield(handles,'nump')
end

%cd ('C:\Users\E26903\Documents\My Dropbox\laptopsleep\anushka')
[filename, pathname] = uigetfile('*.edf', 'Pick the EDF file to load');
handles.fn=filename;
handles.pathEDF=pathname;
cd (pathname)
set(handles.text8,'BackgroundColor',[1 0 0])
set(handles.text8,'string','Reading File')
handles.EDF=sdfopen(filename);
%handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
set(handles.filename,'string',filename)
handles.dur=handles.EDF.NRec*handles.EDF.Dur;%duration in secs of the whole thing
a=handles.EDF.Label(1,:);
if strcmp(a,'                ')
    handles.EDF.Label(1,1:4)='Stim'
end
set(handles.raw_signals,'string',handles.EDF.Label);
handles.selchan=get(handles.raw_signals,'value');
handles.hto=handles.EDF.T0(4);%initial hour
handles.mto=handles.EDF.T0(5);%initial minute
handles.sto=handles.EDF.T0(6);%initial second
set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));

if str2num(get(handles.nperiods,'string'))>1 & get(handles.checkbox6,'value')
    handles.dur=str2num(get(handles.endp,'string'));
end

nh=floor(handles.dur/3600);
if nh>48
    nh=48;%Limit on the total duration that can be read to avoid memory issues.
end
nm=floor((handles.dur-(nh*3600))/60);
ns=handles.dur-(nh*3600)-(nm*60);
sf=mod(handles.sto+ns,60);
mf=mod((handles.mto+floor((handles.sto+ns)/60)+nm),60);
hf=mod(handles.hto+nh+floor((handles.mto+floor((handles.sto+ns)/60)+nm)/60),24);
nd=floor((handles.hto+nh+floor((handles.mto+floor((handles.sto+ns)/60)+nm)/60))/24);
handles.nh=nh;
ht0_str=num2str(handles.hto);
if length(ht0_str)==1
    ht0_str=strcat('0',ht0_str);
end
mt0_str=num2str(handles.mto);
if length(mt0_str)==1
    mt0_str=strcat('0',mt0_str);
end

st0_str=num2str(handles.sto);
if length(st0_str)==1
    st0_str=strcat('0',st0_str);
end

handles.emgscale=[0 10^5];%Fixed scale for FFT
set(handles.endtime,'string',strcat('Tf:',num2str(hf),':',num2str(mf),':',num2str(round(ns))));
set(handles.toedit,'string',strcat(ht0_str,':',mt0_str,':',st0_str));
set(handles.stdate,'string',strcat('D0:',num2str(handles.EDF.T0(3)),'/',num2str(handles.EDF.T0(2)),'/',num2str(handles.EDF.T0(1))));
set(handles.enddate,'string',strcat('Df:',num2str(handles.EDF.T0(3)+nd),'/',num2str(handles.EDF.T0(2)),'/',num2str(handles.EDF.T0(1))));
handles.d0=0.5;
handles.df=4;
handles.tet0=4;
handles.tetf=8;
%ltrace=round(3600);%1 h
set(handles.endp,'string',num2str(floor(handles.dur)))
set(handles.startp,'string','0')

%[handles.s,edfs]=sdfread(handles.EDF,ltrace,ltrace);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Custom channels
%%%%%%%%%%%%%%%%%%%%%%%
if str2num(get(handles.chauto,'string'))>0
    handles.cht=str2num(get(handles.chauto,'string'));
    handles.chfft=str2num(get(handles.chanfft,'string'));
    handles.chanemg=str2num(get(handles.chemg,'string'));%channel with EMG
else
    handles.cht=2;
    handles.chfft=2;
    handles.chanemg=3;
end
sr=handles.EDF.SampleRate(handles.cht);

%Making the vector with the epoch times and score for the whole register
handles.elauto=2;%fixed in 2 s epochs for autoscoring-first pass
handles.el=str2double(get(handles.edit7,'string'));%Duration of the epoch. The final score is given by the values of the 2s epochs.
handles.nepochsauto=floor(handles.dur/handles.elauto);
handles.nepochs=floor(handles.dur/handles.el);
handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
handles.score=ones(size(handles.epocht));
handles.score(:)=NaN;%Actual score
handles.scorea=ones(1,handles.nepochsauto);
handles.scorea(:)=NaN;%2-s epoch auto score

handles.powbands=[];
handles.distance=6;%distance between traces for multichannel plotting
disp('reading channel')

%Making a large matrix with all the EEG and EMG data (ch num, epoch num, data). Each row has one
%epoch of data points

%reading the first epoch for initialization
[aux,edfs]=sdfread(handles.EDF,handles.elauto,0);
auxfft=getthepower(aux(:,handles.cht),handles.elauto,100,0);
npepoch=floor(handles.elauto*sr);
handles.edfdata=zeros(length(handles.EDF.SampleRate),npepoch,handles.nepochsauto);%N cahnnels, datpepochs, nepochs
handles.fftmat=zeros(handles.nepochsauto,length(auxfft));
%read the whole thing, filter and make epochs and FFTs
[handles.EDF]=sdfclose(handles.EDF);
handles.EDF=sdfopen(get(handles.filename,'string'),'r');
progressbar('Reading EDF file')
for i=0:handles.nepochsauto-1
    [aux,edfs]=sdfread(handles.EDF,handles.elauto,i*handles.elauto);
    handles.edfdata(:,:,i+1)=aux(1:npepoch,:)';%If the number of points changes due to rounding effect, it will left out the extra point
    if mod(i,1000)==0
        progressbar((i+1)/(handles.nepochsauto-1)) % Update figure
    end
end
handles.sr=edfs.SampleRate;
[handles.EDF]=sdfclose(handles.EDF);
eegdata=fixdim(handles.edfdata(handles.cht,:,:));%matrix format
emgdata=fixdim(handles.edfdata(handles.chanemg,:,:));
% if get(handles.rem_negemg,'Value')
%     emgdata(find(emgdata<0))=0;
% end
handles.backupedf=handles.edfdata;
%EMG filter:
%1- remove heart artifact by removing above 1 std in the direction of the
%artifact, since it usually goes either up or down.
%2- calculate the median every 5 points if sr>500 or every 3 points if
%sr<500 to reduce peaks

%identify epoch with lowest EMG:
rmsEMG=rms(emgdata);
[v,ep]=min(rmsEMG);
emgepoch=emgdata(:,ep);

%detection of the heart artifact by autocorrelation
indp=find(emgepoch>0);
indn=find(emgepoch<0);
pemg=emgepoch-0.5*std(emgepoch);
nemg=emgepoch+0.5*std(emgepoch);
pemg(indn)=0;
nemg(indp)=0;
emgxcp=xcorr(pemg,floor(sr),'coeff');
emgxcn=xcorr(nemg,floor(sr),'coeff');
aux=handles.edfdata(handles.chanemg,:,:);
t0=floor(sr*0.1);%100 ms
stdemg=std(emgdata(:));
%Removing the artifacted side after 1 stds
% if max(emgxcp(floor(sr+t0):end))>max(emgxcn(floor(sr+t0):end))
%     indp=find(emgdata-1*stdemg>0);
%     emgdata(indp)=0;
% else
%     indn=find(emgdata+1*stdemg<0);
%     emgdata(indn)=0;
% end

%applying median filter after a high pass
%filtemg=bandpassfilter(emgdata(:),sr,[1 floor(sr/2.5)]);
%filtemg=emgdata(:);
aux = emgdata(:);
handles.medianemg=medfilt1(emgdata(:),7);%Try this as EMG data for autoscore
filtemg=bandpassfilter(handles.medianemg,sr,[1 floor(sr/2.5)]);
handles.medianemg =1000* filtemg.^2;
% figure
% plot(aux(1:100000),'r-')
% hold on
% plot(handles.medianemg(1:100000),'k-')
handles.medianemgmat=reshape(handles.medianemg,size(emgdata));
%handles.indexemg=0.5*(max(abs(handles.medianemgmat))+rms(handles.medianemgmat));
handles.indexemg=rms(handles.medianemgmat);
%handles.indexemg=std(handles.medianemgmat);
shftemg=[handles.indexemg(1) handles.indexemg(1:end-1)];
handles.difemg=handles.indexemg./shftemg;
progressbar(1);

%adding filtered EMG to the signals
handles.edfdata(length(handles.sr)+1,:,:)=handles.medianemgmat;
stg=get(handles.raw_signals,'string');
stg(length(handles.sr)+1,:)='Median EMG      ';%16 characters long
set(handles.raw_signals,'string',stg);

%getting the max-min for every signal
for nsig=1:size(handles.edfdata,1)
    auxs=handles.edfdata(nsig,:,:);
    ss=sort(auxs(:));
    ls=length(ss);
    handles.ylim(nsig,1)=ss(ceil(0.000001*ls));
    handles.ylim(nsig,2)=ss(floor(0.999999*ls));
end
stdeeg=std(eegdata(:));
handles.eegrange=6*stdeeg;
handles.stdeeg=stdeeg;
progressbar('calculating Sleep Parameters');
%Caclulating the fft for each 2s epoch and the power for delta, teta and
%H.gama as the mean between max and average within each band
%N=length(handles.medianemgmat(:,handles.cht));
N=length(eegdata(:,1));
handles.freq =(0:floor(N/2)-1)/(handles.elauto);
lowlim=[0.5 6.5 70];%lower limits for delta, teta andgama
highlim=[5.5 11 100];
aux1=getthepower(eegdata(:,1),handles.elauto,100,0);
handles.fftmat=zeros(handles.nepochsauto,length(aux1));
%Index for autocorelation in the teta range:
%period corresponding to 6-9 Hz -> [0.111 - 0.167] s
t0=floor(sr*0.11);%Limits to look for autocorrelation in teta range
tf=ceil(sr*0.166);
handles.autot=zeros(1,handles.nepochsauto);
handles.acemg=handles.autot;
%getting the FFT and the autocorrelation of EMG to detect sleep and EEG in
%the teta range to detect REM.

for i=1:handles.nepochsauto
    if round(i/300)==i/300
        progressbar(i/handles.nepochsauto)
    end
    handles.fftmat(i,:)=getthepower(eegdata(:,i),handles.elauto,100,0);
    xcv=xcorr(handles.edfdata(handles.cht,:,i),tf,'coeff');
    handles.autot(i)=max(xcv(t0+tf:end));%xcorr foes from -tf to tf. This should help to identify REM
    emgxc=xcorr(handles.edfdata(handles.chanemg,:,i),floor(sr),'coeff');%looking for 1 sec autocorrelation of EMG
    handles.acemg(i)=max(emgxc(floor(sr+t0):end));
end
progressbar(0.5)
handles.autot(find(handles.autot<0))=0;%Autocorrelation in the teta range for EEG
handles.acemg(find(handles.acemg<0))=0;%Maxc Autocorrelatioon of the EMG. Good to detect sleep.
for i = 1:length(lowlim)%1=delta, 2=theta, 3=high gamma
    [v,pmin]=min(abs(handles.freq-lowlim(i)));
    [v,pmax]=min(abs(handles.freq-highlim(i)));
    %     if i>1
    handles.meanbands(i,:)=mean(handles.fftmat(:,pmin:pmax)');
    handles.maxbands(i,:)=max(handles.fftmat(:,pmin:pmax)');
end
progressbar(0.6)
handles.powbands=0.5*(handles.meanbands+handles.maxbands);
%Geenrating sleep parameters for each epoch
%We will use delta EEG, gamma EEG, Delta/Teta+delta and RMS EEG,
%autocorrelation for EEG and EMG and max-median EMG
%The states are: W, NR, R, WA, U. WA means non physiological
%artifact, not mixed state
handles.ndelta=pseudonorm(handles.powbands(1,:));
handles.ndelta=handles.ndelta-min(handles.ndelta);
handles.nteta=pseudonorm(handles.maxbands(2,:));
handles.nteta=handles.nteta-min(handles.nteta);
handles.ngama=pseudonorm(handles.powbands(2,:));
handles.ngama=handles.ngama-min(handles.ngama);
handles.nemg=pseudonorm(handles.indexemg);%(handles.emgpe);
%handles.nemg=handles.nemg-min(handles.nemg);
handles.rem=pseudonorm(handles.nteta./(handles.ndelta+handles.nteta));%index for REM detection
handles.rem=handles.rem-min(handles.rem);
handles.nautot=pseudonorm(handles.autot)-min(pseudonorm(handles.autot));
handles.nacemg=pseudonorm(handles.acemg)-min(pseudonorm(handles.acemg));
aux=rms(eegdata);
handles.nrms=pseudonorm(aux)-min(pseudonorm(aux));
handles.ndifemg=handles.difemg;
%handles.ndifemg=(handles.difemg)-min(pseudonorm(handles.difemg));
%Eliminating hi freq unscorable epocs where the peak after 20 Hz is larger that the peak before 20 Hz:
flim=20;
N = floor(handles.elauto*sr); %% number of points
T = handles.elauto; %% define time of interval
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
[v,posmaxf]=min(abs(freq-flim));
maxlf=max(handles.fftmat(:,1:posmaxf)');
maxhf=max(handles.fftmat(:,posmaxf:end)');
indu=find(0.25*maxhf>=maxlf);%This will detect HF noise
handles.nemg(indu)=-1;
handles.ndelta(indu)=-1;
handles.nteta(indu)=-1;
handles.ngama(indu)=-1;
handles.rem(indu)=-1;
handles.nautot(indu)=-1;
handles.nacemg(indu)=-1;
handles.nrms(indu)=-1;
handles.ndifemg(indu)=-1;
progressbar(1);

handles.ascore=handles.score;
handles.bW=zeros(size(handles.ascore));
handles.bWA=handles.bW;
handles.bNR=handles.bW;
handles.bR=handles.bW;


handles.validatedsc=zeros(size(handles.score));
handles.ltrace=str2double(get(handles.lengthtrace,'string'));
handles.neptpl=floor(handles.ltrace/handles.el);
if handles.neptpl<1
    set(handles.lengthtrace,'string',num2str(handles.el))
    handles.ltrace=handles.el;
    handles.neptpl=1;
end
set(handles.text6,'string',strcat('SR: ',num2str(sr)));
dat2plot=handles.edfdata(:,:,1:round(handles.ltrace/handles.el));
handles.s=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*round(handles.ltrace/handles.el)))';
num=str2double(get(handles.limemg2,'string'));
if ~isfield(handles,'chemg')
    handles.limemg=[0 num*std(handles.s(:,2))];
else
    handles.limemg=[0 num*std(handles.s(:,handles.chanemg))];
end
handles.x=handles.ltrace*(0:length(handles.s(:,handles.selchan))-1)/(length(handles.s(:,handles.selchan))-1);
handles.xi=1/handles.sr(handles.selchan);
handles.t0=0;%Initial time to plot in s
handles.ce=1;%current epoch
handles.tf=handles.t0+handles.ltrace;%final time to plot in s
handles.maxf=12;%maxfrec for plotting when scoringplot_traces(handles);
handles.step=round(handles.el*sr);%number of points of each epoch
plot_traces(handles)
set(handles.text8,'BackgroundColor',[0 1 0])
set(handles.text8,'string','Ready')
handles.NOWscoring=1;%Flag for scoring mode
manualscore=nan(size(handles.scorea));%Initializing Manual score in 2s epochs

figure%ploting distribution
var={'handles.nemg','handles.ndelta','handles.nteta','handles.ngama','handles.rem','handles.nautot','handles.nacemg','handles.nrms'};
for i=1:8
    p=char(var{i});
    eval(strcat('pr=',p,';'));
    subplot(4,2,i)
    hist(pr,200);
    title(p(9:end),'fontsize',16)
end
guidata(hObject, handles);


function isc=getsc(handles)
set(handles.text8,'string','Score Epoch')
sc=char(inputdlg('Enter score sleected epoch (NR, R, W, NA, RA, WA, U)'))
switch sc
    case 'W'
        isc=0;
    case 'WA'
        isc=0.1;
    case 'NR'
        isc=1;
    case 'NA'
        isc=1.1;
    case 'R'
        isc=2;
    case 'RA'
        isc=2.1;
    case 'U'
        isc=-1;
end

function plot_traces(handles)
% handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
% handles.tf=handles.t0+handles.ltrace;
set(handles.text8,'backgroundcolor','g')
set(handles.text8,'string','Ready')
set(handles.edit6,'string',num2str(handles.ce))
%disp(handles.ce*handles.el)
%disp(handles.epocht(handles.ce))
axes(handles.axes1)
cla
xlabel('s','fontsize',14)
%set(handles.slider1,'max',tl);
%getting the max in the slider
nchtp=length(handles.selchan);%number of channels to plot
for i=1:nchtp
    selchan=handles.selchan(i);
    handles.x=handles.ltrace*(0:length(handles.s(:,selchan))-1)/(length(handles.s(:,selchan))-1);
    handles.x=handles.x+handles.t0;
    %     if selchan==1 & handles.cht==2
    %         handles.s(:,selchan)=handles.s(:,selchan)*0.4*1E-4;
    %     end
    %     if selchan==2 & size(handles.s,2)>2 & ~get(handles.rem_negemg,'value')
    %         plot(handles.x,(handles.distance*(i-1)*std(handles.s(:,handles.selchan(1))))+(handles.s(:,1)-handles.s(:,3)),'k-')
    %     else
    plot(handles.x,handles.distance*(i-1)*2*handles.stdeeg+handles.s(:,selchan),'k-')
    %plot(handles.x,(handles.distance*(i-1)*0.002)+handles.s(:,selchan),'k-')
    hold on
    axis tight
    minmax=get(gca,'ylim');
    %     end
    %plot(handles.x,handles.s(round(handles.xi*handles.sr(selchan)):round((handles.xi*handles.sr(selchan))+length(handles.x)-1),get(handles.raw_signals,'value')))
    
    
end



% if  handles.stdeeg<2*diff(minmax)
set(gca,'ylim',[-6*handles.stdeeg handles.distance*2*(nchtp-1)*handles.stdeeg+6*handles.stdeeg])
% end
%adding anotehr plot of the difference
% if nchtp==2
%     i=i+1;
%     plot(handles.x,(handles.distance*(i-1)*1*std(handles.s(:,handles.selchan(1))))+handles.s(:,2)-handles.s(:,1),'k-')
%     axis tight
%set(gca,'ylim',(sum(handles.ylim(handles.selchan,1)))
% end
% if nchtp==1
%     axis tight
%     set(gca,'ylim',handles.ylim(handles.selchan,:))
% end

xi=handles.x(1);
xf=handles.x(end);
minmax=get(gca,'ylim');
xminmax=get(gca,'xlim');
p=find(handles.epocht>=xi);%(xi/handles.sr(selchan)));
firstep=p(1);
p=find(handles.epocht<=xf);%;(xf/handles.sr(selchan)));
lastep=p(end);
hold on
plot([handles.epocht(firstep:lastep)' handles.epocht(firstep:lastep)'],minmax,'g--')
%writing the scoring
posytxt=minmax(1)+0.95*(minmax(2)-minmax(1));
posxtxt=0.05*handles.el;
flagauto=1;
% flagauto=0;
%     if min(isnan(handles.score(2:end)))
%         flagauto=1;%if there are no scored epochs, display the autoscore
%     end
for i=firstep:lastep
    %  text(handles.epocht(i)+posxtxt,posytxt,strcat('EMG:',num2str(handles.emgpe(i)),scr2txt(handles.score(i))),'fontsize',14,'color','r');
    if handles.validatedsc(i)==1
        %text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt,strcat(scr2txt(handles.score(i)),':',num2str(handles.acemg(i))),'fontsize',9,'color','r');
        text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt,scr2txt(handles.score(i)),'fontsize',15,'color','r');
    else
        %text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt,strcat(scr2txt(handles.score(i)),':',num2str(handles.acemg(i))),'fontsize',9,'color','g');
        text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt,scr2txt(handles.score(i)),'fontsize',15,'color','g');
        if flagauto & handles.el==2
            text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt,scr2txt(handles.scorea(i)),'fontsize',15,'color','m');
        end
    end
    %     text(min(xminmax(2),handles.epocht(i)+posxtxt+0.5),posytxt-0.003,strcat('W:',num2str(handles.bW(i))),'fontsize',9,'color','r');
    %     text(min(xminmax(2),handles.epocht(i)+posxtxt+0.5),posytxt-0.0045,strcat('WA:',num2str(handles.bWA(i))),'fontsize',9,'color','r');
    %     text(min(xminmax(2),handles.epocht(i)+posxtxt+0.5),posytxt-0.006,strcat('NR:',num2str(handles.bNR(i))),'fontsize',9,'color','r');
    %     text(min(xminmax(2),handles.epocht(i)+posxtxt+0.5),posytxt-0.0075,strcat('R:',num2str(handles.bR(i))),'fontsize',9,'color','r');
    %text(min(xminmax(2),handles.epocht(i)+posxtxt+0.5),posytxt-0.009,strcat('difemg:',num2str(handles.difemg(i))),'fontsize',9,'color','r');
    
    %The variable sare 'handles.nemg','handles.ndelta','handles.ngama','handles.rem','handles.nautot','handles.nacemg'
    
    %     if get(handles.smart_score,'value')
    %         text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt-0.00003,scr2txt(handles.autoscore(i)),'fontsize',10,'color','k');
    %         text(min(xminmax(2),handles.epocht(i)+posxtxt),posytxt-0.0001,num2str([handles.certW(i); handles.certNR(i); handles.certREM(i)],'%.3f'),'fontsize',10,'color','k');
    %     end
end
%Finally marking h=the active epoch
if handles.ce<handles.nepochs
    xv=[handles.epocht(handles.ce) handles.epocht(handles.ce+1)];
    einf=[minmax(1) minmax(1)];
    emax=[minmax(2) minmax(2)];
    X=[xv,fliplr(xv)];                %create continuous x value array for plotting
    %Y=[einf,fliplr(emax)];              %create y values for out and then back
    Y=[einf,einf/1.5];     
    %plot filled area
    %hl=fill(X,Y,[0.92 0.92 0.95],'EdgeColor','none');
    hl=fill(X,Y,[0.8 0.8 0.8],'EdgeColor','none');
    uistack(hl,'bottom')
    %Now plot MT
    %if get(handles.mt,'value')
    axes(handles.axes5)
    cla
    emgtp=handles.s(:,handles.chanemg);
    %emgtp=bandpassfilter(handles.s(:,1),handles.sr(1),[90 140]);USe  this
    %if there is no EMG
    indp=find(emgtp>0);
    indn=find(emgtp<0);
%     if get(handles.rev_hf,'value')
%         emgtp(indn)=0;
%     else
%         emgtp(indp)=0;
%     end
    if get(handles.rem_negemg,'Value')
        emgtp(indn)=0;
    end
    plot(handles.x,(emgtp.^2),'b-')
    %plot(handles.x,emgtp,'b-')
    axis tight
    if get(handles.fixEMG,'value')
        set(gca,'ylim',handles.limemg)
    end
    %set(gca,'ylim',[mean(handles.s(:,handles.chanemg))-handles.limemg mean(handles.s(:,handles.chanemg))+handles.limemg])
    %     set(gca,'ylim',[0 mean(handles.s(:,handles.chanemg).^2)+handles.limemg])
    axis off
    if str2double(get(handles.lengthtrace,'string'))<=120
        plot_FFT(handles);
    else
        axes(handles.axes2)
        cla
        axis off
        axes(handles.axes4)
        cla
        axis off
    end
    % end
    
    %Now plotting the the current position
    %figure
    zt0=time2h(get(handles.edit4,'string'));%The time for lights on
    aux1=get(handles.toedit,'string');
    h0=time2h(aux1(1:8));%the time of the first recorded data point
    % newt0=mod(h0-zt0,24);
    newt0=h0-zt0;
    % if h0<zt0
    %     newt0=-newt0;
    % end
    % figure
    % plot([newt0+(handles.epocht(handles.ce)/3600) newt0+(handles.epocht(handles.ce)/3600)],[0 2],'r.-')
    % set(gca,'Xtick',0:floor(handles.dur/3600))
    % box off
    % hold on
    % plot(newt0+(handles.epocht/3600),handles.score,'k-')
    % xlabl=str2num(get(gca,'Xticklabel'));
    % axis tight
    %
    % % set(gca,'Xticklabel',num2str(mod(xlabl,24)))
    % %now plotting the stimulus (sync signal)
    % if isfield(handles,'stimoff')
    %     plot([(newt0+handles.stimoff)' (newt0+handles.stimoff)'],[0 2]','c--')
    % end
    % if isfield(handles,'stimon')
    %     plot([(newt0+handles.stimon)' (newt0+handles.stimon)'],[0 2]','m--')
    % end
    
    if min(isnan(handles.score))
        handles.score(1)=0.1; %This is for display purposes only, so the cursor shows up when its all NAN
    end
    axes(handles.axes3)
    cla
    axis on
    if isfield(handles,'blueon')
        plot([newt0+handles.blueon' newt0+handles.blueon'],[0 2],'b.-')
    end
    plot([newt0+(handles.epocht(handles.ce)/3600) newt0+(handles.epocht(handles.ce)/3600)],[0 2],'r.-')
    if isfield(handles,'yellowon')
        plot([newt0+handles.yellowon' newt0+handles.yellowon'],[0 2],'y.-')
    end
    %set(gca,'Xtick',0:floor(handles.dur/3600))
    box off
    hold on
    plot(newt0+(handles.epocht(1:length(handles.score))/3600),handles.score,'k-')
    if flagauto & handles.el==2
      plot(newt0+(handles.epocht(1:length(handles.scorea))/3600),handles.scorea,'b-')
    end
%     xlabl=str2num(char(get(gca,'Xticklabel')));
    axis tight
    
    % set(gca,'Xticklabel',num2str(mod(xlabl,24)))
    %now plotting the stimulus (sync signal)
    if isfield(handles,'stimoff')
        plot([(newt0+handles.stimoff)' (newt0+handles.stimoff)'],[0 2]','c--')
    end
    if isfield(handles,'stimon')
        plot([(newt0+handles.stimon)' (newt0+handles.stimon)'],[0 2]','m--')
    end
    set(gca,'TickLength',[0 0])
end

function plot_FFT(handles)
%plotting the FFT and the bar plots with delta and teta
if (handles.nepochs-12)>handles.ce
axes(handles.axes2)
%handles.maxf=100;
cla
axis on
pvec=[];
N = floor(handles.el*handles.sr(handles.chfft)); %% number of points
T = handles.el; %% define time of interval
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
[v,posmaxf]=min(abs(freq-handles.maxf));
df=freq(2)-freq(1);
%make a single vector with the concatenated fft from 0 to maxf
aux=handles.fftmat(max(1+floor(handles.t0/handles.el)):ceil(handles.tf/handles.el),1:round(posmaxf-1))';
% xaux1=ones(size(aux));
% d=diag(freq(1:posmaxf));
% newm=d*xaux1;
pvec=aux(:);
xpvec=0:df:df*(length(pvec)-1);
% for i=0:floor(handles.ltrace/handles.el)-1
%     aux=getthepower(handles.s(floor(1+(i*(handles.el*handles.sr(handles.cht)))):floor((1+i)*(handles.el*handles.sr(handles.cht))),handles.cht),handles.el,handles.maxf-df,0)';
%     pvec=[pvec aux];
%     if i==0
%         xpvec=freq(1:length(aux));
%     else
%         xpvec=[xpvec 2*xpvec(end)-xpvec(end-1)+freq(1:length(aux))];
%     end
% end
plot(xpvec,pvec)

axis tight;
if get(handles.fixFFT,'value')
    set(gca,'ylim',handles.emgscale)
end
df=xpvec(2)-xpvec(1);%df * X = handles.maxf
[v,p]=min(abs(xpvec-handles.maxf));%Position of the max frequency to us ein the plot
minmax=get(gca,'ylim');%handles.emgscale;
hold on
plot([xpvec(1:p-1:length(xpvec))' xpvec(1:p-1:length(xpvec))'],minmax,'g--','linewidth',2)
set(gca,'XTick',0:2:length(pvec));
set(gca,'XTickLabel',num2str((0:2:handles.maxf-0.1)'))
grid off
end
%Now the bar plots with the ratios of frequncies: delta=delta power/total
%power of the epoch. Teta=teta power/delta power (both for the epoch)
% axes(handles.axes4)
% [v,xi]=min(abs(handles.x-handles.ti));
% [v,xf]=min(abs(handles.x-handles.tf));
% cla
% for kk=0:handles.neptpl-1
%     trace=handles.s((xi*kk)+1:(xi*kk)+handles.step,handles.chfft);
%     tracet=handles.s((xi*kk)+1:(xi*kk)+handles.step,handles.cht);
%     delta(kk+1)=getpband(trace,handles.el,handles.d0,handles.df)/getpband(trace,handles.el,handles.d0,handles.tetf);
%     teta(kk+1)=getpband(tracet,handles.el,handles.tet0,handles.tetf)/getpband(trace,handles.el,handles.d0,handles.df);
% end
% %bar([(delta-min(delta))',(teta-min(teta))'])
%
% %x=1:length(delta);
% bar([delta',teta'])
%
% set(gca,'xticklabel','')
%axis tight
%axis off
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, ~, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in rescore.
function rescore_Callback(hObject, eventdata, handles)
% hObject    handle to rescore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ss=30;


%To do:
%Low delta wake requires low AC EMG
%Reduce REM threshold after REM epoch
%If heart artifact in EMG is high, increase W threshold. Compare value of median vs
%mean to detect high level of heart artifact
%Save rescored scoring for future comparisons.
%Adjusting hte threshold of the classes
% figure;hist(handles.bNR,100)
% figure;hist(handles.bR,100)
% figure;hist(handles.bW,100)
% figure;hist(handles.bWA,100)
% figure;hist(handles.bWA)

pw=handles.bW;
pwa=handles.bWA;
pnr=handles.bNR;
pr=handles.bR;


indnr=find(handles.score==1);
indw=find(handles.score==0);
indwa=find(handles.score==1.1);
indr=find(handles.score==2);

if min ([length(indnr)  length(indr)   length(indw)  ])>1

     figure;subplot(3,1,1)
 plot(pnr,pw,'y.')
 xlabel('NR')
ylabel('W')
box off
hold on
p1=plot(pnr(indnr),pw(indnr),'m.')
p2=plot(pnr(indw),pw(indw),'g.')
legend([p1 p2],{'NR','W'})

subplot(3,1,2)
 plot(pr,pw,'y.')
 xlabel('R')
ylabel('W')
box off
hold on
p1=plot(pr(indr),pw(indr),'m.')
p2=plot(pr(indw),pw(indw),'g.')
legend([p1 p2],{'R','W'})

subplot(3,1,3)
 plot(pr,pnr,'y.')
 xlabel('R')
ylabel('NR')
box off
hold on
p1=plot(pr(indr),pnr(indr),'m.')
p2=plot(pr(indnr),pnr(indnr),'g.')
legend([p1 p2],{'R','NR'})





indexmp=find(~isnan(handles.score));

figure;plot(indexmp,handles.score(indexmp),'o')
hold on

indwrong=find(handles.score(indexmp)~=handles.scorea(indexmp));
indwrong0=indwrong;
matb=[handles.bW;handles.bWA;handles.bNR;handles.bR];
vecaux=[0 0.1 1 2];
mu=0.000003;
nmax=2000;
it=0;
plot(indexmp,handles.scorea(indexmp),'k.')
title('Before training')
%while length(indwrong)>1 || it<1000

lerr=zeros(1,nmax);
while it<nmax
    it=it+1;
    for q=1:length(indwrong)
        [v,pc]=min(abs(vecaux-handles.score(indexmp(indwrong(q)))));%position of the correct score
        if handles.threspar(pc)>0.1
            handles.threspar(pc)=handles.threspar(pc)-mu;%Make that state more likely
        end
        
        [v,pi]=min(abs(vecaux-handles.scorea(indexmp(indwrong(q)))));%position of the incorrect score
        if handles.threspar(pi)<0.8
            handles.threspar(pi)=handles.threspar(pi)+mu;%Make that state less likely
        end
    end

    %rescoring...
    handles.bW=sigjh(1,ss,handles.threspar(1),handles.pvals(1,:));
    handles.bWA=sigjh(1,ss,handles.threspar(2),handles.pvals(2,:));
    handles.bNR=sigjh(1,ss,handles.threspar(3),handles.pvals(3,:));
    handles.bR=sigjh(1,ss,handles.threspar(4),handles.pvals(4,:));
    matv=ones(4,handles.nepochsauto);
    matv(1,:)=0;
    matv(2,:)=0.1;
    matv(3,:)=1;
    matv(4,:)=2;
    [v,p]=max([handles.bW;handles.bWA;handles.bNR;handles.bR]);
    for ne=1:handles.nepochsauto
        handles.scorea(ne)=matv(p(ne),ne);
    end
    indwrong=find(handles.score(indexmp)~=handles.scorea(indexmp));
    lerr(it)=length(indwrong);
    if round(it/200)==it/200
        disp(it)
    end
end

    figure;plot(indexmp,handles.score(indexmp),'o')
hold on
    plot(indexmp,handles.scorea(indexmp),'k.')
    title('After training')
figure;plot(lerr)
else
    handles.bW=sigjh(1,ss,handles.threspar(1),handles.pvals(1,:));
    handles.bWA=sigjh(1,ss,handles.threspar(2),handles.pvals(2,:));
    handles.bNR=sigjh(1,ss,handles.threspar(3),handles.pvals(3,:));
    handles.bR=sigjh(1,ss,handles.threspar(4),handles.pvals(4,:));
    matv=ones(4,handles.nepochsauto);
    matv(1,:)=0;
    matv(2,:)=0.1;
    matv(3,:)=1;
    matv(4,:)=2;
    [v,p]=max([handles.bW;handles.bWA;handles.bNR;handles.bR]);
    for ne=1:handles.nepochsauto
        handles.scorea(ne)=matv(p(ne),ne);
    end
end

matdb=[handles.bW;handles.bWA;handles.bNR;handles.bR];
%deleting doubtful scores
    mincrit=0.2;
    
[v,p]=max(matdb);
auxmatf=matdb;
for i=1:length(p)
    auxmatf(p(i),i)=0;
end
[v2,p2]=max(auxmatf);
for ne=1:handles.nepochsauto
    %if (v(ne)/v2(ne)>1.5 || max(p(ne),p2(ne))<3) & v(ne)>mincrit %If the max is too low, skip it, otherwise must be 40% larger than the second best, or the prefered and second best must be either W or WA
        handles.scorea(ne)=matv(p(ne),ne);%only when the prefered state is 30% larger than the second best or the two best are W and WA
    %else
    %    handles.scorea(ne)=nan;
    %end
end
%handles.scorea(find(U))=-1;
threspar=handles.threspar;


indtrans=find(abs(diff(handles.scorea))>0);%index of the transitions
for i=1:length(indtrans)
    [aux,indp]=sort(matdb(:,indtrans(i)+1));%Degrees of belonging for the epoch with the transition
    dif=aux(4)-aux(3);%difference between the selected class and the second best
    if handles.scorea(indtrans(i))==matv(indp(3),1) & dif<0.05
        handles.scorea(indtrans(i)+1)=handles.scorea(indtrans(i));
    end
    %Special case for REM: If there is atransition to REM, degree of
    %membership must be >0.2, else assign the second best class
    if handles.scorea(indtrans(i)+1)==2 & aux(4)<0.2 %too weak membership to state a REM transition
        handles.scorea(indtrans(i)+1)=matv(indp(3),1);%Transition to second best
    end
end
%Addig context criteria
%1- orphan REM before and after W must be W if dB REM<0.5
shiftscore=[handles.scorea(2:end) 0];
shiftrem=[handles.bR(2:end) 0];

shiftscore2=[handles.scorea(3:end) 0 0];
indor=find(handles.scorea<0.5 & shiftscore==2 & shiftscore2~=2 & shiftrem<0.3);%index with orphan REM following W
handles.scorea(indor+1)=0;
indor=find(handles.scorea~=2 & shiftscore==2 & shiftscore2<0.5 & shiftrem<0.3);%index with orphan REM followed by W
handles.scorea(indor+1)=0;

%2- 2 s R epoch flanqued by 2 NR epochs must be NR
shiftscore=[handles.scorea(2:end) 0];
shiftscore2=[handles.scorea(3:end) 0 0];
indor=find(handles.scorea==1 & shiftscore==2 & shiftscore2==1 & shiftrem<0.3);
handles.scorea(indor+1)=1;

%3- Orphan NR flanked by R should be R
shiftscore=[handles.scorea(2:end) 0];
shiftscore2=[handles.scorea(3:end) 0 0];
indor=find(handles.scorea==2 & shiftscore==1 & shiftscore2==2);
handles.scorea(indor+1)=2;

% %Again...
% %1- orphan REM before and after W must be W
% shiftscore=[handles.scorea(2:end) 0];
% shiftscore2=[handles.scorea(3:end) 0 0];
% indor=find(handles.scorea<0.5 & shiftscore==2 & shiftscore2~=2);%index with orphan REM following W
% handles.scorea(indor+1)=0;
% indor=find(handles.scorea~=2 & shiftscore==2 & shiftscore2<0.5);%index with orphan REM followed by W
% handles.scorea(indor+1)=0;
%
% %2- 2 s R epoch flanqued by 2 NR epochs must be NR
% shiftscore=[handles.scorea(2:end) 0];
% shiftscore2=[handles.scorea(3:end) 0 0];
% indor=find(handles.scorea==1 & shiftscore==2 & shiftscore2==1);
% handles.scorea(indor+1)=1;
%
% %3- Orphan NR flanked by R should be R
% shiftscore=[handles.scorea(2:end) 0];
% shiftscore2=[handles.scorea(3:end) 0 0];
% indor=find(handles.scorea==2 & shiftscore==1 & shiftscore2==2);
% handles.scorea(indor+1)=2;
%

%Adjusting thresholds according to examples


%saving thresholds in an appendable structure
k=1;
if exist('thdatabase.mat')
    load('thdatabase.mat')
    while(~strcmp(thdata(k).name,handles.fn))
        if max(size(thdata))<(k+1)
            thdata(k+1).name=handles.fn
        end
        k=k+1;
    end
    thdata(k).name=handles.fn;
    thdata(k).vals=[handles.thresEMG_W handles.thresDLT_WA handles.thresDLT_NR handles.thresACEMG_SLP handles.thresACEEG_R...
    handles.thresRIND_R handles.thresG_W handles.thresEMGdiff_W];
    thdata(k).mscore=handles.manualscore2;
    thdata(k).thresstate=threspar;
    
    save('thdatabase.mat','thdata')
else
    thdata(k).name=handles.fn;
    thdata(k).vals=[handles.thresEMG_W handles.thresDLT_WA handles.thresDLT_NR handles.thresACEMG_SLP handles.thresACEEG_R...
        handles.thresRIND_R handles.thresG_W handles.thresEMGdiff_W];%handles.thresG_W
    thdata(k).mscore=handles.manualscore2;
    thdata(k).thresstate=threspar;
    save('thdatabase.mat','thdata')
end
%Now the final score in 4s epochs...
progressbar('Making 4s score')
set(handles.edit7,'string',4)
handles.el=str2num(get(handles.edit7,'string'))
handles.score=score4s(handles.scorea);%Converts the 2 s score into 4 s score
handles.nepochs=floor(handles.dur/handles.el);
handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
[nch,np,neps]=size(handles.edfdata);
aux=handles.edfdata(:,:,1:2*floor(neps/2));
handles.edfdata=reshape(aux,[nch,np*2,floor(neps/2)]);
eegdata=fixdim(handles.edfdata(handles.cht,:,:));%matrix format
handles.fftmat=[];
for i=1:handles.nepochs
    if round(i/300)==i/300
        progressbar(i/handles.nepochs)
    end
    handles.fftmat(i,:)=getthepower(eegdata(:,i),handles.el,100,0);
end

plot_traces(handles);
disp(strcat('% autoscored:',num2str(100*length(find(~isnan(handles.scorea)))/length(handles.scorea))))
progressbar(1);

%Addig context criteria in 4s epochs
%1- orphan REM before and after W must be W
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
indor=find(round(shiftscore)==2 & round(handles.score)==0 & round(shiftscore2)==0);%index with orphan REM following W
handles.score(indor+1)=0.1;

%2-R epoch flanqued by 2 NR epochs must be NR
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
indor=find(round(shiftscore)==2 & round(handles.score)==1 & round(shiftscore2)==1);%index with orphan REM between NR
handles.score(indor+1)=1.1;

%3- Orphan NR flanked by R should be R
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
indor=find(round(shiftscore)==1 & round(handles.score)==2 & round(shiftscore2)==2);%index with orphan REM between NR
handles.score(indor+1)=2.1;

%4- Orphan NR: R-NR-W -> NR should be WA (or is it RA?) 
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
indor=find(round(shiftscore)==1 & round(handles.score)==2 & round(shiftscore2)==0);%index with orphan REM between NR
handles.score(indor+1)=0.1;

%5- Orphan R: W-R-NR -> should be NRA 
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
indor=find(round(shiftscore)==2 & round(handles.score)==0 & round(shiftscore2)==1);
handles.score(indor+1)=1.1;

%6- W epoch flanqued by 2 R epochs must be R
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
indor=find(round(shiftscore)==0 & round(handles.score)==2 & round(shiftscore2)==2);
handles.score(indor+1)=2.1;


%6- 2 NR epochs in between R should be R
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
shiftscore3=[handles.score(4:end) 0 0 0];
indor=find(round(shiftscore)==1 & round(handles.score)==2 & round(shiftscore2)==1 & round(shiftscore3)==2);
handles.score(indor+1)=2.1;
handles.score(indor+2)=2.1;

%6- 2 R epochs in between NR should be NR
shiftscore=[handles.score(2:end) 0];
shiftscore2=[handles.score(3:end) 0 0];
shiftscore3=[handles.score(4:end) 0 0 0];
indor=find(round(shiftscore)==2 & round(handles.score)==1 & round(shiftscore2)==2 & round(shiftscore3)==1);
handles.score(indor+1)=1.1;
handles.score(indor+2)=1.1;


handles.autoscore=handles.score;


guidata(hObject, handles);



% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.rescore,'BackgroundColor',[0 1 0])
set(handles.stop,'BackgroundColor',[0.5 0 0])
handles.NOWscoring=0;
guidata(hObject, handles);

% --- Executes on selection change in raw_signals.
function raw_signals_Callback(hObject, eventdata, handles)
% hObject    handle to raw_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns raw_signals contents as cell array
%        contents{get(hObject,'Value')} returns selected item from raw_signals
handles.selchan=get(hObject,'Value');
guidata(hObject, handles);
plot_traces(handles);

% --- Executes during object creation, after setting all properties.
function raw_signals_CreateFcn(hObject, eventdata, handles)
% hObject    handle to raw_signals (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmen

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function lengthtrace_Callback(hObject, eventdata, handles)
% hObject    handle to lengthtrace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of lengthtrace as text
%        str2double(get(hObject,'String')) returns contents of lengthtrace as a double
if isfield (handles,'el')
    if str2double(get(handles.lengthtrace,'string'))<handles.el
        set(handles.lengthtrace,'string',num2str(handles.el))
    end
    handles.ltrace=min(240,str2double(get(handles.lengthtrace,'string')));
    handles.tf=handles.t0+handles.ltrace;
    
    
    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(handles.ltrace/handles.el)))';
    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
    
    %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
    robot = java.awt.Robot;
    pos = get(handles.axes1, 'Position');
    set(0, 'PointerLocation', [pos(1:2)+100]);
    robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
    robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);
    
    guidata(hObject, handles);
    plot_traces(handles)
end
% --- Executes during object creation, after setting all properties.
function lengthtrace_CreateFcn(hObject, eventdata, handles)
% hObject    handle to lengthtrace (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in stats.
function stats_Callback(hObject, eventdata, handles)
% hObject    handle to stats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%getting the Nepochs by state
np=str2num(get(handles.nperiods,'string'));
if np>1
    for i=1:np
        prompt{2*i-1}=strcat('Start P',num2str(i))
        prompt{2*i}=strcat('End P',num2str(i))
    end
    name='Enter start and end times';
    numlines=1;2*np;
    defaultanswer={'0','3600','18000','21600','39600','43200'};
    answer=str2num(char(inputdlg(prompt,name,numlines,defaultanswer)));
    startsec=answer(1:2:end);
    endsec=answer(2:2:end);
    indwa=[];
    indnr=[];
    indr=[];
    indawa=[];
    indanr=[];
    indar=[];
    for i=1:np %building the indexes of the epochs across all periods
        [v,startep(i)]=min(abs(handles.epocht-startsec(i)));
        [v,endep(i)]=min(abs(handles.epocht-endsec(i)));
        indawa=[indawa startep(i)-1+find(handles.score(startep(i):endep(i))>=0 & handles.score(startep(i):endep(i))<1)];
        indanr=[indanr startep(i)-1+find(handles.score(startep(i):endep(i))>=1 & handles.score(startep(i):endep(i))<2)];
        indar=[indar startep(i)-1+find(handles.score(startep(i):endep(i))>=2)];
        indwa=[indwa startep(i)-1+find(handles.score(startep(i):endep(i))==0)];
        indnr=[indnr startep(i)-1+find(handles.score(startep(i):endep(i))==1)];
        indr=[indr startep(i)-1+find(handles.score(startep(i):endep(i))==2)];
    end
else
    startsec=str2double(get(handles.startp,'string'));
    endsec=str2double(get(handles.endp,'string'));
    [v,startep]=min(abs(handles.epocht-startsec));
    [v,endep]=min(abs(handles.epocht-endsec));
    
    %indexes with artifacts
    indawa=startep-1+find(handles.score(startep:endep)>=0 & handles.score(startep:endep)<1);
    indanr=startep-1+find(handles.score(startep:endep)>=1 & handles.score(startep:endep)<2);
    indar=startep-1+find(handles.score(startep:endep)>=2);
    
    %indexes without artifacts
    indwa=startep-1+find(handles.score(startep:endep)==0);
    indnr=startep-1+find(handles.score(startep:endep)==1);
    indr=startep-1+find(handles.score(startep:endep)==2);
    
end
%Calculating stats: Percentage in each state, distribution of bout lenghts,
%power spect by state and Heatmap.3876-7416
if length(indawa)<2
    boutwa=0;
else
    %boutwa=getbout(indawa)*handles.el;
    boutwa=getboutok(round(handles.score(startep:endep)),0);
    boutwalong=boutwa(find(boutwa>1));
end
if length(indanr)<2 %This is not the right way to fix this
    boutnr=0;
    boutnrlong=0;
else
    %boutnr=getbout(indanr)*handles.el;
    boutnr=getboutok(round(handles.score(startep:endep)),1);
    boutnrlong=boutnr(find(boutnr>1));
end
if length(indar)<2
    boutr=0;
    boutrlong=0;
else
    %boutr=getbout(indar)*handles.el;
    boutr=getboutok(round(handles.score(startep:endep)),2);
    if length(find(boutr>1))>0
        boutrlong=boutr(find(boutr>1));
    else
        boutrlong=0;
    end
    
end

figure
subplot (8,3,[4 7 10]+12)
neps=length(indwa)+ length(indnr)+ length(indr);
bar(100*[length(indwa)/neps length(indnr)/neps length(indr)/neps]);
set(gca,'fontsize',14)
set(gca,'xticklabel',{'WA','NR','REM'})
title('% Time','fontsize',21)
box off

subplot (8,3,[4 7 10]+13)
bar([mean(boutwalong) mean(boutnrlong) mean(boutrlong)]);
set(gca,'xticklabel',{'WA','NR','REM'})
set(gca,'fontsize',14)
title('Mean Bout Duration (s)','fontsize',21)
box off

%Calculating the average FFT by state from channels 1, 3 and 1-3:
%edit 3 and edit 2 have the start and end of the period under stimulation

%initializing matrices with the power spectrum
maxfrec=20;


nEDF=sdfopen(handles.fn);
[eegtrace,edfs]=sdfread(nEDF,handles.el,1);
%[nEDF]=sdfclose(nEDF);
aux=getthepower(eegtrace(:,handles.selchan(1)),handles.el,maxfrec,0);
N = length(eegtrace); %% number of points
T = handles.el; %% define time of interval, 3.4 seconds
t = [0:N-1]/N; %% define time
t = t*T; %% define time in seconds
freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
freq=freq(1:length(aux));

kWA=0;kNR=0;kREM=0;k=0;
%nEDF=sdfopen(handles.fn);
% if get(handles.do_all,'value')
%     newep0=1;
%     newepf=handles.nepochs-2;
% else
newep0=startep;
newepf=endep;
% end

matpowerWA=zeros(length(indwa),length(aux));
matpowerNR=zeros(length(indnr),length(aux));
matpowerREM=zeros(length(indr),length(aux));

if np==1
    matheatmap=zeros(newepf-newep0+1,length(aux));
end
vecep=[];
for i=1:np
    vecep=[vecep startep(i):endep(i)];
end
for currep=vecep
    ti=handles.epocht(currep);
    eegtrace=handles.edfdata(handles.selchan,:,currep);
    %eegtrace=handles.filteeg(round(ti*handles.sr(1)):round((ti+handles.el)*handles.sr(1))-1);
    %
    %     [nEDF]=sdfclose(nEDF);
    %     nEDF=sdfopen(handles.fn);
    %     [eegtrace,edfs]=sdfread(nEDF,handles.el,handles.epocht(currep));
    %     if handles.selchan==2
    %         aux2=getthepower(1000*(eegtrace(:,1)-eegtrace(:,3)),handles.el,maxfrec,0);
    %     else
    %aux2=getthepower((10^6)*eegtrace,handles.el,maxfrec,0);%In microvolts
    aux2=getthepower(eegtrace,handles.el,maxfrec,0);
    
    %     end
    
    if handles.score(currep)==0
        kWA=kWA+1;
        matpowerWA(kWA,:)=aux2;
    end
    if handles.score(currep)==1
        kNR=kNR+1;
        matpowerNR(kNR,:)=aux2;
    end
    if handles.score(currep)==2
        kREM=kREM+1;
        matpowerREM(kREM,:)=aux2;
    end
    k=k+1;
    matheatmap(k,:)=aux2;
end
subplot (8,3,[4 7 10]+14)
plot(freq,mean(matpowerWA),'k-','linewidth',2);
box off
hold on
plot(freq,mean(matpowerNR),'b-','linewidth',2);
xlabel('Hz','fontsize',21)

plot(freq,mean(matpowerREM),'r-','linewidth',2);
set(gca,'fontsize',14)
xlabel('Frequency (Hz)','fontsize',21)
box off
ylabel('Power (\muV^2)','fontsize',21)
legend('W','NR','REM')

%plotting score
subplot (8,3,1:3)
zt0=get(handles.edit4,'string');
xzt=handles.EDF.T0(4)+(handles.EDF.T0(5)/60)+(handles.EDF.T0(6)/3600)-str2double(zt0(1:2))-(str2double(zt0(4:5))/60)-(str2double(zt0(7:7))/3600)+(handles.epocht(newep0(1))/3600)+(handles.epocht(vecep)/3600);
plot(xzt,round(handles.score(vecep)),'k-','linewidth',1.5);
set(gca,'YTick',[0 1 2])
set(gca,'YTicklabel',{'W','NREM','REM'})
box off
set(gca,'fontsize',14)
xlabel('ZT (Hours)','fontsize',16)
set(gca,'TickLength',[0 0])
axis tight
%plotting EEG & EMG
subplot (8,3,4:6)
aux01=handles.edfdata(handles.selchan,:,:);
eeg=aux01(:);
aux=eeg(max(1,ceil(handles.sr(1)*startsec)):ceil(handles.sr(1)*endsec));
auxemg=handles.edfdata(handles.chanemg,:,:);
auxemg=auxemg(:);
auxemg=auxemg(max(1,ceil(handles.sr(1)*startsec)):ceil(handles.sr(1)*endsec));
xtime=(1:length(auxemg))/(3600*handles.sr(1));
plot(xtime+3,(10^6)*aux/20,'k-')
axis tight
box off
set(gca,'TickLength',[0 0])

subplot (8,3,7:9)
plot(xtime+3,(10^6)*auxemg/20,'k-')
box off
set(gca,'TickLength',[0 0])
axis tight

subplot (8,3,10:12)
plot(xzt(1:ceil(endsec/handles.el)-ceil(startsec/handles.el)+1),handles.ndelta(ceil(startsec/handles.el):ceil(endsec/handles.el)),'k-')
box off
axis tight
set(gca,'ylim',[-0.1 1])
title('d','fontsize',18)

subplot (8,3,13:15)
plot(xzt(1:ceil(endsec/handles.el)-ceil(startsec/handles.el)+1),handles.ngama(ceil(startsec/handles.el):ceil(endsec/handles.el)),'k-')
box off
axis tight
set(gca,'ylim',[-0.1 1])
title('Hg','fontsize',18)
%
% zt0=get(handles.edit4,'string');
% plot(handles.EDF.T0(4)+(handles.EDF.T0(5)/60)+(handles.EDF.T0(6)/3600)-str2double(zt0(1:2))-(str2double(zt0(4:5))/60)-(str2double(zt0(7:7))/3600)+(handles.epocht(newep0(1))/3600)+(handles.epocht(vecep)/3600),round(handles.score(vecep)),'k-','linewidth',1.5);
% set(gca,'YTick',[0 1 2])
% set(gca,'YTicklabel',{'W','NREM','REM'})
% box off
% set(gca,'fontsize',14)
% xlabel('ZT (Hours)','fontsize',16)
% set(gca,'TickLength',[0 0])
% axis tight



%figure
%changing the range of heatmap to [0 64]
% minhm=min(min(matheatmap));
% maxhm=max(max(matheatmap));
% matheatmap=matheatmap-minhm;
% matheatmap=matheatmap/(maxhm-minhm);
% matheatmap=matheatmap*64;
% %shifting heatmap so the plot saturates at 99% of max val
% v=sort(matheatmap(:));
% chosen_val=v(round(0.99*length(v)));
% fact=64/chosen_val;
% matheatmap=fact*matheatmap;
% image(matheatmap');
% axis xy
% colormap('jet')
% minmax=get(gca,'xlim')
% set(gca,'xlim',0.1*round(minmax.*10));
% minmax=get(gca,'xlim');
% set(gca,'XTick',[min(minmax):(minmax(2)-minmax(1))/10:max(minmax)]);
% xlabl=str2num(get(gca,'Xticklabel'));
% %each x point is one epoch
%
% set(gca,'Xticklabel',num2str(0.1*round(10*ep2zt(10*xlabl+handles.epocht(newep0),handles))));
% ylabl=str2num(get(gca,'Yticklabel'))
% set(gca,'Yticklabel',num2str(ylabl/10))
% xlabel('ZT (hours)','fontsize',21)
% ylabel('Hz','fontsize',21)
%
% %adding a stim bar
% if get(handles.do_all,'value')
%     hold on
%     plot(6*[startp/60 endp/60],[5 5],'w-','linewidth',3)
% end
% %title('Heatmap')
% set(gca,'fontsize',14)
% c=colorbar;
% ylablcb=str2num(get(c,'Yticklabel'));
% set(c,'Yticklabel',num2str(0.1*round(10*((ylablcb./64)*(maxhm-minhm)+minhm))));
% set(gca,'fontsize',14)
%saving data
fndata=strcat(handles.fn(1:end-4),'_',num2str(startsec(1)),'_',num2str(endsec(end)),'_',num2str(np),'_periods','_data.mat');
sc=handles.score;
pwa=100*length(indwa)/neps;
pnr=100*length(indnr)/neps;
pr=100*length(indr)/neps;

mboutwa=mean(boutwalong);mboutnr=mean(boutnrlong);mboutr=mean(boutrlong);
save(fndata,'zt0','sc','pwa','pnr','pr','startsec','endsec','matpowerWA','matpowerNR','matpowerREM','freq','mboutwa','mboutnr','mboutr')
helpdlg('Data file saved')
[nEDF]=sdfclose(nEDF);
%Now the power spectra


%ylabel('mV^2')

function newt=ep2zt(time_points,handles)
%Convert a set of time points in sec. to their respective ZT times in hours
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
aux2=h0+(time_points/3600);
newt=mod(aux2-zt0,24);

function newt=seg2zt(time_points,handles)
%Convert a set of time points in sec. to their respective ZT times in hours
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
aux2=h0+(time_points/3600);
newt=mod(aux2-zt0,24);


% --- Executes on button press in rem_negemg.
function rem_negemg_Callback(hObject, eventdata, handles)
% hObject    handle to rem_negemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rem_negemg

if get(hObject,'Value')
    %Removes the side of the EMG with largest value
    
else
    handles.edfdata=handles.backupedf;
end
guidata(hObject, handles);

% --- Executes on button press in rev_hf.
function rev_hf_Callback(hObject, eventdata, handles)
% hObject    handle to rev_hf (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rev_hf
plot_traces(handles);

% --- Executes on button press in smart_score.
function smart_score_Callback(hObject, eventdata, handles)
% hObject    handle to smart_score (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of smart_score


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6


% --- Executes on button press in do_all.
function do_all_Callback(hObject, eventdata, handles)
% hObject    handle to do_all (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of do_all


% --- Executes on button press in mt.
function mt_Callback(hObject, eventdata, handles)
% hObject    handle to mt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of mt


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9


% --- Executes on scroll wheel click while the figure is in focus.
function figure1_WindowScrollWheelFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	VerticalScrollCount: signed integer indicating direction and number of clicks
%	VerticalScrollAmount: number of lines scrolled for each click
% handles    structure with handles and user data (see GUIDATA)
l=str2double(get(handles.lengthtrace,'string'));
if eventdata.VerticalScrollCount==1
    if l>5
        set(handles.lengthtrace,'string',num2str(round(l-5)))
    end
else
    if l<handles.dur
        set(handles.lengthtrace,'string',num2str(min(handles.dur,round(l+5))))
    end
end
guidata(hObject, handles);


function endp_Callback(hObject, eventdata, handles)
% hObject    handle to endp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endp as text
%        str2double(get(hObject,'String')) returns contents of endp as a double


% --- Executes during object creation, after setting all properties.
function endp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to endp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function startp_Callback(hObject, eventdata, handles)
% hObject    handle to startp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of startp as text
%        str2double(get(hObject,'String')) returns contents of startp as a double


% --- Executes during object creation, after setting all properties.
function startp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text

%        str2double(get(hObject,'String')) returns contents of edit6 as a double
handles.ce=str2double(get(hObject,'String'));
robot = java.awt.Robot;
pos = get(handles.axes1, 'Position');
set(0, 'PointerLocation', [pos(1:2)+100]);
robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key release with focus on figure1 or any of its controls.
function figure1_WindowKeyReleaseFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was released, in lower case
%	Character: character interpretation of the key(s) that was released
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) released
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'autoscoring')
if handles.autoscoring>0 %key read for the autoscoring part only
    datacursormode on
    gcf
    switch eventdata.Key
        case 'w'
            handles.score(handles.ce)=0;
            handles.autoscoring=handles.autoscoring+1;
            guidata(hObject, handles);
            uiresume(handles.axes1)
        case 'r'
            handles.score(handles.ce)=2;
            handles.autoscoring=handles.autoscoring+1;
            guidata(hObject, handles);
            uiresume(handles.axes1)
        case 'n'
            handles.score(handles.ce)=1;
            handles.autoscoring=handles.autoscoring+1;
            guidata(hObject, handles);
            uiresume(handles.axes1)
    end
else
    
    
    
    if isfield(handles,'s')
        %iscorev4('figure1_WindowKeyReleaseFcn',hObject,eventdata,guidata(hObject))
        set(handles.text8,'BackgroundColor',[1 0 0])
        set(handles.text8,'string','Reading File')
        %if isfield(handles,'EDF')
        % handles.EDF=sdfclose(handles.EDF);
        % handles.EDF=sdfopen(get(handles.filename,'string'));
        %handles.dur=min(12*3600,EDF.NRec*EDF.Dur);%Can't open more than 12 hours
        %This will display a cross at the cursor and disable the keypress to avoid crashing
        ltrace=str2num(get(handles.lengthtrace,'string'));
        
        datacursormode on
        switch eventdata.Key
            
            case 'rightarrow'
                
                handles.ce=(min(handles.nepochs-1,handles.ce+1));
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el)+round(handles.t0/handles.el))));
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                
                
                
                
                
                %         handles.ce=min(handles.ce+1,handles.nepochs);
                %         %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
                %         handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                %         handles.tf=handles.t0+handles.ltrace;
                %         [handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                %         guidata(hObject, handles);
                %         plot_traces(handles);
            case 'leftarrow'
                
                handles.ce=(max(1,handles.ce-1));
                %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot(handles.chanemg,:,:)=handles.medianemgmat(:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                
            case 'uparrow'
                
                handles.ce=min(handles.ce+floor(handles.ltrace/handles.el),handles.nepochs-1);
                %handles.t0=max(0,min(handles.dur-handles.ltrace, handles.epocht(handles.ce)-handles.ltrace/2));
                handles.t0=min(handles.dur-handles.ltrace, handles.t0+(floor(handles.ltrace/handles.el)*handles.el));
                handles.tf=handles.t0+handles.ltrace;
                %dat2plot=handles.edfdata(:,:,1:min(size(handles.edfdata,3),(ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
           
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                %aux=(reshape(dat2plot,[size(dat2plot,1),size(dat2plot,2)*size(dat2plot,3)]));%ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                
                
            case 'downarrow'
                
                handles.ce=(max(1,handles.ce-floor(handles.ltrace/handles.el)));
                %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                
                %now for the scoring:
                %0:W, 0.1:WA, , 0.05:Systematic WA, 1:NR, 1.1:NRA, 2:R, 2.1:RA, -0.1:C1, -0.2:C2, -0.3:U
                
            case 'numpad7'
                handles.score(handles.ce)=1.1;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
                
            case 'numpad8'
                handles.score(handles.ce)=2.1;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
                
            case 'numpad9'
                handles.score(handles.ce)=0.1;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
            case 'numpad4'
                handles.score(handles.ce)=-0.1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
                
            case 'numpad5'
                handles.score(handles.ce)=2;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
                
            case 'numpad6'
                handles.score(handles.ce)=-0.3;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
            case 'numpad1'
                handles.score(handles.ce)=1;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
            case 'numpad2'
                handles.score(handles.ce)=-0.2;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
            case 'numpad3'
                handles.score(handles.ce)=2;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                
            case 'numpad0'
                handles.score(handles.ce)=0;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                %handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                %dat2plot=handles.edfdata(:,:,(1:min(size(handles.edfdata,3),ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                
                
            case 'decimal'
                handles.score(handles.ce)=0.05;
                handles.validatedsc(handles.ce)=1;
                handles.ce=min(handles.ce+1,handles.nepochs);
                handles.t0=min(handles.dur-handles.ltrace, handles.t0+handles.el);
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                if get(handles.smart_score,'value')
                    handles.ce=handles.ce+min(find(isnan(handles.score(handles.ce:end))))-1;
                    %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                    handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                    handles.tf=handles.t0+handles.ltrace;
                    dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                end
            case 'b'
                handles.validatedsc(1:handles.ce)=1;
                
            case 'p'
                axes(handles.axes4)
                cla
                %minmax=get(gca,'ylim')
                plot([handles.bW(handles.ce-10:handles.ce+9);handles.bWA(handles.ce-10:handles.ce+9);handles.bNR(handles.ce-10:handles.ce+9);handles.bR(handles.ce-10:handles.ce+9)]','d')
                
             case 'r'%goes to the next REM
                 ne=min(find(round(handles.score(handles.ce:end))==2));
                 handles.ce=ne+handles.ce-1;
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                
                case 'w'%goes to the next W
                 ne=min(find(round(handles.score(handles.ce:end))==0));
                 handles.ce=ne+handles.ce-1;
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                 
           case 'q'%goes to the next NREM
                 ne=min(find(round(handles.score(handles.ce:end))==1));
                 handles.ce=ne+handles.ce-1;
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
            case 'v'
                handles.validatedsc(handles.ce)=1;
                handles.ce=(min(handles.nepochs,handles.ce+1));
                %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
                %[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
                
            case 'n'
                if length(find(isnan(handles.score)))>0
                    handles.ce=min(find(isnan(handles.score)));
                else
                    handles.ce=handles.nepochs;
                end
                
                %handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
                handles.t0=min(handles.epocht(end)-handles.ltrace,max(0,handles.epocht(handles.ce)-(handles.ltrace/2)));
                handles.tf=handles.t0+handles.ltrace;
                dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
                aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
                handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
            case 'a'
                if get(handles.smart_score,'value')
                    set(handles.smart_score,'value',0)
                else
                    set(handles.smart_score,'value',1)
                end
                
        end
        guidata(hObject, handles);
        plot_traces(handles);
        
        %disp(handles.ce)
        set(handles.edit6,'string',num2str(handles.ce))
        % axes(handles.axes3)
        % cla
        % plot([(handles.epocht(handles.ce)/3600) (handles.epocht(handles.ce))/3600],[0 2],'r.-')
        % box off
        % hold on
        % plot(handles.epocht/3600,handles.score,'k-')
        % axis tight
        % set(gca,'xcolor','g')
        %
        %pause(0.01);
        axes(handles.axes1)
        %plot_traces(handles)
        set(handles.text8,'BackgroundColor',[0 1 0])
        set(handles.text8,'string','Ready')
        datacursormode off
    end
    guidata(hObject, handles);
end
end

% --- Executes on button press in savescore.
function savescore_Callback(hObject, eventdata, handles)
% hObject    handle to savescore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'.mat');
k=0;
backupfn=fn;
while exist(backupfn)
    k=k+1;
    backupfn=get(handles.filename,'string');
    backupfn=strcat(fn(1:end-4),'_',num2str(k),'.mat');
end
if k>0
    copyfile(fn,backupfn)
end

if isnan(handles.score(end))
    handles.score(end)=handles.score(end-1);
end
startp=str2double(get(handles.startp,'string'));
endp=str2double(get(handles.endp,'string'));
sc=handles.score;
vali=handles.validatedsc;
scalefft=get(handles.limemg2,'string');
zt0=get(handles.edit4,'string');
rangefft=handles.emgscale;
epocl=handles.el;
if isfield(handles,'autoscore')%save original autoscore without manual corrections
    asc=handles.autoscore;
    save(fn,'sc','vali','startp','endp','zt0','scalefft','rangefft','epocl','asc');
else
    save(fn,'sc','vali','startp','endp','zt0','scalefft','rangefft','epocl');
end
helpdlg('Score saved')

% --- Executes on button press in loadscore.
function loadscore_Callback(hObject, eventdata, handles)
% hObject    handle to loadscore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'_BL.mat');
if isnan(handles.score(end))
    handles.score(end)=handles.score(end-1);
end
startp=str2double(get(handles.startp,'string'));
endp=str2double(get(handles.endp,'string'));
sc=handles.score;
vali=handles.validatedsc;
scalefft=get(handles.limemg2,'string');
zt0=get(handles.edit4,'string');
rangefft=handles.emgscale;
epocl=handles.el;
save(fn,'sc','vali','startp','endp','zt0','scalefft','rangefft','epocl');

fn=get(handles.filename,'string');
fn=strcat(fn(1:end-4),'.mat');
dat=load(fn);
if isfield(dat,'scalefft')
    set(handles.limemg2,'string',dat.scalefft);
    set(handles.edit4,'string',dat.zt0);
    handles.emgscale=dat.rangefft;
end
if isfield(dat,'epocl')
    handles.el=dat.epocl;
    if handles.el~=str2num(get(handles.edit7,'string'));
        set(handles.edit7,'string',num2str(dat.epocl));
        handles.nepochs=floor(handles.dur/handles.el);
        handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
    end
end

handles.score(1:length(dat.sc))=dat.sc;
handles.validatedsc(1:length(dat.vali))=dat.vali;
if isfield(dat,'endp')
    set(handles.endp,'string',num2str(dat.endp));
    set(handles.startp,'string',num2str(dat.startp));
end
handles.ce=1;
helpdlg('Score loaded')
if exist('imagingtime.mat') & get(handles.checkbox10,'value') %loading sync signal with onset and ofset of imaging
    imgt=load('imagingtime.mat')
    handles.stimoff=imgt.stopimg;
    handles.stimon=imgt.startimg;
    handles.origimgon=handles.stimon;
    handles.origimgoff=handles.stimoff;
end
guidata(hObject, handles);

% indoksc=find(handles.autoscore==round(handles.score));
% figure
% subplot(2,1,1)
% plot(handles.score,'k.')
% hold on
% plot(handles.autoscore,'r.')
% plot(indoksc,handles.autoscore(indoksc),'g.')
% subplot(2,1,2)
% plot(handles.certW,'g.')
% hold on
% plot(handles.certNR,'b.')
% plot(handles.certREM,'r.')

% p=100*length(find(handles.autoscore==round(handles.score)))/length(handles.autoscore);
% disp('percentage autoscored correctly:');disp(p)
% %finding epochs without artifact:
% indwoa=find(handles.score==round(handles.score));
% pwa=100*length(find(handles.autoscore(indwoa)==handles.score(indwoa)))/length(indwoa);
% disp('percentage autoscored correctly without artifacts:');disp(pwa)
%
%
% plot_traces(handles);


% --- Executes on button press in goto.
function goto_Callback(hObject, eventdata, handles)
% hObject    handle to goto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%TO dO: hide all other plots
zt0=time2h(get(handles.edit4,'string'));%The time for lights on
aux1=get(handles.toedit,'string');
h0=time2h(aux1(1:8));%the time of the first recorded data point
%newt0=mod(h0-zt0,24);
newt0=(h0-zt0);

axes(handles.axes3)
[xpos,nrem]=ginput(1);
xpos=xpos-newt0;
[v,p]=min(abs(handles.epocht-xpos*3600));
handles.ce=p;
handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
handles.tf=handles.t0+handles.ltrace;
dat2plot=handles.edfdata(:,:,(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el));
aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(handles.ltrace/handles.el)))';
handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
%[handles.s,edfs]=sdfread(handles.EDF,handles.ltrace,handles.t0);
guidata(hObject, handles);
plot_traces(handles);


function st=state(timeinp,handles)
%returns the state for a given time in s
sepocht=[handles.epocht(2:end) handles.epocht(end)+handles.el ];
ind=find(timeinp>=handles.epocht & timeinp<sepocht);
st=round(handles.score(ind));

function st=statefl(timeinp,handles)
%returns the state for a given time in s
ind=round(timeinp/handles.el);
st=handles.score(ind);



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
robot = java.awt.Robot;
pos = get(handles.axes1, 'Position');
set(0, 'PointerLocation', [pos(1:2)+100]);
robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in incemg.
function incemg_Callback(hObject, eventdata, handles)
% hObject    handle to incemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.emgscale=handles.emgscale*2;
guidata(hObject, handles);


% --- Executes on button press in decemg.
function decemg_Callback(hObject, eventdata, handles)
% hObject    handle to decemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.emgscale=handles.emgscale/2;
guidata(hObject, handles);



function limemg2_Callback(hObject, eventdata, handles)
% hObject    handle to limemg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of limemg2 as text
%        str2double(get(hObject,'String')) returns contents of limemg2 as a double
num=str2double(get(hObject,'String'));
handles.limemg=num*std(handles.s(:,handles.chanemg));
robot = java.awt.Robot;
pos = get(handles.axes1, 'Position');
set(0, 'PointerLocation', [pos(1:2)+100]);
robot.mousePress(java.awt.event.InputEvent.BUTTON1_MASK);
robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_MASK);
guidata(hObject, handles);
% --- Executes during object creation, after setting all properties.
function limemg2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to limemg2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function toedit_Callback(hObject, eventdata, handles)
% hObject    handle to toedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
h=get(hObject,'String');
handles.hto=str2double(h(1:2));%initial hour
handles.mto=str2double(h(4:5));%initial minute
handles.sto=str2double(h(7:8));%initial second
%set(handles.toedit,'string',strcat(num2strft(handles.hto),':',num2strft(handles.mto),':',num2strft(handles.sto)));
guidata(hObject, handles);
% Hints: get(hObject,'String') returns contents of toedit as text
%        str2double(get(hObject,'String')) returns contents of toedit as a double


% --- Executes during object creation, after setting all properties.
function toedit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to toedit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10



function nperiods_Callback(hObject, eventdata, handles)
% hObject    handle to nperiods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of nperiods as text
%        str2double(get(hObject,'String')) returns contents of nperiods as a double


% --- Executes during object creation, after setting all properties.
function nperiods_CreateFcn(hObject, eventdata, handles)
% hObject    handle to nperiods (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in fixEMG.
function fixEMG_Callback(hObject, eventdata, handles)
% hObject    handle to fixEMG (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of fixEMG
axes(handles.axes5)
axis tight
minmax=get(gca,'ylim');
handles.limemg=minmax;
guidata(hObject, handles);




% --- Executes on key press with focus on figure1 or any of its controls.
function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in autoscore.
function autoscore_Callback(hObject, eventdata, handles)
% hObject    handle to autoscore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%1-ask the user to score epocs spanning the whole range [0 1] to find
%the threshold for each variable using [thres,error_flag]=findthreshold(handles,parameter,index,sttlow,stthi)
%2- Define the relevant concepts of present and absent using sigmoids centered in the threshold
%3-Evaluate the rules by multiplication of sigmoides and score each 2s epoch.
%4-apply rules to establish the final score with longer epochs

%Checking if the thresholds are saved already. If so, load them:
f=1;
handles.manualscore2=nan(1,handles.nepochsauto);
if exist('thdatabase.mat')
    load('thdatabase.mat');
    i=1;
    while i<=size(thdata,2)
        if strcmp(thdata(i).name,handles.fn)
            handles.thresEMG_W=thdata(i).vals(1);
            handles.thresDLT_WA=thdata(i).vals(2);
            handles.thresDLT_NR=thdata(i).vals(3);
            handles.thresACEMG_SLP=thdata(i).vals(4);
            handles.thresACEEG_R=thdata(i).vals(5);
            handles.thresRIND_R=thdata(i).vals(6);
            %  handles.thresG_W=thdata(i).vals(7);
            handles.thresEMGdiff_W=thdata(i).vals(7);
            handles.manualscore2=thdata(i).mscore;
            if isfield (thdata,'thresstate');
                handles.threspar=thdata(i).thresstate;
            end
            f=0;
        end
        i=i+1;
        if f
            disp('File name not found')
        end
    end
end
index=1:handles.nepochsauto;
ss=30;%slope of sigmoid
%The variables are 'handles.nemg','handles.ndelta','handles.ngama','handles.rem','handles.nautot','handles.nacemg'
if handles.thresEMG_W==0
    %EMG for W:
    sttlow=[1 2];%Low values could be NREM or REM
    stthi=[0 0.1];%High values are W
    err=1;
    %disp small and large value
    while err
        [handles.thresEMG_W,err,lo_posslp,Hi_posW]=findthreshold2(handles,handles.nemg,index,'EMG');
    end
end

Pemg=sigjh(1,ss,handles.thresEMG_W,handles.nemg);%Prescence of EMG in every epoch
Aemg=sigjh(1,-ss,handles.thresEMG_W,handles.nemg);%Abscence of EMG in every epoch
PemgWA=sigjh(1,ss,3*handles.thresEMG_W,handles.nemg);%Threshold for prescenc of EMG for WA is fdouble of the one for W
if handles.thresDLT_WA==0
    %Delta for WA:
    indexwa=find(handles.nemg>2*handles.thresEMG_W);%Looking for wake artifact when EMG is twice as the minimum for wake
    err=1;
    while err
        [handles.thresDLT_WA,err,lo_pos,Hi_pos]=findthreshold2(handles,handles.ndelta(indexwa),indexwa,'Delta WA');
    end
end
PdeltaWA=sigjh(1,ss,handles.thresDLT_WA,handles.ndelta);
AdeltaWA=sigjh(1,-ss,handles.thresDLT_WA,handles.ndelta);

% if handles.thresEMGdiff_W==0
%     %ioncrease in EMG as W:
%     sttlow=[1 2];%If no increase, could be anything
%     stthi=0;%High values are transition to W
%     err=1;
%     while err
%         [handles.thresEMGdiff_W,err,lo_pos,Hi_pos]=findthreshold(handles,handles.ndifemg,index,sttlow,stthi,'Transition to W');
%     end
% end
PdifEMG=sigjh(1,ss,handles.thresEMGdiff_W,handles.ndifemg);

if handles.thresDLT_NR==0
    %Delta for NREM:
    sttlow=[0 2];%low values are REM or W
    stthi=1;%High values are NR
    err=1;
    
    while err
        [handles.thresDLT_NR,err,lo_pos,Hi_pos]=findthreshold2(handles,handles.ndelta,index,'Delta NR');
    end
end

PdeltaNR=sigjh(1,ss,handles.thresDLT_NR,handles.ndelta);
AdeltaNR=sigjh(1,-ss,handles.thresDLT_NR,handles.ndelta);

if handles.thresACEMG_SLP==0
    %Autoc EMG for W
    sttlow=[0];%W have low autocorrelation
    stthi=[1 2];%High values are NR or R
    err=1;
    while err
        [handles.thresACEMG_SLP,err,lo_pos,Hi_pos]=findthreshold2(handles,handles.nacemg,index,'AC EMG');
    end
    %handles.thresACEMG_SLP=(handles.nacemg(lo_posslp)+handles.nacemg(Hi_posW))/2;%Using the previous borderline epocs found for EMG
    
end
PacEMG=sigjh(1,ss,handles.thresACEMG_SLP,handles.nacemg);
AacEMG=sigjh(1,-ss,handles.thresACEMG_SLP,handles.nacemg);


if handles.thresRIND_R==0
    %REM EEG-based index for R detection. Using only epochs with  low EMG
    indexw=find(handles.nemg<handles.thresEMG_W);
    sttlow=[1];%W and NR can have low values
    stthi=[0 0.1 2];%High values are R or W or Wa
    err=1;
    while err
        [handles.thresRIND_R,err,lo_posNRW,Hi_posR]=findthreshold2(handles,handles.rem(indexw),indexw,'REM Index');
    end
end
Prem=sigjh(1,ss,handles.thresRIND_R,handles.rem);
Arem=sigjh(1,-ss,handles.thresRIND_R,handles.rem);

if handles.thresACEEG_R==0
    
    
    %Autoc EEG in teta range for R
    %     sttlow=[0 1];%W and NR can have low autocorrelation
    %     stthi=[2];%High values are R
    %     err=1;
    %     while err
    %         [handles.thresACEEG_R,err]=findthreshold(handles,handles.nautot,index,sttlow,stthi,'AC Teta');%Maybe just use the epochs where EMG is low?
    %     end
    handles.thresACEEG_R=(handles.nautot(lo_posNRW)+handles.nautot(Hi_posR))/2;
end
Pacteta=sigjh(1,ss,handles.thresACEEG_R,handles.nautot);
Aacteta=sigjh(1,-ss,handles.thresACEEG_R,handles.nautot);

%Setting the thrshold for teta according to the stats
threst=mean(handles.nteta);
Pteta=sigjh(1,ss,threst,handles.nteta);

if handles.thresG_W==0
    %Gama to separate NREM from W. Excluding REM epochs
    indnorem=find(handles.rem<handles.thresRIND_R & handles.nautot<handles.thresACEEG_R);
    sttlow=[1];%low values are NR but could be R
    stthi=[0];%High values are W but could be R as well
    err=1;
    while err
        [handles.thresG_W,err,lo_pos,Hi_pos]=findthreshold2(handles,handles.ngama,index,'Gama (no REM)');
    end
end
%calculating the htreshold for gama
indw=find(handles.rem<handles.thresRIND_R & handles.nautot<handles.thresACEEG_R & handles.nemg>handles.thresEMG_W);
indw=find(handles.rem<handles.thresRIND_R & handles.nemg>2*handles.thresEMG_W);
%handles.thresG_W=min(handles.ngama(indw));
Pgama=sigjh(1,ss,handles.thresG_W,handles.ngama);
Agama=sigjh(1,-ss,handles.thresG_W,handles.ngama);

handles.scorea=nan(1,handles.nepochsauto);%delteing previous scoring
U=(handles.nemg==-1);
figure;plot(handles.manualscore2,'kd')
%now scoring just with if-then rules. Adding the ~=-1 to keep unscorable
%epocs as such

%Adtional crtieria for NREM: high rec should be smaller than low frec
%     flim=4.5;
%     N = floor(handles.el*handles.sr(handles.chfft)); %% number of points
%     T = handles.el; %% define time of interval
%     freq = [0:floor(N/2)-1]/T; %% find the corresponding frequency in Hz
%     [v,posmaxf]=min(abs(freq-flim));
%     handles.maxlf=max(handles.fftmat(:,1:posmaxf)');
%     handles.maxhf=max(handles.fftmat(:,posmaxf:end)');

%RULEZ normalized in [0 1]:

if get(handles.useac,'value')
    PbW=pseudonorm(max(Pemg,max(max(Pemg.* AdeltaNR .*AacEMG, AacEMG .* PdifEMG .* AdeltaWA), Pgama .* AacEMG)));%Degree of belonging to W for each epoch, normalized
% handles.bWA=pseudonorm(PdeltaWA .* PemgWA .*  .* AacEMG);
% handles.bNR=pseudonorm(PdeltaNR .* Aemg .* Agama .* PacEMG);
    PbWA=pseudonorm(PdeltaWA .* PemgWA .* AacEMG.* Pemg);
%PbNR=max(PdeltaNR .* Aemg .* PacEMG, PdeltaNR .* Aemg .* Agama)
    PbNR=pseudonorm(max(PdeltaNR .* Aemg .* PacEMG, PdeltaNR .* Aemg));
    PbR=pseudonorm(max(Pacteta.* PacEMG,Prem.* PacEMG) .* Pteta .* Aemg .* PacEMG .* AdeltaNR);
else %If there is no clear heart artifact during sleep use this
    PbW=pseudonorm(max(Pemg,max(Pemg.* AdeltaNR,PdifEMG .* AdeltaWA)));%Degree of belonging to W for each epoch, normalized
    PbWA=pseudonorm(PdeltaWA .* PemgWA .* Pemg);
    PbNR=pseudonorm(PdeltaNR .* Aemg);
    PbR=pseudonorm(max(Pacteta,Prem) .* Pteta .* Aemg .* AdeltaNR);
end
indw=find(handles.score==0);
indwa=find(handles.score==0.1);
indnr=find(handles.score==1);
indr=find(handles.score==2);
handles.pvals=[PbW;PbWA;PbNR;PbR];
if max(handles.threspar)==0
    
    %Find thresholds for all clases based on the examples. This will normalize
    %the degree of membership in [0 1] and also make te degree of memebership
    %of all the manual examples >=0.5 for the respective class
    maxother=1;
    if length(indw)>0
        mw=min(PbW(indw));
        indother=[indwa indnr indr];
        maxother=max(handles.bW(indother));
        thresW=min(mw,(mw+maxother)/2);%either the mid point or if the values of the others is actually larger, stay with the minimum
        if thresW<0.001
            thresW=0.9*maxother;
        end
    else
        thresW=0.9*maxother;
    end
    
    if length(indwa)>0
        mwa=min(PbWA(indwa));
        indother=[indw indnr indr];
        maxother=max(PbWA(indother));
        thresWA=min(mwa,(mwa+maxother)/2);
        if thresWA<0.001
            thresW=0.9*maxother;
        end
    else
        thresWA=0.9*maxother;
    end
    
    if length(indnr)>0
        mnr=min(PbNR(indnr));
        indother=[indwa indw indr];
        maxother=max(PbW(indother));
        thresNR=min(mnr,(mnr+maxother)/2);
        if thresNR<0.001
            thresNR=0.9*maxother;
        end
    else
        thresNR=0.9*maxother;
    end
    
    if length(indr)>0
        mr=min(PbR(indr));
        indother=[indwa indnr indw];
        maxother=max(PbR(indother));
        thresR=min(mr,(mr+maxother)/2);
        if thresR<0.001
            thresR=0.9*maxother;
        end
    else
        thresR=0.9*maxother;
    end
    
    %Setting thresholds by hand:
    figure;
    plot(PbR,'.')
    hold on
    plot(indr,PbR(indr),'r.','markersize',16)
    plot(thresR*ones(1,length(PbR)),'g--')
    title('Set Threhold for REM')
    [xpos,aux]=ginput(1);
    if xpos>0 %If click to the left of the axis, uses the default value insted
        thresR=aux;
    end
    cla
    
    plot(PbNR,'.')
    hold on
    plot(indnr,PbNR(indnr),'r.','markersize',16)
    plot(thresNR*ones(1,length(PbNR)),'g--')
    title('Set Threhold for NREM')
    [xpos,aux]=ginput(1);
    if xpos>0
        thresNR=aux;
    end
    
    cla
    
    plot(PbWA,'.')
    hold on
    plot(indwa,PbWA(indwa),'r.','markersize',16)
    plot(thresWA*ones(1,length(PbWA)),'g--')
    
    title('Set Threhold for WA')
    [xpos,aux]=ginput(1);
    if xpos>0
        thresWA=aux;
    end
    
    cla
    plot(PbW,'.')
    hold on
    plot(indw,PbW(indw),'r.','markersize',16)
    plot(thresW*ones(1,length(PbW)),'g--')
    title('Set Threhold for W')
    [xpos,aux]=ginput(1);
    if xpos>0
        thresW=aux;
    end
    
    
    cla
    handles.threspar=[thresW thresWA thresNR thresR];
end
%Finally getting the degree of memebrship from sigmoids to each state
% lw=length(indw);
% lwa=length(indwa);
% lnr=length(indnr);
% lr=length(indr);


% epochs4train=[indw indwa indwa indnr indr indr indr];%epochs manuallly scored
% inputs=[PbW(epochs4train);PbWA(epochs4train);PbNR(epochs4train);PbR(epochs4train)];
% outputs=[sigjh(1,ss,thresW,PbW(epochs4train));sigjh(1,ss,thresWA,PbWA(epochs4train));sigjh(1,ss,thresNR,PbNR(epochs4train));sigjh(1,ss,thresR,PbR(epochs4train))];
% target=[[ones(1,lw) zeros(1,(lwa+lnr+lr))];[zeros(1,lw) ones(1,lwa) zeros(1,(lnr+lr))];[zeros(1,lw+lwa) ones(1,lnr) zeros(1,(lr))];[zeros(1,lw+lwa+lnr) ones(1,lr)]];
%
% erroro=sum(sum((outputs-target).^2));
%
%%%%%%%%%%%%%%%%%%%%
%training sigmoids
%%%%%%%%%%%%%%%%%%%%%
%Geadient descent: t'= -mu* dE/dT
%dE/dT = sum(sum(2(output-target) doutput/dT
%= sum(sum(2E * ss*sig *(1-sig(T))
% mu=0.0000001;
threspar=handles.threspar;%rand(1,4)
% erroro=zeros(1,100)
% for ite=1:100
%     for parmnum=1:4
%         outputs=[sigjh(1,ss,threspar(1),PbW(epochs4train));sigjh(1,ss,threspar(2),PbWA(epochs4train));sigjh(1,ss,threspar(3),PbNR(epochs4train));sigjh(1,ss,threspar(4),PbR(epochs4train))];
%         target=[[ones(1,lw) zeros(1,(lwa+lnr+lr))];[zeros(1,lw) ones(1,lwa) zeros(1,(lnr+lr))];[zeros(1,lw+lwa) ones(1,lnr) zeros(1,(lr))];[zeros(1,lw+lwa+lnr) ones(1,lr)]];
%         erroro(ite)=sum(sum((outputs-target).^2));
%         sumgrad=2*erroro(ite)*sum((outputs(parmnum,:)-target(parmnum,:))*ss.*sigjh(1,ss,threspar(parmnum),inputs(parmnum,:)).*(1-sigjh(1,ss,threspar(parmnum),inputs(parmnum,:))));
%         threspar(parmnum)=threspar(parmnum)+mu*sumgrad;
%     end
% end
% figure;plot(erroro);




%%%%%%%%%%%%%%%%%%%%%%%%
%Instead of doign a vector operation, going epoch by epoch, changing the threshold for each state according to previous state
handles.bW(1)=sigjh(1,ss,threspar(1),PbW(1));
handles.bWA(1)=sigjh(1,ss,threspar(2),PbWA(1));
handles.bNR(1)=sigjh(1,ss,threspar(3),PbNR(1));
handles.bR(1)=sigjh(1,ss,threspar(4),PbR(1));
matdb(1,:)=[handles.bW(1);handles.bWA(1);handles.bNR(1);handles.bR(1)];
[v,p]=max(matdb);
disp('scoring...')
for i=2:length(PbW)
    thresmod=ones(1,4);
    thresmod(p)=2;
    %special case for REM sleep to prevent NREM
    if p==4
        thresmod(3)=0.5;
    end
    handles.bW(i)=sigjh(1,ss,threspar(1)/thresmod(1),PbW(i));
    handles.bWA(i)=sigjh(1,ss,threspar(2)/thresmod(2),PbWA(i));
    handles.bNR(i)=sigjh(1,ss,threspar(3)/thresmod(3),PbNR(i));
    handles.bR(i)=sigjh(1,ss,threspar(4)/thresmod(4),PbR(i));
    matdb(i,:)=[handles.bW(i);handles.bWA(i);handles.bNR(i);handles.bR(i)];
    [v,p]=max(matdb);
end
disp('Ready')
matv=ones(4,handles.nepochsauto);
matv(1,:)=0;
matv(2,:)=0.1;
matv(3,:)=1;
matv(4,:)=2;
matdb=[handles.bW;handles.bWA;handles.bNR;handles.bR];
% figure;plot(matdb(:,1:1000)')
% hold on
% title('Set Threhold for min criteria')
% [xpos,mincrit]=ginput(1);
    mincrit=0.1;
    
[v,p]=max(matdb);
auxmatf=matdb;
for i=1:length(p)
    auxmatf(p(i),i)=0;
end
[v2,p2]=max(auxmatf);
figure;plot(v/v2)

for ne=1:handles.nepochsauto
    %if (v(ne)/v2(ne)>1.1 || max(p(ne),p2(ne))<3) & v(ne)>mincrit %If the max is too low, skip it, otherwise must be 10% larger than the second best, or the prefered and second best must be either W or WA
        handles.scorea(ne)=matv(p(ne),ne);%only when the prefered state is 30% larger than the second best or the two best are W and WA
    %else
    %    handles.scorea(ne)=nan;
    %end
end
handles.scorea(find(U))=-1;
% handles.scorea(find(Pemg & ~U & AdeltaNR & Pgama & AacEMG))=0;%W
% handles.scorea(find(PdeltaNR & Aemg & ~U & Agama & PacEMG))=1;%NREM
% handles.scorea(find( ~U & AacEMG & PdifEMG & AdeltaWA))=0;%W
% handles.scorea(find(Pacteta & ~U & Aemg & PacEMG & AdeltaNR))=2;
% handles.scorea(find(Prem & ~U & Aemg & AdeltaNR & PacEMG))=2;
% handles.scorea(find(PdeltaWA & PemgWA & ~U & Pgama & AacEMG))=0.1;%WA

%state continuity: If the next epoch is scored differently but the 2nd best
%state is the same as the previous state adnthe different between 1st and
%2nd is <0.01 then change it.

% 
% indtrans=find(abs(diff(handles.scorea))>0);%index of the transitions
% for i=1:length(indtrans)
%     [aux,indp]=sort(matdb(:,indtrans(i)+1));%Degrees of belonging for the epoch with the transition
%     dif=aux(4)-aux(3);%difference between the selected class and the second best
%     if handles.scorea(indtrans(i))==matv(indp(3),1) & dif<0.05
%         handles.scorea(indtrans(i)+1)=handles.scorea(indtrans(i));
%     end
%     %Special case for REM: If there is atransition to REM, degree of
%     %membership must be >0.2, else assign the second best class
%     if handles.scorea(indtrans(i)+1)==2 & aux(4)<0.2 %too weak membership to state a REM transition
%         handles.scorea(indtrans(i)+1)=matv(indp(3),1);%Transition to second best
%     end
% end
% %Addig context criteria
% %1- orphan REM before and after W must be W if dB REM<0.5
% shiftscore=[handles.scorea(2:end) 0];
% shiftrem=[handles.bR(2:end) 0];
% 
% shiftscore2=[handles.scorea(3:end) 0 0];
% indor=find(handles.scorea<0.5 & shiftscore==2 & shiftscore2~=2 & shiftrem<0.3);%index with orphan REM following W
% handles.scorea(indor+1)=0;
% indor=find(handles.scorea~=2 & shiftscore==2 & shiftscore2<0.5 & shiftrem<0.3);%index with orphan REM followed by W
% handles.scorea(indor+1)=0;
% 
% %2- 2 s R epoch flanqued by 2 NR epochs must be NR
% shiftscore=[handles.scorea(2:end) 0];
% shiftscore2=[handles.scorea(3:end) 0 0];
% indor=find(handles.scorea==1 & shiftscore==2 & shiftscore2==1 & shiftrem<0.3);
% handles.scorea(indor+1)=1;
% 
% %3- Orphan NR flanked by R should be R
% shiftscore=[handles.scorea(2:end) 0];
% shiftscore2=[handles.scorea(3:end) 0 0];
% indor=find(handles.scorea==2 & shiftscore==1 & shiftscore2==2);
% handles.scorea(indor+1)=2;
% 
% % %Again...
% % %1- orphan REM before and after W must be W
% % shiftscore=[handles.scorea(2:end) 0];
% % shiftscore2=[handles.scorea(3:end) 0 0];
% % indor=find(handles.scorea<0.5 & shiftscore==2 & shiftscore2~=2);%index with orphan REM following W
% % handles.scorea(indor+1)=0;
% % indor=find(handles.scorea~=2 & shiftscore==2 & shiftscore2<0.5);%index with orphan REM followed by W
% % handles.scorea(indor+1)=0;
% %
% % %2- 2 s R epoch flanqued by 2 NR epochs must be NR
% % shiftscore=[handles.scorea(2:end) 0];
% % shiftscore2=[handles.scorea(3:end) 0 0];
% % indor=find(handles.scorea==1 & shiftscore==2 & shiftscore2==1);
% % handles.scorea(indor+1)=1;
% %
% % %3- Orphan NR flanked by R should be R
% % shiftscore=[handles.scorea(2:end) 0];
% % shiftscore2=[handles.scorea(3:end) 0 0];
% % indor=find(handles.scorea==2 & shiftscore==1 & shiftscore2==2);
% % handles.scorea(indor+1)=2;
% %
% 
% %saving thresholds in an appendable structure
% k=1;
% if exist('thdatabase.mat')
%     load('thdatabase.mat')
%     while(~strcmp(thdata(k).name,handles.fn))
%         if max(size(thdata))<(k+1)
%             thdata(k+1).name=handles.fn
%         end
%         k=k+1;
%     end
%     thdata(k).name=handles.fn;
%     thdata(k).vals=[handles.thresEMG_W handles.thresDLT_WA handles.thresDLT_NR handles.thresACEMG_SLP handles.thresACEEG_R...
%         handles.thresRIND_R handles.thresG_W handles.thresEMGdiff_W];
%     thdata(k).mscore=handles.manualscore2;
%     thdata(k).thresstate=threspar;
%     
%     save('thdatabase.mat','thdata')
% else
%     thdata(k).name=handles.fn;
%     thdata(k).vals=[handles.thresEMG_W handles.thresDLT_WA handles.thresDLT_NR handles.thresACEMG_SLP handles.thresACEEG_R...
%         handles.thresRIND_R handles.thresG_W handles.thresEMGdiff_W];%handles.thresG_W
%     thdata(k).mscore=handles.manualscore2;
%     thdata(k).thresstate=threspar;
%     save('thdatabase.mat','thdata')
% end
% %Now the final score in 4s epochs...
% progressbar('Making 4s score')
% set(handles.edit7,'string',4)
% handles.el=str2num(get(handles.edit7,'string'))
% handles.score=score4s(handles.scorea);%Converts the 2 s score into 4 s score
% handles.nepochs=floor(handles.dur/handles.el);
% handles.epocht=0:handles.el:handles.el*(handles.nepochs-1);
% [nch,np,neps]=size(handles.edfdata);
% aux=handles.edfdata(:,:,1:2*floor(neps/2));
% handles.edfdata=reshape(aux,[nch,np*2,floor(neps/2)]);
% eegdata=fixdim(handles.edfdata(handles.cht,:,:));%matrix format
% handles.fftmat=[];
% for i=1:handles.nepochs
%     if round(i/300)==i/300
%         progressbar(i/handles.nepochs)
%     end
%     handles.fftmat(i,:)=getthepower(eegdata(:,i),handles.el,100,0);
% end
% 
% plot_traces(handles);
% disp(strcat('% autoscored:',num2str(100*length(find(~isnan(handles.scorea)))/length(handles.scorea))))
% progressbar(1);
guidata(hObject, handles);

function [thresh,error_flag,lo_pos,Hi_pos]=findthreshold2(handles,parameter,index,namepar)
%Finds the threshold to consider a parameter high or low by asking the user
%index has the position of the parameters in the
%corresponding epoch number. If length paramter == nepochs, index =
%1:nepochs.
%Unscorable epochs must be previously identified by making te parameter -1 for that epoch.
error_flag=0;%Becomes 1 if user press redo.
parameter(find(isnan(parameter)))=0;
%finding the low and hi states
auxscore=nan(size(handles.scorea));
[sorted,p]=sort(parameter);
%ask for scoring of the extremes
ltrace=str2num(get(handles.lengthtrace,'string'));
If=[];
I0=[];
I0(1)=min(find(sorted>0))%I0 and If are the intial and final value in ascendent order of parameter.
If(1)=floor(0.99*length(parameter));
handles.ce=index(p(I0(1)));
k=1;
colorb='rgbwkcmgkr';
collet=colorb(ceil(10*rand));
while parameter(p(I0(k)))+0.04*std(parameter)<parameter(p(If(k)))
    k=k+1;
    nextpossorted=I0(k-1)+floor((If(k-1)-I0(k-1))/2);%Newton method
    %assigning to If or I0 according to the scoring
    handles.ce=index(p(nextpossorted));
    handles.t0=max(0,handles.epocht(handles.ce)-(handles.ltrace/2));
    handles.tf=handles.t0+handles.ltrace;
    dat2plot=handles.edfdata(:,:,min(size(handles.edfdata,3),(1:ceil(handles.ltrace/handles.el))+round(handles.t0/handles.el)));
    aux=(reshape(dat2plot,size(dat2plot,1),size(dat2plot,2)*ceil(ltrace/handles.el)))';
    handles.s=aux(1:min(length(aux),round(handles.ltrace*handles.sr(1))),:);
    plot_traces(handles);
    set(handles.text8,'backgroundcolor',collet);
    disp(['max:' num2str(max(parameter)) ' min:' num2str(min(parameter)) ' median:' num2str(median(parameter)) ' current:' num2str(parameter(p(nextpossorted)))]);
    set(handles.text8,'string',['Low ', 'or ','High ','for ',namepar]);
    axes(handles.axes1)
    xminmax=get(gca,'xlim');
    yminmax=get(gca,'ylim');
    ry=yminmax(2)-yminmax(1);
    text(xminmax(1)+1,yminmax(1)+0.1*ry,'High','fontsize',16,'color','r')
    text(xminmax(1)+1,yminmax(2)-0.1*ry,'Low','fontsize',16,'color','r')
    text(xminmax(2)-3,yminmax(2)-0.1*ry,'Redo','fontsize',16,'color','r')
    text(xminmax(2)-3,yminmax(1)+0.1*ry,'Unscorable','fontsize',16,'color','m')
    answer=ginput(1);
    if answer(2)>mean(yminmax)/2
        if answer(1)<xminmax(1)+3 %press on low
            auxscore(handles.ce)=1;
            disp(1)
        else
            %press on redo
            disp('Redo')
            error_flag=1;
        end
    else
        if answer(1)<xminmax(1)+3 %press on high
            auxscore(handles.ce)=0;
            disp(0)
        else
            %press on skip
            disp('Unscorable in 2s')
            auxscore(handles.ce)=-1;
        end
    end
    
    if error_flag
        thresh=-1;
        lo_pos=index(p(max(I0)));
        Hi_pos=index(p(min(If)));
        break
    else
        if auxscore(handles.ce)<0.5
            If(k)=nextpossorted;%If the value with smaller EMG still scores as W (<0.5), then assign the value as the upper limit and keep the lower limit
            I0(k)=I0(k-1);
        else
            I0(k)=nextpossorted;%%If the value with smaller EMG scores as NR or R (>0.5), then assign the value as the lower limit and keep the upper limit
            If(k)=If(k-1);
        end
        axes(handles.axes4)
        cla
        plot(I0,'b.-','linewidth',2)
        hold on
        plot(If,'r.-','linewidth',2)
        
        disp(strcat('lower lim=',num2str(parameter(p(I0(k)))),' upper limit=',num2str(parameter(p(If(k))))))
    end
    %Now establishing the threshold
    thresh=(parameter(p(min(If)))+parameter(p(max(I0))))/2;
    lo_pos=index(p(max(I0)));
    Hi_pos=index(p(min(If)));
end


disp(thresh)
guidata(gca, handles);

function state=val2state(val)
switch val
    case -1
        state='U';
    case -2
        state='M';
    case 0
        state='W';
    case 0.1
        state='WA';
    case 1
        state='NR';
    case 2
        state='R';
        
end


function sc=waitfork
k=0;
while ~k
    k=waitforbuttonpress;
    if ~strcmp(get(gcf,'currentcharacter'),'w');
        k=0;
        sc=0;
    end
    if ~strcmp(get(gcf,'currentcharacter'),'s');
        k=0;
        sc=1;
    end
end

function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in loadtextsc.
function loadtextsc_Callback(hObject, eventdata, handles)
% hObject    handle to loadtextsc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%1-loads a txt file with the score
%2-convets from string to the epoch number:0-W;0.1-WA;1-NR;1.1-NA;2-R;2.1-RA
%3- identify the epoch corresponding to 12:30:00 (first epoch scored) and
%assign the score
[fname, pathname, filterindex] = uigetfile('*.txt', 'Pick a file with manual score');
cd(pathname)

fid = fopen(fname);
tline = fgetl(fid);
ind=0;
while ischar(tline)
    ind=ind+1;
    if ind>handles.nepochs
        disp('Max epochs reached')
        %return;
    end
    mscore(ind)=NaN;
    if strcmp(tline,'W')
        mscore(ind)=0;
    end
    if strcmp(tline,'WA')
        mscore(ind)=0.1;
    end
    if strcmp(tline,'NR')
        mscore(ind)=1;
    end
    if strcmp(tline,'NA')
        mscore(ind)=1.1;
    end
    if strcmp(tline,'R')
        mscore(ind)=2;
    end
    if strcmp(tline,'RA')
        mscore(ind)=2.1;
    end
    tline = fgetl(fid);
end
fclose(fid);
if length(mscore)<length(handles.score)
    %calculating the number of seconds until 12:30
    h0=handles.EDF.T0(4)
    m0=handles.EDF.T0(5)
    s0=handles.EDF.T0(6)
    sh=3600*(12-h0);
    sm=60*(30-m0);
    %11:40:10 should give 3600-10*60-10
    dt=sh+sm-s0;
    fep=max(1,ceil(dt/handles.el))+1;
    handles.score(fep:fep+ind-1)=mscore;
    handles.validatedsc(fep:fep+ind-1)=1;
else
    handles.score=mscore(1:length(handles.score));
    handles.validatedsc(1:length(handles.score))=1;
    disp('que aselga?')
end
helpdlg(strcat('Score loaded for ',num2str(ind),' epochs'))

handles.score=handles.score(1:handles.nepochs);
guidata(hObject, handles);



plot_traces(handles);



function chauto_Callback(hObject, eventdata, handles)
% hObject    handle to chauto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of chauto as text
%        str2double(get(hObject,'String')) returns contents of chauto as a double


% --- Executes during object creation, after setting all properties.
function chauto_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chauto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function chanfft_Callback(hObject, eventdata, handles)
% hObject    handle to chanfft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of chanfft as text
%        str2double(get(hObject,'String')) returns contents of chanfft as a double


% --- Executes during object creation, after setting all properties.
function chanfft_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chanfft (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function chemg_Callback(hObject, eventdata, handles)
% hObject    handle to chemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of chemg as text
%        str2double(get(hObject,'String')) returns contents of chemg as a double


% --- Executes during object creation, after setting all properties.
function chemg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chemg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in fixFFT.
function fixFFT_Callback(hObject, eventdata, handles)
% hObject    handle to fixFFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes2);
minmax=get(gca,'ylim');
handles.emgscale=minmax;
guidata(hObject, handles);


% --- Executes on button press in useac.
function useac_Callback(hObject, eventdata, handles)
% hObject    handle to useac (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of useac
