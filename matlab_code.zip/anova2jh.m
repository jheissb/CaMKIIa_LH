%runs a 2-way anova unbalanced
%G1=DOX, noDOX
%G2=ALM, VEH

cd 'F:\data2017\HCRT_DREADD\newDOX\'
dox=load('doxpt.mat');
cd 'F:\data2017\HCRT_DREADD\newnoDOX\'
nodox=load('nodoxpt.mat');
%getting the cumt time from 5h of drug effect - cumt time from 5h of VEH-SAL
aux_alm=(dox.alm_cno-dox.veh_sal)*60/100;%in min
aux_veh=(dox.veh_cno-dox.veh_sal)*60/100;
cumdox_alm=sum(aux_alm(:,2:end),2)';
cumdox_veh=sum(aux_veh(:,2:end),2)';

aux_alm2=(nodox.alm_cno-nodox.veh_sal)*60/100;%in min
aux_veh2=(nodox.veh_cno-nodox.veh_sal)*60/100;
cumnodox_alm=sum(aux_alm2(:,2:end),2)';
cumnodox_veh=sum(aux_veh2(:,2:end),2)';

%getting the number of elements in each combination
Ndox_alm=length(cumdox_alm);
Ndox_veh=length(cumdox_veh);
Nnodox_alm=length(cumnodox_alm);
Nnodox_veh=length(cumnodox_veh);
y=[cumdox_alm cumdox_veh cumnodox_alm cumnodox_veh]';
g1=[repmat('SIDOX',Ndox_alm,1);repmat('SIDOX',Ndox_veh,1);repmat('NODOX',Nnodox_alm,1);repmat('NODOX',Nnodox_veh,1)];
g2=[repmat('ALM',Ndox_alm,1);repmat('VEH',Ndox_veh,1);repmat('ALM',Nnodox_alm,1);repmat('VEH',Nnodox_veh,1)];
[pv,tbl,stats,terms]= anovan(y,{g1,g2},'varnames',{'Chow','Drug'},'model','interaction')
[tmc,h,nms]=multcompare(stats,'Display','on','ctype','lsd')
vtp=[mean(cumdox_alm) mean(cumdox_veh) mean(cumnodox_alm) mean(cumnodox_veh)];
err=[sem(cumdox_alm) sem(cumdox_veh) sem(cumnodox_alm) sem(cumnodox_veh)];
figure
box off
errorbar(vtp,err,'k.','linewidth',1);
hold on
bar(vtp)
set(gca,'xlim',[0.5 4.5])
set(gca,'xtick',[1 2 3 4])
minmax=get(gca,'ylim');
% if pv_cum(ztok)<0.05
%     plot(1.5,minmax(2),'k*')
% end
set(gca,'xticklabel',{'ALM-CNO/DOX+','VEH-CNO/DOX+','ALM-CNO/DOX-','VEH-CNO/DOX-'})
set(gca,'ylim',[0 minmax(2)]);
set(gca,'fontsize',14)
box off
ylabel('D Total W time (min)','fontsize',18)

%now plotting separate bar plots
figure
subplot(1,2,1)
box off
errorbar(vtp(1:2),err(1:2),'k.','linewidth',1);
hold on
bar(vtp(1:2))
set(gca,'xlim',[0.5 2.5])
set(gca,'xtick',[1 2])
minmax=get(gca,'ylim');
% if pv_cum(ztok)<0.05
%     plot(1.5,minmax(2),'k*')
% end
set(gca,'xticklabel',{'ALM-CNO','VEH-CNO'})
set(gca,'ylim',[0 minmax(2)]);
set(gca,'fontsize',14)
box off
ylabel('D Total W time (min)','fontsize',18)
[h,p]=ttest2(cumdox_alm,cumdox_veh);
title(['p=' num2str(p)])

subplot(1,2,2)
box off
errorbar(vtp(3:4),err(3:4),'k.','linewidth',1);
hold on
bar(vtp(3:4))
set(gca,'xlim',[0.5 2.5])
set(gca,'xtick',[1 2])
minmax=get(gca,'ylim');
% if pv_cum(ztok)<0.05
%     plot(1.5,minmax(2),'k*')
% end
set(gca,'xticklabel',{'ALM-CNO','VEH-CNO'})
set(gca,'ylim',[0 minmax(2)]);
set(gca,'fontsize',14)
box off
ylabel('D Total W time (min)','fontsize',18)
[h,p]=ttest2(cumnodox_alm,cumnodox_veh);
title(['p=' num2str(p)])


