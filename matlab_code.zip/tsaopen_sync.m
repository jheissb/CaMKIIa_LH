function tsa=tsaopen(filename)
%%Opens a tsa file for reading. Gets the header info in the tsa structure.
%%If channel names have at most one space, the function will replace the
%%space by an underscore. If it has more spaces, it will crash or behave
%%herratically.
%%Jaime Heiss, 5/22/2013
fid = fopen(filename);
%tsa = fread(fid,100);%
C = textscan(fid,'%f',1);%Read first line (number of channels)
%disp(char(C))
tsa.nchannels=C{1};
C = textscan(fid,'%s %s %s %s %s %s %s %s %s %s ',C{1}+1);%Read header (9 fields plus one extra in case there is a space). Channel names cannot have more than 1 space
%Probably there is a simpler way to do this...
%Identifying channel names with spaces: (The spaces can only be in the name
%of the channel making the first part being stored in C{1} and the second
%part in C{2}, thus those lines will have a non empty character in C{10}
for i=1:tsa.nchannels
    if ~isempty(char(C{10}(i)))
        C{1}(i)=strcat(C{1}(i),'_',C{2}(i));%concatenating both parts of the name
        for k=2:9
            C{k}(i)=C{k+1}(i);%Shidfting the rest to the left.
        end
    end
end
%now assigning the values to the tsa structure:
tsa.name='sync';
%tsa.name=C{1}(2:tsa.nchannels+1);
tsa.units=C{1}(2:tsa.nchannels+1);
tsa.samplingrate=str2double(C{2}(2:tsa.nchannels+1));
tsa.npoints=str2double(C{3}(2:tsa.nchannels+1));
tsa.color=str2double(C{4}(2:tsa.nchannels+1));
tsa.height=str2double(C{5}(2:tsa.nchannels+1));
tsa.type=str2double(C{6}(2:tsa.nchannels+1));
tsa.byb_method=str2double(C{7}(2:tsa.nchannels+1));
tsa.byb_chn=str2double(C{8}(2:tsa.nchannels+1));
tsa.fname=filename;
fclose(fid);

 


