function [pvals_singlerep,pval_conds]=repmeasanova(data);
%Find significant differences between conditions on the data matrix of
%conds x subject x repeats using rep. meas 2-way anova to find the
%conditions that are diferent and then 1-way anova for each repeat.
%If a measurement contains NaN, it will be excluded and the pvals_singlerep
%for that measurment wil be NaNs.

nconds=size(data,1);
nsubj=size(data,2);
nreps0=size(data,3);

pval_conds=nan(1,round((nconds-1)*nconds/2));%(N-1)*N/2 couples to compare
ind=sum(sum(isnan(data),1));
indmeas=find(~ind);%these are the measurements where there were no NaNs
%indmeas=indmeas(find(indmeas>4 & indmeas<8));%skipping the first 3 hours for RM anova
newdata=data(:,:,indmeas);
nrepsf=size(newdata,3);
%2-way rep meas anova
xl2=char(num2str((1:nrepsf)'));

%making names
for varnum=1:nrepsf
    varNames{varnum} = strcat('ZT',num2str(varnum));
end

Y=[];
argwithin=[];

for qq=1:nconds
    nameconds{qq}=strcat('cond',num2str(qq));
end
if size(newdata,3)>1
for qq=1:nconds
    Y=[Y;fixdim(newdata(qq,:,:))];
    argwithin = [argwithin;repmat({nameconds{qq}},nsubj,1)];
end

    t = array2table(Y,'VariableNames',{varNames{1:nrepsf}});
    factorName = {'Condition'};
    within=table(argwithin,'VariableNames',factorName);
    t=[within t];
    Meas = table([1:size(Y,2)]','VariableNames',{'ZTs'});
    stringarg=[char(varNames{1}) '-' char(varNames{nrepsf}) '~Condition'];
    rm = fitrm(t,stringarg,'WithinDesign',Meas);
%     auxv=zeros(size(Meas,1),1);
%     auxv(1)=1;
%     auxv(end)=-1;
%     
%     
%     tableAnova=coeftest(rm,eye(length(nameconds)),auxv)
    table_all=multcompare(rm,'Condition');
    comps=zeros(nconds);%matrix with the indices
    %making list with the comparison pairs to exclude repeats
    indtabl=0;
    goodcomps=[];
    for i=1:nconds
        for j=1:nconds
            if i~= j
                indtabl=indtabl+1;%Next item in the table. If it hasn'b be used, it should be stored
                if comps(i,j)==0 && comps(j,i)==0
                    goodcomps=[goodcomps indtabl];%This should give (N-1)*N/2 couples to compare
                end
                comps(i,j)=1;
            end
        end
    end
    short=table_all(goodcomps,5);
    pval_conds=short.pValue;
end
disp(pval_conds)
%identifying timepoints with significant differences between
%conditions
for zth=1:nreps0
    if max(max(isnan(fixdim(data(:,:,zth)))))
        pvals_singlerep(zth,:)=nan(1,length(pval_conds));
    else
        [pv,tbl,stats]= anova1(data(:,:,zth)',nameconds,'off');
        tmc=multcompare(stats,'Display','off','ctype','bonferroni');
        pvals_singlerep(zth,:)=tmc(:,end);
    end
end