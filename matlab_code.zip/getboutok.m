function boutdur = getboutok(index,st);
%boutdur = getboutok(index)
%   index is the array of scores for a given set of epochs 
%   The function generates an array with the duration of each bout (in epochs), determined by a
%   number 1 in dindex where dindex=diff(index) (i.e. the state is present in consecutive epochs).
%   EX: index2= [345 346 347 370 371 372 373 429 437] dindex=[1 1 23 1 1 1
%   56 8], boutdur =[3 4 1] where index2=find(round(index)==st);

index2=find(round(index)==st);
if ~isempty(index2)
    dindex=diff(index2);
    nbout=0;
    pos_index=0;
    while(pos_index<length(dindex))
     pos_index=pos_index+1;
     k=1;
    while(dindex(pos_index)==1 && pos_index<length(dindex))
        pos_index=pos_index+1;
        k=k+1;
    end
     nbout=nbout+1;
     boutdur(nbout)=k;
    end
    %add the last epoch
    if index2(end-1)+1==index2(end)
        boutdur(nbout)=boutdur(nbout)+1;
    end
else
    boutdur=0;
end
