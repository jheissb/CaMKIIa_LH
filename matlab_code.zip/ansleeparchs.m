clear
dir_struct = dir ('*.mat'); 
timp2skip=2;%skip time points before dosing
figure
colormap(jet)
map=colormap;
index=[5 10 20 40 80 160 320 640 1280 2560];
for i=1:length(dir_struct)
    fname=dir_struct(i).name;
    m=load(fname);
    subplot(2,2,1)
    p(i)=plot(m.freq,mean(m.matpowerNR),'linewidth',2','color',map(max(1,6*(i-1)),:));
    title('NREM POWER')
    hold on
    set(gca,'xlim',[0 10])

    subplot(2,2,2)
    plot(m.freq,mean(m.matpowerWA),'linewidth',2','color',map(max(1,6*(i-1)),:));
    title('WA POWER')
    hold on
    ptnr(i)=m.pnr;
    bdurnr(i)=m.mboutnr;
    ind(i)=(1+round(m.startsec/3600)); 
    name{i}=num2str(index(ind(i)));  
end
legend(p,name)
subplot(2,2,1)
set(gca,'xlim',[0 10])
minmax=get(gca,'ylim')
subplot(2,2,2)
set(gca,'xlim',[0 10])
set(gca,'ylim',minmax)

subplot(2,2,3)
plot(index(ind),ptnr,'ko')
title('%Time NR')
subplot(2,2,4)
plot(index(ind),bdurnr,'ko')
title('%Bdur NR')
xlabel('Time stiulus ON (ms)')


