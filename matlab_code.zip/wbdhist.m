function wbdh = wbdhist(scoring,state,epoch_duration,first_ep,last_ep,min_l,max_l,pl)
%% wbdhist(scoring,state,epoc_duration)
%Computes and plots the percentage of time spent in different bout length bins
%for a given state. 
%% Inputs: 
%   scoring:    array of numbers with score of each epoch. Epochs
%   containing artifacts must be equal to the state after rounding, 
%   for example W=0, WA=0.1, NRA = 1.1, NR=1, R=2, RA=2.1
%   state:      state to be quantified (usually 0 (W))
%   epoch_duration: duration in s of each epoch
%   first_ep:   First epoch to include in analysis
%   last_ep:    Last epoch to include in analysis
%   min_l: Length in minutes of the smallest time bin. Smaller bout
%   durations will be discarded
%   max_l: Length in minutes of the largest time bin. Larger bout
%   durations will be added to this bin. 
%   pl: 1 for plotting, 0 if not
%% Outputs:
%   matrix where first row is the lower limit of the bout durations in min
%   and second row are the percentage of the time spent in that interval

nbins = floor(log2(max_l)); %number of bins. The scale is log2 base
%making bins in 2^(0:nbins)
xhist=[0 2.^[0:nbins]];
xhist(1)=min_l;
xhist(end) = max_l;
nbins=length(xhist)
%get bout durations for state
bdwa=getboutok(scoring(first_ep:last_ep),state);%looking for state bouts
%Remove short bouts
minb = ceil(min_l/(epoch_duration/60));
bdwa=bdwa(find(bdwa>minb))*epoch_duration/60;%valid bout durations in minutes
%Gets frequencies of BDs with hyper resolution
[n,x]=hist(bdwa,min(1000,length(scoring)));
total=sum(n.*x);%total time in valid wake
%Now binning according to xhist.
perc=zeros(nbins,1);
for k=1:nbins-1
    indbin=find(x>=xhist(k) & x<xhist(k+1));
    if length(indbin)>0
        perc(k)=100*sum(n(indbin).*x(indbin))/total;
    end
end
%last bin:
k=nbins;
indbin=find(x>=xhist(k));
    if length(indbin)>0
        perc(k)=100*sum(n(indbin).*x(indbin))/total;
    end
xhist
perc
sum(perc)
wbdh=[xhist;perc'];
if pl %plotting
    figure;%Assuming the state is W:
    set(gca,'FontSize',16);
    semilogx(wbdh(1,:),wbdh(2,:),'o-','linewidth',2)
    xlabel('WBD (min)','FontSize',18)
    ylabel('% of W time','FontSize',18)
    hold on
    box off
    
    axis tight
    set(gca,'xtick',xhist)
end